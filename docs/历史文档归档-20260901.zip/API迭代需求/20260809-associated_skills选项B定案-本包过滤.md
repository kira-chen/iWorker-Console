# 提案：associated_skills 跨岗位语义定案为「选项 B·本包过滤」+ §3.5 定义修正(③)

**创建时间**：2026-08-09

**状态**：项目负责人 2026-08-09 授权本次契约变更(业务系统与业务系统技能尚未上线、无存量数据依赖)→ **代码已实施 + 合并终版 §3.5 定义/口径注已同步修订** → 待客户端交叉审 + 通知客户端(§1.6 剩余步骤)

**前置**：本提案是 `docs/architecture/契约§3.5修订提案-业务系统技能随包下发与associated_skills语义.md` §3「遗留决策点」的**定案**。原提案列出选项 A(跨岗位全量)/ B(本包过滤)未决,本次拍板 **选项 B**。

**文件**：
1. docs/api/客户端接口文档-合并终版.md（§3.5 `business_systems.json` 字段定义）
2. backend 实现（已改,见「已实施」）

---

## 一、决策:选项 B(本包过滤)

`associated_skills` 反查(`SkillBizRefRepository.findReferencingSkills`)是**跨岗位**的——只按 `bizSystemId` 反查,会列出内容只在**别的岗位包**里的 FDE 技能句柄,造成「下发了句柄却本包拉不到内容」的悬空。

**定案选项 B**:`associated_skills` 只保留**本包可解析**的句柄。本包可解析集与 `SkillTreePackager.writeSkillTree` 实际写入的 `writtenIds` **严格同源**:
- 岗位技能:`configView.orderedSkills()` 的技能 id(= 打包目录句柄);
- 业务系统专属技能:各已下发(非悬空/非停用)业务系统的 `findDeliverableDedicatedSkills`(origin=BUSINESS_SYSTEM ∧ MANUAL ∧ published)。

跨岗位悬空句柄被过滤。结果:客户端拿到的每个 `associated_skills` 句柄**一定能在本包内解析**,客户端逻辑最简。

**为何选 B 而非 A**:B 兑现了原提案自己立的「凡进 associated_skills 的技能内容必须同包」原则,彻底消除悬空句柄;代价「同一系统在不同岗位包的 associated_skills 不一致」恰是**正确**的——不同岗位包本是不同下发单元,A 岗位客户端本就不该看到只存在于 B 包的技能。选项 A 的「全量一致」是表面整齐,实则制造客户端拿不到内容的句柄。

**为何现在敢直接改**:业务系统与业务系统技能功能尚未上线,`associated_skills` 无真实存量数据、无线上客户端消费,选项 B 的过滤不打任何存量(与向下兼容铁律无冲突),可一步到位、无需 A→B 迁移过渡。

## 二、契约 §3.5 定义须同步修正(两处)

现行 §3.5 第 872 行仍写「**该系统专属 skill 的句柄列表**」——既是旧窄定义(实际含引用该系统的岗位技能),也未提本包过滤。须改为:

> `associated_skills`：与该业务系统关联、**且随本岗位包下发(本包可解析)**的技能句柄列表(含该系统专属技能 + 本包内引用该系统的岗位技能),去重保序;空则省略该键。客户端拿到的每个句柄都保证能在本包技能目录内找到,**不会出现指向本包外的句柄**。

## 三、已实施(backend,本批随代码提交)

- `BusinessSystemsContributor`:新增 `resolveInPackageSkillHandles(ctx, bizCodes)` 算本包可解析集;`associatedSkillHandles` 增 `inPackageHandles` 过滤参数,只保留本包句柄。
- 测试:`BusinessSystemsContributorTest` 更新 `associatedSkills_deliveredFromReverseLookup`(反映本包语义),新增 `associatedSkills_crossPositionHandle_filteredOut`(跨岗位句柄被过滤,核心用例)、`associatedSkills_dedicatedBizSkill_retained`(随包专属技能句柄保留)。已用「临时去掉过滤 → 核心用例转红 → 恢复复绿」自证判别力。
- 全量相关测试绿:`BusinessSystemsContributorTest` 11、`SkillTreePackagerTest` 8、`BusinessSystemsAssemblyEndToEndTest` 3。

## 四、客户端影响

- `associated_skills` 语义收紧:客户端可**移除**对「本包不可解析句柄」的容错分支(选项 A 原本要求的「包内可解析才可调用」现由服务端保证)。
- 同一业务系统在不同岗位包的 `associated_skills` 可能不同(各包各自过滤)——这是预期语义,请客户端知悉:该字段是「本包内该系统关联技能」,非「该系统全局关联技能」。
- 因功能未上线,无存量客户端受影响;本变更为「上线前定型」。

## 五、待办(§1.6 流程)

1. ✅ 项目负责人授权(2026-08-09);
2. ✅ 合并终版 §3.5 第 872 行定义 + 第 876 行口径注已同步修订(选项 B 语义);
3. ✅ 原 `契约§3.5修订提案` §3 决策点状态已更新为「已定案 B」;
4. ✅ 客户端交叉审材料已备齐(可直接转发):`docs/api/客户端变更通知-associated_skills本包过滤与version同源勘误-20260809.md`(合并 ②③ 对客说明 + 回执);合并终版对应条目已标「⏳ 待 §1.6 交叉审确认」;
5. ⏳ **由项目负责人/对接人把上述材料发给客户端团队 → 收回执**（此步为跨团队人际动作，需人工发送，非服务端可自动完成）;
6. ⏳ 客户端确认后，去掉合并终版三处「⏳ 待交叉审」标注转正。
