# MCP stdio env 声明式改造与客户端下发（含配置弹窗改造设计）

- **创建时间：** 2026-08-31 16:19

- **需求是什么：**
  当前 stdio 模式 MCP 的环境变量（env，密钥载体）**不下发客户端**（`ExternalMcpsContributor` / `ConfigYamlBuilder` 白名单明确排除 `envConfig`），与 http 模式鉴权"明文随包下发"（R2·S5/P1 拍板）不对称，造成两个问题：
  1. 需要环境变量密钥的 stdio server（如需 `API_KEY` 的第三方服务），客户端拿到 command/args 也**起不来**；
  2. "每个客户自己的密钥"（如天眼查 apikey）平台本就**不该持有值**，现有"平台配死 KV"模型无法表达"这个变量由客户侧填"。

  本提案把 env 从"平台配死的 KV"升级为**变量声明模型**：每个变量 = {名称、描述、是否客户端填写、平台值}，并经 `external_mcps.json` 下发——平台值明文下发（对齐 http 鉴权口径），客户端填写项只下发声明不下发值（客户端**必填**，收集齐才能启用该 MCP）。

  连带一并审定管理后台 McpEditor 弹窗的配套功能设计（B 节，含两项非契约 UI 调整）。

- **要改哪个 api 相关代码文件：**
  - `backend/src/main/java/com/aiassistant/contract/config/packaging/ExternalMcpsContributor.java` —— 新增 env 段输出（解密平台值明文 / 输出客户端填写声明）
  - `backend/src/main/java/com/aiassistant/tooldef/service/AdminMcpService.java` —— env 落库结构演进与互斥校验（applyEnv 重做）
  - `backend/src/main/java/com/aiassistant/tooldef/dto/McpDefRequest.java` —— `EnvItem` 扩 `description` / `clientFill`
  - `backend/src/main/java/com/aiassistant/tooldef/dto/McpDefDetailVO.java` —— env 回显结构扩字段（脱敏形态）
  - `docs/api/客户端接口文档-合并终版.md` —— §3.4 字段表与示例新增 `env` 段（§1.6 流程同步）
  - （非契约、连带改造）`frontend/src/components/admin/McpEditor.vue`、`frontend/src/utils/mcpEnv.js` 及其单测

- **要怎么修改：**

  ## A 节：契约与下发（契约变更主体）

  ### A.1 `external_mcps.json` 每条 MCP 新增 `env` 数组（additive）

  | 字段 | 类型 | 必填 | 说明 |
  |---|---|---|---|
  | `env` | array | ⬜ | stdio 环境变量清单；该 MCP 无 env 则整段省略。仅 `transport=stdio` 会出现 |
  | `env[].name` | string | ✅ | 变量名（如 `TYC_API_KEY`） |
  | `env[].description` | string | ⬜ | 变量用途说明（FDE 在后台填写，供客户侧运维理解，如"天眼查 API Key，在 xxx 控制台申请"）；空则省略 |
  | `env[].value` | string | ⬜ | **平台值（明文）**——与既有 `auth.headers` 明文下发同口径。仅平台配值的变量携带 |
  | `env[].client_input` | boolean | ⬜ | `true` = **客户端必填项**：值由客户侧收集，本字段与 `value` **互斥**（有 `client_input:true` 必无 `value`，反之亦然）。缺省视为 `false` |

  **客户端行为约定**：某 MCP 的全部 `client_input:true` 变量**收集齐之前，该 MCP 不得启用**（必填语义，无"跳过"分支）；启动子进程时把 `value` 项与客户侧收集项合并注入进程环境。

  **示例（目标形态，stdio 条目）**：

  ```jsonc
  [
    {
      "id": "mc_7xKpQ2mVnRt",
      "server_name": "tianyancha",
      "transport": "stdio",
      "env": [
        { "name": "TYC_API_KEY", "description": "天眼查 API Key，在天眼查开放平台申请", "client_input": true },
        { "name": "TYC_ENDPOINT", "value": "https://api.tianyancha.com" }
      ]
    }
  ]
  ```

  ### A.2 边界不动项

  - `config.yaml` 的 `mcp_servers` 段**维持现状**（仍只有 url/transport/command/args/enabled），继续遵守"config.yaml 不含密钥"的既有边界——env 与鉴权一样收口在 `external_mcps.json`。
  - http 条目不受影响（env 段不出现）；`auth` 段语义不变。
  - 纯新增字段，老客户端忽略未知键即可，**无破坏性**；合并语义随文件既有口径（整体覆盖）。

  ### A.3 后端存储与入参

  - 存储采用**双列分离**（实施时较原「env_config 改数组」方案调整，2026-08-31 实施定稿）：
    - `mcp_def.env_config` **保持扁平 `{"KEY": "<密文>"}` 不动**——只存平台值密文，探测/spawn（StdioTransport）/密钥重加密（CredentialReencryptTask）链路零改动；
    - 新增 `mcp_def.env_meta`（jsonb，Flyway V110）——有序声明数组 `[{key, description, clientFill}]`，只存声明不存值；
    - **存量行零改动**：`env_meta` 为 NULL 时变量清单按 `env_config` 键派生（全平台值、无描述），行为与改造前完全一致（向下兼容铁律）。
  - `McpDefRequest.EnvItem` 扩 `description` / `clientFill`；服务层互斥校验：
    - `clientFill=true` → `value` 必空（带值报 400）；
    - `clientFill=false` → 新建必填值；编辑留空 = 保留旧密文（既有语义不变）。
  - `ExternalMcpsContributor`：平台值解密成明文下发（复用 env 既有 AES-256-GCM 解密，口径对齐 `McpAuthResolver` 明文鉴权头）；`clientFill=true` 项输出 `client_input:true` 且**绝不携带 value**。
  - 详情回显（`McpDefDetailVO`）：平台值仍只回显 masked，新增 description/clientFill 原样回显。

  ## B 节：McpEditor 弹窗功能设计（含非契约 UI 项）

  1. **Command 改纯下拉**：枚举 `npx / uvx / node / python3 / docker`；**存量非枚举值回显时动态追加为下拉选项**（不丢数据、可正常保存）；后端不收紧 command 校验（兼容存量）。
  2. **Arguments 更名 args**：控件维持"一行一项"textarea 不变；**不加引号包裹**（数组直接执行、无 shell，界面引号会诱导 FDE 输入引号导致启动失败）。
  3. **Environment 更名 Env，textarea 改逐行结构化编辑器**：每行四要素——变量名称、变量描述、客户端填写（勾选）、平台值；联动规则：勾选 → 平台值禁填清空，取消勾选 → 平台值必填；平台值保持加密落库、星号回显、留空=保留旧值。
  4. `frontend/src/utils/mcpEnv.js` 的"完整期望集"提交语义按新结构整体重做（漏带 key=删除的语义保留），**单测同步重写**——此处历史上出过"编辑保存清空 env"事故，为高危改造区。

- **影响范围是哪些：**
  - **下发物**：`external_mcps.json` 新增 `env` 段（additive）；`config.yaml` 无变化；岗位包 zip 结构无变化。
  - **客户端行为**：新增"收集 client_input 变量→注入 stdio 子进程环境"链路；未收集齐 = 该 MCP 不可启用（必填语义）。老客户端忽略 env 段，行为同现状（即 stdio 密钥类 server 继续起不来，不劣化）。
  - **管理端**：MCP 弹窗 stdio 三字段全部改造（B 节）；MCP 详情/列表回显 additive 扩字段。
  - **安全口径**：平台 env 值明文进包，与既有 auth.headers 明文口径一致（"本期不考虑安全、共享密钥明文下发"拍板的延伸）；员工私人凭据边界不变（本提案只涉 McpDef 平台级配置，不触 UserBizCredential）。
  - **存量数据**：存量 env_config 扁平 KV 读兼容，不迁移不改行；此前"存量非枚举 command"经下拉动态追加保持可编辑。

---

- **状态：A 节（契约下发）待决策；B 节 + A.3（弹窗与管理端存储）已于 2026-08-31 实施**

  实施说明：B 节弹窗改造与 A.3 管理端存储（V110 迁移、EnvItem 扩字段、互斥校验、声明式回显）已落地并验证
  （后端 2023 例 / 前端 1406 例全绿；Playwright 实走新建/编辑/互斥联动；真库核验密文与声明分离落存）。
  **契约下发链路未动**：ExternalMcpsContributor 仍不输出 env（A.1 契约段待本提案批准后实施），
  管理端已录入的声明在批准前不下发、零对外影响。

- **批准后待办：**
  1. ~~后端 + 前端代码改造（B 节 / A.3）~~（已实施，见上）；
  2. ExternalMcpsContributor 新增 env 段输出（A.1）；
  3. 《客户端接口文档-合并终版.md》§3.4 同步更新（§1.6 提案 → 双方交叉审 → 两份文档同步）；
  4. 通知客户端：新增 env 段消费规则 + client_input 收集交互。
