# MCP 连接器图标下发接成真值 + `biz_name` 取值订正

- **创建时间：** 2026-08-20 17:40
- **性质：** 已实施（产品负责人 2026-08-20 明确授权「直接改，契约文档同步订正」）。本文件作**变更记录 + 客户端通知底稿**，供 §1.6 交叉审对账。

## 需求是什么

产品决策：**MCP 的配置项要增加 icon，由管理后台配置，便于客户端拉取展示。**

查实的现状（决定了这是「接真值」而非「加字段」）：
- `GET /api/market/connectors` 的 `icon` 字段**早已存在于契约中**（§2.11），但服务端返回的是
  `MarketMockFields.icon()` —— **按连接器 id 哈希从 6 个 lucide 图标名里挑一个的 mock 假值**。
- 所以本次是把一个**既有假字段接成真实配置值**，字段本身不新增。

顺带订正一处随实现改动而语义更准的字段：`schema.json` 的 `biz_name`。

## 要改哪个 api 相关代码文件

- `docs/api/客户端接口文档-合并终版.md` §2.11（`icon` 行）、§2.12（`schema.json` 的 `biz_name` 行）——**已订正**；
- `backend/.../openapi/dto/OpenConnectorVO.java` —— 加 `icon` 分量；
- `backend/.../openapi/service/OpenConnectorService.java` —— MCP 传真实 icon，API/BIZ 传 null；
- `backend/.../contract/market/service/MarketQueryService.java` —— 真值优先、mock 兜底；
- `backend/.../tooldef/mcp/McpToolsCacheMerger.java` —— `bizName` 优先取 server 的 `title`。

## 要怎么修改

### 变更点 1：`icon` 语义（§2.11 连接器列表）

**形态与已上线的岗位头像（§2.3 `positions[].avatar`）完全同口径**，刻意复用以便客户端一套渲染逻辑通吃：

- ① **emoji 字符**（后台从内置图标库选，如 `🗺️`）；
- ② **相对路径 URL** `/api/public/icons/<文件名>`（后台上传的图片）。
- 判别：以 `/api/public/icons/` 开头 = 图片路径（拼服务端 base URL 直接 GET，**免 token**）；否则按 emoji 字符渲染。
- **未配置图标的 MCP，以及 API / 业务系统连接器**（本轮无图标配置源）：**仍下发原有 lucide 占位值**（如 `map-pin`）。
  之所以不返 null：老客户端按图标名渲染，突然给 null 会渲染空白，保底给值更稳。
- 服务端对该值**无形态强校验**（与岗位头像同口径），异常取值请按占位图标兜底渲染。

### 变更点 2：`biz_name` 取值（§2.12 `schema.json`）

- **此前**：恒等于 `tool_name`（实测改造前全库 29 个工具 `bizName` 全部 == `name`，是纯冗余重复值，导致该键一直下发技术 ID）。
- **现在**：优先取 MCP Server 声明的官方 `title` 字段（面向人的显示名，如 `get_weather_data` → "获取天气"），server 未声明 title 才回落 `tool_name`。
- **类型（string|null）与可空性均未变，仅取值更准 —— 客户端无需任何改动。**

## 影响范围是哪些

- **对外**：
  - 变更点 1 **需要客户端配合**：icon 值形态由「lucide 图标名」扩展为「emoji / 图片相对路径 / lucide 占位名」三种，客户端须按判别规则分支渲染，并对异常值兜底占位。
  - 变更点 2 **不需要客户端改动**（类型不变、语义更准）。
  - `schema.json` 的 **6 键封闭集未被打破**（未新增键）；`connector.json` 9 键未动；`external_mcps.json` 未动。
- **对内**：`mcp_def` 新增 `icon`/`timeout_ms` 两个可空列（迁移 V97，纯加列、存量全 NULL 即维持原行为）；
  复用既有 `IconService` 上传设施与 `IconPickerPopover` 组件，**不新建资源通道、不引入外链依赖**（故无需 `trustedDomains` 白名单）。
- **安全**：图标仅接受 emoji 或本站相对路径，不接受外链 URL —— 规避 SSRF 与外部资源失效风险。

## 验证

- 端到端实测：后台配置 icon=🧪 → 客户端 `/api/market/connectors` 实收 `"icon":"🧪"`；未配置的连接器仍回落 mock（`search`/`database`），两条路径同时验证。
- 后端全量 1879 通过 / 0 失败；前端全量 1208 通过；`vite build` 通过。
- 实测数据已全部复原为改造前状态。

## 状态

**已实施**（负责人授权直接改 + 文档同步订正）。《合并终版》§2.11 / §2.12 已订正并带【2026-08-20 变更】标注。
**待办：① 通知客户端变更点 1 的渲染分支；② 客户端 §1.6 交叉审确认。**
