# 专家插画 image_url 与 expert.json 下发（D2 提案）

- **创建时间：** 2026-08-10
- **来源：** `docs/改动需求/改动策略/2026-07-29-后端.md` 第 1/4 节 + 决策点 **D2**（该策略定稿为「本仓零改码，D2 待负责人拍板进提案」，近两周未推进，本文件即把 D2 正式转为契约提案）
- **性质：** **触及对外 API 契约**——新增下发物 `expert.json` + 专家列表加性字段 `image_url`。按《接口契约变更铁律》，**动手前须负责人确认**；本文件仅提案，未改任何代码、未改《合并终版》。

---

## 一、需求

专家（平台 `domain_expert`）对客户端下发时，补齐两块目前缺失的内容：

1. **专家列表 `image_url`**：`/api/market/experts`（§2.14）返回项增加插画字段 `image_url`，供客户端展示专家插画/头像。
2. **专家包 `expert.json`**：`/api/market/experts/{expert_id}/download` 产出的专家 zip 根部，新增下发物 `expert.json`（含 `id`/`name`/`role_desc`/`skills`），使客户端拿到专家自描述元数据，而非仅靠技能句柄目录名推断。

两者数据底座在本树**已就绪**：`DomainExpert.avatar`（可存 emoji/路径/图片 URL）、`DomainExpert.roleDesc`（列注释已注明「与契约 `expert.json.role_desc` 对齐，预留后续下发直接透传」）。即产品侧数据早已到位，**只差下发侧接通**。

## 二、涉及文件（现状已核，2026-08-10）

| 文件 | 现状 | 与需求的差距 |
|---|---|---|
| `contract/market/dto/MarketExpertVO.java` | 有 `icon`/`color`，**无 `image_url`** | 缺列表插画字段 |
| `contract/market/service/ExpertMarketQueryService.java` | 组装 `MarketExpertVO` | 缺 `image_url` 取值（从 `avatar`） |
| `contract/market/service/ExpertPackageService.java` | zip 只打技能目录；注释明写「不放 manifest」 | 缺在 zip 根写 `expert.json` |
| `domainexpert/entity/DomainExpert.java` | 已有 `avatar`、`roleDesc` 字段 | **无需改**（取值源已备好） |
| `docs/api/客户端接口文档-合并终版.md` | §2.14 专家列表、§2.7A expert.json | 需补 `image_url` 字段行 + `expert.json` schema（**待确认后与代码同步改**） |

## 三、怎么改（确认后执行，当前不动）

1. **`MarketExpertVO`**：加 `@JsonProperty("image_url") String imageUrl`（加性字段，末位追加，不动既有字段顺序与语义）。
2. **`ExpertMarketQueryService`**：`imageUrl` 取 `DomainExpert.avatar`，**口径与岗位头像下发一致**——绝对 URL 与 `/` 开头站内相对路径原样下发，emoji/空置为 `null`（策略文档第 4 节要求「直接落最终口径，不复刻只放行 http(s) 的旧版再修，省一次回归」；具体复用哪个岗位侧方法在改码时对齐）。
3. **`ExpertPackageService`**：在 zip 根写 `expert.json`，字段：`id`(维持 `de_` 句柄)、`name`、`role_desc`(空写空串)、`skills`(=实际打入包的技能句柄目录名，与现有跳过未发布技能的口径一致，不含被跳过的)。
4. **《合并终版》**：§2.14 加 `image_url` 字段行、§2.7A 补 `expert.json` schema——**属契约文档改动，随本提案一并经确认后同步，并通知客户端。**

## 四、影响范围

- **对外契约**：**是**。①`image_url` 为**加性**字段，老客户端忽略未知字段即向下兼容；②`expert.json` 为**新增**下发物，专家 zip 结构变化（根部多一个文件），客户端需知悉但不破坏既有技能目录解析。
- **数据库**：无（`avatar`/`role_desc` 既有列）。
- **兼容性**：均为加性，符合[[backward-compat-iron-rule]]向下兼容铁律；无删改字段。
- **不在本提案范围**：策略文档 §1.8B 的专家连接器下发文件（`config.yaml`/`external_apis.json`/`external_mcps.json`）另立提案；D1（custom_providers 下发）、D3（nginx）、D4（提案对账）不在此。

## 五、风险与回滚

- **风险**：`expert.json` 的 `skills[]` 口径须与「实际打入包（跳过未发布/非平台技能）」严格一致，否则清单与目录不符——落地时以 `ExpertPackageService` 实际 `packed` 的句柄为准，不取 refs 全量。
- **回滚**：两项均加性，回滚 = 移除字段/下发物即恢复原状，无数据迁移、无破坏性。

---
状态：待负责人确认（提案）
