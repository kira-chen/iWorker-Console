# 移除连接器下载包 schema.json 中 requires_confirmation 历史字段

- **创建时间：** 2026-07-08 11:27
- **需求是什么：** MCP 详情页取消工具级"二次确认"（requiresConfirmation）配置，客户端统一只根据「读/写」（write_class / side_effect）判断执行前是否走确认门。平台侧该字段退役后，连接器市场下载包 `schema.json` 中对外下发的 `requires_confirmation` 键失去独立数据来源，应从契约中移除，避免客户端继续依赖一个已无人维护的历史字段。
- **要改哪个 api 相关代码文件：**
  - `docs/api/客户端接口文档-合并终版.md` §2.12（连接器下载包 schema.json 的 tool 字段表，589 行附近）——删除 `requires_confirmation` 行，tool 六键改五键；
  - `backend/src/main/java/com/aiassistant/openapi/dto/OpenConnectorToolVO.java` ——删除 `requiresConfirmation` 字段；
  - `backend/src/main/java/com/aiassistant/openapi/service/OpenConnectorService.java` ——tools 派生逻辑去掉该字段拷贝；
  - `backend/src/main/java/com/aiassistant/contract/market/service/ConnectorPackageExportService.java` ——导出包组装处同步去键（以实际引用为准）。
- **要怎么修改：** 从 `schema.json` 的每个 tool 对象中删除 `requires_confirmation` 键（六键 → 五键：`tool_name / biz_name / description / input_schema / write_class`），文档同步删行并在变更记录注明"历史字段退役，确认语义统一由 write_class（MCP）/ side_effect（API，岗位包 §3.3）承载"。
- **影响范围是哪些：**
  - 对外：连接器市场"下载"接口（§2.12）返回的 zip 内 `schema.json` 每个 tool 少一个键。契约文档 589 行已标注该字段为"历史字段；语义同岗位包 external_apis.json 的 side_effect，以后者为准"，理论上客户端不应再消费它，但删除仍属契约字段变更，**须走 §1.6 契约变更流程（提案 → 双方交叉审 → 两份文档同步）并通知客户端确认其未依赖后方可实施**。
  - 对内（不在本提案内、可先行）：管理后台 MCP 详情页去掉该字段编辑入口、tools_cache 不再存储、相关 FDE 内部端点（`PUT /api/fde/connectors/mcp/{id}/tools/{toolName}/confirmation`）退役。**过渡期兼容方案：在契约变更获批前，schema.json 继续下发 `requires_confirmation`，取值由 `write_class == 'WRITE'` 派生（与 side_effect 同口径），保证契约层零变化。**
- **状态：** 待决策（待项目负责人确认 + 客户端交叉审）
