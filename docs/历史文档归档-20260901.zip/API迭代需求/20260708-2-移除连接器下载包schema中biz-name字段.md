# 移除连接器下载包 schema.json 中 biz_name 字段

- **创建时间：** 2026-07-08 11:27
- **需求是什么：** MCP 详情页工具清单收敛为「从 MCP server 拉取、只读展示」，取消 FDE 手填的工具业务名（bizName）概念——工具展示名统一用 MCP server 自报的技术名 `name`。平台侧字段退役后，连接器市场下载包 `schema.json` 中对外下发的 `biz_name` 键失去独立数据来源（恒等于 `tool_name`），应从契约中移除。
- **要改哪个 api 相关代码文件：**
  - `docs/api/客户端接口文档-合并终版.md` §2.12（586 行附近 tool 字段表）——删除 `biz_name` 行；
  - `backend/src/main/java/com/aiassistant/openapi/dto/OpenConnectorToolVO.java` ——删除 `bizName` 字段；
  - `backend/src/main/java/com/aiassistant/openapi/service/OpenConnectorService.java` ——tools 派生逻辑去掉该字段拷贝；
  - `backend/src/main/java/com/aiassistant/contract/market/service/ConnectorPackageExportService.java` ——导出包组装处同步去键（以实际引用为准）。
- **要怎么修改：** 从 `schema.json` 的每个 tool 对象中删除 `biz_name` 键，文档同步删行并在变更记录注明"字段退役，工具显示名以 `tool_name` 为准"。与 [20260708-移除连接器下载包schema中requires-confirmation历史字段](20260708-移除连接器下载包schema中requires-confirmation历史字段.md) 同批提交交叉审（同一节、同一下发物，建议合并评审）。
- **影响范围是哪些：**
  - 对外：连接器市场"下载"接口（§2.12）返回 zip 内 `schema.json` 每个 tool 少一个键。契约中 `biz_name` 类型为 `string|null`（可空），客户端若有展示逻辑需改为取 `tool_name`。属契约字段变更，**须走 §1.6 契约变更流程并通知客户端确认后方可实施**。
  - 对内（不在本提案内、可先行）：管理后台 MCP 详情页去掉业务名输入框，`tools_cache` 中 `bizName` 改为恒等于 `name` 的派生兼容值（存量已核查：当前库内无任何自定义 bizName，无数据损失）。**过渡期兼容方案：契约变更获批前，`schema.json` 继续下发 `biz_name`（取值=技术名），契约层零变化。**
- **状态：** 待决策（待项目负责人确认 + 客户端交叉审）
