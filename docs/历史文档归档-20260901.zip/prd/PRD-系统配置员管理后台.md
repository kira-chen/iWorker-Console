# PRD｜系统配置员管理后台（系统配置模块功能总览 · 精简主文档）

> 模块：管理后台 / 系统配置（SYS_CONFIG）　｜　作者：产品经理　｜　日期：2026-06-24　｜　状态：待评审
>
> 性质：**角色视角功能总览 PRD（需求/PRD，不含技术方案）**。本文以「系统配置员（SYS_CONFIG）」视角，整合他在「系统配置」模块下能用到的全部功能、核心规则、状态机、权限与验收，作为团队（架构师/前后端/QA/UI）的统一口径。
>
> **本文为精简主文档**，每个功能域只留：功能概述 / 核心逻辑与业务规则 / 状态机 / 关键验收。**逐动作交互流程、行卡/Toolbar/抽屉字段、失败-空-异常 UI 呈现、术语对照、产品建议细节** 见配套附录《**PRD-系统配置员管理后台-交互细节附录.md**》。两份配套，概念/规则以主文档为准，互相用章节号交叉引用。

---

## 0. 文档信息与关系

### 0.1 文档信息

| 项 | 内容 |
|---|---|
| 文档名 | PRD-系统配置员管理后台.md（精简主文档） |
| 配套附录 | PRD-系统配置员管理后台-交互细节附录.md |
| 作者 / 日期 / 状态 | 产品经理 / 2026-06-24 / 待评审 |
| 适用角色 | 系统配置员（SYS_CONFIG）/ 系统管理员（admin）|
| 适用入口 | `/admin` 下「系统配置」模块：连接器 `/admin/connector`、工具市场 `/admin/market`、平台技能 `/admin/platform-skills`、配置报表 `/admin/reports/sysconfig` |
| 现状基线 | 2026-06-23「数字员工管理后台 · 双模块重构」后的系统配置模块 |

### 0.2 与现有 PRD/设计文档的关系（本文是整合，不重定义）

各功能域的数据结构细节与技术契约以下列专项文档为准，本文只做角色视角整合并引用：

| 引用文档 | 引用内容 |
|---|---|
| `PRD-API连接器页改造.md` | API 字段总表、鉴权（不鉴权/API KEY）、密钥脱敏、真实外呼统计语义 |
| `PRD-平台级技能与发布.md` | 平台技能 CRUD、多目标发布、审核流、状态机、6 项已拍板决策、对外接口 |
| `数字员工管理后台-双模块重构设计.md` | 双模块划分、SYS_CONFIG 角色与账号、AdminRoleGuard 模块映射门、报表指标与数据源 |
| `MCP数据结构扩展与使用统计-设计.md` | MCP 字段展示矩阵、使用统计口径 |
| `问答链路plan模式与工具市场-技术方案.md` | 工具市场 V29 发布/审核范式、状态机、收藏被动响应 |

> 字段级差异以**专项文档**为准；"该角色能做/不能做什么、状态怎么流转"以**本文**为准；交互细节以**附录**为准。

---

## 1. 角色定义与职责边界

### 1.1 系统配置员是谁

**系统配置员（SYS_CONFIG）** 负责的内容包括以下2部分：
1. 整个平台基础连接器数据（MCP/API/业务系统）的建设及维护，核心操作是把 MCP/API/业务系统接进来、做成可被技能引用的工具、经发布审核上架、沉淀平台级技能并发布。平台上的连接器按需发布到「FDE工作台」以及「用户端」进行使用；
2. 面向「用户端」使用的技能管理***（暂不涉及，后续补充）***。

- 种子账号：`sysconfig` / `sysconfig123`（纯系统配置员，仅可进系统配置模块）。
- 种子账号：`admin` / `admin123`（管理员，可执行系统配置模块全部操作，重点是可以审核发布数据）。

### 1.2 职责范围（四大功能域）

系统配置模块在窄轨（AdminRail）下分**两段分组**，四大功能域各归其段：

**基础配置（SYSCONFIG_BASE，随 canSysConfig 显隐）：**

| 功能域 | 入口 | 一句话职责 |
|---|---|---|
| **连接器** | `/admin/connector`（三 Tab：MCP / API / 业务系统）+ 工具检活 | 把 MCP/API/业务系统接入平台，登记定义、测试连通、拉取工具、配二次确认、检活监控 |
| **发布审核** | `/admin/market`（发布管理 / 审核台，路由名 AdminMarket 保留） | 把已接入的 MCP/API 工具发布到 FDE 工作台/用户端，审核通过后生效 |
| **配置报表** | `/admin/reports/sysconfig` | 看系统配置模块实时数据总览 |

**用户端配置（SYSCONFIG_USER）：**
***暂不涉及，后续补充***


### 1.3 职责边界（不属于本角色）

- **不碰 FDE 工作台**：岗位/Agent/岗位技能/岗位数据表归 FDE，系统配置员看不到、进端点 **403 是预期**（角色隔离即目的）。
- **不审自己的产出（两审核台口径一致）**：发布审核与平台技能审核的「通过/驳回」**方法级均仅 ADMIN**（requireAdminUserId）+ **审查人≠作者**（assertReviewerNotAuthor，提交人=审核人报 FORBIDDEN）。系统配置员作为作者，**对两个审核台都：前端看不到入口、点不到、不撞 403**（发布审核台 tab 仅 ADMIN 可见、技能审核台路由仅 ADMIN）。系统配置员只做发布管理类动作，不做审核决策（详见 §4.4、§5.4、§7）。
- **不接触终端用户登录态**：业务系统存连接配置/凭据模板，**不回显、不持有**任何终端用户登录态。
- **不做用户端**：平台技能"发布到用户端"只产生发布态 + 标准化接口，用户端市场页/技能箱/引用/执行由上层应用负责。

---

## 2. 整体工作流（登录后看到什么 → 做什么）

### 2.1 登录与落地

1. `sysconfig` 登录，后端返回角色集合含 `SYS_CONFIG`（不含 FDE/ADMIN）。
2. 前端窄轨（AdminRail）渲染系统配置的**两段分组**：**基础配置**（连接器/发布审核/报表，随 canSysConfig 显隐）+ **用户端配置** ***（暂不涉及，后续补充）***
3. **默认落地页 = 连接器首页（AdminConnector）**。

### 2.2 典型一条龙工作流

```
① 接入外部能力（A 连接器·基础配置）：新建 MCP（stdio / streamable-http）→ 测试连接（握手）→ 拉取工具写 tools_cache → 逐工具配二次确认 → 立即检活
        ▼
② 发布上架（B 发布审核·基础配置）：新建发布选 MCP/API 工具 → 填元数据 → 提交发布(PENDING) → ADMIN 审核 → PUBLISHED
        ▼
③ 沉淀平台技能（C 平台技能·用户端配置）：新建平台技能 → 编辑 skill.md/触发词/引用平台级工具 → 选发布目标 → 提交 → ADMIN 审核 → 生效
        ▼
④ 看实时数据（D 配置报表·基础配置）：6 指标卡 + 3 图表
```

### 2.3 全局展示范式（四域统一，细节见附录 A1/A2）

- 行卡两行式（line1 主标识 / line2 元信息弱色）、conn-toolbar（搜索 300ms 防抖 + 状态筛选 + 异常红点徽标 + 新建）、右侧抽屉编辑器、el-pagination 常显分页器、检活四态 HealthTag、双主题跟随。
- **分页现状**：连接器域后端分页；**发布审核/平台技能两域后端全量返回、前端分页**（QA 勿按后端分页验收）。
- **三个易混动作**（测试连接 / 拉取工具 / 立即检活）触发与响应不同，术语对照见附录 A2。

---

## 3. 功能域 A · 连接器模块

> 入口 `/admin/connector`，三 Tab（MCP/API/业务系统）+ 横切「工具检活」。逐动作流程、行卡/抽屉字段（含 MCP 按 transport 条件字段）、stdio 运行机制与安全配置、失败-空-异常 UI 见 **附录 B1–B6**。

### 3.1 功能概述

把三类外部能力以统一范式登记进平台：**MCP 连接器**（**两种 transport：stdio / streamable-http**，握手/拉工具/逐工具配二次确认）、**API 连接器**（鉴权/单一 url/入参出参/真实外呼+统计）、**业务系统**（登录入口/业务页面配置/凭据加密不回显，无检活）、**工具检活**（四态健康 + 立即检活 + 定时巡检）。三类连接器都带 `origin`（PLATFORM/FDE，默认 PLATFORM）标识归属级别，系统配置员管的是平台级（PLATFORM）。

### 3.2 核心逻辑与业务规则（复核重点）

| 规则 | 内容 |
|---|---|
| **MCP 双 transport** | 支持 `stdio` 与 `streamable-http` 两种传输（AdminMcpService TRANSPORTS）。编辑器**按 transport 条件显隐字段**并切换时互清对方字段：streamable-http 显 Endpoint(URL,必填)+http 鉴权(本轮占位)；stdio 显 Command(必填,仅命令本身)+Arguments(多行,每行一参)+Environment(多行 KEY=VALUE)。字段清单见附录 B1.4 |
| **MCP stdio env 加密 + 脱敏 + 留空保留旧值** | env 全 value **AES-256-GCM 加密**存储（CredentialCryptoService，AAD 域 MCP_ENV_AAD_DOMAIN）；detail 出参只回 `[{key,valueMasked:true}]`，**绝不回明文/密文**；编辑态某 KEY 留空=保留旧密文、重填=加密覆盖、删 KEY=不下发新值且后端不删旧值；KEY 校验 `[A-Za-z_][A-Za-z0-9_]*` 不重复，审计仅记 KEY 名不记 value。运行机制/安全配置见附录 B6 |
| **MCP stdio 安全姿态** | args 逐项直喂 ProcessBuilder **不经 shell**；env 经子进程 environment 注入**绝不进命令行**；命令白名单 `allowed-commands` 默认 `[]` 不限制（受信 SYS_CONFIG + 全审计 + 预留白名单）；继承环境最小白名单 `[PATH,HOME,LANG,TMPDIR]`；max-processes=8 达上限拒新建返 CONN_FAILED；spawn 失败固定脱敏文案「MCP stdio 启动失败」不携 command/cause。完整配置项见附录 B6 |
| **MCP 三动作分离** | 测试连接=仅 initialize 握手不写库（stdio 即用即销不计名额）；拉取工具=initialize→tools/list 真实写 tools_cache；立即检活=同步探测刷 HealthTag（见附录 A2/B1） |
| **code 创建后只读** | MCP code 用户填、API code 系统生成（用户不填、列表隐藏）；均创建后锁死 |
| **二次确认单工具级** | 逐工具设 `requiresConfirmation`，是写操作安全第一道闸；与发布审核回写同一处落地 |
| **重复拉取保护** | 再次拉取按 name 合并：仍返回的工具保留已设 requiresConfirmation/bizName（不冲掉）；新工具用启发式默认；本次未返回的旧工具移除（先清后填） |
| **API 数据结构** | 单一 `url`(base_url+path 合并)、`description`、`requires_confirmation`(写类默认 true)；鉴权 NONE/API_KEY；检活四态(check_status/consecutive_failures/last_check_at/last_check_error/health_check_path)；使用统计(call_count/success_count/sum_success_ms) |
| **API 鉴权 + 密钥脱敏** | 不鉴权/API KEY（参数名+值+位置）；密钥保存后任何视图不回显、显「已配置」、留空不改/重填覆盖 |
| **API 使用统计** | 调用次数=发起即计（成功+失败+超时）；平均执行时间=仅成功加权（≥1000ms 显 s）；无样本显「—」；检活与统计并存 |
| **业务系统特殊性** | `biz_pages` JSONB 多业务页 `[{url,name,description}]` + `operation_meta`(无头浏览器操作元信息,本期加密托管、真实执行排后期)；凭据 AES 加密不回显；**无检活**（不入库、不计入健康分布） |
| **检活四态 + 阈值** | UNKNOWN(灰)/HEALTHY(绿)/UNHEALTHY(红)/DISABLED(UI 合成不入库)；MCP 与 API 都有检活；`consecutive_failures ≥ 3`（failure-threshold=3）才翻 UNHEALTHY；5 分钟定时巡检；健康分布统计=MCP+API（业务系统不计） |
| **引用保护 403** | 删除被技能引用的连接器→**拦截返回 403**，防断链（提示粒度建议见附录 F1-5） |
| **统计无样本兜底** | 一律「—」或「暂无调用」，不出 null/NaN/Infinity |

### 3.3 关键验收标准

- [ ] AC-A1 登录默认落连接器首页，三 Tab 可切换；行卡 line1/line2、搜索 300ms 防抖、状态筛选、异常红点徽标 countUnhealthy 正确。
- [ ] AC-A2 MCP 测试连接仅握手不写库、拉取工具写 tools_cache、草稿预览不写库；可逐工具设二次确认并持久化。
- [ ] AC-A2b MCP 编辑器按 transport 显隐：streamable-http 显 Endpoint(必填)、stdio 显 Command(必填)+Arguments+Environment；切换互清对方字段。
- [ ] AC-A2c MCP stdio env 全 value AES-256-GCM 加密；detail 只回 `{key,valueMasked}` 不回明文/密文；留空保留旧值、重填覆盖、删 KEY 不删旧值；KEY 校验 `[A-Za-z_][A-Za-z0-9_]*` 不重复。
- [ ] AC-A2d MCP stdio 安全：args 不经 shell、env 不进命令行、max-processes=8 达上限拒新建 CONN_FAILED、继承环境最小白名单、spawn 失败脱敏文案不携 command。
- [ ] AC-A3 重复拉取保留仍存工具的二次确认标志，不被冲掉。
- [ ] AC-A4 MCP/API code 创建后只读（API 系统生成、列表隐藏）；三类连接器都有 origin（系统配置员管 PLATFORM）。
- [ ] AC-A5 API 鉴权不鉴权/API KEY（三必填子字段）；密钥脱敏不回显、留空不改/重填覆盖/切走清密钥可感知。
- [ ] AC-A6 API line2 含调用次数+平均执行时间，语义正确、无样本显「—」；检活与统计并存。
- [ ] AC-A7 业务系统无检活四态列、不回显用户登录态、biz_pages 可配多业务页面。
- [ ] AC-A8 立即检活同步刷 HealthTag；四态色 HEALTHY 绿/UNHEALTHY 红/UNKNOWN 灰/DISABLED 合成；`consecutive_failures≥3` 才翻 UNHEALTHY、定时巡检生效。
- [ ] AC-A9 删除被引用连接器返回 403（引用保护）。

> P0：MCP（**stdio + streamable-http 双 transport**，stdio env 加密脱敏 + 安全姿态）/API/业务系统 CRUD、握手+拉工具+二次确认、API 鉴权+真实外呼+统计、检活四态+立即检活+引用保护。P1：草稿预览拉取、统计无样本收敛、定时巡检、业务页面多条配置。

---

## 4. 功能域 B · 发布审核模块（原「工具市场」，V36 改名）

> 入口 `/admin/market`（路由名 AdminMarket 保留）：发布管理（MarketPublish.vue）+ 审核台（MarketReview.vue，**tab 仅 ADMIN 可见**，单 tab 退化为无 tab 栏，深链 `?tab=review` 回落 publish）。逐动作/候选集/审核台交互见 **附录 C1–C2**。
> PageHeader title=「发布审核」、subtitle=「把已接入的 MCP/API 工具发布到 FDE 工作台/用户端，审核通过后生效」。归「基础配置」段。

### 4.1 功能概述

把连接器里登记的 **MCP/API 工具**发布上架为"可被收藏与消费的工具条目（listing）"，并管理上下架生命周期。系统配置员是**发布作者**（建/编辑/下架/重上架/撤回）；**审核（通过/驳回）方法级仅 ADMIN + 审查人≠作者**（与平台技能审核一致）。收藏由用户侧产生，发布审核维护"有效集 = 收藏 ⋈ 已发布"的被动响应。端点 `/api/fde/market`，动作 list/detail/publish/review/delist/relist/updateMeta/withdraw。

### 4.2 核心逻辑与业务规则（复核重点）

| 规则 | 内容 |
|---|---|
| **审核仅 ADMIN + 审查人≠作者** | `review` 方法级 `requireAdminUserId()` + `assertReviewerNotAuthor`（提交人=审核人报 FORBIDDEN）；发布管理类动作 SYS_CONFIG/ADMIN；SYS_CONFIG 前端看不到审核 tab、不撞 403（与技能审核口径一致，见 §7） |
| **审核回写确认标志** | 通过须填 `writeClass`(READ/WRITE)+`requiresConfirmation`，回写到连接器侧对应单工具确认标志；驳回须填 `reviewComment` |
| **多目标发布逐 target 非原子** | publish 多目标(FDE_WORKBENCH/USER_END)**逐 target 非原子**处理，返回逐 target 结果（部分成功部分失败可分辨） |
| **ListingVO 出参为 ID** | 出参 `submitterId`/`reviewerId`/`reviewComment` 为 **ID 非名**，展示名需另解析 |
| **唯一约束 (tool_type,tool_code) 不含 status** | 允许驳回后同行 reset 重提，不撞唯一约束 |
| **撤回=物理删行（不可逆）** | 撤回未审删 PENDING 行、元数据丢失（与平台技能撤回一致；建议二次确认见附录 F1-9） |
| **收藏被动响应** | 有效集 = favorite ⋈ listing WHERE status=PUBLISHED；下架/驳回后收藏被动剔出（join 过滤） |
| **候选集现状** | 新建发布候选集 = `/api/fde/tools/available` 三来源全量、**未过滤 active/HEALTHY**（是否过滤待确认，§8-4） |

### 4.3 状态机（发布审核 listing · 单行原地流转）

```
              ┌──────────── 撤回（删行）
              │
[未发布]──提交发布──►[PENDING_REVIEW]──通过──►[PUBLISHED]
                          │                      │
                          └──驳回──►[REJECTED]    └──下架──►[DELISTED]
                                       │                      │
                                       └──重提（同行reset）     └──重新上架──►[PUBLISHED]
                                          回 PENDING_REVIEW
```

**状态 → 可见操作矩阵**（"通过/驳回"= **仅 ADMIN**；其余动作 = SYS_CONFIG/ADMIN）：

| 当前态 ＼ 操作 | 提交发布 | 撤回 | 编辑元数据 | 通过(ADMIN) | 驳回(ADMIN) | 重提 | 下架 | 重新上架 |
|---|---|---|---|---|---|---|---|---|
| 未发布（草稿） | ✅→PENDING | — | ✅ | — | — | — | — | — |
| PENDING_REVIEW | ✗（已在审） | ✅（删行） | ✅（审中可改） | ✅→PUBLISHED | ✅→REJECTED | ✗ | ✗ | ✗ |
| REJECTED | ✗（用重提） | — | ✅（改后） | — | — | ✅→PENDING（同行reset） | ✗ | ✗ |
| PUBLISHED | ✗ | — | ✅（元数据原地） | — | — | ✗ | ✅→DELISTED | ✗ |
| DELISTED | ✗ | — | ✅ | — | — | ✗ | ✗ | ✅→PUBLISHED |

### 4.4 关键验收标准

- [ ] AC-B1 发布管理可按 status/toolType/keyword 过滤；新建发布可选 MCP/API 工具并填元数据。
- [ ] AC-B2 提交发布→PENDING；撤回未审=物理删行（不可逆）。
- [ ] AC-B3 通过须填 writeClass+requiresConfirmation 并回写连接器侧确认标志→PUBLISHED；驳回须填 reviewComment→REJECTED。
- [ ] AC-B4 **发布审核 review 方法级仅 ADMIN + 审查人≠作者（assertReviewerNotAuthor）**；纯 SYS_CONFIG 前端看不到审核 tab、深链 ?tab=review 回落 publish，构造请求后端 403/FORBIDDEN（与平台技能审核一致）。
- [ ] AC-B4b publish 多目标逐 target 非原子，返回逐 target 结果；ListingVO 出参 submitterId/reviewerId 为 ID 非名。
- [ ] AC-B5 REJECTED 同行 reset 重提回 PENDING（唯一约束不冲突）；PUBLISHED 可下架→DELISTED、DELISTED 可重上架→PUBLISHED。
- [ ] AC-B6 工具下架/驳回后对应收藏被动剔出有效集；状态→可见操作矩阵逐条符合 §4.3。

> P0：发布管理 CRUD+提交、审核台通过/驳回（含回写确认标志、仅 ADMIN）、状态机四态、收藏被动响应。P1：撤回未审、驳回同行重提、下架/重上架、过滤项完整。

---

## 5. 功能域 C · 平台技能模块

> 入口 `/admin/platform-skills`（含审核台 SkillReviews.vue，**路由仅 ADMIN**）。完整需求以 `PRD-平台级技能与发布.md` 为准。逐动作/FDE 侧消费见 **附录 D1**。

### 5.1 功能概述

平台技能 = **不归属任何岗位**（origin=PLATFORM，无 position/agent）的平台级技能。系统配置员复用 FDE 技能编辑器配置，**多目标发布**到 FDE 工作台 / 用户端，须经 ADMIN 审核。发到 FDE 工作台的，FDE 只读可见 + 可"挂载引用"到岗位 Agent 真执行（跟随最新、不可编辑本体）；发到用户端的由上层应用经标准化接口消费。

### 5.2 核心逻辑与业务规则（复核重点）

| 规则 | 内容 |
|---|---|
| **来源隔离** | origin=PLATFORM、position/agent 空；code 按来源分命名空间（与岗位技能不冲突），展示名可重名 |
| **复用 FDE 技能编辑器** | 同一套 skill.md/触发词/工具引用编辑体验，不重复造编辑器 |
| **引用工具范围** | 可引用平台级 MCP/API；数据表/业务系统暂不支持（无岗位归属、运行时不可达） |
| **多目标发布** | 勾选 FDE_WORKBENCH/USER_END（可多选、至少一个）；**一次审核管两端**（内容一次审过）；两目标可分别启停（启停=目标开关、不触发重审） |
| **审核仅 ADMIN + 审查人≠作者** | approve/reject/list 三处 `requireAdminUserId()`；前端路由仅 ADMIN，SYS_CONFIG 无入口 |
| **改内容触发重审（requeueForReview，现状已实现）** | 改已 PUBLISHED 内容→PUBLISHED 行回退 PENDING_REVIEW（清空上轮 reviewer/comment，**version 不增**，待重新通过再增）；PENDING 不变、DELISTED/REJECTED 不回退 |
| **撤回=删行（与市场一致）** | 仅 PENDING_REVIEW 可撤、回无行态、单目标、不可逆 |
| **FDE 编辑兜底** | FDE 尝试编辑平台技能本体→前端无入口 + 后端拒绝（FDE 仅只读/引用） |

### 5.3 状态机（平台技能发布 · 单条记录原地流转）

```
[DRAFT]──提交发布(勾目标,至少一个)──►[PENDING_REVIEW]──ADMIN 审核(≠作者)
   ├─通过─►[PUBLISHED]（按目标生效，两目标可分别启停）
   │          ├─含 FDE_WORKBENCH → FDE 只读可见 + 可引用执行
   │          └─含 USER_END     → 上层应用经标准化接口拉取
   └─驳回─►[REJECTED]（填 comment）──改后重提(同条 reset)──►回 [PENDING_REVIEW]
[PUBLISHED]──下架──►[DELISTED]──重新上架──►[PUBLISHED]
```

**合法流转矩阵**（"通过/驳回"= 仅 ADMIN）：

| 当前态 ＼ 动作 | 提交发布 | 通过(ADMIN) | 驳回(ADMIN) | 重提 | 下架 | 重新上架 | 编辑 |
|---|---|---|---|---|---|---|---|
| DRAFT | ✅→PENDING | — | — | — | — | — | ✅（仍 DRAFT） |
| PENDING_REVIEW | ✗（已在审） | ✅→PUBLISHED | ✅→REJECTED（填因） | ✗ | ✗ | ✗ | ✅（审中改，仍 PENDING） |
| REJECTED | ✗（用重提） | — | — | ✅→PENDING（同条 reset） | — | ✗ | ✅（重提前可改） |
| PUBLISHED | ✗ | ✗ | ✗ | ✗ | ✅→DELISTED（可按目标分别下架） | ✗ | ✅改名/描述原地；**改内容触发重审（requeueForReview，version 不增）** |
| DELISTED | ✗ | — | — | — | ✗ | ✅→PUBLISHED | ✅（下架态可改，不被回退重审） |

### 5.4 关键验收标准

- [ ] AC-C1 系统配置员可对平台技能完整 CRUD（复用 FDE 技能编辑器）；origin=PLATFORM、position/agent 空、与岗位技能数据隔离、code 按来源隔离、展示名可重名。
- [ ] AC-C2 发布可勾目标（可多选、至少一个）→PENDING；改 PUBLISHED 内容触发 requeueForReview 回退重审（version 不增）。
- [ ] AC-C3 **审核 approve/reject 方法级仅 ADMIN + 审查人≠作者**；纯 SYS_CONFIG 前端看不到技能审核台、构造请求 403。
- [ ] AC-C4 驳回同条 reset 重提；下架（可按目标分别）/重上架/撤回未审生效；两目标可分别启停、不触发重审。
- [ ] AC-C5 可引用平台级 MCP/API；数据表/业务系统不可引用；状态机流转符合 §5.3、非法流转无入口。

> P0：CRUD（来源隔离）、多目标发布、ADMIN 审核流、状态机、平台级 MCP/API 引用、requeueForReview 重审。P1：驳回重提、按目标分别下架/重上架、撤回未审、编码空间隔离细节。

---

## 6. 功能域 D · 配置报表模块

> 入口 `/admin/reports/sysconfig`（SysConfigReports.vue）；后端 `GET /api/fde/reports/sysconfig/overview`。指标/图表/钻取细节见 **附录 E1**。

### 6.1 功能概述

一张"系统配置模块实时数据总览"：6 指标卡 + 3 ECharts 图表，全部 DB 实时 COUNT/GROUP BY（不依赖未就绪日聚合 job），双主题跟随。后端 `GET /api/fde/reports/sysconfig/overview` 返回 `summary`(7 字段) + `distributions`(3 项)。

### 6.2 核心逻辑与业务规则

- **summary 7 字段**：`connectorTotal`(MCP+API+业务系统总数,**V36 新增**) / `mcpTotal` / `apiTotal` / `bizSystemTotal` / `marketTotal` / `marketPendingReview` / `favoriteTotal`（口径见附录 E1.1）。
- **前端 6 指标卡**：MCP / API / 业务系统 / 发布工具总数 / 待审核 / 收藏（指标卡仍展示 6 张，connectorTotal 为汇总字段供卡片或副文案用）。
- **distributions 3 图表**：`healthDistribution` 检活健康分布（环形，**只出三态** HEALTHY/UNHEALTHY/UNKNOWN，MCP+API，业务系统不计、DISABLED 不出桶）、`marketByStatus` 发布工具各状态分布（竖柱四态）、`favoriteTop` 热门收藏工具 Top5（横柱）。
- **双主题跟随**：图表取 CSS 变量 `--c-*`，切暗色重算 setOption，不硬编码色。
- 数据实时查询、进页拉一次 overview；指标卡钻取为产品建议（附录 E1.3）。

### 6.3 关键验收标准

- [ ] AC-D1 6 指标卡来自实时 DB 统计，口径正确。
- [ ] AC-D2 检活健康分布只出三态、色彩映射正确且暗色跟随；发布工具各状态竖柱含四态；热门收藏横柱 Top5；summary 含 connectorTotal(7 字段)。
- [ ] AC-D3 双主题切换图表配色跟随、无硬编码色；报表端点落 SYS_CONFIG/ADMIN 角色门（FDE 访问 403）。

> P0：6 卡 + 3 图实时数据 + 角色门。P1：双主题精细对齐、空/错误态体验。

---

## 7. 权限边界（贯穿四域 · 复核重点）

### 7.1 角色与账号

| 角色 | 账号 | 在系统配置模块的权限 |
|---|---|---|
| `SYS_CONFIG` | sysconfig/sysconfig123 | 连接器/发布审核/平台技能/配置报表的**发布管理类全部功能**；**两个审核台的审核（发布审核 review、技能 approve/reject）均不可执行**（前端无入口 + 后端方法级仅 ADMIN + 审查人≠作者） |
| `ADMIN` | admin/admin123 | 超管短路，两模块全通，含全部审核类方法 |
| `FDE` | fde/fde123 | 系统配置模块端点一律 **403**（角色隔离，预期行为） |
| `EMPLOYEE` | demo 等 | 调连接器/发布审核/报表端点 → **业务码 403**「无权限访问该后台模块（需 SYS_CONFIG 或 ADMIN 角色）」（**HTTP 200 + body.code=403**，本项目业务错误用 HTTP200+body.code） |

> **两个审核台权限完全一致（本节核心）：** 发布审核（MarketController.review）与平台技能审核（SkillReviewController）后端均 `requireAdminUserId()` + 审查人≠作者（assertReviewerNotAuthor，提交人=审核人报 FORBIDDEN）；前端均对 SYS_CONFIG 不可见（发布审核台 tab 仅 ADMIN、深链 `?tab=review` 回落 publish；技能审核台路由 `meta.roles=['ADMIN']`）。**口径统一，仅前端载体不同（tab vs 独立路由）。**

### 7.2 后端角色门（AdminRoleGuard · 最长前缀映射，ADMIN 超管短路）

| 路径前缀 | 模块 | 放行角色 |
|---|---|---|
| `/api/fde/connectors/**` | 连接器（MCP/API/业务系统/检活） | SYS_CONFIG / ADMIN |
| `/api/fde/tools` | 工具 | SYS_CONFIG / ADMIN |
| `/api/fde/market/**` | 发布审核（含 review） | SYS_CONFIG / ADMIN（**review 方法级仅 ADMIN + 审查人≠作者**） |
| `/api/fde/platform-skills/**` | 平台技能 | SYS_CONFIG / ADMIN |
| `/api/fde/skill-reviews/**` | 技能审核台 | SYS_CONFIG / ADMIN（**方法级 approve/reject/list 均仅 ADMIN**） |
| `/api/fde/reports/sysconfig/**` | 配置报表 | SYS_CONFIG / ADMIN |

- **模块门 vs 方法门**：两审核台模块门都是 SYS_CONFIG/ADMIN，但审核决策方法门都收紧到仅 ADMIN（requireAdminUserId）+ 审查人≠作者（作者 SYS_CONFIG 不能审自己）。
- 业务码 403（非 401）：EMPLOYEE 调上述三功能端点 → `ResultVO.code=403`、文案「无权限访问该后台模块（需 SYS_CONFIG 或 ADMIN 角色）」（HTTP 200 + body.code）。401 仍由 Security filter 在前处理（无 token→401），与角色门 403 不同链路。

### 7.3 前端导航分组与路由/可见性

**窄轨（AdminRail）系统配置两段分组：**

| 分组 | key | 可见条件 | 含菜单 |
|---|---|---|---|
| **基础配置** | SYSCONFIG_BASE | `canSysConfig` | 连接器(AdminConnector) / 发布审核(AdminMarket) / 报表(SysConfigReports) |
| **用户端配置** | SYSCONFIG_USER | `canSysConfig`（技能审核项仅 ADMIN） | 平台技能(SysConfigSkills) / 技能审核(SkillReviews，仅 ADMIN 可见) |

**路由 / tab 角色门：**

| 路由 / tab | 角色门 | SYS_CONFIG 前端可见？ | 分组 |
|---|---|---|---|
| AdminConnector | 路由 `['SYS_CONFIG','ADMIN']` | ✅（默认落地页） | 基础配置 |
| AdminMarket / 发布管理 tab | 路由 `['SYS_CONFIG','ADMIN']` | ✅ | 基础配置 |
| **AdminMarket / 审核 tab** | **tab 仅 ADMIN** | **❌（深链 ?tab=review 回落 publish）** | 基础配置 |
| SysConfigReports | 路由 `['SYS_CONFIG','ADMIN']` | ✅ | 基础配置 |
| SysConfigSkills（平台技能列表/编辑） | 路由 `['SYS_CONFIG','ADMIN']` | ✅ | 用户端配置 |
| **SkillReviews（技能审核台）** | **路由 `['ADMIN']`** | **❌（前端无入口）** | 用户端配置 |

- 守卫逐层求交：`requiredRoles.some(r => user.roles.includes(r))`；窄轨按 `canSysConfig` 显隐两段分组（技能审核项再按 ADMIN 收紧）。
- **两个审核台对纯 SYS_CONFIG 都 = 前端无入口**（不是"看得到却点出 403"），不存在审核按钮置灰/tooltip 问题。
- 登录后落地：纯 SYS_CONFIG 默认落连接器首页（AdminConnector，基础配置段）。

### 7.4 角色隔离即目的（预期行为）

- 纯 SYS_CONFIG 访问 FDE 工作台端点、纯 FDE 访问系统配置端点均返回 **403 是预期**。需同时管两模块用 admin，或分别用 sysconfig/fde 账号。

### 7.5 关键验收标准

- [ ] AC-P1 sysconfig 登录见**基础配置 + 用户端配置**两段分组、默认落连接器首页；可执行连接器/发布审核/平台技能/报表全部非审核功能。
- [ ] AC-P2 sysconfig **看不到发布审核台 tab**（深链回落 publish）+ **看不到技能审核台**（路由仅 ADMIN）；构造请求两审核台均 403/FORBIDDEN（requireAdminUserId + 审查人≠作者）。
- [ ] AC-P3 两审核台口径一致：审核仅 ADMIN + 审查人≠作者 + 前端对 SYS_CONFIG 不可见（仅载体不同）。
- [ ] AC-P4 ADMIN 两模块全通含全部审核方法；纯 FDE 访问系统配置端点全 403（预期）；EMPLOYEE 调三功能端点业务码 403（HTTP200+body.code）。

---

## 8. 待澄清开放问题（供 PM 决策，不自行编造答案）

1. **业务系统「检活」具体语义（架构师拍板）**：无四态列、"检活"=配置就绪度+加密链路自检不入库，但具体校验项、是否给 UI 就绪提示、与 MCP/API 四态视觉如何区分未明确。
2. **收藏的产生入口归属（产品/用户确认）**：`user_tool_favorite` 由用户侧产生，系统配置员只看统计不直接收藏；用户在哪个角色/界面收藏未交代清楚。
3. **平台技能引用工具的取数来源（架构师评估）**：允许引用平台级 MCP/API，但取数来源（连接器全集 vs 仅市场 PUBLISHED）及运行时可达性待确认。
4. **工具市场发布候选集是否过滤（确认）**：现状 `/api/fde/tools/available` 三来源（MOCK / MCP / API）全量、未过滤 active/HEALTHY；是否过滤为"仅 active/HEALTHY"待确认。**另：候选集含 MOCK（内置演示/占位工具），发布到生产市场语义略意外——是否应把 MOCK 排除出可发布候选集，一并确认。**
5. **业务系统"检活"操作员体感（优先级提示）**：配完如何确认"成没成"（无四态、不入库），建议优先给就绪度提示。

> **已决策/已回填为现状（不再开放）：**
> - ~~市场审核未做方法级 ADMIN 收紧、与平台技能口径不一致~~ → **已决策（2026-06-24 用户拍板）+ 已实现 + CR 通过**：工具市场审核与平台技能审核**保持一致 = 方法级仅 ADMIN**（后端 `review` 改 `requireAdminUserId` + 加审查人≠作者守卫；前端审核台 tab 仅 ADMIN 可见 + 深链 `?tab=review` 回落 publish）。本 PRD §1.3/§4/§7/AC-B4/AC-P 已全面对齐。
> - ~~平台技能改内容是否重审~~ → **现状已实现 requeueForReview**（§5.2/§5.3）。
> - ~~API「健康检查路径」与「单一 API 地址」关系~~ → **现状已有兜底**（V24 `api_def.health_check_path`，未配则探测 base_url）；彻底合并归 PRD-API连接器页改造 演进项。

---

## 9. 全局优先级汇总

| 优先级 | 跨域范围 |
|---|---|
| **P0（必做）** | 连接器 CRUD（**MCP stdio+streamable-http 双 transport、stdio env 加密脱敏+安全姿态**）+握手+拉工具+二次确认+鉴权+真实外呼+检活+引用保护；发布审核 发布+审核(仅 ADMIN)+状态机+收藏被动响应；平台技能 CRUD+多目标发布+审核流(仅 ADMIN)+状态机+requeueForReview；配置报表 6 卡 3 图(summary 7 字段)；权限边界（基础配置/用户端配置两段分组+角色门+方法门+前端守卫+落地连接器首页） |
| **P1（应做）** | 草稿预览拉取、统计无样本收敛、定时巡检、撤回未审、驳回同行/同条重提、按目标分别启停、双主题精细对齐、空/错误态体验 |
| **P2（可选/不做）** | API 成功率上列表、统计清零入口、调用明细日志、平台技能差异化 override、主动 push 变更通知 |

---

> 主文档结束。交互细节见配套《PRD-系统配置员管理后台-交互细节附录.md》；各功能域字段/契约/运行时实现以引用的专项文档为准；§8 待澄清项需 PM 决策或上报用户/架构师拍板后回填。
