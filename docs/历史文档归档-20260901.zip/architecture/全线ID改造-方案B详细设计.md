# 全线 ID 改造 · 方案 B 详细执行 + 迁移设计

> 类型：架构详细设计（**只设计、不写实现代码、不改 DB**）
> 作者：架构师　日期：2026-06-30　状态：待 PM/用户二次确认 + 后端/前端 CR
> 前置：用户已拍板 **方案 B —— 把业务实体主键从 BIGINT IDENTITY 自增改为定长字符串主键**（真改 PK，不是只对外换 code）；范围全线统一；存量加密凭证按"迁移时重加密"保住、不作废。
> 复用：本设计承接高层调研 `全线ID标识改造-调研方案.md`（盘点结论复用，不重述），并以 5 路源码探查核实承重事实后落为可执行步骤。
> 修订：经后端 + 前端可行性 CR（方向可行、无致命硬伤）做**文档级修订**——纳入后端硬伤 H1（rootIdOf 链）/H2（LIKE 前缀转义）/H3（`Persistable<String>`）+ 必补 M1~M4 + 订正 C1~C3，以及前端低估面修订（Number/parseInt 实 23 处、灰度兼容策略、测试改造量）。切片骨架（后扩为 6 切片 B0~B5，见 §8.0）与"B4 不可逆活放最后"不变。
> 修订 2（2026-07-01，PM 已采纳；经 AI + 后端两路 CR 定稿）：**`app_user` 整体移出 B2、单独成「Bu 用户切片」**（B2 收窄为纯 expert/agent/数据表链）。切片骨架扩为 **7 切片 B0/B1/B2/Bu/B3/B4/B5**。新增内容：§8.0u（Bu 裁决 + 不可逆片边界新结论）、§4.4（认证/隔离链路改造护栏 + §4.4.3 工作量重估）、§5.5（user_biz_credential 双段 AAD 重加密下沉 B4）、铁律 1′（AAD 跨多【会迁移】主键且分属不同片时重加密落"最后那片"一次完成；含固定域常量的单迁主键 AAD 仍归铁律 1）、铁律 4（结构性/隔离 user_id 列必与 app_user 同片，否则隔离破裂）、R1u/R15/R16 风险。**关键结论：不可逆片仍唯一（B4）**——Bu 迁 app_user.id 虽触 user_biz_credential 的 AAD userId 段，但其重加密下沉 B4 一次完成（不在 Bu 分段），故 Bu 无不可逆活、可回滚。
> CR 定稿订正（2026-07-01）：① 删虚构列 `tool_market_listing.user_id`（该表无此列，实为 submitter_id/reviewer_id 纯归属 → B5）；② 补遗漏 `memory_import_job.user_id`（有归属过滤 → Bu）；③ `audit_log.user_id` 显式定档 B5（纯写入归属）；④ JWT 订正——userId 在 `uid` claim（非 sub，sub=username 不动），改动点 JwtAuthFilter L45-46 + JwtTokenProvider.generate，无 refresh/remember-me、强制重登可行、零兼容层；⑤ 消费面重估 requireUserId **126 调用点/228 声明/79 文件** + requireAdminUserId 11 处 + InternalMemoryController 数字注入点（其 Python 调用方同步）+ 30 测试文件（远大于初估 ~54），Bu 当独立大工作量排期、不拆片；⑥ 跨表 JOIN 硬约束 memory_extract_cursor.user_id 与 session.user_id 两列须同窗口同切；⑦ AI 标注利好——当前无 user_biz_credential 解密消费方，Bu→B4 窗口风险"低/潜在"，护栏采纳①冻结（②shim 仅备选 + B4 后强制拆除）。
>
> **Bu 实施期订正（2026-07-01，已落地 + 真 PG 验收）**：⑧ **隔离列补漏 `data_record.uid`**——初版清单遗漏（命名 `uid` 非 `user_id`），V18 注释确证其为 TABLE 行「归属用户」隔离核心（运行时 ToolTraceContext.userId 注入、查询恒带 uid 谓词、越权核心防线），按铁律 4 必与 app_user 同片切 VARCHAR；**教训：隔离列穷举须含 `uid`/`owner_user_id` 别名 + 语义判定，不能只 grep `user_id`**。⑨ 迁移文件 `V49__app_user_pk_to_string.java`（**14 隔离列**：13 + data_record.uid），含 user_role 复合 PK (user_id, role_id) DROP/重建 + 跨表同切阶段C 后硬断言 + `*_old` DROP NOT NULL 通则。⑩ **真 PG 逮到 UNIQUE 约束 vs 索引区分**：`uk_user_tool_favorite`/`uk_user_biz_credential`/`uk_extract_cursor_user_session` 由 UNIQUE **约束**支撑（非部分索引），切列前须 `DROP CONSTRAINT`（`DROP INDEX` 会因约束依赖失败），H2 测不出、真 PG 才暴露。⑪ **安全回归（实施期自查逮到并修）**：requireUserId() 返回 String 后，controller 传 operatorId 处若把 `requireUserId()` 整体替换为 `null`，会**误删方法级鉴权守卫**（未登录不再抛 401）；10 个 controller 命中，已恢复独立 `SecurityUtils.requireUserId();` 守卫语句（鉴权侧作用）后再对 Long/B5 operatorId 传 null。**范式：传 null 给 B5 审计列时，务必保留 requireUserId() 的鉴权副作用（独立成句），不可连鉴权一起删。** ⑫ 前端 userId 为不透明值（无数字强转/比较）→ 前端零代码改动（仅 companion.js localStorage 昵称键值变 usr_ 串，展示态自愈）。⑬ Python 测试 150 passed；Java 全量回归 1662 绿 + 真 PG fresh V1→V49 验收通过。
>
> ⚠️ **架构师立场声明（必读，CR 后仍保留）**：用户已选 B，本文据此给出**可执行、可回滚、可分片、不可逆点双校验**的完整方案。但作为架构师，我对方案 B **仍保留一条强烈劝退意见**（见 §10），因为它触碰"密文 AAD 绑数字主键"这一**全程唯一不可逆段**且系统为有真实凭据的 live 实例。该保留意见供 PM 向用户二次确认；若用户确认坚持 B，则按本设计的"凭证片单独成片 + 最重护栏"执行。

---

## 0. TL;DR（给 PM）

- **ID 规格**：`<前缀>_<11位 base58(去混淆)>`，前缀逐实体定（sk_/ps_/ag_/mc_/ap_/bz_/dt_/df_/pv_/tk_…）；新建 `PublicIdGenerator`（JDK SecureRandom + base58 字母表 + 落库前查重重试），**不引新依赖**；JPA 主键改 `@Id String id` + 应用层赋值，去掉 `@GeneratedValue(IDENTITY)`。
- **迁移骨架**（每张被改实体表统一三段式）：① 建映射表 `id_map_<table>(old_bigint → new_str)` 并对全量行生成新 id；② 给本表加**影子主键列 `id_new VARCHAR`** 回填、给所有引用它的表加**影子 FK 列 `<fk>_new VARCHAR`** 按映射回写；③ 全量校验引用完整后，在一个受控切片内**切主键 + 切 FK + 删旧列**。旧列保留至该切片回归通过后再删（回滚靠旧列仍在）。
- **物化路径 path**：`skill.path` 是数字 id 链（`/5/8/`），PK 变字符串后必须用**新字符串 id 自顶向下重建**整条链（根 `/<id_new>/`，子 `parent.path_new + id_new + '/'`），并保证子树/深度查询不回归。另有**两条反向依赖 path 内部结构**的路径必须同改（归 B3）：① `AdminSkillService.rootIdOf` 取 path 首段做 `Long.parseLong` 返回 `Long`、下游缓存失效签名也是 `Long`（H1，字符串 id 下会抛异常 break、缓存静默失准）；② `countDescendants/findByPathStartingWith` 的 LIKE 前缀**未转义**，而 id 内分隔符 `_` 是 LIKE 单字符通配符，会跨子树误匹配（H2，须加 `ESCAPE` 并转义 `_/%/\`）。详见 §4。
- **JPA `Persistable<String>`（H3）**：应用层 String 主键实体若不实现 `Persistable<String>`（`getId` + `@Transient isNew` 新建标记），`save` 会走 `merge`（先 SELECT 再 INSERT），批量退化、有语义隐患（项目 `MemoryImportJob` 是带病先例）。~26 个被改实体逐个加新建标记。
- **凭证重加密（不可逆点，单独成片，最重护栏）**：三处密文 AAD 绑数字 id —— `user_biz_credential`（AAD=`userId|bizSystemId`）、`mcp_def.env_config`（AAD=`mcpId|-1L`）、`api_def.auth_config`（AAD=`0|api_def.id`）。需**受控启动期 Java data-fix**（非纯 SQL，需拿到加密密钥 + AES-GCM 逻辑）：旧 AAD 解密 → 新 AAD（字符串 id）重加密。**时序已锁定（M2）：先切三表 PK、后同窗口重加密**（新 AAD 用真实新主键值，消除主键真值与 AAD 用值解耦）。护栏：迁移前全量逻辑备份 + 解密失败立即中止回滚 + 重加密后逐条解密双校验 + 幂等标记（重跑不二次加密）。
- **正向收益（M1）**：改应用层 String id 后，insert 前即有主键 → api_def/MCP 的"两步 save（先 insert 取 IDENTITY，再加密二次 save）"可**收敛为一次加密入库**，删两步 save + 删 `AdminApiService` "勿合并优化"注释 + 改单测。
- **Java↔Python wire**：`skillId/expertId/sectionId` 等 `Optional[int]→Optional[str]`，Java 侧 `Long→String`，两侧必须同一提交同步改（N1 教训锁区）；含 1 处数字解析 `parseSectionId`、`Set<Long> allowedSectionIds`、`Map<String,Long> toolSkillIds` 需改类型；wire 契约测试需同步更新。
- **DB FK 约束 = 43 条（C1 订正）**：迁移涉及的 DB 级 FK 约束实为 43 条（非此前 41）；无显式命名的靠 PG 默认名 `<table>_<col>_fkey`，断约束前先查 `information_schema.table_constraints` 拿真实名。
- **对外面**：41 条 `{xxxId:\d+}` 路由放宽（去 `\d+`，并防字面量误捕获）、48 处 `@PathVariable Long→String`、前端 4 条 `(\d+)` 路由约束放宽 + **23 处** `Number()/parseInt()` 清理（重点 AgentLane 拖拽 dataTransfer；其中 `Chat.vue` 的 `Number.isFinite` 守卫会静默吞字符串 id，属删逻辑分支级）。**前端 Number 清理走灰度兼容策略——不在每个后端切片同步清，统一到 B3 尾去除**（见 §7/§8）。
- **分期（B1 实施前按凭证耦合 + 跨片 FK 孤儿重排；B2 FK 穷举后追加结构性 FK/弱审计列解耦；2026-07-01 app_user 单独成 Bu 用户切片）**：B 排在"删 Agent 技能游离化（V44）"**之后**；**7 切片 B0 基础设施 → B1 service_provider_system → B2 expert/agent + data_table_def(含子表)，纯结构性 FK、不含 app_user → Bu 用户切片(app_user.id + 全部 →app_user 结构性 user_id FK + 认证/隔离链路 requireUserId Long→String/JWT 主体；user_biz_credential 只切 user_id FK 列、密文重加密下沉 B4) → B3 skill+path+wire(前端清理收于 B3 尾) → B4 mcp/api/biz 三表 PK + 全 FK + 三类凭证重加密(含 user_biz_credential 双段 AAD 一次重加密) → B5 审计归属收尾(弱审计列横切)**。**铁律：①凭证表 PK 迁移与其存量重加密同片（→ B4 唯一不可逆片）；①′ AAD 跨多主键分布在不同片时，重加密落"最后确定那片"一次完成（user_biz_credential→B4，不在 Bu 重加密，故 Bu 可回滚）；②被 NOT NULL FK 引用的父表 PK 须与子表 FK 同片；③结构性 FK（有 DB 约束）必须与父 PK 同片、弱审计列解耦延后 B5；④结构性 user_id 列必须与 app_user 同片切（Bu），否则字符串 currentUserId 过滤 BIGINT 列→用户数据隔离破裂**（详见 §8/§8.0/§8.0u）。
- **最高风险 + 回滚**：见 §9。最危险四坑——凭证 AAD（不可逆）、path 重建、wire 锁区、FK 切换顺序。

> 关键校准：现存最高 Flyway 版本为 **V44**（`V44__detach_unbound_skills_to_orphan.sql`，即游离化）。本改造 Flyway 从 **V45** 起编号，已应用迁移一律不改。

---

## 1. 字符串 ID 规格 + PublicIdGenerator

### 1.1 ID 格式

| 维度 | 规格 | 说明 |
|------|------|------|
| 结构 | `<prefix>_<random>` | 下划线分隔，前缀辨识 + 随机段不可枚举 |
| 随机段长度 | **11 位 base58** | 11 × log2(58) ≈ 64.4 bit 熵；够短可念可抄 |
| 字符集 | base58 去混淆（去 `0 O I l`，即 `123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz`） | URL 安全、双击全选友好、防手抄歧义 |
| 总列宽 | `VARCHAR(20)`（前缀 ≤3 + `_` + 11，预留余量到 20） | 统一列宽，便于 FK 列对齐 |

> **📌 校准标注（2026-07-17）**：「前缀 ≤3」指**≤3 个字母 + 下划线**（如 `sps_` 为 3 字母 + `_`）；`PublicIdGenerator` 代码注释中的「前缀 ≤4」按**含下划线**计，两处口径已统一，不矛盾。详见《设计文档校准审计-20260717.md》。

### 1.2 逐实体前缀（建议，CR 时定稿）

| 实体 | 前缀 | 实体 | 前缀 |
|------|------|------|------|
| skill | `sk_` | service_provider_system | `pv_` |
| expert(=position) | `ps_` | scheduled_task | `tk_` |
| agent | `ag_` | task_execution | `te_` |
| mcp_def | `mc_` | memory_item | `mm_` |
| api_def | `ap_` | tool_market_listing | `tm_` |
| biz_system_def | `bz_` | app_user | `usr_` |
| data_table_def | `dt_` | role | `rol_` |
| data_field_def | `df_` | data_record | `dr_` |
| position_sample_task（岗位样例定时任务） | `st_` | skill_display_category（技能分类） | `cat_` |
| user_login_log（登录明细） | `llg_` | llm_model_config（模型配置注册表，V76） | `md_` |
| user_feedback（用户反馈，V80） | `fb_` | 中间/引用表自身 PK（统一 REF 类） | `ref_` |
| skill_package_snapshot（平台技能发布版本快照） | `sps_` | position_publication（岗位版本发布记录） | `pp_` |
| position_package_snapshot（岗位版本包快照） | `pps_` | | |

> **📌 校准标注（2026-07-17）**：上表后 5 行为 2026-07-17 校准补记——定稿后代码侧陆续新增的 9 个枚举成员（依据 `backend/src/main/java/com/aiassistant/common/id/PublicIdType.java`），文档此前未随之回写。详见《设计文档校准审计-20260717.md》。

> 中间/引用表（skill_*_ref、skill_file、skill_publication、skill_reference、user_*）的**自身 PK** 是否也随之改字符串：建议**改**（全线统一诉求），前缀可统一用 `ref_` 类或各自前缀；但它们的 PK 不对外暴露、不被别表引用，改造最轻（仅自身 PK + JPA），**可放到收尾切片**。其 FK 列（指向 skill/expert/… 等被改实体）必须随被引用表一起改——这是重点。

### 1.3 PublicIdGenerator（应用层生成，不引新依赖）

- **算法**：`SecureRandom` 抽取 11 个字符自 base58 字母表 → 拼前缀。
- **查重重试**：落库前按目标表唯一查询（`existsById` / 唯一索引命中），命中则重生成，最多重试 N=5 次，超限抛异常（极不可能触发）。复用现有 `generateUniqueXxxCode` 的"生成→查重→重试"骨架。
- **碰撞概率**：64 bit 空间下，按生日界，达到 1e-9 碰撞概率需 ~1.9 亿条同表数据；本系统单表量级远低于此，**单次插入碰撞概率可忽略**，查重重试是兜底而非常态路径。
- **JPA 主键生成方式**：
  - `@Id` 字段改 `String id`，**去掉** `@GeneratedValue(strategy = IDENTITY)`。
  - 实体在 `@PrePersist` 或 Service 层 save 前调用 `PublicIdGenerator` 赋 id（应用层赋值，对齐项目已有先例 `memory_import_job` 的 `@Id String jobId` 应用层 UUID）。
  - **不引第三方库**（nanoid/uuid creator 等一律不引），JDK `SecureRandom` 足够。
- **H3 必须实现 `Persistable<String>`（CR 必修硬伤）**：应用层赋值的 String 主键实体，若**不实现 `Persistable<String>`**（重写 `getId()` + 一个 `@Transient` 的 `isNew` 新建标记，通常 `@PrePersist`/`@PostLoad` 维护），Spring Data 的 `save` 无法靠"id 是否为 null"判断新增/更新，会**退化为 `merge`（先 SELECT 再 INSERT）**——批量插入性能退化、且有"误判已存在"的语义隐患。项目现有 `MemoryImportJob`（`@Id String` 但未实现 Persistable）是**带病先例，不可照抄**。
  - 影响：**~26 个被改实体逐个加 `Persistable<String>` + isNew 标记**，工时按 26 实体计（B0 定改造模式，各业务片落地）。
- **与现有语义 code 的关系**：保留各实体现有 `code` 列（语义/导入幂等键，如 `expert.code` 销售拼音、`skill.code` 等）**不动**；新字符串 PK 是另一维度。`PublicIdGenerator` 与现有 `CodeGenerator`（语义拼音 code）**分离不复用**。
- **M1 消除两步 save（正向收益）**：现 `api_def`/MCP env 加密因 AAD 绑 `IDENTITY` 主键，须"先 insert 取 id → 再加密 → 二次 save"（`AdminApiService` 注释明示"勿合并优化"）。**改应用层 String id 后，insert 前主键已确定** → 可在首次 save 前就用真实 id 算 AAD 加密、**一次加密入库**。落地动作：删两步 save、删"勿合并优化"注释、改对应单测。**落点 B4**（重排后 api_def/mcp_def 的 PK 迁移收进 B4，M1 随之；与 §5 存量重加密同片但目标不同——B4 的存量重加密处理**历史**密文、M1 简化的是 PK 切换后的**新写入**路径，二者同片协同、不冲突）。

---

## 2. 逐表 PK→VARCHAR + 全 FK 改写清单与依赖顺序

### 2.1 被改实体（其 PK 从 BIGINT → VARCHAR(20)）

核心 7 + 数据 3 + 用户/任务 4 + 中间/引用 6+，共 ~26 张（含 V1 之外的 expert_resource/skill_resource/skill_relation/expert_skill/user_role/session 等，CR 时按实际逐张复核）。

### 2.2 「被引用 → 引用」依赖矩阵（决定切 FK 顺序）

> 原则：**被引用表（父）先准备好新 id 映射 → 引用表（子）的 FK 列按映射回写 → 最后统一切主键/外键约束**。**C2 订正：无 FK 循环** —— `api_def.provider_system_id → service_provider_system(id)` 是**单向** FK（约束 `fk_api_def_provider_system`），按拓扑 **service_provider_system 第0层先切、api_def 第1层后切**即可，无"先断后建循环"问题。

| 被改实体（父） | 指向它的 FK 列（子表.列 → 父表）| 约束类型 |
|---|---|---|
| **app_user**（被 50+ 表引用，最高风险）| 各表 `user_id` / `created_by` / `updated_by`；`scheduled_task.user_id`、`user_biz_credential.user_id`、`user_expert_binding.user_id`、`user_expert_override.user_id`、`user_skill_override.user_id`、`memory_item.user_id`、`session.*` 等 | 多为**逻辑 FK**（无 DB 约束），少量 DB FK |
| **expert(=position)**（被 40+ 表引用）| `agent.position_id`(DB FK)、`skill.position_id`(DB FK,V26)、`data_table_def.expert_id`(DB FK)、`expert_resource.expert_id`(DB FK,V15)、`user_expert_binding.expert_id`、`user_expert_override.expert_id`、`user_skill_override.expert_id`、`session.primary_expert_id`(可空)、`memory_item`(逻辑) | DB FK + 逻辑混合 |
| **skill**（自引用 + 被 20+ 引用）| `skill.parent_id`(**自引用** DB FK)、`skill.agent_id`(DB FK,V21,可空)、`skill_mcp_ref.skill_id`(DB FK)、`skill_api_ref.skill_id`(DB FK)、`skill_biz_ref.skill_id`(逻辑)、`skill_table_ref.skill_id`(DB FK,V20)、`skill_publication.skill_id`(逻辑)、`skill_file.skill_id`(逻辑)、`skill_reference.platform_skill_id`(逻辑)、`skill_resource.skill_id`(DB FK,V15)、`user_skill_override.base_skill_id`(可空)、`skill_relation.*`、`expert_skill.*` | DB FK + 逻辑混合；**还含 path 物化列（见 §4）** |
| **agent** | `skill.agent_id`(DB FK,V21,可空)、`skill_reference.agent_id`(逻辑) | DB FK + 逻辑 |
| **mcp_def** | `skill_mcp_ref.mcp_def_id`(DB FK)、`tool_market_listing`(逻辑，靠 tool_code 非 id) | DB FK |
| **api_def** | `skill_api_ref.api_def_id`(DB FK) | DB FK；**自身含 `provider_system_id` FK 指向 pv（单向，故 api_def 排 pv 之后切）** |
| **service_provider_system** | `api_def.provider_system_id`(DB FK，约束名 `fk_api_def_provider_system`,V40,V41 NOT NULL) | DB FK（**唯一显式命名约束**）|
| **biz_system_def** | `skill_biz_ref.biz_system_id`(逻辑)、`user_biz_credential.biz_system_id`(DB FK,V25) | DB FK + 逻辑 |
| **data_table_def** | `data_field_def.table_def_id`(DB FK,V18)、`data_record.table_def_id`(DB FK,V18)、`skill_table_ref.table_def_id`(DB FK,V20) | DB FK |
| **data_field_def** | `data_record`(JSONB key 内，**非列**) | 逻辑（JSONB） |
| **scheduled_task** | `task_execution.task_id`(逻辑) | 逻辑 |
| **role** | `user_role.role_id`(DB FK,V1) | DB FK |

### 2.3 切换依赖顺序（拓扑）

```
第0层（无对被改实体的 FK 依赖，可最先切 PK）：
  role, mcp_def, biz_system_def, service_provider_system, memory_item
第1层（依赖第0层 / 自身被广泛引用的基座）：
  api_def(依赖 pv)、app_user、expert
第2层（依赖 expert/app_user）：
  agent(→expert)、data_table_def(→expert)、scheduled_task(→app_user)
第3层（依赖 agent/expert/自引用）：
  skill(→agent,→expert,→skill 自引用)  ← path 同步重建
第4层（依赖 data_table_def）：
  data_field_def, data_record
第5层（中间/引用表，依赖上面所有被引用表）：
  skill_mcp_ref, skill_api_ref, skill_biz_ref, skill_table_ref,
  skill_publication, skill_file, skill_reference, tool_market_listing,
  expert_resource, skill_resource, skill_relation, expert_skill
第6层（用户绑定 / 引用关系，均为单列代理 PK）：
  user_role, user_biz_credential, user_expert_binding(单列代理PK，两 FK 列另回写),
  user_expert_override, user_skill_override, task_execution
```

> **C3 订正：全库无复合主键** —— 经核实 `@EmbeddedId`/`@IdClass` 0 处，`user_expert_binding` 等是**单列代理主键**（自身 PK 一列 + `user_id`/`expert_id` 两个普通 FK 列）。其改造 = 自身单列 PK 改 String + 两个 FK 列各自走对应 id_map 影子回写，**无"复合 PK 特例"复杂度**（原 §3.3 已删）。

### 2.4 唯一约束/索引影响

- 复合唯一约束含被改 PK 或 FK 列的，需随列类型变更**重建**：
  - `uk_skill_code_origin(code, origin)` —— code 不变，但若 skill 表整体重建索引会牵动；保持语义不变，仅列类型迁移期间重建。
  - `uk_expert_code_alive`、各 `*_ref` 复合唯一 `(skill_id, xxx_id)`（两列都改）、`uk_skill_file_skill_path(skill_id, path)`、`uk_skill_pub_skill_target(skill_id, target)`、`uk_skill_ref_agent_skill(agent_id, platform_skill_id)`。
- **M3 部分唯一索引清单补全（含被改 FK 列的，逐条随对应切片重建 + 唯一性回归）**：
  - `uk_data_table_def_alive(expert_id, table_code) WHERE NOT deleted` —— 含 expert_id（B2）。
  - `uk_expert_resource_alive(expert_id, ...) WHERE NOT deleted` —— 含 expert_id（B2）。
  - `uk_ueo_user_expert_active(user_id, expert_id) WHERE active` —— 含 user_id+expert_id（B2/B6 用户绑定层）。
  - `uk_uso_base_active` / `uq_user_skill_override_base`（user_skill_override 含 base_skill_id/expert_id/user_id）—— 跨 skill+expert+user（随 skill 片 B3 / 用户层）。
  - 通则：**凡部分唯一索引的列里出现被改 FK 列，必须在该 FK 列影子切换的同一切片内 DROP→以新 VARCHAR 列 CREATE**，并补"软删行不冲突 / 活跃行唯一"回归。
- `idx_skill_path`、`idx_skill_parent` 随 path/parent_id 改造重建（见 §4）。
- **性能提示**：字符串 PK/FK 使 B-Tree 索引更大、JOIN 探查更慢、page 命中率下降，尤其 skill 子树 LIKE 与大量 ref JOIN。建议迁移后做一轮 EXPLAIN 回归，必要时为热点 FK 补索引。

---

## 3. 存量数据迁移（最大风险项）：映射表 → 回写 FK → 切 PK

> 总策略：**影子列双写并存 + 映射表驱动回写 + 受控切换 + 旧列保留回滚窗口**。不追求单事务跨十几表（不可回滚），改为**分表分层、每层可校验可回滚**。

### 3.1 三段式（对每张被改实体表）

**阶段 A：建映射表 + 生成新 id（纯加法，零破坏）**

1. 对每张被改实体表 `T`，建 `id_map_T(old_id BIGINT PRIMARY KEY, new_id VARCHAR(20) UNIQUE NOT NULL, mapped_at TIMESTAMPTZ)`。
2. 对 `T` 全量存量行，生成 `new_id = <prefix>_<base58>`（生成期保证 map 内唯一），写入 `id_map_T`。生成可由受控启动期 Java 任务调 `PublicIdGenerator`（保证与运行时同算法），或迁移内 PL/pgSQL（需等价 base58 实现，建议走 Java 以单一来源）。

**阶段 B：加影子列 + 回填本表 PK 影子 + 回写所有 FK 影子（纯加法）**

3. `ALTER TABLE T ADD COLUMN id_new VARCHAR(20)`；`UPDATE T SET id_new = m.new_id FROM id_map_T m WHERE T.id = m.old_id`。
4. 对**每个指向 T 的 FK 列** `child.fk`：`ALTER TABLE child ADD COLUMN fk_new VARCHAR(20)`；`UPDATE child c SET fk_new = m.new_id FROM id_map_T m WHERE c.fk = m.old_id`（可空 FK 的 NULL 保持 NULL）。
5. **自引用**（skill.parent_id）：`UPDATE skill s SET parent_id_new = m.new_id FROM id_map_skill m WHERE s.parent_id = m.old_id`。
6. **引用完整性校验**（切换前强制门禁，**M4 加强**）：
   - (a) **漏映射检查**：对每个 FK，断言"非空 `fk` 行都有对应 `fk_new`"，`COUNT(fk) = COUNT(fk_new)`。
   - (b) **错配反向 JOIN 校验**（新增，仅 (a) 查不出错填）：断言每条 `fk_new` 反查 id_map 得到的 `old_id` **等于该行原始 `fk` 值**——即 `JOIN id_map_T m ON child.fk_new = m.new_id WHERE m.old_id <> child.fk` 必须**零行**。防"UPDATE…FROM JOIN 写错把 A 行的 fk 填成 B 的 new_id"。
   - 任一不匹配 → **停止，不进入阶段 C**。

**阶段 C：切主键 + 切外键 + 收尾（受控切片，按 §2.3 顺序）**

7. 按拓扑顺序（被引用表先），在该切片事务/分批中：
   - 删除指向 T 的 DB FK 约束。**显式名**（如 `fk_api_def_provider_system`）直接 DROP；**无显式名的**走 PG 默认名 `<table>_<col>_fkey`，但**断约束前先查 `information_schema.table_constraints` / `pg_constraint` 拿到运行库的真实约束名**（默认名可能因历史而异），不硬编码猜名（C1）。
   - `ALTER TABLE child RENAME COLUMN fk TO fk_old; RENAME COLUMN fk_new TO fk;`（FK 列切换）。
   - `ALTER TABLE T DROP CONSTRAINT <pk>; RENAME COLUMN id TO id_old; RENAME COLUMN id_new TO id; ADD PRIMARY KEY (id);`（PK 切换）。
   - 重建 DB FK 约束（新列类型 VARCHAR 对齐）、重建受影响唯一索引/普通索引。
   - **JPA 实体此时已是 `@Id String`**（代码切片与 DB 切片同发布，见 §8）。
8. **skill.path 重建**（§4）在 skill 切 PK 后同片执行。

### 3.2 回滚策略（影子列 + 旧列保留）

- **阶段 A/B 可即时回滚**：纯加列/加表，`DROP` 影子列/映射表即回到原状，业务无感。
- **阶段 C 回滚窗口**：切换时**保留 `id_old` / `fk_old` 旧列一段时间**（不立即 DROP）。若切换后回归发现问题，回滚 = 反向 RENAME（`id`→`id_new`，`id_old`→`id`）+ 恢复旧 FK 约束。旧列在该切片 live 回归通过、稳定运行 N 天后，由独立"清理切片"DROP。
- **不可整体回滚的边界**：一旦进入 §5 凭证重加密并删除旧密文/备份，则该部分进入不可逆区——故凭证片单独、最重护栏、且**最后做或独立做**。

### 3.3 多 FK 列表（user_expert_binding 等，C3 订正：无复合 PK）

`user_expert_binding`/`user_expert_override`/`user_skill_override` 等是**单列代理主键**（非复合 PK，全库 `@EmbeddedId`/`@IdClass` 0 处）。改造 = ① 自身单列 PK 走本表 id_map 改 String；② 表上**多个 FK 列各自走对应被引用表的 id_map 影子回写**（`user_id`→id_map_app_user、`expert_id`→id_map_expert、`base_skill_id`→id_map_skill），各列独立 §3.1 三段式。无"复合主键重建"特殊步骤。

---

## 4. 技能物化路径 path 用新字符串 id 重建

### 4.1 现状（已核实）

- 列：`skill.path VARCHAR(512)`（V7 建），索引 `idx_skill_path`(B-Tree)、`idx_skill_parent`。
- 构造：根（`parent_id IS NULL`）`path = '/' || id || '/'`；子 `path = parent.path || id || '/'`。
- 查询：`findByPathStartingWith(prefix)`（子树）、`countDescendants(prefix LIKE, selfId)`（后代数）、按 path 字典序排序、按 path 首段反推根 id 做缓存失效。
- **前端/orchestrator 均不消费 path**（wire 不下发 path，子技能按 sectionId 回调）——重建是纯后端内部迁移。

### 4.2 重建算法（skill 切 PK 后、同片执行）

path 链由数字 id 段组成，PK 变字符串后必须整链改为新字符串 id：

1. **根**（`parent_id IS NULL`）：`UPDATE skill SET path = '/' || id || '/' WHERE parent_id IS NULL AND deleted = false`（此时 `id` 已是新字符串）。
2. **自顶向下逐层**：按层迭代（或递归 CTE），`UPDATE skill s SET path = p.path || s.id || '/' FROM skill p WHERE s.parent_id = p.id AND s.parent_id IS NOT NULL`，重复至无更新。必须**保证父先于子**重算（按深度层级推进）。
3. **VARCHAR(512) 容量复核**：base58 段每层约 14 字符（`sk_` + 11 + `/`），512 ÷ 14 ≈ 36 层。数字 id 时代每层约 6 字符（85 层）。**深度上限从 ~85 收窄到 ~36**——需确认现网最大技能树深度 < 36（探查未取到实测最大深度，**标注待核实**：迁移前跑一次 `MAX(层级)` 校验；若逼近上限则把 path 列扩到 `VARCHAR(1024)`）。
4. **校验**：重算后断言每行 `path` 与 `id/parent_id` 一致（根 = `/id/`，子 = `parent.path + id + /`），`COUNT(broken)=0` 方为通过。
5. **索引**：`REINDEX idx_skill_path / idx_skill_parent`。子树/深度查询逻辑（LIKE 前缀、字典序排序）**对字符串 path 透明，无需改业务代码**，仅依赖重建正确性。

> ⚠️ 字典序排序变化：数字 id 时代 `/5/8/ < /5/9/` 是数字序巧合；字符串 id 后排序变为 base58 字典序，子技能展示顺序会变。若 UI 依赖此顺序需确认（多数按 name/created_at 另排，**标注待 CR 复核**）。

### 4.3 反向依赖 path 内部结构的代码（CR 必修硬伤 H1/H2，均归 B3）

path 改字符串不只是"重算数据"，还有两处**代码反向解析 path 内部结构**，不改会运行期出错：

- **H1 `AdminSkillService.rootIdOf` 链（除 path 重算外第二条硬依赖）**：现实现取 `path` 首段做 `Long.parseLong(p)` 返回 `Long`（L174-189），下游 `cacheEviction.evictExpertsReferencingAfterCommit(Long rootId)`（L170）签名为 `Long`。字符串 id 下 `Long.parseLong("sk_...")` 抛 `NumberFormatException` → 要么中断、要么（若被吞）**缓存失效静默失准**（编辑技能后引用它的岗位缓存不刷新）。
  - 改造：`rootIdOf` 解析改为**按 `/` 切分取首段字符串**、返回 `String`；`evictExpertsReferencingAfterCommit` 及其调用链签名 `Long → String`。归 B3，随 skill 片同发。
- **H2 LIKE 前缀未转义（误匹配子树）**：`countDescendants` / `findByPathStartingWith` 用 `path LIKE :prefix%` 求子树，而 base58 id 含分隔符 `_`，`_` 在 SQL LIKE 中是**单字符通配符**。例：前缀 `/sk_aaa/` 会把 `/skXaaa/`（不存在但同形）等误匹配，更现实的是 `_` 通配导致**跨子树污染计数/查询**。
  - 改造：LIKE 加 `ESCAPE '\'` 并对 prefix 中的 `_` `%` `\` 转义后再拼 `%`；或改用 `path LIKE prefix || '%'` 仍需转义 prefix 内通配符。
  - **必补回归用例**：构造两个 id 仅在"被 `_` 误匹配的位置"不同的兄弟子树，断言 `countDescendants`/子树查询**互不串扰**（"带 `_` 的 id 跨子树不误匹配"）。

---

## 4.4 认证 / 隔离链路改造（Bu 用户切片 · 本片最高风险 · 安全重点）

> 归属：**Bu 用户切片**（随 `app_user.id` BIGINT→`usr_xxx` 同片、同发布、同回滚）。这是全线 ID 改造里**唯一直接触碰认证主体与用户数据隔离**的改造面，风险高于 path/wire/FK，护栏单列。

### 4.4.1 链路全貌（`app_user.id` Long→String 的级联面，CR 订正后）

> **JWT 表述订正（后端 CR）**：userId 不在 `sub`——`sub` 是 **username**（不动）；userId 在 **`uid` claim（Long）**。改动点 = `JwtAuthFilter` L45-46 `claims.get("uid", ...)`（`Long`→`String`，即 `get("uid", String.class)` 口径）+ `JwtTokenProvider.generate(...)` 签发 uid（`Long → String`）。系统**无 refresh-token / remember-me**，故"强制重登"可行、**零兼容层**。

| 环节 | 现状（Long） | 改造（String `usr_xxx`） | 风险 |
|---|---|---|---|
| JWT `uid` claim（**非 sub；sub=username 不动**）| `uid` = 数字 user id | `uid` = `usr_xxx` 字符串 | 签发(`JwtTokenProvider.generate`)/解析(`JwtAuthFilter` L45-46 `get("uid",...)`)两侧必须同时改类型；旧 token uid=数字 → 失效 |
| 登录签发 | `generate(...)` 写 `uid`(Long) | 写 `uid`(String) | 改后存量 token 的 uid 仍数字 → 解析后 requireUserId 拿数字串，无法在已切 VARCHAR 列命中 → **强制重登**（无 refresh/remember-me，可行） |
| `SecurityUtils.requireUserId()` | 返回 `Long` | 返回 `String` | **消费面 CR 重估：126 调用点 / 228 声明 / 79 文件**（非~54）；漏改一处 → 编译失败暴露（好）或字符串/数字混比（隐患） |
| `SecurityUtils.requireAdminUserId()`（**CR 补**）| 返回 `Long` | 返回 `String` | **11 处**，同样返回 Long、须一并改（同 requireUserId） |
| 按 user_id 过滤的仓储 | `WHERE user_id = :uid`(Long 绑 BIGINT 列) | `WHERE user_id = :uid`(String 绑 VARCHAR 列) | **过滤列必须与 app_user.id 同片切为 VARCHAR（铁律 4），否则字符串过滤 BIGINT 列查不到 → 隔离破裂** |
| `InternalMemoryController` `@RequestParam @NotNull Long userId`（**CR 补 · 数字注入点**）| 应用态内部 API 直收 Long userId | 改 `String` | **纠正"都走 requireUserId、无遗漏数字注入点"的表述**——此内部 API 旁路 requireUserId 直注入数字 userId，须改 String，且其 **Python 调用方（§6 wire）同步**改 int→str |

> **消费面重估口径（后端 CR）**：requireUserId **126 调用点 / 228 声明 / 79 文件** + requireAdminUserId **11 处** + InternalMemoryController 注入点 + **30 个测试文件**。即 Bu 的代码改造面是全库最大扇出 + 认证核心，**工作量与回归面远大于初估 ~54**——**不拆片（隔离/认证须原子切），但按独立大工作量单独排期**（详见 §4.4.3）。

### 4.4.2 安全改造护栏（保证改造期间隔离不破裂）

1. **过滤列与主键同片切（铁律 4，最关键）**：`memory_item.user_id`/`personal_doc.user_id`/`session.user_id`/`memory_extract_cursor.user_id`/`user_tool_favorite.user_id`/**`memory_import_job.user_id`（CR 补：有 `findByUserIdAndIdempotencyKey` + `getUserId().equals(userId)` 归属过滤，属隔离链路）** 等**一切运行时按 currentUserId 过滤的 user_id 列**，必须与 `app_user.id` 在 Bu **同片**从 BIGINT 切 VARCHAR（影子回写 + 切列 + 重建索引）。任何"主键切了、过滤列没切"的中间态都会让 String currentUserId 过滤 BIGINT 列 → 0 行 → 用户查不到自己数据。最终隔离列清单见 §8.0u②。
2. **跨表 JOIN 硬约束（CR 补 · 两列必须同窗口同切）**：`memory_extract_cursor.user_id` 与 `session.user_id` 之间有 `ON c.user_id = s.user_id` JOIN，且 `memory_extract_cursor` 有 `ON CONFLICT(user_id, session_id)` 唯一约束——**这两列必须在 Bu 同一窗口同切 VARCHAR**，绝不允许一列切了另一列还是 BIGINT（否则 JOIN 类型失配 / 字符串-数字比不上 / ON CONFLICT 失效）。**迁移脚本须显式断言两列同切完**（阶段 C 切换后校验两列均为 VARCHAR 才放行）。
3. **代码与 DB 同发布同回滚**：`requireUserId()`/`requireAdminUserId()` Long→String、JWT `uid` claim 签发/解析、126 调用点/228 声明/79 文件、`InternalMemoryController` 注入点 + 仓储**与 Bu 的 DB 切 PK 同一次发布**；回滚则一并回滚（反向 RENAME 恢复 BIGINT 列 + 回退代码）。禁止代码先行或 DB 先行造成 Schema-代码错配。
4. **迁移窗口冻结写**：Bu 切换窗口内冻结用户态写入（登录可暂停或置维护态），避免迁移中产生"新字符串 user_id 行 / 旧数字 user_id 行"混杂。
5. **值重映射统一走 `id_map_app_user`**：所有 user_id 列影子回填一律 `UPDATE child SET user_id_new = m.new_id FROM id_map_app_user m WHERE child.user_id = m.old_id`，门禁用 `MigrationIntegrityGate`（(a) 漏映射 COUNT 严格相等——结构性列非空必须全有 new；(b) 错配反向 JOIN 零行）。**结构性 user_id 列用严格 (a)（非弱审计的容忍口径）**。
6. **JWT `uid` 切换时机**：在 Bu 发布瞬间，`uid` claim 由数字改 `usr_xxx`（`sub`=username 不动）。**存量旧 token（uid=数字）一律失效、强制重登**（旧数字 uid 经 requireUserId 后无法在已切 VARCHAR 的 user_id 列命中）。系统**无 refresh-token / remember-me**，强制重登可行；发布说明标注"用户需重新登录"。不做"旧 token 数字 uid → 查 id_map 换 usr_xxx"的兼容层（增加攻击面与复杂度，且登录态可重建，**零兼容层**）。
7. **user_biz_credential 的特殊窗口**（与 §5.5 联动，CR 订正风险等级）：Bu 只切 `user_biz_credential.user_id` FK 列、**不重加密其密文**（重加密下沉 B4）。**AI CR 标注利好：当前全后端仅 3 处 `decrypt`（均 api/mcp），无 user_biz_credential 运行时解密消费方** → Bu→B4 窗口 GCM 失配风险实质为"低/潜在"。**护栏采纳①冻结**（业务凭证写入冻结跨 Bu→B4；读因无消费方实际不触发解密）；**②userId-段-旧数字 shim 仅作"未来出现新解密消费方且不可冻结"时的备选**，且若启用，**B4 重加密后强制拆除 shim 列为验收门禁**。
8. **隔离回归红线（QA 必跑，CR 补凭证断言）**：Bu 发布后必须以"切换前已有数据的真实用户"登录，断言其 `memory_item`/`personal_doc`/`session`/`memory_import_job`/历史会话**全部可见**，**且 `user_biz_credential` 托管凭证 status 按新 `usr_xxx` 可命中**（防切 user_id FK 列时丢归属——即便密文未重加密，托管列表/status 查询走 user_id 过滤，须验新 usr_xxx 能查到自己的凭证条目）。不是 happy-path 新建用户。任一历史数据/凭证条目查不到即判隔离破裂、立即回滚。这是本片验收的硬门禁。

### 4.4.3 工作量与排期重估（后端 CR）

- 消费面 CR 实测：`requireUserId` **126 调用点 / 228 声明 / 79 文件**、`requireAdminUserId` **11 处**、`InternalMemoryController` 数字注入点 1 处、按 user_id 过滤仓储若干、**30 个测试文件**。这是**全库最大扇出 + 认证核心**，工作面远大于初估 ~54。
- **不拆片**：认证主体类型切换 + 隔离 user_id 列切换必须**原子**（任一中间态都会破隔离），故 Bu 不可再细分。
- **当独立大工作量排期**：Bu 体量接近一个独立里程碑，排期上按"大片"对待（独立窗口、独立回归、独立回滚演练），不与相邻片压缩进同一发布。Bu 在 B2 之后实施。

---

## 5. 凭证重加密（不可逆点 · 单独成片 · 最重护栏）

### 5.1 现状（已核实，三处 AAD 绑数字 id）

| 场景 | 表.列（类型）| AAD 拼装 | 密文格式 |
|------|------|---------|---------|
| 业务系统用户凭据 | `user_biz_credential.credential_cipher`(TEXT) | `userId + "\|" + bizSystemId` (UTF-8)　**双段 AAD：userId=app_user.id（Bu 迁）、bizSystemId=biz_system_def.id（B4 迁）→ 重加密下沉 B4 一次完成，见 §5.5** | `keyAlias:base64(iv):base64(cipher+tag)` |
| MCP stdio env | `mcp_def.env_config`(JSONB，value 加密 key 明文) | `mcpId + "|" + (-1L)`（域常量 `MCP_ENV_AAD_DOMAIN=-1L`）| 同上（每 value）|
| API 密钥 | `api_def.auth_config`(JSONB，`valueCipher` 字段) | `0L + "|" + api_def.id`（`SYSTEM_API_KEY_USER_ID=0L`）| 同上 |

- 算法：`AES/GCM/NoPadding`，AES-256，12B 随机 IV，128bit tag；密钥经 `KeyProvider`（master-keys map + active-key-alias），由环境变量/`application-local.yml` 注入，启动 fail-fast。
- 解密：`CredentialCryptoService.decrypt(cipherText, userId, bizSystemId)`，AAD 不匹配则 GCM tag 校验失败抛 `IllegalStateException`。
- **含义**：PK 变字符串后，旧密文用旧数字 AAD 加密，新代码用新字符串 AAD 解密 → **GCM 校验必然失败、凭证全部解不开**。必须逐条"旧 AAD 解密 → 新 AAD 重加密"。这是**全程唯一不可逆段**。

### 5.2 为什么必须 Java 迁移、不能纯 SQL

重加密需要加密密钥 + AES-GCM 逻辑 + AAD 拼装，纯 SQL/PLpgSQL 无法做。项目**当前无 Java-based Flyway migration 先例**（仅 SQL 脚本），故采用**受控启动期 data-fix 任务**（一次性、带开关、可幂等重跑）而非 Flyway Java migration（避免新引 `flyway` Java 装配与迁移历史耦合）。该任务能注入 `CredentialCryptoService` + `KeyProvider`，复用同一套加解密。

> 决策点（给 CR）：受控启动期 data-fix vs Flyway Java migration（需加 flyway 对 Java 的装配）。建议**前者**（不改 Flyway 形态、易加开关与幂等、可独立触发与回滚）。

### 5.3 重加密执行流程（最重护栏）

**前置（迁移前，强制）**
- P1. **全量逻辑备份**：`pg_dump` 三张表（user_biz_credential / mcp_def / api_def）+ id_map 映射表，落到受控位置，校验可还原。**无备份不得启动重加密。**
- P2. **冻结写入**：重加密窗口内禁止凭证相关写操作（停相关入口 / 维护态），避免迁移中产生新旧混杂密文。
- P3. **幂等标记设计**：每条密文迁移状态可判定（推荐：迁移前在密文串加临时迁移前缀/或建 `cred_remap_log(table, row_pk, status, done_at)` 记录已完成行）。重跑时**已完成的跳过**（不二次加密）。

**逐条重加密（对每条密文）**
1. 用**旧数字 AAD**（旧 userId/bizSystemId/mcpId/api_def.id，从 id_map 反查 old）`decrypt` → 得明文。
2. **解密失败立即中止**：任一条解密失败（GCM 校验/密钥缺失）→ **停止整个任务、不写任何新密文、触发回滚（恢复备份）**。绝不"跳过坏行继续"。
3. 用**新字符串 AAD**（new userId/bizSystemId/mcpId/api_def.id）`encrypt` → 新密文。
4. 写回新密文 + 标记该行已迁移（幂等）。

**重加密后逐条双校验（强制）**
5. 对每条**新密文**，立即用**新 AAD `decrypt` 验证可解且明文 == 原明文**（双校验：写得进 + 解得出 + 内容一致）。任一条双校验失败 → **中止 + 回滚备份**。
6. 全量双校验通过、计数核对（已迁移条数 == 应迁移条数）后，方视为该片成功。
7. 备份保留 N 天回滚窗口后再清理（清理即进入不可逆，单独操作）。

**护栏清单（铁律）**
- [ ] 迁移前全量备份且验证可还原（无备份不启动）
- [ ] 重加密窗口冻结凭证写入
- [ ] 解密失败 → 立即整体中止 + 回滚，绝不跳过坏行
- [ ] 重加密后逐条解密双校验（可解 + 内容一致）
- [ ] 幂等（已迁移行跳过，重跑不二次加密）
- [ ] 计数核对（应迁移 == 已迁移 == 双校验通过）
- [ ] 密钥、明文绝不落日志（沿用现有 fail-fast 与不泄露约定）
- [ ] 此片**单独发布、单独回归、不与其他改动混提**

### 5.4 与 PK 切换的时序（M2 已锁定，不再悬空）

**CR 决议：先切三表 PK、后在同一维护窗口重加密。** 不再保留"两序均可"。理由：重加密的**新 AAD 必须用 mcp_def/api_def/user/biz 的真实新主键值**；若先重加密再切 PK，AAD 里用的"新 id"与表上尚未切换的真实主键解耦，存在"AAD 用值 ≠ 主键真值"的隐患窗口。锁定顺序：

1. 完成三表（及相关 FK 表）§3 全流程**切 PK**（新字符串主键已落到表上、id_map 在手）。
2. **同一维护窗口内**紧接执行 §5.3 重加密：从 id_map 取每行 old→new，用 **old 数字 AAD 解密 → new 字符串主键真值 AAD 重加密**。
3. 期间凭证写入冻结（P2），**窗口外不得有解不开的凭证暴露给业务**（切 PK 后、重加密前的瞬态密文用旧 AAD，业务此刻被冻结，不触发解密）。

> 该顺序使"主键真值 == AAD 所用 id"恒成立，消除决策悬空。

### 5.5 user_biz_credential 双段 AAD · 重加密下沉 B4（Bu 裁决联动，铁律 1′）

> 背景：`user_biz_credential.credential_cipher` 的 AAD=`userId|bizSystemId`，**两段都是会迁移的主键**——`userId`=`app_user.id`（**Bu** 迁）、`bizSystemId`=`biz_system_def.id`（**B4** 迁）。原 §5.1 只标注"PK 变字符串→密文解不开"，未拆分两段分属不同片的事实；本节补全。

**为什么不在 Bu 重加密（避免双重不可逆活）**：若 Bu 切 app_user.id 时就重加密（new userId + 旧数字 bizSystemId），到 B4 切 biz_system_def 又得再次重加密换 new bizSystemId ⇒ **同一密文两次重加密 = 两段不可逆活**，且 Bu 沦为不可逆片，打破"B4 唯一不可逆"。故按**铁律 1′** 下沉到 B4 一次完成。

**B4 一次重加密的执行（在 §5.3 流程内，针对 user_biz_credential 这一类）**：
1. 前提：Bu 已产出并保留 `id_map_app_user`（old 数字→new `usr_xxx`），B4 本片产出 `id_map_biz_system_def`。
2. 对每条 `user_biz_credential` 密文：用 **旧数字双段 AAD**（`old_userId | old_bizSystemId`，分别从 `id_map_app_user` / `id_map_biz_system_def` 反查 old，或从 `user_id_old` / `biz_system_id_old` 旧列取）`decrypt` → 明文。
3. 用 **新字符串双段 AAD**（`usr_xxx | bz_yyy`）`encrypt` → 新密文写回。
4. 双校验（new AAD 可解 + 内容一致）、幂等标记、计数核对——与 §5.3 三类密文同一套护栏。
5. **时序**：在 B4 内须等 `app_user.id`（Bu 早已切）与 `biz_system_def.id`（本片切）都已是字符串、两 id_map 齐备后执行（M2 顺序：先切 biz_system_def PK，后同窗口重加密；userId 段早在 Bu 切定）。

**Bu→B4 窗口护栏（AI CR 定稿：风险降级 + 采纳①冻结）**：

- **风险实测降级**：AI CR 核实**全后端仅 3 处 `decrypt`（均 api/mcp），当前无 user_biz_credential 运行时解密消费方** → Bu→B4 窗口内并无现存调用路径会拿 `usr_xxx` 拼 AAD 去解 user_biz_credential 密文，失配风险实质为**"低/潜在"**（潜在=未来若新增解密消费方才显现）。
- **① 冻结（定稿采纳）**：Bu 发布起冻结"业务系统用户凭据"**写入**跨 Bu→B4，B4 重加密完成解冻。读因无消费方实际不触发解密。最简、最稳，凭证功能本就建议迁移期冻结。
- **② 解密临时 shim（仅备选）**：**仅当未来出现 user_biz_credential 解密消费方且该窗口不可冻结时**，才启用——窗口内 user_biz_credential 解密的 userId AAD 段临时取旧数字值（从 `app_user.id_old`/`id_map_app_user` 反查 `usr_xxx`→old），不取 live `requireUserId()`。**一旦启用，B4 重加密后强制拆除 shim 列为验收门禁**（防 shim 残留成隐患）。复杂度与攻击面更高，非默认。

> 结论：user_biz_credential 的**不可逆段（重加密）只在 B4**；Bu 对它只做可回滚的 user_id FK 列切换。不可逆片仍唯一（B4）。

---

## 6. Java↔Python wire 契约改造（N1 教训锁区）

### 6.1 wire 字段清单（已核实）

| wire JSON key | Python(contracts.py) | Java(OrchestrateRequest.java) | 用途 | 数字运算 |
|---|---|---|---|---|
| `skillId` | `EffectiveSkill.skillId: Optional[int]` | `SkillPayload.skillId: Long`(无@JsonProperty) | 技能 id | 透传 |
| `expertId` | `EffectiveExpert.expertId: Optional[int]` | `EffectiveExpertPayload.positionId: Long` **@JsonProperty("expertId")** | 岗位 id | 透传（注意 wire 名=expertId、内部=positionId 的桥接）|
| `sectionId` | `SectionIndex.sectionId: Optional[int]` | `SectionIndexPayload.sectionId: Long` | 子技能索引 | **有数字解析/集合/查询** |
| `sessionId` | `OrchestrateRequest/ToolExecuteRequest.sessionId: Optional[int]` | `Long` | 会话 id | runner.py:89 转 str |
| `userId` | `UserContext/ToolExecuteRequest.userId: Optional[int]` | `Long` | 用户 id | 透传（**`userId` int→str 随 Bu 用户切片同发布**——app_user.id 字符串化时 wire userId 即变；与 sessionId/skillId 等的 B3 wire 改造分属不同片，但 wire 契约测试需一并覆盖 userId 的字符串化）|

### 6.2 两侧同步改动点（必须同一提交）

**Python（`orchestrator/app/`）**
- `integration/contracts.py`：`skillId/expertId/sectionId/sessionId/userId` 全部 `Optional[int]→Optional[str]`。
- `runner.py:89`：`str(req.sessionId)` 逻辑（已是 str 化则简化）。
- `graph/nodes.py:546-547,1074-1078`：`_to_int(...)` → 改为直接用字符串（`_to_str` 或去转换）；session_id/userId 回填工具请求时不再转 int。
- `graph/prompt.py:134-148`：`sectionId` 仅作字符串插入显示，**无需改逻辑**（但确认类型变更不破坏 `is not None` 过滤）。

**Java（`backend/.../orchestration/` 等）**
- `dto/OrchestrateRequest.java`：`SkillPayload.skillId`、`SectionIndexPayload.sectionId`、`EffectiveExpertPayload.positionId`(@JsonProperty("expertId") 保留名)、`sessionId`、`userId` 由 `Long → String`。**@JsonProperty wire 名一字不改**（N1：锚 wire 名，改类型不改 key）。
- `skill/tool/section/SkillSectionExecutor.java`：`parseSectionId()`(L92-108) 删 `Long.parseLong` 分支，直接取字符串；`Long sectionId`→`String`；`Set<Long> allowed`→`Set<String>`（L72-73）。
- `orchestration/OrchestrateRequestAssembler.java`：`sectionPayloads`/`allowedSectionIds`(L160-162)、`toolSkillIds`(L146-147) 由 Long → String。
- `orchestration/run/OrchestrationRun.java`：`Set<Long> allowedSectionIds`→`Set<String>`、`Map<String,Long> toolSkillIds`→`Map<String,String>`(L40)。
- `skill/repository`：`findById(sectionId)` 入参随 PK 改 String（SkillSectionExecutor L79）。
- **测试**：`OrchestrateRequestWireContractTest.java` 测试数据 `7L`→`"sk_..."`、反序列化断言改 String（L42-43,100-101,183）。

### 6.3 N1 锁区铁律

- **JSON key 一字不改**（`skillId/expertId/sectionId/...`），只改两侧类型 int↔String。`expertId↔positionId` 桥接维持（@JsonProperty 不动）。
- **Java/Python 必须同一 PR/commit 落地**，禁止分离发布（否则一侧 int 一侧 str → 反序列化失败 → 办事链路全断）。
- **按字段所属片切，但每个字段的两侧必须同片同提交**：`userId` int→str 随 **Bu**（app_user 字符串化）、`skillId/sectionId/sessionId` 随 **B3**（skill/会话字符串化）、`expertId` 随 **B2**（expert 字符串化）。规则是"**每个 wire 字段的 Java 侧 + Python 侧在同一片同一 commit 改**"，不是"所有 wire 字段必须挤在同一片"。**易错点**：Bu 改 `userId` 时 `OrchestrateRequest.java` 里 `userId Long→String` 只改 userId 一项、其余 wire 字段保持原类型；B3 再改其余——两次都要跑 wire 契约测试，且测试数据按"该片已字符串化的字段用 `usr_xxx`/`sk_xxx`、未切的仍数字"组织，避免一次性全改导致与未发布片错配。
- **InternalMemoryController 注入点（CR 补 · 随 Bu）**：除 orchestrate wire 外，`InternalMemoryController` 的 `@RequestParam @NotNull Long userId`（应用态内部 API，旁路 requireUserId 直收数字 userId）须改 `String`，**其 Python 调用方同步改 int→str（Java/Python 同提交）**——这是除 §6.1 wire 字段外的第二个 Java↔Python userId 接口面，**纠正"userId 都走 requireUserId、无遗漏数字注入点"的旧表述**，须随 Bu 一并改并入 wire 契约/集成测试。
- wire 契约测试是生产约束红线，改动后必须先绿。

---

## 7. 对外面：路由 / @PathVariable / 前端清理

### 7.1 后端路由 `:\d+` 放宽（41 条，5 个 Controller）

| Controller | 条数 | 备注 |
|---|---|---|
| SkillFileController | 13 | 全部 `{skillId:\d+}` |
| PlatformSkillFileController | 12 | 同结构 |
| PlatformSkillController | 7 | 详情/发布 |
| PositionSkillController | 6 | `{id:\d+}`/`{skillId:\d+}` |
| SkillReferenceController | 3 | `{id:\d+}`，**注释"全仓铁律：防字面量 /platform-skill-candidates 误捕获"** |

- 去掉 `\d+` 后字符串 id 路由方可命中。**易漏点**：字面量路径（`/import-zip`、`/platform-skill-candidates`、`/skills/tool-picker` 等）与 `{id}` 变量路由的冲突。放宽正则后需靠 **Spring PathPattern 优先级**（精确字面量优先于变量）保证字面量不被 `{id}` 误捕获；并补单测覆盖每个字面量端点。新字符串 id 带前缀（`sk_`），与字面量词天然不同形，进一步降低冲突，但仍需测试兜底。

### 7.2 `@PathVariable Long → String`（48 处）

集中在上述 5 个 Controller（SkillFile 13、PlatformSkillFile 12、PlatformSkill 7、PositionSkill 9、SkillReference 6）。逐个 `Long → String`，并下查 Service 层签名（`findById` 等）随 PK 类型连改。**易漏点**：Service/Repository 仍 `Long` 会编译失败暴露，但跨模块调用（如 admin 调 position）要全链改。

### 7.3 前端

- **router/index.js 4 条 `(\d+)`**：TaskEdit `tasks/:id(\d+)/edit`(L26)、TaskDetail `tasks/:id(\d+)`(L32)、AdminSkillEdit `/admin/skills/:id(\d+)/edit`(L203)、SysConfigSkillEdit `/admin/platform-skills/:id(\d+)/edit`(L211) → 去 `(\d+)`。**去约束后补字面量优先级单测**（如 `tasks/new` 不被 `tasks/:id` 误吞、`skills/tool-picker` 等）。
- **23 处 `Number()/parseInt()` 清理（前端低估订正：实 23 处，非 13）**，分三类：
  - (i) **转换**：`FrontLayout.vue:26`、`Personalize.vue:18,100`、`AdminSkillEditPage.vue:90`、`TaskDetail.vue:61`、`useRebindFlow.js:69`、`AgentLane.vue:132,134`。
  - (ii) **`Number(a) === Number(b)` 归一比较（此前漏列的一类）**：`FrontLayout`、`positionBinding.js:13`、`PositionPickerDialog.vue:34,55` 等把两侧都 `Number()` 后比较——改为字符串严格相等。
  - (iii) **守卫分支（删逻辑级，单列）**：`Chat.vue:313` `const id = Number(rawId); if (!Number.isFinite(id)) return` —— 字符串 id 经 `Number()` 成 `NaN` → **守卫静默 return、岗位切换失效**。须删 `Number()`+`isFinite` 守卫，改字符串非空判定。
- **重点易漏点 AgentLane.vue 拖拽 dataTransfer**：L113-114 写入 `String(skill.skillId)`/`String(agent.agentId)`（已字符串化，OK）；L132-134 读取用 `Number(getData(...))` 反序列化、L138 同泳道判定 `fromAgentId === toAgentId`、L139 `findIndex(s => s.skillId === skillId)` —— 读取处去掉 `Number()`，保持字符串比较，否则字符串 id 经 `Number()` 变 `NaN` 致拖拽错乱。
- **companion.js localStorage key `${userId}:${positionId}`**：key 形态随 id 字符串化变更 → **老昵称缓存失效**（非阻断，仅个性化昵称需重设）。**发布说明标注**，无需数据迁移。
- **URL 拼接 `${id}`**（~102 处，16 个 api 文件）：模板字符串，**字符串 id 天然兼容，零改**。
- **localStorage**（如 boundPositionId）：存取本就字符串，去掉读取后的 `Number()` 即可。
- **前端测试改造量（计入工时）**：**28 个测试文件 / 216 处 id 字面量**断言需从数字改字符串（`positionId: 5` → `'ps_...'` 等）。

#### 7.3.1 灰度兼容策略（关键，决定前端何时清 Number）

现有 `Number(a) === Number(b)` 归一比较有一个**意外的灰度红利**：它恰好兼容"一侧已切字符串、另一侧仍是数字"的中间态（两边都 `Number()` 后，纯数字 id 仍能比上）。因此：

- **后端按 B1/B2/B3 分片切表时，前端 Number 清理不同步进行**——保留 `Number()` 兜底，让灰度期新旧 id 形态都能比对，避免"某实体切了字符串、前端却已去 Number 致比较失败"。
- **待所有对外暴露的被改实体切完字符串后（即 B3 末，skill/任务等最后一批对外 id 已字符串化），在 B3 尾统一去除 Number/parseInt**，换字符串严格相等。**注意：前端统一清理必须在 B3 完成，不得拖到 B4——B4 是纯凭证不可逆片，不混任何前端/对外口径改动。**
- 例外：(iii) 类 `Chat.vue` 守卫和 (ii) 类纯归一比较一旦该实体已是字符串就会坏——这些**随对应实体切换片同步改**（不能等收尾），其余转换类(i)可留到收尾。CR 时按实体逐项标"随片改 / 收尾改"。

---

## 8. 分期（6 切片，B1 实施前按凭证耦合 + 跨片 FK 孤儿重排；B2 FK 穷举后追加"结构性 FK / 弱审计列"解耦裁决）

> **前置时序**：B 排在"删 Agent 技能游离化（V44，进行中/已落地）"**之后**启动，避免同时大改 skill 表叠加迁移/回归。Flyway 从 **V45** 起。每片：CR（后端→架构师 / 前端→架构师+UI / wire→交叉 / 凭证→AI专家+架构师）+ QA 真机回归 + 明确回滚点。

### 8.0 B2 FK 穷举裁决（结构性 FK vs 弱审计列解耦，2026-07-01）

> 来源：`全线ID改造-B2-FK清单.md` 穷举 `app_user.id` 引用面时，暴露原 §8 B2 留白的切片边界问题——`created_by`/`updated_by` 等**无 DB 外键约束的弱审计归属列**（~32 列 / 9+ 表，含 B3/B4 所属表）是否要在 B2 改表结构。

**裁决：采纳候选 (B)（解耦），并新增独立"审计归属收尾片 **B5**"承接弱审计列。**

- **app_user 的引用面分两类，按"有无 DB FK 约束"分治：**
  - **结构性 FK（有 DB 外键约束）** → **必须与 `app_user.id` 同片迁（B2）**。理由：切父 PK 时若子表 FK 列仍是 BIGINT、约束仍在，会出现悬挂引用 / 重建约束类型失配 / NOT NULL 失配——这是**结构完整性硬约束**，不可延后。
  - **弱审计列（无 DB 外键约束：`created_by`/`updated_by` 及若干逻辑 `user_id`/`owner_user_id`/`submitter`/`reviewer`）** → **解耦，归 B5**。理由：① 无 FK 约束 → 切 app_user PK 不会因它们悬挂、不会建约束失败（与结构性 FK 本质不同），可安全延后；② 它们与已落地的**审计底座片（V46，`audit_log.target_id → VARCHAR`）同类**——审计归属是**横切关注点**，宜集中处理而非散在每个 PK 迁移片；③ 若按候选 (A) 让 B2 去改 B3/B4 所属表（skill/skill_file/skill_table_ref/skill_resource/mcp_def/api_def/biz_system_def 等）的审计列，B2 的 blast radius 跨片碰这些表结构，与"每片只动本片归属表"的分片原则相悖、增大回归面与返工风险。

- **为何 (B) 安全而非偷懒**：弱审计列改不改**不影响结构完整性**，只影响**审计归属正确性**。归属正确性靠 B5 在所有 PK 片之后用各实体 id_map 批量重映射值补齐，不依赖"与父表同片"。这与有约束的结构性 FK（不同片即破完整性）是本质不同的两类，故可分治。

- **B5 放在哪**：放在**所有 PK 迁移片之后（B4 之后）**。硬约束：B5 须能拿到**全部被迁实体的 id_map**（app_user / expert / agent / skill / mcp / api / biz / data_* / scheduled_task …）才能把弱审计列里的旧数字值重映射成新字符串 id；各实体的 id_map 在其迁移片产生并**保留至 B5 用完**（旧列清理片不得早于 B5）。B5 自身**无凭证、可回滚**，不破坏"B4 是唯一不可逆片"的结论（B4 仍是不可逆活的终点，B5 是其后的纯审计归属收尾，无不可逆活）。

### 铁律（重排根因，写入文档）

- **铁律 1 · 凭证表 PK 迁移必须同片重加密**：凡 PK（或被别表 AAD 引用的 id）参与了密文 AAD 的表，其 **PK 数字→字符串迁移与存量凭证重加密必须在同一切片、同一维护窗口完成**，绝不拆到不同片。一旦只切 PK 不重加密，旧密文用旧数字 AAD 加密、新代码用新字符串 AAD 解密 → GCM 校验必败、凭证全部解不开。**受影响三表：`mcp_def`（AAD=自身 id|-1L）、`api_def`（AAD=0|自身 id）、`biz_system_def`（其 id 进 `user_biz_credential` 的 AAD=userId|bizSystemId）** → 三表 PK + 其 FK + 三类凭证重加密全部收进 **B4**。
- **铁律 1′ · AAD 跨多个【会迁移的】主键且分布在不同片时，重加密落"最后确定的那一片"一次完成（Bu 裁决新增）**：当一张凭证表的 AAD 引用了**多个会迁移的主键**、且这些主键分布在不同切片时，其重加密**绝不在中途分段进行**（每段重加密都是一段不可逆活 → 双重不可逆 + 中间失配窗口），必须**延后到所有【会迁移的】AAD 参与主键都已切完的那一片一次性重加密**。**典型：`user_biz_credential` 的 AAD=`userId|bizSystemId`，userId=app_user.id（Bu 迁）、bizSystemId=biz_system_def.id（B4 迁）** → 其重加密落 **B4**（两 id_map 齐备，旧数字双段解密→新字符串双段一次重加密）；**Bu 只切其 user_id FK 列、不动密文**（可回滚）。窗口护栏见 §8.0u③/§5.5。
  - **限定（CR 补，防误延后 mcp/api）**："多主键"专指**多个会迁移的主键**。AAD 里**含固定域常量**（`mcp_def.env_config` 的 `-1L`、`api_def.auth_config` 的 `0L`）的，那一段是**不变常量、不是会迁移的主键**，故 mcp/api 的 AAD 实际只有**单个会迁移主键**（自身 id）→ 仍归**铁律 1**（PK 迁移与重加密同片，全在 B4），**不适用铁律 1′ 的"延后/分段"讨论**，绝不能因 1′ 把 mcp/api 误判为"跨片需延后"。
  - **推论：Bu 无不可逆活，B4 仍是唯一不可逆片。**
- **铁律 4 · 结构性 user_id 列必须与 app_user 同片切，否则用户数据隔离破裂（Bu 裁决新增）**：凡运行时按 `currentUserId` 过滤的 user_id 列（`memory_item.user_id`/`personal_doc.user_id`/`session.user_id` 等结构性列），必须与 `app_user.id` **同片（Bu）**从 BIGINT 切到 VARCHAR。否则 `app_user.id` 已是 `usr_xxx` 而过滤列仍 BIGINT → 字符串 `currentUserId` 过滤 BIGINT 列匹配不上 → **用户查不到自己数据 → 隔离破裂**。这是"结构性 FK 同片"（铁律 3）在隔离安全维度的强化：判定不仅看"有无 DB 约束"，还看"是否参与运行时隔离过滤"——参与隔离过滤的逻辑 user_id 列即便无 DB 约束，也按结构性列处理、必与 app_user 同片（区别于纯归属用途的弱审计 created_by/updated_by 归 B5）。
- **铁律 2 · 被 NOT NULL FK 引用的表，其 PK 迁移须与子表 FK 影子回写同片**：否则单独切父表 PK、子表 FK 留后片 → 破引用完整性 / NOT NULL 失配。**典型：`data_table_def`** 被 `data_field_def.table_def_id` / `data_record.table_def_id`（V18，NOT NULL）+ `skill_table_ref.table_def_id`（V20，NOT NULL）引用 → data_table_def 移入 **B2**，其 B2 层子表 FK 同片处理；跨到 B3 的 `skill_table_ref.table_def_id` 按拓扑**在 data_table_def 迁移片（B2）做影子回写**（影子列先建好，B3 切 skill_table_ref 自身 PK 时该 FK 已就绪）。
- **铁律 3 · 结构性 FK 必须同片，弱审计列可解耦延后（B2 FK 穷举新增）**：判定标准是**有无 DB 外键约束**。
  - **有 DB FK 约束（结构性 FK）** → 与被引用父表 PK **同片**迁（影子回写 + 切列在父 PK 同片），否则破结构完整性。
  - **无 DB FK 约束（弱审计列 / 逻辑归属列：`created_by`/`updated_by`/逻辑 `user_id`/`owner_user_id`/`submitter`/`reviewer` 等）** → 当**横切关注点**，统一改 VARCHAR + 按各实体 id_map 重映射值，归**审计归属收尾片 B5**，**不绑在各 PK 迁移片**（与审计底座 V46 `target_id` 一脉相承）。
  - **区分动作**：① 弱审计列的**列类型改 VARCHAR** 在 B5；② 弱审计列的**值重映射（旧数字→新字符串 id）** 也在 B5（须晚于所有 PK 片、能拿到全部 id_map）；③ 切勿在 B2/B3/B4 顺手把别片表的弱审计列也改了——会扩大本片 blast radius 且无完整性收益。

### 8.0u app_user 单独成"用户切片 Bu"裁决（2026-07-01，PM 已采纳）

> 来源：B2 收窄实施中，复核 `app_user.id` 引用面与认证链路耦合后，把 `app_user` 整体移出 B2、单独成 **Bu 用户切片**。本节定义该片并厘清它对"不可逆片边界"的冲击与新结论。

**裁决：`app_user` 整体移出 B2，单独成「Bu 用户切片」，位次 B2 之后、B3 之前。`user_biz_credential` 的密文重加密下沉 B4（不在 Bu）。**

**① 为什么单独成片（三条根因）**
- **扇出最大**：`app_user.id` 是全库扇出最高的主键，`user_id` 遍布 30+ 表；与 expert/agent/数据表链混在一片会让 B2 blast radius 失控。
- **触达认证/隔离核心**：`app_user.id→String` 会让 `SecurityUtils.requireUserId()`（及 `requireAdminUserId()`）返回 `String`，CR 实测级联 **126 调用点 / 228 声明 / 79 文件 + requireAdminUserId 11 处 + InternalMemoryController 数字注入点 + 按 user_id 过滤仓储 + 30 测试文件 + JWT `uid` claim（数字→`usr_xxx`，注：`sub`=username 不动）**。这是全程最敏感面、全库最大扇出，独立成片便于单独冻结、单独回归、单独回滚。
- **结构性 user_id FK 必须与 app_user 同迁**：`memory_item.user_id`/`personal_doc.user_id` 等是**有 DB 约束或参与隔离过滤的结构性列**。若 `app_user.id` 已是 `usr_xxx` 而这些列仍 BIGINT、运行时用字符串 `currentUserId` 过滤 BIGINT 列 → **匹配不上 → 用户查不到自己数据 → 隔离破裂**。故所有结构性 user_id 列必须与 `app_user.id` **同片切**（铁律 4）。

**② Bu 的完整范围**：见 §8 切片定义表 Bu 行 + §4.4 认证链路改造。要点：`app_user.id` PK→`usr_xxx`；全部 →app_user 的引用列按"**有 DB FK 约束 + 参与运行时隔离过滤**"判定收入本片——

- **DB 约束结构性 FK（8 条，V1 REFERENCES app_user(id)）**：`user_role.user_id`、`user_expert_binding.user_id`、`user_expert_override.user_id`、`user_skill_override.user_id`、`session.user_id` 等 → 必同片（否则切父 PK 后悬挂/约束失配）。
- **无 DB 约束但参与隔离过滤的结构逻辑列**（铁律 4，按"是否用于查我自己的数据"判，CR 订正后）：`scheduled_task.user_id`、`memory_item.user_id`、`personal_doc.user_id`、`memory_extract_cursor.user_id`、`user_tool_favorite.user_id`、`task_execution.owner_user_id`、**`memory_import_job.user_id`（CR 补：有 `findByUserIdAndIdempotencyKey` + `getUserId().equals(userId)` 归属过滤）**、`user_biz_credential.user_id`（仅切 FK 列，密文重加密下沉 B4，见③）→ 必同片（否则字符串 currentUserId 过滤 BIGINT 列 → 隔离破裂）。
- **CR 订正剔除/定档**：
  - ❌ **删虚构列 `tool_market_listing.user_id`**——该表实际**无 user_id 列**，归属列是 `submitter_id`/`reviewer_id`（纯归属审计、无 user_id 过滤仓储）→ 归 **B5**（与 `skill_publication.submitter/reviewer` 同类）。前几版误列，本次纠正。
  - ✅ **`audit_log.user_id` 显式定档 B5**：纯写入归属、无 `userId` 过滤方法 → 归 B5（与审计底座 V46 一脉相承）。
  - **边界列 `skill_publication.submitter/reviewer`**：纯归属审计、无隔离过滤 → 归 **B5**。
  - `created_by`/`updated_by` 全库纯归属，仍归 B5（铁律 3 不变）。
  - **定档线（CR 已逐列核）**：列值是否被运行时用于"查我自己的数据"过滤 → 是入 Bu，否（纯记录谁创建/审核/提交）入 B5。
- `user_expert_binding/override/skill_override` 在本片只切 `user_id` 列（expert_id 侧 B2 已建、自身代理 PK 留 B4）。
- **跨表 JOIN 硬约束**：`memory_extract_cursor.user_id` 与 `session.user_id` 有 `ON c.user_id=s.user_id` + `ON CONFLICT(user_id, session_id)` → **两列 Bu 同窗口同切 VARCHAR**，迁移脚本显式断言两列同切完（§4.4.2-2）。

**③ user_biz_credential 凭证耦合 → 不可逆段如何安置（本片最关键裁决）**
- 事实：`user_biz_credential.credential_cipher` 的 AAD = `userId|bizSystemId`，**两段都是会迁移的主键**——`userId`=`app_user.id`（Bu 迁）、`bizSystemId`=`biz_system_def.id`（B4 迁）。`app_user.id→String` 会改 AAD 的 userId 段 → **该表密文解不开**。按铁律 1「凭证表的 AAD 参与列迁移须同片重加密」，朴素做法会要求 Bu 也重加密 user_biz_credential——**这会让 Bu 成为不可逆片，打破"B4 是唯一不可逆片"的假设**。
- 候选方案：
  - **(A) Bu 就地重加密 user_biz_credential**（用 new userId + 旧数字 bizSystemId）→ B4 迁 biz_system_def 时**再次重加密**（换 new bizSystemId）。⇒ **同一密文被重加密两次 = 两段不可逆活、风险翻倍**，且 Bu 沦为不可逆片。**否决**。
  - **(B) 重加密整体下沉 B4，一次完成**：Bu **只切 `user_biz_credential.user_id` FK 列**（影子回写，纯结构、可回滚），**不动密文**；到 B4，`userId`（Bu 产 `id_map_app_user`）与 `bizSystemId`（B4 产 `id_map_biz_system_def`）两映射齐备，**用旧数字双段 AAD 解密 → 新字符串双段 AAD 一次重加密**。⇒ user_biz_credential 只重加密一次、仍 100% 落在 B4。**采纳**。
- **采纳 (B) 的代价 + 风险实测降级（窗口护栏，§5.5/§4.4，AI CR 订正）**：Bu 切完后到 B4 重加密前，`app_user.id` 已是 `usr_xxx` 而 user_biz_credential 密文仍用旧数字 userId 段加密。理论上此窗口内若按 `requireUserId()`（=`usr_xxx`）拼 AAD 解密会 GCM 失败。**AI CR 实测利好：全后端仅 3 处 `decrypt`（均 api/mcp），当前无 user_biz_credential 运行时解密消费方** → 窗口失配风险实质为**"低/潜在"**（无现存调用路径触发该解密）。**护栏定稿：采纳①冻结**——`user_biz_credential` 写入冻结跨 Bu→B4，B4 重加密后解冻（读因无消费方实际不触发解密，冻结写已足够）；**②userId-段-旧数字 shim**（窗口内 user_biz_credential 解密的 userId AAD 段从 `app_user.id_old`/`id_map_app_user` 反查取旧数字、不取 live requireUserId）**仅作"未来新增 user_biz_credential 解密消费方且不可冻结"的备选**，且一旦启用，**B4 重加密后强制拆除 shim 作为验收门禁**。
- **结论**：user_biz_credential 的**不可逆段（重加密）仍只在 B4**；Bu 对它只做可回滚的 FK 列切换。**不可逆片边界不变：B4 唯一**。

**④ 不可逆片边界 · 新结论（铁律更新）**
- 仍只有 **B4 一处不可逆段**（三类密文重加密：user_biz_credential / mcp_def.env_config / api_def.auth_config）。Bu 迁 app_user.id 触到了 user_biz_credential 的 AAD userId 段，但通过"FK 列切换在 Bu、密文重加密下沉 B4 一次完成"把不可逆活全部收口到 B4，**未新增第二处不可逆片**。
- 这强化了铁律 1 的一个推论（**铁律 1′**）：当一张凭证表的 AAD **跨多个【会迁移的】主键、且这些主键分布在不同切片**时，其重加密必须**延后到所有【会迁移的】AAD 参与主键都已确定其新值的那一片**一次性完成，**绝不在中途分段重加密**（避免双重不可逆活 + 中间失配窗口）。user_biz_credential 即此例：AAD 跨 app_user(Bu)+biz_system_def(B4) → 重加密落 B4。
  - **限定（CR 补）**：AAD 里**含固定域常量**（mcp 的 `-1L`、api 的 `0L`）的那一段不是会迁移的主键，故 mcp/api 的 AAD 实际只有单个会迁移主键 → 仍归**铁律 1 同片**（全在 B4），**不被 1′ 误判为"跨片需延后"**。1′ 仅适用 user_biz_credential 这种"AAD 含 ≥2 个会迁移主键且分属不同片"的真跨片情形。

### 切片定义（重排后 · 7 切片 B0/B1/B2/Bu/B3/B4/B5）

| 切片 | 迁哪些表 PK | FK 影子回写（含跨片处理位置）| 含凭证重加密 | 可回滚 | 依赖前序 |
|------|------|------|------|------|------|
| **B0 基础设施**（已完成）| —（不切表）| — | 否 | 随时可弃 | — |
| **B1 service_provider_system** | `service_provider_system` 一表（无凭证耦合、零子表 NOT NULL 风险）| `api_def.provider_system_id`（指向 provider 的 FK）在本片随 provider PK 做影子回写。**关键安全点：此 FK 回写不碰 api_def 自身 PK、不碰 api_def 凭证 AAD**（api_def 密文 AAD=`0`\|`api_def.id`，用 api_def 自身 id，与 provider id 无关，已核实 AdminApiService L286）| **否** | **可**（影子列 + 旧列保留，反向 RENAME）| B0 |
| **B2 岗位/Agent/数据表（收窄：纯 expert/agent/数据表链，不含 app_user、不碰弱审计列）** | `expert`、`agent`、`data_table_def`、`data_field_def`、`data_record`、`scheduled_task` | **本片只处理"有 DB FK 约束的结构性 FK"（已剔除全部 →app_user 的 user_id 链——整体移入 Bu 用户切片）**：→expert：`agent.position_id`(DB FK)、`data_table_def.expert_id`(DB FK)、`expert_resource.expert_id`(DB FK)、`user_expert_binding.expert_id`、`user_expert_override.expert_id`、`user_skill_override.expert_id`(可空)、`session.primary_expert_id`(可空)、`skill.position_id`(DB FK,**影子先建,B3 切 skill 用**)；→data_table_def：`data_field_def.table_def_id`(NOT NULL,同片)、`data_record.table_def_id`(NOT NULL,同片)、**跨片 `skill_table_ref.table_def_id`(NOT NULL) 在本片做影子回写**（B3 切 skill_table_ref 自身 PK 时就绪）。**显式排除①（归 Bu）：`app_user.id` PK 及所有 →app_user 的 user_id 结构性 FK（`user_role.user_id`、`user_expert_binding/override/skill_override.user_id`、`session.user_id`、`scheduled_task.user_id` 等）——B2 一律不碰**（裁决 2026-07-01，见 §8.0u）。**显式排除②（归 B5）：全库 `created_by`/`updated_by`（~32 列含 B3/B4 表）及逻辑归属列 `owner_user_id`/`submitter`/`reviewer`/MemoryItem.user_id 等无约束列——B2 一律不改其类型、不重映射其值**（铁律 3）。注：`user_expert_binding/override/skill_override` 在 B2 只切其 `expert_id` 侧影子、在 Bu 切其 `user_id` 侧影子、自身代理 PK 留 B4——三 FK 列分别随各自父表片走。 | **否**（expert/agent/data 表均无凭证 AAD）| **可**（影子 + 旧列保留）| B0、B1 |
| **Bu 用户切片（app_user.id + 全部 →app_user 结构性 FK + 认证/隔离链路；user_biz_credential 重加密下沉 B4，故本片可回滚）** | `app_user`（id PK→`usr_xxx`；全库扇出最大，user_id 遍布 30+ 表）| **本片切全部"指向 app_user 的结构性 FK（有 DB 约束）"+ 同片逻辑 user_id 结构链**：DB FK（V1，8 条 REFERENCES app_user(id)）：`user_role.user_id`、`user_expert_binding.user_id`、`user_expert_override.user_id`、`user_skill_override.user_id`、`session.user_id` 等；同片结构性逻辑列（参与隔离过滤，CR 订正）：`scheduled_task.user_id`、`memory_item.user_id`、`personal_doc.user_id`、`memory_extract_cursor.user_id`、`user_tool_favorite.user_id`、`task_execution.owner_user_id`、**`memory_import_job.user_id`（CR 补）**、`user_biz_credential.user_id`（**FK 列影子回写在本片；其密文 AAD 重加密下沉 B4，见下「含凭证重加密」列**）。**跨表 JOIN 硬约束**：`memory_extract_cursor.user_id` 与 `session.user_id` 两列须 Bu 同窗口同切（§4.4.2-2）。**CR 定档 B5（非 Bu）**：`tool_market_listing` 无 user_id 列（实为 submitter_id/reviewer_id 纯归属）、`audit_log.user_id` 纯写入归属、`skill_publication.submitter/reviewer` 纯归属 → 均归 B5。`user_expert_binding/override/skill_override` 在本片改 `user_id` 列（其 expert_id 侧在 B2 已建影子、自身代理 PK 留 B4）。**认证/隔离链路改造（本片最高风险，§4.4）**：`requireUserId()`/`requireAdminUserId()` `Long→String`（126 调用点/228 声明/79 文件 + 11 处）、JWT `uid` claim 数字→`usr_xxx`（sub=username 不动）、登录签发解析、InternalMemoryController 数字注入点、按 user_id 过滤仓储——随本片 DB 切 PK **同发布同回滚**；窗口冻结写 + 值重映射用 `id_map_app_user` + JWT uid 切换时机锁定 + 强制重登（无 refresh/remember-me，零兼容层）（§4.4 护栏） | **本片不含**（`user_biz_credential` 的 user_id **FK 列**在本片切，但**密文重加密下沉 B4**——见 §8.0u 裁决：避免 app_user→String 与 biz_system_def→String 两段 AAD 分两片导致**双重重加密**，故 user_biz_credential 重加密在 B4 一次完成；本片对 user_biz_credential 仅切 FK 列、不动密文）| **可**（本片不删任何密文、无不可逆活；app_user.id 与全部 user_id FK 走影子 + 旧列保留，反向 RENAME；JWT/认证链路代码随片回滚——见 §4.4 窗口护栏）| B0、B1、B2 |
| **B3 技能 + wire** | `skill`（自引用+20+被引用）、skill_*_ref（含 skill_mcp_ref/skill_api_ref/skill_biz_ref/skill_table_ref 的**自身 PK** 及其 `skill_id` 侧 FK）、`skill_file`、`skill_publication`、`skill_reference`、`tool_market_listing`、`task_execution` 等中间表 | `skill.parent_id`(自引用)、`skill.agent_id`(指向 B2 的 agent，B2 已建影子)、各 ref 的 `skill_id`；**path 自顶向下重建（§4）+ rootIdOf 链改造(H1)+ LIKE 转义(H2)**；**Java↔Python wire int→str 同步改（§6，N1 锁区，两侧同提交）**。注：各 ref 表里指向 **mcp/api/biz** 的 FK 列（`mcp_def_id`/`api_def_id`/`biz_system_id`）**本片不切**（那三父表 PK 在 B4 才迁）——本片只切 ref 表自身 PK 与 `skill_id` 侧；指向 mcp/api/biz 的 FK 列留到 B4 随父表迁移做影子回写。注：`task_execution.owner_user_id` 的 **user_id 侧**已在 Bu 切（本片只切这些表的自身 PK 与 skill_id 侧 FK）；`skill_publication.submitter/reviewer`、`tool_market_listing.submitter_id/reviewer_id` 已 CR 定档 B5（纯归属），本片不碰其归属 user 侧 | **否**（skill 无凭证）| **可**（影子 + 旧列；wire 两侧同 commit 同回滚）| B0、B1、B2、Bu |
| **B4 凭证三表 + 全 FK + 凭证重加密（不可逆片 · PK 迁移链终点 · 最重护栏）** | `mcp_def`、`api_def`、`biz_system_def` 三表 PK→String；**user_expert_binding/override/skill_override（单列代理 PK）收尾**（其 user_id 侧在 Bu 已切、expert_id/base_skill_id 侧在 B2/B3 已切，本片只切自身代理 PK）| 指向这三表的全部 FK 影子回写并切换：`skill_mcp_ref.mcp_def_id`、`skill_api_ref.api_def_id`、`skill_biz_ref.biz_system_id`、`user_biz_credential.biz_system_id`（B3 已切这些 ref 表自身 PK；`user_biz_credential.user_id` 侧已在 **Bu** 切——本片只切它指向 biz 的 `biz_system_id` 侧 FK）| **是 · 三类全覆盖**：① `user_biz_credential.credential_cipher`（AAD `userId\|bizSystemId`——**两段均已字符串化：userId 段在 Bu、bizSystemId 段在本片；本片用 id_map 反查的旧数字双段解密 → 新字符串双段一次重加密**，见 §8.0u/§5.5，**不双重重加密**）② `mcp_def.env_config`(AAD mcpId\|-1L)③ `api_def.auth_config`(AAD 0\|api_def.id)。§5 全护栏：**备份+冻结写入+解密失败整体中止回滚+重加密后逐条解密双校验+幂等+计数核对**；时序 M2=**先切本片三表 PK、后同窗口重加密**；user_biz_credential 重加密须等 Bu（userId 段）与本片（bizSystemId 段）两 id_map 齐备，故其重加密只在本片做；M1 消除两步 save 随本片落地 | **备份内可逆**（清理备份后不可逆，单独操作）| B0、B1、B2、Bu、B3 |
| **B5 审计归属收尾（弱审计列横切，无凭证·可回滚）** | —（不切任何实体 PK；只改弱审计列类型 + 重映射值）| **全库无 DB FK 约束的弱审计/归属列统一改 VARCHAR(20) + 按各实体 id_map 重映射旧数字值→新字符串 id**：① `created_by`/`updated_by`（~32 列 / 9+ 表，含 expert/agent/skill/skill_file/skill_table_ref/skill_resource/data_table_def/data_field_def/data_record/expert_resource/position 等，实体侧 11 个有 Long createdBy/updatedBy）；② **纯归属逻辑列**（非隔离过滤、纯审计/归属用途，CR 定档）：`skill_publication.submitter/reviewer`（发布审计归属）、**`tool_market_listing.submitter_id/reviewer_id`（CR 订正：该表无 user_id 列，归属列是 submitter_id/reviewer_id）**、**`audit_log.user_id`（CR 补：纯写入归属、无 userId 过滤方法）** 等无约束归属列。**已上移 Bu（不在 B5）**：`memory_item.user_id`/`personal_doc.user_id`/`memory_extract_cursor.user_id`/`user_tool_favorite.user_id`/`memory_import_job.user_id`/`task_execution.owner_user_id` 等**参与运行时按 currentUserId 过滤、属隔离链路的结构性 user_id 列**——按铁律 4 与 app_user 同片切（Bu），**不在 B5**。**Bu / B5 的判定线（CR 已逐列核）：列值是否用于"查我自己的数据"的运行时过滤 → 是则隔离列归 Bu，否（纯记录谁创建/审核/提交）则归 B5。** **值重映射用各实体 id_map（主要 id_map_app_user，归属链涉哪个实体就用哪个 map）**——故本片须晚于所有 PK 片、能拿到全部 id_map（各 id_map 保留至本片用完）。与审计底座 V46（`audit_log.target_id`）一脉相承。**注**：弱审计列既无 FK 约束，迁移仅"列改类型 + UPDATE…FROM id_map 重映射值 + 漏映射/错配门禁（M4 同款）"，无切 PK/切约束动作 | **否**（无凭证 AAD） | **可**（影子列 + 旧列保留，反向 RENAME；纯加列/回填可即时弃）| B0、B1、B2、Bu、B3、B4 |

> **顺序（7 切片）**：**B0 基础设施 → B1 provider → B2 expert/agent/数据表 → Bu 用户切片 → B3 技能+wire → B4 凭证三表+全 FK+重加密 → B5 审计归属收尾**。Bu 紧随 B2、前于 B3：① app_user 的结构性 FK 不依赖 skill，且 `user_expert_binding/override/skill_override` 的 expert_id 影子已在 B2 备好，紧接切其 user_id 列最干净；② 认证/隔离链路是全程最敏感面，独立成片便于单独冻结/回归/回滚，不与 skill/path/wire 大改叠加。
> **不可逆片边界（重大更新，见 §8.0u）**：凭证密文（不可逆段）现仍 **100% 集中在 B4**。Bu 虽迁 `app_user.id`（它是 `user_biz_credential` AAD 的 `userId` 段），但 Bu **不对 user_biz_credential 重加密**——其重加密下沉 B4 一次完成（届时 userId 段[Bu 产]与 bizSystemId 段[B4 产]两 id_map 齐备，旧数字双段解密→新字符串双段一次重加密，避免 Bu+B4 双重重加密）。故 **Bu 无不可逆活、可回滚**；**B4 仍是唯一不可逆片、是 PK 迁移链终点**；"B4 不可逆活放最后"的结论不变。B1~B3、Bu、B5 全部是**无凭证、可回滚**的纯加列/影子/切换/回填片。
>
> 补充：B0 的"~26 实体加 `Persistable<String>` + isNew 标记（H3）"是改造模式定稿，各实体落地随其所在片（B1/B2/Bu/B3/B4）做；M1 删两步 save 随 mcp/api（**B4**，不再是 B1）落地。
>
> B5 时序硬约束：B5 须晚于 B1~B4（含 Bu）全部 PK 迁移片，且**各被迁实体的 id_map 必须保留至 B5 重映射用完后**才能由清理片 DROP（旧列/映射表清理片不得早于 B5）。`id_map_app_user` 是 Bu 产物，既供 B4 的 user_biz_credential 重加密、又供 B5 的弱审计列重映射，**必须保留至 B5 用完**。

### 8.1 前端切片映射（随哪个后端片发 + 中间态兼容）

> 原则：前端 URL `${id}` 拼接天然兼容（零改），故前端**不必**和每个后端片严格同步；只有"会因字符串化坏掉的比较/守卫/拖拽/路由约束"要随对应实体切换片改，其余转换类与 Number 兜底**统一留到 B3 尾清理**（见 §7.3.1 灰度策略）。**B4 不含任何前端改动**（纯凭证不可逆片）。

| 前端改动 | 随片 | 说明 |
|---|---|---|
| `positionBinding.js`、`PositionPickerDialog.vue`、`FrontLayout.vue`、`Personalize.vue`、`Chat.vue:313` 守卫、`companion.js` localStorage | **B2**（岗位/Agent 切字符串时）| 岗位 id 字符串化即生效，归一比较/守卫必须同片改，否则岗位切换/绑定坏 |
| `AgentLane.vue` 拖拽 dataTransfer（读取去 Number）| **跨 B2+B3** | 拖拽涉及 agentId（B2）+ skillId（B3），两片都切完才完全字符串化；中间态保留 Number 兜底 |
| `useRebindFlow.js`、`AdminSkillEditPage.vue`、`TaskDetail.vue`、router `(\d+)` 4 条 + 字面量优先级单测 | **B3**（技能/任务切字符串时）| 技能/任务 id 相关 |
| 其余转换类 Number/parseInt 统一去除 + 全前端字符串相等审查 | **B3 尾** | 对外 id 全部字符串化后统一清，灰度红利用尽；不拖到 B4 |
| 28 文件 / 216 处测试 id 字面量改字符串 | **随各自实体片增量改** | 各片回归门禁的一部分 |

> 注：重排后**取消独立的 B5 收尾片**——前端 Number 统一清理 + 对外口径收尾并入 **B3 尾**（skill/任务等最后一批对外 id 字符串化后即清）。这样 B4 得以保持"纯凭证不可逆活、零其他改动"的最干净状态（铁律 1 的要求）。若现网体量大需把 B3 尾的前端清理单拎一个轻量发布，可作为 B3 的子发布，但**绝不并入 B4**。

---

## 9. 风险清单 + 回滚总策略

### 9.1 最危险四坑 + 兜底

| 风险 | 等级 | 兜底 |
|------|------|------|
| **R1 凭证 AAD 重加密不可逆损坏** | **致命/不可逆** | 集中 B4（唯一不可逆片）+ 全量备份（无备份不启动）+ 解密失败立即整体中止回滚 + 重加密后逐条解密双校验 + 幂等 + 维护窗口冻结写入；**user_biz_credential 双段 AAD 不在 Bu 分段重加密、下沉 B4 一次完成（铁律 1′），杜绝双重不可逆活** |
| **R1u app_user.id→String 致用户数据隔离破裂**（字符串 currentUserId 过滤 BIGINT user_id 列查不到自己数据；JWT uid/requireUserId 级联）| **致命（数据不可见 / 越权风险）** | **Bu 用户切片**：结构性/隔离 user_id 列与 app_user 同片切 VARCHAR（铁律 4，含 memory_extract_cursor/session 跨表 JOIN 两列同切）+ requireUserId/requireAdminUserId Long→String 与 **126 调用点/228 声明/79 文件 + InternalMemoryController 注入点 + JWT `uid` 签发解析**（代码与 DB 同发布同回滚）+ 迁移窗口冻结写 + 旧 token 强制重登（无 refresh/remember-me，零兼容层）+ **QA 以"切换前已有数据的真实用户"回归历史 memory/session + user_biz_credential status 全可见**（非新建用户 happy-path）。详见 §4.4 |
| **R2 path 重建错误致子树/深度查询回归** | 高 | 自顶向下逐层重算 + 重算后逐行一致性校验（broken=0 才过）+ VARCHAR(512) 深度容量复核（不足扩 1024）+ REINDEX |
| **R3 wire int→str 触 N1 锁区致办事链路断** | 高 | JSON key 不改只改类型 + Java/Python 同一提交 + wire 契约测试红线 + parseSectionId/Set/Map 类型连改不漏 |
| **R4 FK 切换顺序错 / 悬挂或错配引用** | 高 | 严格按 §2.3 拓扑（被引用表先，**无 FK 循环**，C2）+ 阶段 B 双重门禁（(a) COUNT 查漏 + (b) **反向 JOIN 校验 old==原 fk** 查错配，M4）+ 影子列双写 + 断约束前查 information_schema 真实名（C1） |

### 9.2 其他风险

| 风险 | 兜底 |
|------|------|
| R5 字面量路径被 `{id}` 误捕获 | PathPattern 优先级 + 前缀 id（sk_）天然区分 + 字面量端点单测 |
| R6 字符串 PK/FK 索引/JOIN 性能劣化 | 迁移后 EXPLAIN 回归 + 热点 FK 补索引 |
| R7 dataTransfer/Number 比较因字符串化出错 | AgentLane 读取去 Number() + 全前端字符串相等审查 |
| R8 path 字典序排序变化致 UI 顺序变 | CR 复核 UI 是否依赖 path 序（多数另排）|
| R9 含被改 FK 列的部分唯一索引重建遗漏 | M3 逐条清单（§2.4：uk_data_table_def_alive / uk_expert_resource_alive / uk_ueo_user_expert_active / uk_uso_base_active / uq_user_skill_override_base）随 FK 列切换同片 DROP→CREATE + 唯一性回归 |
| ~~R10 复合 PK 双映射~~（**已删**：C3 订正全库无复合 PK，user_expert_binding 是单列代理 PK，无此复杂度）| — |
| R11 rootIdOf 取 path 首段 Long.parseLong 抛异常 / 缓存静默失准（H1）| §4.3：rootIdOf 改按 `/` 切分取首段字符串、返回 String，下游 evict 签名连改 String + 缓存失效回归 |
| R12 LIKE 前缀未转义、id 内 `_` 通配致跨子树误匹配（H2）| §4.3：LIKE 加 ESCAPE + 转义 `_/%/\` + "带 `_` 的 id 跨子树不误匹配"回归用例 |
| R13 String 主键未实现 Persistable 致 save 走 merge 退化（H3）| §1.3：~26 实体实现 `Persistable<String>` + isNew 标记（B0 定模式，各片落地）|
| R14 前端在后端切片时同步清 Number 致灰度中间态比较失败 | §7.3.1 灰度策略：保留 Number 兜底，**B3 尾**统一清（不拖到 B4）；仅守卫(iii)/归一比较(ii) 随对应实体片改 |
| R15 Bu→B4 窗口内 user_biz_credential 密文解不开（userId 段已 usr_xxx、密文仍旧数字加密；重加密下沉 B4）| §5.5：窗口内**冻结业务凭证读写跨 Bu→B4**（建议）或解密 userId AAD 段临时取旧数字 shim；B4 重加密后解冻/拆 shim |
| R16 Bu 漏切某隔离 user_id 列（散落 30+ 表，遗漏一列即该实体用户数据查不到）| 按 §8.0u②/B2-FK 清单穷举 →app_user 引用列逐列定档（隔离过滤→Bu / 纯归属→B5）+ Bu 后 QA 真实用户历史数据全覆盖回归（R1u 红线）|

### 9.3 回滚总策略

- **分层分片，非单事务**：每片独立回滚点。阶段 A/B（加表/加列/回填）可即时 `DROP` 回滚，业务无感。
- **阶段 C 切换保留旧列**（`id_old`/`fk_old`）作回滚窗口，反向 RENAME + 恢复旧约束即回退；旧列稳定 N 天后由独立清理片 DROP。
- **Bu 用户切片可回滚**：本片无不可逆活（user_biz_credential 密文不动、重加密在 B4）。回滚 = `app_user.id` 与全部 user_id 列反向 RENAME 恢复 BIGINT + 恢复旧 FK 约束 + 回退认证链路代码（requireUserId/JWT 签发解析）。**回滚后须强制全员重登**（JWT 主体回退数字）。Bu 与 B4 之间若需回滚，注意 B4 的 user_biz_credential 重加密依赖 Bu 产 `id_map_app_user`——回滚 Bu 前若 B4 已执行则须连带回滚 B4（备份恢复）。
- **B4 凭证片**：备份是唯一回滚手段（恢复 pg_dump）；备份保留期内整体可逆，清理备份后进入不可逆——故清理动作单独、谨慎、需 PM 确认。
- **代码与 DB 同发布**：JPA `@Id String` / wire 改动 / **认证链路（requireUserId/JWT）随 Bu** 的 DB 迁移同发布同回滚，避免代码-Schema 错配。

---

## 10. 架构师劝退保留（CR 后仍保留，供 PM 向用户二次确认）

> **本节是 CR 后明确要求保留的架构师立场记录。** 后端 + 前端 CR 结论为"方向可行、无致命硬伤"，但"可行"不等于"最优"——硬伤可修不改变下列三点结构性判断。用户已坚持 B，此保留仅作风险知情记录，请 PM 转达。

用户已选 B，本设计已据此给出可执行方案。但作为架构师，我**仍保留一条强烈意见**，依职责写明供 PM 二次确认：

1. **方案 B 引入一个方案 A 完全不存在的不可逆段（R1 凭证重加密）**，且本系统是**有真实加密凭证的 live 实例**。即便护栏拉满（备份+双校验+幂等+中止回滚），重加密一旦在备份清理后发现问题，即为不可逆数据损坏。方案 A（保留 BIGINT 主键、对外换定长 code）**根本不触碰密文 AAD**，无此不可逆风险。
2. **B 的工程量与回归面是 A 的一个数量级以上**，CR 后实际更大：全 FK 迁移（**43 条 DB FK**）+ path 重建 + **rootIdOf/LIKE 两条 path 反向依赖（H1/H2）** + **~26 实体 Persistable 改造（H3）** + wire 锁区 + 41 路由 + 48 PathVariable + **前端 23 处 Number/parseInt + 28 文件/216 处测试断言** + 全量数据迁移；而**两者对用户的可见收益等价**——用户诉求是"对外别露 1/2/3 递增"，A 已 100% 满足。
3. **性能**：字符串 PK/FK 使索引更大、JOIN 更慢，skill 子树 LIKE + 大量 ref JOIN 是热点，长期有可观测的劣化。
4. **正向减项**：M1（消除两步 save）是 B 带来的唯一正向收益，但不足以抵消 1~3 的代价。

**补充（Bu 用户切片放大的保留点，CR 重估后更显著）**：app_user 单独成 Bu 后，方案 B 的不可逆/高危面进一步显形——`app_user.id→String` 触达**认证主体 + 用户数据隔离**，CR 实测消费面 **126 调用点 / 228 声明 / 79 文件 + requireAdminUserId 11 处 + InternalMemoryController 数字注入点 + 30 测试文件 + 30+ user_id 列**（远大于初估 ~54），任一隔离 user_id 列漏切即"用户查不到自己数据"（R1u/R16），是全库最大扇出 + 认证核心、须当独立大工作量排期；且 `user_biz_credential` 双段 AAD 让凭证不可逆段的处置更微妙（虽经铁律 1′ 收口 B4 不双重重加密、且 AI CR 实测当前无 user_biz_credential 解密消费方使窗口风险降为"低/潜在"，但仍需冻结凭证写、R15）。这些都是方案 A（不动主键、不动 AAD、不动 requireUserId 类型）**完全不存在**的风险。架构师立场不变。

**结论**：若用户的诉求确实仅是"对外标识不可枚举、不露递增数字"，**架构师仍建议方案 A**；若用户有"主键本身就必须是字符串（如对接外部系统主键、合规、跨库统一）"等 A 无法满足的硬约束，则方案 B 成立，按本设计的 **7 切片（B0~B2 → Bu → B3~B5）+ B4 最重护栏 + Bu 认证/隔离护栏（§4.4）** 执行。**此保留请 PM 转达用户拍板**：维持 B，还是降级 A。

---

## 附：关键文件索引（含本轮核实行号）

- 凭证加密：`bizsystem/crypto/CredentialCryptoService.java`(aad L100-103, encrypt L59, decrypt L75, MCP_ENV_AAD_DOMAIN L41)、`tooldef/service/AdminMcpService.java`(applyEnv L348-371, 必修8注释 L157-159)、`tooldef/mcp/transport/StdioTransport.java`(decryptEnv L361-390)、`tooldef/service/AdminApiService.java`(两步save L156-172, AAD L286, SYSTEM_API_KEY_USER_ID=0L L70)；密钥 `KeyProvider.java` / `GcmCipherService.java`；配置 `application.yml` L20-54（flyway L20-23, crypto L24+）。
- path：`db/migration/V7__sprint2_1_skill_tree.sql`(path 列 L4-5, idx L13-14, 回填 L10)、`SkillRepository.java`(findByPathStartingWith L231, countDescendants L234-235)、`PositionConfigQueryServiceImpl.java`(L369-370, 排序 L384)、`AdminSkillService.java`(rootIdOf L175-189, fallback L197)、`OpenPlatformSkillService.java`(L139-142)。
- wire：`orchestrator/app/integration/contracts.py`(L17,37,43,72,99,129)、`runner.py:89`、`graph/nodes.py`(L546-547,1074-1078)、`graph/prompt.py`(L134-148)、`orchestration/dto/OrchestrateRequest.java`(expertId@JsonProperty L52, skillId L70, sectionId L88)、`skill/tool/section/SkillSectionExecutor.java`(parseSectionId L92-108, allowed L72-73, findById L79)、`orchestration/OrchestrateRequestAssembler.java`(L146-147,160-162)、`orchestration/run/OrchestrationRun.java`(L40)、test `OrchestrateRequestWireContractTest.java`(L42-43,100-101,183)。
- FK/迁移：`db/migration/`（V1__init 主表+FK、V15 expert/skill_resource、V18 data_table、V20 skill_table_ref、V21 position_agent_skill、V25 biz_credential、V26 skill.position_id、V37 mcp env、V40 provider_system fk_api_def_provider_system、V41 NOT NULL、V44 游离化=当前最高）。**DB FK 约束实测 43 条**（C1）。下一可用 **V45**。
- 路由/前端：5 个 Controller（SkillFileController/PlatformSkillFileController/PlatformSkillController/PositionSkillController/SkillReferenceController，`:\d+` 41 条 + @PathVariable Long 48 处，SkillReferenceController L51 全仓铁律注释）；`frontend/src/router/index.js`(L26,32,203,211)、`AgentLane.vue`(L113-114,132-134,138-139)、`FrontLayout.vue:26`、`Personalize.vue:18,100`、`Chat.vue:313`(Number.isFinite 守卫)、`AdminSkillEditPage.vue:90`、`TaskDetail.vue:61`、`useRebindFlow.js:69`、`PositionPickerDialog.vue:34,55`、`positionBinding.js:13`、`companion.js`(localStorage key)。**Number/parseInt 实 23 处；前端测试 28 文件/216 处 id 字面量**。
- H1/H2/H3 核实点：`AdminSkillService.rootIdOf`(L174-189, Long.parseLong) + `evictExpertsReferencingAfterCommit(Long)`(L170)；`SkillRepository`(countDescendants/findByPathStartingWith LIKE 未转义)；`MemoryImportJob`(@Id String 未实现 Persistable，带病先例)。FK 计数 / 无复合 PK（@EmbeddedId/@IdClass=0）/ 无 FK 循环均经本轮 grep 核实。

> 待核实项（迁移前实测）：① 现网最大技能树深度（path VARCHAR(512) 容量，base58 后 ~36 层上限）；② UI 是否依赖 path 字典序展示顺序；③ 受控启动期 data-fix vs Flyway Java migration 的最终形态（建议前者）；④ M3 部分唯一索引清单按运行库实际逐条核名重建。

---

## 附 B：CR 修订记录（本轮经后端 + 前端可行性 CR）

| 编号 | 类别 | 修订点 | 落点 |
|---|---|---|---|
| H1 | 后端硬伤 | rootIdOf 取 path 首段 Long.parseLong→改 / 切分取字符串、返回 String + 下游 evict 签名 String | §0、§4.3、R11、B3 |
| H2 | 后端硬伤 | countDescendants/findByPathStartingWith LIKE 前缀未转义、id 内 `_` 通配误匹配→加 ESCAPE + 转义 + 回归用例 | §0、§4.3、R12、B3 |
| H3 | 后端硬伤 | String 主键须实现 `Persistable<String>` + isNew，否则 save 走 merge 退化；~26 实体工时计入 | §0、§1.3、R13、B0 |
| M1 | 后端必补(收益) | 应用层 String id 后消除 api_def/MCP 两步 save、一次加密入库、删"勿合并优化"注释 | §0、§1.3、**B4**（随 mcp/api 三表迁移落地，重排后不再 B1）|
| M2 | 后端必补 | 凭证片时序锁定为"先切三表 PK、后同窗口重加密"（消除决策悬空） | §0、§5.4、B4 |
| M3 | 后端必补 | 部分唯一索引清单补全（uk_data_table_def_alive/uk_expert_resource_alive/uk_ueo_user_expert_active/uk_uso_base_active/uq_user_skill_override_base）随片重建 | §2.4、R9 |
| M4 | 后端必补 | 引用完整性门禁加"反向 JOIN 校验 old==原 fk"防错配（COUNT 只查漏） | §3.1、R4 |
| C1 | 后端订正 | DB FK 43 条非 41；无显式名靠 PG 默认名，断约束前查 information_schema 真实名 | §0、§3.1、§9.1、附 |
| C2 | 后端订正 | 无 FK 循环（api_def→provider 单向）；删"先断后建循环"伪命题 | §2.2、§2.3、R4 |
| C3 | 后端订正 | 全库无复合 PK（@EmbeddedId/@IdClass=0）；user_expert_binding 是单列代理 PK，删 §3.3 特例 + R10 | §2.3、§3.3、R10 |
| F1 | 前端必补 | Number/parseInt 实 23 处非 13；补归一比较类 + Chat.vue Number.isFinite 守卫(删逻辑级) | §0、§7.3 |
| F2 | 前端必补 | 灰度兼容策略：保留 Number 兜底，**B3 尾**统一去除（不拖到 B4），不每片同步清 | §7.3.1、§8.1、R14 |
| F3 | 前端必补 | 前端测试 28 文件/216 处 id 字面量改造计入工时 | §7.3 |
| F4 | 前端必补 | companion.js localStorage key 形态变更致老昵称缓存失效（发布说明标注，非阻断） | §7.3 |
| F5 | 前端必补 | 路由去 `\d+` 后补字面量优先级单测（tasks/new vs :id 等） | §7.3 |
| F6 | 前端必补 | §8 补前端切片映射表（哪些前端文件随哪片发 + 中间态兼容） | §8.1 |

> 切片骨架由 5 切片（B0~B4）扩为 6 切片（B0~B5，2026-07-01 B2 FK 穷举后新增 B5 审计归属收尾，承接弱审计列横切）；"B4 凭证片是唯一不可逆片、单独成片、最重护栏"不变（B5 在 B4 之后但无不可逆活）；架构师劝退 A 立场（§10）CR 后保留。
