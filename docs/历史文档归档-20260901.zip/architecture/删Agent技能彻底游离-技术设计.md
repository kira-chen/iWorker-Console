# 删 Agent 技能彻底游离化 · 技术设计

> 状态：设计稿（待 PM 汇总 + 用户确认存量迁移点后实现）
> 作者：架构师
> 日期：2026-06-30
> 关联：`岗位模型-数据模型与两级路由设计.md`、`FDE工作台技能模块改造-设计.md`、`平台级技能与发布-技术方案.md`、`技能编辑器性能批次二契约与口径.md`

---

## 0. 背景与决策（用户已拍板）

**变更前（现状）：** 删 Agent → 其下技能 `agent_id` 置 NULL、**保留 `position_id`**，以「未绑定 Agent」收纳泳道留在岗位白板，可在白板拖回/「分配到…」重绑（`PUT /skills/{id}/assign`）。

**变更后（本设计）：**

1. 删 Agent → 其下技能**彻底脱离岗位、变游离技能**：同时清空 `agent_id` **与** `position_id`。
2. 岗位白板**去掉「未绑定 Agent」收纳泳道**。
3. 这些游离技能**只在「技能」管理页 `/admin/skills`（实际端点 `GET /api/fde/skills`）展示**。
4. 技能页只加「游离 / 未挂载岗位」**标识**，**不加重新分配入口**。

**用户明确的单向行为口径（重要）：** 技能一旦游离，**无界面重绑回岗位 / Agent**，只能在技能页编辑或删除。这是被接受的单向（不可逆）行为，不需要也不应提供反向 UI 入口。

---

## 1. 删 Agent 行为变更

### 1.1 仓储层 `detachSkillsFromAgent`

`SkillRepository.detachSkillsFromAgent`（现 `UPDATE Skill s SET s.agentId = NULL WHERE s.agentId = :agentId`）改为**同时清 `position_id`**：

```java
/**
 * 删 Agent 时把其下技能彻底游离化（agent_id 与 position_id 一并置 NULL，
 * 技能脱离岗位变游离技能，新口径·用户拍板）。返回受影响（变游离）的技能数 = orphanedSkillCount。
 * 显式 JPQL UPDATE（绕过实体加载，事务内一次性置空）；调用方须在同事务后清理持久化上下文。
 */
@Modifying
@Query("UPDATE Skill s SET s.agentId = NULL, s.positionId = NULL WHERE s.agentId = :agentId")
int detachSkillsFromAgent(@Param("agentId") Long agentId);
```

> 注：原方法上的 V26 JavaDoc「仅置空 agent_id，**保留 position_id**」整段需改写为新口径，并删去「这是技能列表能按岗位列出未绑定技能的关键」一句（该能力本设计已下线）。

### 1.2 服务层 `AgentService.delete` 时序与缓存

`AgentService.delete` 主体时序**不变**，仍是：

1. `detachSkillsFromAgent(agentId)` —— 现在一次性清 `agent_id + position_id`（事务内 JPQL UPDATE，返回受影响技能数）。
2. 软删 Agent（`a.setDeleted(true)`）。
3. `cacheEviction.evictExpertAfterCommit(a.getPositionId())` —— **仍按原岗位失效**。理由：被 detach 的技能本就只有「published + agent_id 非空」才进 `EffectivePositionView`，删 Agent 后它们从原岗位运行视图消失，必须失效原岗位合并视图缓存。这点与现状一致，**不需改**。

**`orphanedSkillCount` 语义微调：** 字段名与类型不变（`AgentDeleteResultVO.orphanedSkillCount`），但前端二次确认文案口径从「将变为**未绑定**（留在本岗位、可重分配）」改为「将**脱离本岗位变为游离技能**，仅可在『技能』管理页查看 / 编辑 / 删除，**不可再绑回**」。后端 JavaDoc 同步改写。建议提示语示例：

> 删除 Agent「X」？其下 N 个技能不会被删除，但将**脱离本岗位变为游离技能**，之后只能在「技能」管理页编辑或删除，**无法再绑回岗位 / Agent**。

> ⚠️ 文案要把「单向不可逆」说清楚，避免 FDE 误以为还能像旧版一样在白板拖回。

### 1.3 事务/持久化上下文注意

`detachSkillsFromAgent` 是绕过实体加载的批量 JPQL UPDATE。当前 `delete()` 在它之后再 `agentRepository.save(a)`（操作的是 Agent 实体，与 Skill 持久化上下文无交叉），返回前不再读被改的 Skill 实体，故**不需要额外 `clearAutomatically`**——现状已正确，沿用即可。

---

## 2. 存量数据迁移（⚠️ 数据变更，需用户确认后执行）

### 2.1 问题

变更后的「游离」口径 = `agent_id IS NULL AND position_id IS NULL`。但库里已有一批**旧口径的「未绑定」技能**：`agent_id IS NULL AND position_id IS NOT NULL`（如销售岗 positionId=5 的技能 13「客户交互记录」、14「CRM 同步」，均已 published）。

这些行处于「半脱离」状态：没有 Agent（运行时不加载、不随发布生效），但仍挂在 `position_id=5`。变更后：

- 它们**不会**出现在白板（收纳泳道已下线）。
- 它们**会**出现在技能页（`searchAdmin` 不按 position 过滤，本就混列）。
- 但按新口径它们 `position_id` 非空，**不会被标为「游离」**，造成「页面里看得到、却既不在任何白板、又不显示游离标识」的口径不一致。
- 另有一处隐患：删岗位级联 `softDeleteAllByPositionId` 按 `position_id` 命中，这些行仍会随原岗位删除被级联软删——而新口径的游离技能不应随任何岗位消亡。

### 2.2 建议：**一次性迁移存量为游离（推荐）**

**推荐迁移**，理由：

- 口径统一：避免「未绑定（旧）」与「游离（新）」两套并存，技能页标识逻辑可单一判据 `position_id IS NULL`，不必兼容旧半脱离态。
- 行为一致：迁移后这些技能与「删 Agent 新产生的游离技能」完全同态，不会随原岗位删除被误连带软删。
- 数据量小、风险低：现状此类行极少（已知仅销售岗 13/14 两行）。

**不影响项（迁移安全性评估）：**

- **`status='published'` 不动**：迁移只清 `position_id`，不改 `status`。游离技能保留 published 仅是历史状态标记，运行时早已不加载它们（无 agent_id），发布视图无回归。技能页可正常展示其状态。
- **工具引用（`skill_table_ref` 等）不动**：迁移只 UPDATE skill 行，不触碰四张 ref 表。引用行随技能存活（详见 §3）。
- **`origin='POSITION'` 不动**：仍是 FDE 自建技能，技能页照常列出。

### 2.3 迁移脚本（Flyway `V44`，下一可用号）

> 现库最高迁移号为 **V43**（`V43__skill_file_directory.sql`），故新开 **V44**。**已应用迁移一律不改**。

```sql
-- V44__detach_unbound_skills_to_orphan.sql
-- 删 Agent 技能彻底游离化（用户拍板）：将存量「未绑定」技能（agent_id 已 NULL 但 position_id 仍非空、
-- 未软删、FDE 自建）一次性迁为游离态（position_id 一并置 NULL），与新口径一致。
-- 仅影响半脱离技能；status/工具引用/origin 均不动。幂等：position_id 已 NULL 的行不命中。
UPDATE skill
   SET position_id = NULL,
       updated_at  = now()
 WHERE deleted = false
   AND agent_id IS NULL
   AND position_id IS NOT NULL
   AND origin = 'POSITION';
```

> **PG 兼容性自检**：纯 UPDATE，无未类型化 NULL 参数进入比较/子查询，不触发 42P18（V34 系列踩过的坑），H2 与 PG 行为一致。
> **审计**：`updated_by` 不写（无操作人上下文，迁移为系统行为）；如团队约定迁移需留痕可置某系统账户 id，但当前迁移脚本惯例不写 operator，沿用。

### 2.4 备选：不迁移（仅对未来生效）——不推荐

仅新删 Agent 产生的技能走新口径，存量半脱离技能维持 `position_id` 非空。
代价：技能页需**双判据**兼容（`position_id IS NULL` **或** `agent_id IS NULL AND position_id 非空` 都视作「未挂载岗位」才能正确打标识），且删原岗位仍会级联软删这些存量行（与「游离技能不随岗位消亡」语义冲突）。**口径割裂，不推荐。**

> **本节为数据变更，须 PM 汇总后请用户拍板「迁移 / 不迁移」再实现。**

---

## 3. 游离技能对数据表 / 业务系统工具引用的连带影响（重点）

### 3.1 现状机制回顾

- 技能引用的工具（数据表 `skill_table_ref`、业务系统 `skill_biz_ref`、API、MCP）由 `SkillToolRefSyncService` 在**保存 skill.md 时**解析并写入四张 ref 表，**持久化存活**，只在下次保存 skill.md 时全量重建。
- 数据表工具是 **position 维度资产**：`resolve()` 用 `tableDefRepository.findByPositionIdAndTableCode(positionId, ...)` 按岗位定位，**跨岗位查不到 → 不进白名单**（安全边界）。
- 运行时白名单由 `EffectivePositionView` / `PositionRouter` 装配，**只含 agent_id 非空且 published 的技能**——游离技能（无 agent_id）**根本不进运行时**，其 ref 表行**运行时不被读取**。

技能 13「客户交互记录」很可能在 `skill_table_ref` 中持有一条指向岗位 5 数据表「客户交互记录表」的引用行。

### 3.2 处置口径：**保留 ref 表行不动（断链即「运行时本就不加载」），不主动清 ref**

**结论：删 Agent / 迁移游离时，不触碰技能的工具引用表行。** 依据：

1. **运行时本就不加载** —— 游离技能无 agent_id，不进 `EffectivePositionView`，其 `skill_table_ref` 行运行时永不被读取。所谓「断链」在运行时层面**已天然成立**，无需额外清理。
2. **不破坏 `SkillToolRefSync` / 白名单一致性** —— ref 表是「保存 skill.md 时的快照」，与技能归属解耦。删 Agent 不是一次 skill.md 保存，**不应触发 `syncRefs`**（避免引入额外写、避免误触发 category 派生回写、避免破坏性能批二「指纹跳过」铁律）。现状 `AgentService.delete` 不调 `syncRefs`，**维持不调**。
3. **保留 ref 行的好处** —— 若 FDE 之后在技能页编辑该游离技能并**重新保存 skill.md**，`syncRefs` 会用**当前 positionId（游离技能为 NULL）**重新解析：此时数据表 code 因 `findByPositionIdAndTableCode(NULL, ...)` 查不到 → 自动从白名单剔除并记 warning（`本岗位下无对应数据表`）。即**保存路径会自愈断链**，无需迁移期主动清。

### 3.3 「保留但运行时断链」对各环节的影响

| 环节 | 影响 | 处置 |
|------|------|------|
| 运行时装配 | 游离技能不进 view，ref 行不被读 | 无影响（本就不加载） |
| 工具白名单一致性 | ref 表行保留，但不参与任何运行时白名单 | 无破坏；`SkillToolRefSync` 不被触发，零漂移 |
| 工具检活（健康检查） | 检活针对工具定义（DataTableDef 等），与 ref 行无关 | 无影响 |
| 技能页 referencedTools 回显 | 游离技能详情仍会 join ref 表回显「客户交互记录表 · 增删改查」等 | **保留回显**。这是工程师 / FDE 编辑游离技能时的有用信息（它「曾引用过什么」）。不视为 bug |
| 数据表「被引用」断链提示 | 若白板 / 数据表页有「该表被 N 个技能引用」统计，会把游离技能的残留 ref 计入 | **需复核**（见 §3.4） |

### 3.4 需复核点：数据表「被引用计数 / 断链提示」是否把游离技能算入

`skill_table_ref` 保留行后，如有「数据表被哪些技能引用」的反查（用于删表前阻断 / 断链提示），可能把游离技能的残留 ref 也算进去。

- **若该反查仅用于运行时白名单/装配** → 无影响（运行时不读游离技能）。
- **若该反查用于「删数据表前的引用阻断」UI 统计** → 可能让游离技能的死引用「撑住」一张本可删的表。

**建议口径**：删表前的引用阻断/统计若存在，应在反查 SQL 上**排除游离技能**（`AND s.agent_id IS NOT NULL` 或 join 仅 active 装配技能），让游离技能的残留 ref **不阻断**数据表删除。

> **实现期 ACTION**：后端在实现前 grep `skill_table_ref` / `SkillTableRef` 的所有反查消费方，逐一判定是否需排除游离技能。本设计标记为待复核项，不在文档层武断改 SQL（避免误伤运行时装配路径）。**不改 `SkillToolRefSyncService`、不动性能批二 / 批三成果。**

---

## 4. 接口调整

### 4.1 `unbound-skills` 端点 —— 下线（白板去收纳区后无消费方）

`GET /api/fde/positions/{positionId}/unbound-skills`（`PositionSkillController.unboundSkills` → `PositionSkillService.listUnbound` → `SkillRepository.findUnboundByPositionId`）：

- 唯一消费方是白板收纳泳道（`position.js` 的 `loadUnboundSkills`）。收纳区下线后**无前端消费**。
- **建议删除**：端点方法 `unboundSkills`、Service `listUnbound`、仓储 `findUnboundByPositionId`，以及前端 `api/position.js` 的 `getUnboundSkills`。
- 一并删除其测试覆盖（见 §6）。
- 谨慎项：`findUnboundByPositionId` 仅此一处消费，删除安全。删除前 grep 确认无其它调用方。

> **📌 校准标注（2026-07-17）**：实际落地未删该端点，而是保守保留并标 `@Deprecated`——新口径下恒返回空列表。详见《设计文档校准审计-20260717.md》。

### 4.2 `assign` 端点 —— 保留但收窄（防御性）

`PUT /api/fde/skills/{skillId}/assign`（重分配到 Agent）：

- 白板「分配到…」入口随收纳区下线而消失，**且用户明确不提供任何重绑游离技能的 UI**。
- 但 `assign` 端点本身在「同岗位 Agent→Agent 迁移」「白板拖拽迁移」仍可能被白板内部使用（拖拽到另一 Agent）。**需确认白板是否还有 Agent↔Agent 拖拽迁移**——
  - **若白板仍支持 Agent 间拖拽迁移技能** → `assign` **保留**（它服务于「Agent→Agent」，与游离重绑无关）。
  - **若白板不再有任何 assign 触发** → `assign` 可下线。
- **关键防御**：无论保留与否，`assign` 当前逻辑对「游离技能（positionId=null）首次绑定取目标 Agent 岗位」是开放的（§见代码 `if (positionId != null && ...)` 分支）。用户口径是**游离技能不可再绑回**，故应**在 `assign` 加守卫：拒绝对 `position_id IS NULL` 的游离技能执行 assign**（返回 403 / 业务码），堵死「绕过 UI 直调接口把游离技能绑回」的后门，与「单向不可逆」口径一致。

```java
// PositionSkillService.assign 内，requirePositionOrigin 之后追加：
if (s.getPositionId() == null) {
    throw new BusinessException(ResultCode.FORBIDDEN,
            "游离技能（已脱离岗位）不可重新分配到 Agent，请在技能管理页编辑或删除");
}
```

> 这条守卫即使白板仍用 assign 做 Agent↔Agent 迁移也安全：那些技能 `position_id` 非空，不受影响。

### 4.3 `unbind` 端点 —— 保留

`PUT /api/fde/skills/{skillId}/unbind`（从 Agent 解绑单个技能）的语义需**对齐新口径**：解绑也应让技能**彻底游离**（清 `agent_id` + `position_id`），与删 Agent 一致。

> ⚠️ 决策点：当前 `unbind` 只清 `agent_id` 保留 `position_id`（落收纳区）。新口径下「解绑」是否也应彻底游离？
> - **建议：是**，让「单技能解绑」与「删 Agent 批量 detach」语义统一（都→游离）。白板上技能卡 🗑「从 Agent 移除」后技能直接进游离态、转到技能页。
> - 改法：`unbind` 内 `s.setAgentId(null)` 后追加 `s.setPositionId(null)`，幂等判据从 `agentId == null` 改为「`agentId == null && positionId == null`」。
> - 这关系到白板「技能卡 🗑 移除」后的用户体验（技能从白板消失、转到技能页），**需 UI 设计师 + 最终用户在 CR 确认交互可接受**。

### 4.4 技能页查询 —— 加「游离」标识字段

`GET /api/fde/skills`（`AdminSkillService.list` → `searchAdmin`）：

- **不改过滤口径**（仍 `origin='POSITION' AND parent_id IS NULL`，已混列已绑定 + 游离）。
  > **📌 校准标注（2026-07-17）**：后续已按 PRD v1.1 新增 `referenced` 引用状态筛选参数，属本文档之后的演进，与本条「本期不改口径」不冲突。详见《设计文档校准审计-20260717.md》。
- **`AdminSkillListItem` 新增字段** `boolean detached`（或 `mounted`）表示「游离 / 未挂载岗位」：

```java
public record AdminSkillListItem(
        Long id, String code, String name, String description,
        String skillType, String category, String status, int toolCount,
        long referencedByExpertCount, long childCount, OffsetDateTime updatedAt,
        /** 游离技能（未挂载任何岗位/Agent）：position_id IS NULL。技能页打「游离」标识。 */
        boolean detached
) {}
```

- 取值：`Skill` 实体已有 `positionId`，`AdminSkillService.list` 组装时 `boolean detached = (s.getPositionId() == null)` 即可，**无需新增查询 / join**（实体已含该列，分页查询照旧）。
- 标识判据 = `position_id IS NULL`（迁移后口径统一，单一判据；若不迁移则需 §2.4 的双判据，再次印证迁移更优）。

> **不新增任何重分配 / 重绑入口**（用户明确）。技能页仅在列表行渲染一个「游离 / 未挂载岗位」标签（前端 tag），点击仍只进编辑器（编辑）或删除。

---

## 5. 运行时 / 发布（确认无回归）

- `EffectivePositionView` 仅含 `agent_id` 非空且 published 技能。游离技能 `agent_id` 恒 NULL → **本就不进运行时视图、不随岗位发布生效**。本变更只是把「半脱离（position_id 非空）」也变成「全游离（position_id 也 NULL）」，**对运行时装配零影响**（运行时从不读 position_id 来挑技能，而是经 Agent）。
- 发布前置校验（`countByAgentIdAndStatus` / `countByPositionIdAndStatus` 等）均**经 active Agent 统计**，游离技能不计入。无回归。
- **结论：运行时 / 发布链路无需任何改动，亦无回归。** 实现期由 QA 跑既有运行时 / 发布 e2e 回归确认。

---

## 6. 兼容与回归（测试与前端退役）

### 6.1 后端测试

| 用例 | 改动 |
|------|------|
| `PositionManagementIntegrationTest` 删 Agent 转未绑定相关断言 | 断言从「`agent_id=NULL` 且 **`position_id` 保留**」改为「`agent_id=NULL` **且 `position_id=NULL`**」 |
| 删岗位级联软删「混合岗位」用例（按 position_id 命中含未绑定技能） | **需重审**：变更后游离技能 `position_id=NULL`，删原岗位**不再**级联软删它们（正确——它们已脱离岗位）。该用例的「未绑定技能也被级联软删」断言要么删除，要么改为「绑定技能被级联、游离技能不受影响」 |
| `SkillToolRefSyncIntegrationTest` | 不受影响（删 Agent 不触发 syncRefs），跑通即可 |
| `assign` 游离技能守卫（§4.2 新增） | 新增用例：对 `position_id=NULL` 技能调 assign → 403 |
| `unbound-skills` / `listUnbound` 相关用例 | 随端点下线一并删除 |
| `V44` 迁移效果 | 新增集成/迁移验证：存量半脱离技能迁后 `position_id=NULL`，status/ref 不动 |

### 6.2 前端退役（收纳泳道整体下线）

| 文件 | 改动 |
|------|------|
| `PositionWorkbench.vue` | 删除「未绑定 Agent 收纳泳道」`<AgentLane v-if="store.orphanSkills.length" is-orphan>` 整块（L640-653）及相关 handler（`onAssignSkill` 收纳区分配、删 Agent 后并入 orphan 的逻辑）。删 Agent 成功提示文案改为「已删除 Agent · N 个技能已脱离岗位（可在技能页查看）」 |
| `stores/position.js` | 退役 orphan 相关：`ORPHAN_AGENT_ID` 常量、`orphanSkills`/`orphanLoading`、`loadUnboundSkills`、`load` 里对 `loadUnboundSkills` 的并行调用、`removeAgent` 把技能并入 orphanSkills 的逻辑、`assignSkillToAgent` 从收纳区移出的分支、`allSkills` 里拼 orphan 的分支、`checkInput.orphanSkills`。**「收纳泳道闪烁」修复（hydrate 保留 orphanSkills）随 orphanSkills 字段一并退役**——该 bug 因收纳区与详情接口口径错位而生，收纳区下线后问题域消失，对应防御代码（L165-169 注释段逻辑）连同删除 |
| `components/position/AgentLane.vue` | `is-orphan` 分支（淡样式 / 收纳区文案 / 「分配到…」下拉 / 「没有未绑定技能」空态）整段退役；该组件回归为「只渲染绑定 Agent」的纯组件。或保留组件、仅删 isOrphan 相关 props/分支 |
| `components/position/SkillCard.vue` | 收纳区相关分支（`showRemove=false` 针对 orphan 的注释/逻辑）随之简化 |
| `utils/positionModel.js` | 发布前检查的「未绑定 Agent 技能 → warning」（L371/L416-424）退役——游离技能已不属任何岗位，岗位发布检查不应再提它们 |
| `api/position.js` | 删 `getUnboundSkills` |
| `stores/__tests__/position.test.js` | 删/改：`removeAgent 把其技能转未绑定`、`assignSkillToAgent 未绑定→Agent`、`load 装载未绑定技能收纳区`、`收纳泳道闪烁回归`系列、`unbindSkill 搬到未绑定区`、`ORPHAN_AGENT_ID 常量导出` 等。`removeAgent` 用例改为断言「技能不再出现在白板任何泳道」（前端不再持有 orphan 概念） |

> **「收纳泳道闪烁」修复的退役说明**：该修复（hydrate 不清空 orphanSkills + loadUnboundSkills 权威回填）是为「收纳区与详情接口口径错位」打的补丁。收纳区整体下线后，`orphanSkills` 字段、`loadUnboundSkills`、相关 hydrate 防御**全部退役**，闪烁问题随之消失，不存在回归风险（被修复的代码路径已不存在）。

### 6.3 技能页前端

- 列表行渲染「游离 / 未挂载岗位」标签（读 `detached` 字段）。Notion 双主题令牌、tag 样式遵循既有规范。
- **不加任何重绑 / 分配 UI**。

---

## 7. 改动清单汇总（供 PM 派发）

**后端：**

1. `SkillRepository.detachSkillsFromAgent` —— UPDATE 同时清 `position_id`（§1.1）。
2. `AgentService.delete` / `AgentDeleteResultVO` —— JavaDoc 与文案口径改写（行为时序不变，§1.2）。
3. `Flyway V44` —— 存量半脱离技能迁为游离（**待用户确认**，§2.3）。
4. `PositionSkillService.assign` —— 加「游离技能不可 assign」守卫（§4.2）。
5. `PositionSkillService.unbind` —— 解绑也彻底游离（**待 UI/最终用户 CR 确认**，§4.3）。
6. 下线 `unbound-skills` 端点 / `listUnbound` / `findUnboundByPositionId`（§4.1）。
7. `AdminSkillListItem` + `AdminSkillService.list` —— 加 `detached` 字段（§4.4）。
8. 复核 `skill_table_ref` 反查消费方，删表引用阻断排除游离技能（**待复核**，§3.4）。

**前端：**

9. 收纳泳道整体退役（`PositionWorkbench` / `position.js` / `AgentLane` / `SkillCard` / `positionModel` / `api/position.js`，§6.2）。
10. 技能页加「游离」标识 tag（§6.3）。

**测试：** 后端 + 前端用例随上述调整（§6.1 / §6.2）。

---

## 8. 需用户 / PM 拍板的风险点

1. **【数据变更】存量迁移 V44**：是否一次性把现有「未绑定」技能（如销售岗 13/14）迁为游离（清 position_id）？架构师**推荐迁移**（口径统一、行为一致、风险低）。备选「不迁移」会造成双口径割裂，不推荐。— **§2**
2. **【交互口径】`unbind` 是否同步改为彻底游离**：白板技能卡 🗑「从 Agent 移除」后技能直接脱离岗位、转到技能页（而非旧版落收纳区可重绑）。建议「是」以统一语义，但属交互变更，需 UI 设计师 + 最终用户 CR 确认。— **§4.3**
3. **【待复核】数据表「删表前引用阻断」是否需排除游离技能**：避免游离技能的死引用撑住本可删的表。需后端 grep 反查消费方后定。— **§3.4**
4. **【确认】白板是否还有 Agent↔Agent 拖拽迁移**：决定 `assign` 端点保留 / 下线（无论如何都加游离守卫）。— **§4.2**
