# 问答链路 plan 模式与工具市场 —— 技术方案（定稿）

> **📌 校准标注（2026-07-17）**：本文档为混合状态——M1 工具市场部分已实现，但已被后续 V34/V36/V39 演进覆盖（listing 新增 target 列、sourceDefId 改 String、端点扩出 mcp-services 聚合发布族）；§4/§7.2 的 plan 编排接入部分已随主版本运行时剥离移出本仓/未落地（见《主版本运行时剥离-配置分发化设计.md》），本仓不含对应实现，保留作历史设计依据。详见《设计文档校准审计-20260717.md》。

> 作者：架构师 ｜ 状态：定稿（设计先行，本轮不写代码） ｜ 关联 ADR-02（对外 position / 物理列 expert_id 不动）
> 关联文档：`岗位模型-数据模型与两级路由设计.md`、`对话按skill隔离工具-技术方案.md`、`管理后台边界划分与契约显式化重构方案.md`、`连接器后管统一调整-工程方案.md`、`数据表管理-技术方案.md`、`N1命名统一改名映射表.md`、`LangGraph集成架构.md`、`MCP真实运行时-技术方案.md`、`意图分类分流与记忆抽取调度-架构设计.md`
>
> **本文档替代** `trash/岗位级MCP-API直接规划调用-技术方案.md`（旧"岗位级绑定 / 技能引用并集"口径已废弃）。
> 编排器技术栈：LangGraph(Python)。后端：JDK 21 + Spring Boot 3。

---

## 0. 口径锚点（用户已全部拍板，本文档据此设计，不再变更）

整体模型已由旧的"岗位级绑定 / 技能引用并集"**彻底改为"工具市场 + 个人工具箱"**。一句话概括：

> 工具(MCP/API/业务系统)统一接入平台后，有**两条互不冲突的使用方式**：
> ① **旧路（技能路径）**：被 `岗位 → agent → 技能` 引用（`skill.md @tool`）→ 走技能 SOP 时调用；
> ② **新路（plan 路径）**：MCP/API 发布到「工具市场」→ 用户**收藏**到个人工具箱 → 在 **plan** 规划时调用。

编排层 = **前置二分类分流**：① query 命中技能 → 走技能 SOP（现有路径，零回归）；② 未命中 → 模型自主 **plan** 规划。**plan 的可用工具 = 该用户从工具市场收藏的 MCP/API 工具**（个人工具箱：跨岗位、与当前岗位技能是否引用该工具无关）。

定稿逐项口径（不得擅改）：

1. **市场只放 MCP/API**。业务系统**只和技能绑定**、不进市场、不进 plan（且其运行时执行仍未接通）；数据表（TABLE）**不进 plan**，维持 skill-bound + 执行期 run/岗位强校验。
2. 新增角色「**工具管理员**」（本期暂以 `admin` 用户兼具 FDE + 工具管理员）；**任何工具发布到市场前须工具管理员人工审核**，审核时人工把"读/写性质 + 二次确认（`requiresConfirmation`）"配对。**生命周期以后管系统为准**：后管修改/下架后，已收藏用户被动响应（下架→该工具从其可用集消失；修改→自动用新版）。
3. **鉴权仅"平台对平台"**（共享平台凭证），本期不做"个人对平台"。
4. **二次确认/安全（从简）**：运行时 **plan 与技能一视同仁**，按工具自带 `requiresConfirmation` 决定是否弹确认；**不做 plan 专属强制确认 / fail-safe 过度确认**（用户明确不接受其体验代价）。安全靠"**发布时全量人工审核**"保证 `requiresConfirmation` 标对。不可逆工具暂不特殊处理；MCP 不强制 annotation。更强安全兜底一律列入 §9 backlog、本设计不做。
5. **plan 工具暂不做相关性收窄/排序**（收藏多少给多少）；§8 注明已知风险（讯飞 Qwen function-calling 受限、工具多会掉准 + 口头代办），列入 backlog。
6. **不影响现有管理后台服务与使用端页面**（向后兼容、纯加法）；ADR-02 物理层不动。

---

## 1. 目标与非目标

### 1.1 目标

- 在现有"**纯技能驱动**"链路之上，**纯加法**引入「工具市场 + 个人工具箱 + plan 模式」，使用户在 query 未命中技能时也能由模型自主 plan 规划、调用其收藏的 MCP/API 工具。
- 让平台具备「工具发布到市场」与「发布前人工审核」的**后端概念与数据模型**（本期重点）。
- 在编排层确立「**前置二分类分流**」骨架：命中技能走 SOP，未命中走 plan。
- 对存量行为**零回归**：未配置 / 未收藏任何工具的用户与岗位，行为字节级不变。

### 1.2 非目标（本期不做，见 §7 分期 与 §9 backlog）

- 不做 plan 工具的相关性收窄 / 排序。
- 不做 plan 专属强制确认、fail-safe、不可逆管控、两阶段守门器、完成态校验器、三态 writeClass。
- 不做"个人对平台"鉴权。
- 不接通业务系统运行时执行（维持现状未接通）。
- 不动 ADR-02 物理层（DB 列保 `expert_id`）。
- 不重写使用端（收藏 / plan 使用端 UX 依赖上层应用，本期只到后端概念）。

### 1.3 与现有"纯技能驱动"链路的关系（现状锚点）

链路当前为**纯技能驱动**，本设计在其前面加一道分流、并在 plan 分支挂上"收藏工具"，**不改技能分支**：

- 编排器 `orchestrator/app/runner.py`：`_pick_active_skill`（:40）取第一个有 SOP 的技能、`_tool_whitelist`（:52）只给该技能工具、`_build_initial_state`（:58-60）将其放入 `state["tool_whitelist"]`。
- 推理节点 `orchestrator/app/graph/nodes.py:208`：`reason_node` 用 `whitelist_to_openai_tools(state.get("tool_whitelist"))` 生成模型 tools。
- 系统提示词 `orchestrator/app/graph/prompt.py`：`render_system_prompt`（:224）固定 ReAct 行为协议。
- 数据层 `backend/.../skill/runtime/EffectivePositionView.java`：只有 `skills + resources`，工具只在 `EffectiveSkill.toolRefs`；契约层 Python `EffectiveExpert`（`orchestrator/app/integration/contracts.py:71`）同理。
- MCP/API 现状**只**经 `skill.md @tool → skill_mcp_ref / skill_api_ref` 进岗位；**无**"按 positionId 取全岗位 MCP/API"、**无**"用户↔工具"关系、**无**工具市场/收藏（全部从零建）。
- `requiresConfirmation`：MCP 人工按工具开关（端点 `PUT /api/fde/connectors/mcp/{id}/tools/{toolName}/confirmation`，`AdminMcpController.java:99`）、API 可配字段（GET 否 / 非 GET 是 默认）、TABLE delete 恒确认、MOCK/业务系统写死；运行时 `ToolExecutionService.execute()` 按它拦截、`ConfirmApprovalStore.consume()` 一次性凭证。

> 设计立场：**plan 路径复用一切已有的工具快照、确认、执行链路**，新增的只有"市场发布元数据 + 用户收藏关系 + 分流落点 + plan 工具喂入"。

---

## 2. 端到端模型

### 2.1 角色与对象

| 对象 | 说明 |
|------|------|
| 工具（MCP/API） | 平台中**单个可调用工具**的限定名（运行时 toolCode）。**MCP**：一个 `mcp_def` 的 `tools_cache` 含 N 个工具，每个工具的运行时限定名是 `mcp__{mcpCode}__{toolName}`，且 `requiresConfirmation` 逐工具存（端点 `PUT /api/fde/connectors/mcp/{id}/tools/{toolName}/confirmation`）；**API**：1 个 `api_def` = 1 个工具，toolCode = `api_def.code`。**市场以"单个工具"为粒度**，不是以连接器(def)为粒度 |
| 业务系统 / 数据表 | **不进市场、不进 plan**。业务系统只与技能绑定且运行时未接通；TABLE 维持 skill-bound + run 校验 |
| 工具市场（marketplace） | 平台级清单：哪些 MCP/API 工具**已审核通过、可被用户收藏** |
| 个人工具箱（收藏集） | 用户↔工具的收藏关系。**跨岗位**，与当前岗位技能是否引用该工具无关 |
| 工具管理员 | 审核工具发布、把读写性质与 `requiresConfirmation` 配对。本期 `admin` 兼具 FDE + 工具管理员 |
| 外接知识库 | 经 MCP 接入，作为 plan 资源（与普通 MCP 工具同路径进入市场/收藏/plan） |

### 2.2 端到端流程（文字时序）

**A. 发布 + 审核（本期后端重点）**

```
工具管理员(admin)
   │  在后管选择某 MCP/API 工具(toolCode) → 提交"发布到市场"
   ▼
[发布申请] status = PENDING_REVIEW
   │  工具管理员人工审核：确认读/写性质、把 requiresConfirmation 标对
   ▼
审核通过 → status = PUBLISHED（进入市场可见集）
审核驳回 → status = REJECTED（不进市场）
```

**B. 收藏（本期建表，使用端 UX 后续）**

```
用户 → 浏览市场(PUBLISHED 工具) → 收藏某工具 → 写入"用户↔工具收藏关系"
个人工具箱 = 该用户全部收藏 ∩ 当前 PUBLISHED 集（下架/驳回的实时被剔除）
```

**C. 运行时（分流 + plan 消费，后续接入）**

```
query 进入编排器
   │
   ▼ [前置二分类分流] （新增，落在 _pick_active_skill 之前）
   ├─ 命中技能 ──────────► 走技能 SOP（现有路径，零回归）
   │                         tools = active skill 的 toolWhitelist
   └─ 未命中技能 ──────────► plan 模式
                             tools = 该用户个人工具箱(收藏的 PUBLISHED MCP/API)
                                     + 外接知识库(MCP)
                             模型自主规划 → tool_call → 复用现有执行/确认链路
```

### 2.3 数据流示意

```
        ┌─────────────── 接入层（现状，不动）───────────────┐
        │  mcp_def / api_def  ←─ FDE 接入                    │
        └───────┬───────────────────────────┬───────────────┘
                │ ①旧路：skill.md @tool       │ ②新路：发布到市场
                ▼                            ▼
        skill_mcp_ref / skill_api_ref   tool_market_listing (新表, 1行=1单工具, tool_code=运行时限定名)
                │                            │  ▲ 工具管理员人工审核 (逐工具配 requiresConfirmation)
                ▼                            ▼
        EffectiveSkill.toolRefs        user_tool_favorite (新表, 用户↔toolCode 收藏)
                │                            │
                ▼                            ▼ (个人工具箱 = 收藏 ∩ PUBLISHED)
        ┌───────────────── 编排器 (LangGraph) ─────────────────┐
        │  [二分类分流]  命中 → 技能SOP(active skill toolWhitelist) │
        │               未命中 → plan(个人工具箱 + 外接知识库MCP)   │
        └───────────────────────┬──────────────────────────────┘
                                ▼
        tool_call → ToolExecutionService.execute()  (复用：按 requiresConfirmation 拦截)
                                ▼
        ConfirmApprovalStore.consume()  (复用：一次性确认凭证)
```

**关键不变量**：无论工具从"技能"还是"plan"被调用，到达 `ToolExecutionService` 后**完全同一条执行 + 确认链路**，按同一份工具快照的 `requiresConfirmation` 决策（§6）。

---

## 3. 数据层

> 原则：**纯加法**。不改 `mcp_def` / `api_def` / `skill_mcp_ref` / `skill_api_ref` 结构；不动 ADR-02（新表物理列若涉及用户/岗位维度，沿用既有列命名习惯，不引入 expert↔position 物理重命名）。

### 3.1 新增表 1：工具市场发布元数据 `tool_market_listing`

承载"哪些 MCP/API 工具已发布、处于什么审核状态、读写性质与确认配对"。**listing 粒度 = 单个可调用工具**（不是连接器/def）：一个 MCP 连接器下的每个工具各占一行 listing。

| 列 | 类型 | 说明 |
|----|------|------|
| `id` | PK | |
| `tool_type` | varchar | 仅 `MCP` / `API`（**约束层禁止 TABLE / BIZSYSTEM / MOCK / SKILL**，对应口径①） |
| `tool_code` | varchar | **运行时限定名（真正的连接键）**：MCP=`mcp__{mcpCode}__{toolName}`，API=`api_def.code`。收藏/plan/执行全部以此为键，与运行时 `toolCode` 严格同口径 |
| `tool_name` | varchar | MCP 工具的 `toolName`（即 `tools_cache` 内单个工具名，**MCP 必填**）；API 行**可空**（API 1 def→1 tool，无子工具名）。用于回链连接器侧逐工具配置（如 `PUT /api/fde/connectors/mcp/{id}/tools/{toolName}/confirmation`） |
| `source_def_id` | bigint | 来源 `mcp_def.id` / `api_def.id`（按 `tool_type` 解释）。**仅作展示回链用**（点回后管看连接器），**不是连接键**——连接键是 `tool_code` |
| `display_name` | varchar | 市场展示名（默认取该工具 bizName，可由审核时调整） |
| `description` | text | 市场展示描述 |
| `write_class` | varchar | 读/写性质标注（本期二态：`READ` / `WRITE`；审核时人工标。三态 writeClass 入 backlog） |
| `requires_confirmation` | boolean | **该单个工具**发布时人工标对的二次确认开关（**按工具粒度落库**，运行时直接采信，§6） |
| `status` | varchar | `PENDING_REVIEW` / `PUBLISHED` / `REJECTED` / `DELISTED`（下架） |
| `reviewer_id` / `reviewed_at` | | 审核人与时间（工具管理员） |
| `review_comment` | text | 审核意见（驳回原因等） |
| `submitter_id` / `created_at` / `updated_at` | | 提交人与时间戳 |

唯一约束：**`(tool_type, tool_code)` 唯一**（一个**单工具**在市场只有一条 listing）。注意 `tool_code` 已是工具级限定名 → 同一 MCP 连接器下的不同 `toolName` 因 `tool_code` 不同而各成一行，互不冲突。**唯一约束故意不含 `status`**，REJECTED 行的复用规则见 §3.5 状态机（驳回重提走同行 reset，不新插行）。

> **为何把粒度落在单工具（M1 修订要点）**：运行时 toolCode 是工具的限定名，`requiresConfirmation` 在 MCP 侧本就**逐工具**存。若 listing 用 `source_def_id + tool_code` 但实质按 def 落一个确认结论，会让"一个连接器只给一个确认结论"，相对现状逐工具能力**倒退**。故 listing 必须能定位到单个工具：`tool_code` 存运行时限定名、新增 `tool_name`、`source_def_id` 降级为展示回链、唯一键 `(tool_type, tool_code)`，确保 `requires_confirmation` 严格按工具粒度落库。
>
> **为何 listing 也存 `requires_confirmation` / `write_class`**：发布时人工审核是本期唯一的安全保障（口径④），审核结论必须**落库**且作为运行时 plan 路径的权威值——避免 plan 时再去回算连接器侧的 confirmation 解析逻辑造成口径漂移。技能路径仍用其原有快照解析（不动），二者在"同一 toolCode 同一结论"上保持一致，由审核流程 + §6.4 回写机制保证。

### 3.2 新增表 2：用户收藏关系 `user_tool_favorite`

承载"个人工具箱"，**跨岗位**（不带 positionId 维度，对应口径"与当前岗位无关"）。

| 列 | 类型 | 说明 |
|----|------|------|
| `id` | PK | |
| `user_id` | bigint | 收藏人 |
| `tool_type` | varchar | `MCP` / `API` |
| `tool_code` | varchar | 收藏的工具运行时限定名（指向 `tool_market_listing.tool_code`，MCP=`mcp__{mcpCode}__{toolName}` / API=`api_def.code`）。收藏粒度=单工具 |
| `created_at` | | 收藏时间 |

唯一约束：`(user_id, tool_type, tool_code)` 唯一。

**个人工具箱有效集 = `user_tool_favorite` ⋈ `tool_market_listing WHERE status = PUBLISHED`**。
→ 这天然实现口径②的"生命周期以后管为准、被动响应"：
- **下架**（status→`DELISTED`）：join 后该工具自动从用户可用集消失，**无需删收藏行**（保留收藏历史，后管重新上架即恢复）。
- **修改**：listing 的 `display_name`/`description`/`requires_confirmation`/工具 schema 更新后，plan 取的是当前 listing + 当前快照 → **自动用新版**。

### 3.3 与现有 `mcp_def` / `api_def` / `skill_*_ref` 的关系

- `tool_market_listing.source_def_id` **仅作展示回链** `mcp_def` / `api_def`（物理表名已核实：`McpDef.java:23 @Table(name="mcp_def")`、`ApiDef.java:23 @Table(name="api_def")`）；**连接键是 `tool_code`（运行时限定名），不是 `source_def_id`**。MCP 下一个 def 对应多行 listing（每 `toolName` 一行），均回链同一 `source_def_id`。
- **不改** `skill_mcp_ref` / `skill_api_ref`（`SkillMcpRef.java:20`、`SkillApiRef.java:20`）：技能路径完全不受影响，工具仍可"既被技能引用、又发布到市场"，二者是同一 toolCode 的两个入口。
- 同一工具被技能引用 vs 被收藏到工具箱，**互不依赖**（口径：plan 工具与当前岗位技能是否引用无关）。

### 3.4 EffectivePositionView / 契约层是否需扩展

- **本轮范围（§7）不扩展 `EffectivePositionView` 与 `EffectiveExpert`**。原因：本轮只做"市场发布 + 审核后端 + 数据模型"，**plan 编排接入属于后续**。`EffectivePositionView`（`skill/runtime/EffectivePositionView.java`，只含 skills+resources）与 Python `EffectiveExpert`（`contracts.py:71`，只含 skills+resources）维持现状，**零 wire 变更、零 N1 风险**。
- **后续 plan 接入时**才扩展（设计预留，wire 名提前锁定见下）：编排器需要"当前用户的个人工具箱工具集"。两个可选注入通道，**择一，到 plan 接入阶段定**：
  - **通道甲（推荐）**：在 `EffectiveExpert` 新增 `favoriteTools: list[ToolSchema]`（与技能内 `ToolSchema` 同类型），由 Java 装配时按 `userId` 查个人工具箱填充。优点：复用现有 expert payload 通道与 `ToolSchema` 类型，Python 侧对"工具来自技能还是收藏"无感。
  - **通道乙**：编排器经独立 internal 接口按 `userId` 实时拉取个人工具箱。优点：与 expert 装配解耦、收藏变更实时；缺点：多一次 IO。
- **wire 名提前锁定（N1 教训：历史上 N1 漏改 wire 致办事全断）**：若采用通道甲，新字段 Java↔Python **两侧字面均取 `favoriteTools`**，Java record 字段名即 JSON key（无自定义 `@JsonProperty`）、Python Pydantic 字段名即反序列化 key，字面相等→wire 自然对齐；新字段无历史包袱，**不沿用 expert 前缀**。默认空列表→老请求不带该字段时零回归。**到 plan 接入阶段必须加 wire 契约测试**（参照现有 `effectiveExpert`/`expertId` 锚定测试）。

> 锁定铁律重申：本轮**不引入任何新 wire 字段**（最稳）；后续引入时 Java↔Python lockstep + 契约测试，禁止单边改名。

### 3.5 listing 审核状态机（M2 修订要点：合法流转矩阵 + 唯一键防撞）

> 背景：四态 `PENDING_REVIEW / PUBLISHED / REJECTED / DELISTED` 在 `(tool_type, tool_code)` 唯一约束下，若"驳回后重提"用**新插行**会撞唯一键（REJECTED 行已占用同 `tool_code`）。故明确：**全流程对同一 `tool_code` 只维护一行 listing，状态在该行上原地流转，永不为同 `tool_code` 新插第二行。**

**合法状态流转矩阵**（行=当前态，列=动作；✓=允许，✗=非法，空=不适用）：

| 当前态 ＼ 动作 | submit（提交发布） | review→approve（通过） | review→reject（驳回） | resubmit（重提） | delist（下架） | relist（重新上架） | edit metadata（改元数据） |
|---|---|---|---|---|---|---|---|
| (无行) | ✓ → `PENDING_REVIEW`（**首次插行**） | | | | | | |
| `PENDING_REVIEW` | ✗（已在审） | ✓ → `PUBLISHED` | ✓ → `REJECTED`（填 `review_comment`） | ✗（无需重提，本就在审） | **见③** | | ✓（在审改元数据，仍 `PENDING_REVIEW`） |
| `REJECTED` | ✗（用 resubmit，不新插行） | | | ✓ → **同行 reset 回 `PENDING_REVIEW`**（清空 `reviewer_id/reviewed_at`，保留/或清 `review_comment`） | | ✗ | ✓（重提前可改元数据） |
| `PUBLISHED` | ✗ | ✗ | ✗ | ✗ | ✓ → `DELISTED` | ✗（**`PUBLISHED→relist` 非法**，已在架） | **见④** |
| `DELISTED` | ✗ | ✗ | ✗ | ✗ | ✗（已下架） | ✓ → `PUBLISHED`（`relist` **只能从 `DELISTED` 出发**） | ✓（下架态可改元数据，仍 `DELISTED`） |

逐条结论（对应 M2 ①~④）：

- **① 驳回后重提**：`REJECTED --resubmit--> PENDING_REVIEW`，**在同一行上 reset**（同 `tool_code` 复用原行），**绝不新插行** → 不会撞 `(tool_type, tool_code)` 唯一键。这是唯一约束故意**不含 status**的前提：任一 `tool_code` 全生命周期仅一行。
- **② relist 来源限定**：`relist` 仅 `DELISTED → PUBLISHED` 合法；`PUBLISHED → relist` **非法**（已在架，无意义）。下架走 `delist`、上架走 `relist`，二者成对且只在 `PUBLISHED ↔ DELISTED` 间切换。
- **③ `PENDING_REVIEW → delist`**：`PENDING_REVIEW` 阶段**不走 delist**，改提供 **withdraw（撤回）= 删除该行**（因尚未发布、无收藏依赖），等价于"未发生过发布"，避免与 `DELISTED`（专指"曾发布后下架，保留收藏历史"）语义混淆。删行后可重新 submit。`delist` 仅对 `PUBLISHED` 合法。
- **④ PUBLISHED 工具改 listing 元数据是否需重审**：**口径**——仅改 `display_name` / `description`（纯展示字段）**不需重审**，原地更新、维持 `PUBLISHED`。但**改 `write_class` / `requires_confirmation`（安全语义字段）必须重新审核**：将该行置回 `PENDING_REVIEW`（临时退出市场可见集，收藏⋈PUBLISHED 自动剔除直至重新通过），由工具管理员复核后再 `approve` 回 `PUBLISHED`。理由：这两个字段是本期唯一的安全兜底（口径④），任何修改都须经人工复核，不允许绕过审核改安全结论。

> 与 §3.2 有效集的关系：有效集 = `favorite ⋈ status=PUBLISHED`，故仅 `PUBLISHED` 行对用户可见可用；`PENDING_REVIEW`（含因改安全字段退回的）/`REJECTED`/`DELISTED` 行均自动不在用户可用集中，无需额外清理收藏行。前端"状态→可见操作"映射见 §5.4。

---

## 4. 编排层

> 本轮不写代码；本节给出**落点与骨架**，plan 分支的模型决策策略（prompt、是否两阶段等）由 AI 专家在 plan 接入阶段填充，本设计只定架构位与数据来源。

### 4.1 二分类分流落点

现状 `runner.py` 链路：`run_stream`（:200）→ `_build_initial_state`（:58）→ `_pick_active_skill`（:40，取第一个有 SOP 技能）→ `_tool_whitelist`（:52）。

**分流判定加在 `_pick_active_skill` 之前**（`_build_initial_state` 内最前置）：

```
_build_initial_state(req):
    # ① 前置二分类分流（新增）
    route = _classify_route(req)        # 命中技能? -> SKILL ; 否则 -> PLAN
    if route == SKILL:
        active_skill = _pick_active_skill(req)     # 现有逻辑，零改动
        whitelist    = _tool_whitelist(active_skill)
        mode_tag     = "SKILL"
    else:                                # PLAN
        active_skill = None
        whitelist    = _favorite_tools(req)        # 个人工具箱(收藏的 PUBLISHED MCP/API) + 外接知识库MCP
        mode_tag     = "PLAN"
    return {..., "tool_whitelist": whitelist, "_route_mode": mode_tag, ...}
```

- `_classify_route`：二分类（命中技能 / 未命中）。**与现有意图分类分流（`意图分类分流与记忆抽取调度-架构设计.md`）对齐复用**——技能命中判定沿用其现有机制；本设计只在"未命中"出口接上 plan 分支，不新造分类器。
- **技能分支零改动**：命中技能时，`active_skill`/`whitelist` 与现状逐字节一致 → `reason_node`（`nodes.py:208`）看到的工具不变 → **技能路径零回归**。

### 4.2 plan 分支把"个人工具箱"喂给模型

- `_favorite_tools(req)`：返回当前用户收藏且 `PUBLISHED` 的 MCP/API 工具 schema（来源见 §3.4 通道甲/乙）。外接知识库以 MCP 形式收藏 → 同集合内，无需特殊分支。
- 喂入点**复用现有通道**：plan 分支也把工具放进 `state["tool_whitelist"]` → `reason_node`（`nodes.py:208`）的 `whitelist_to_openai_tools(state["tool_whitelist"])` **无需逻辑改动**，模型自然看到 plan 工具。这是最小侵入点。
- **prompt**：plan 模式与技能 SOP 模式提示词不同（plan 无 SOP 剧本，需"自主规划"协议）。`render_system_prompt`（`prompt.py:224`）现固定 ReAct，需按 `_route_mode` 数据驱动渲染 plan 协议段；**具体措辞由 AI 专家填**，本设计只定渲染开关与数据来源（`_route_mode == PLAN`）。
- **plan 工具暂不收窄/排序**（口径⑤）：收藏多少给多少，全部进 `tool_whitelist`。已知风险见 §8。

### 4.3 与现有技能路径并存、零回归

- 两分支在 `_build_initial_state` 出口收敛到**同一个 `state["tool_whitelist"]` 形态**，下游 `reason_node` / 执行回调 / 确认链路**完全共用**，不引入第二套执行路径。
- 工具被模型选中后回调 `ToolExecuteRequest`（`contracts.py:127`）→ Java `ToolExecutionService.execute()` 路由到同一 MCP/API 执行器，`toolCode` 一致即可，**无需新增执行路径**。
- **确认标志的运行时落点（B2 修订要点，给实现者明确边界）**：plan 接入时，确认门禁**复用现有机制、不改 `ToolExecutionService`**。具体——在 **run 装配阶段**（组装本次会话可用工具集时）把每个工具的确认标志写进**现有 run 注册表/工具快照**（与技能路径写入同一处），`ToolExecutionService.execute()` 仍按它原有逻辑从注册表读取并拦截。**实现者切勿改动执行服务本身**：它对"工具来自技能还是 plan"无感，只认注册表里的确认标志。这样 plan 与技能复用完全同一道门禁。
- 可观测：`state["_route_mode"]` 透出到 trace，标注本次走 SKILL 还是 PLAN，供后续分析占比与质量（埋点细化入 §9 backlog）。

---

## 5. 管理后台

> 纯加法、不破坏现有连接器(MCP/API)配置页与服务（口径⑥）。

### 5.1 工具市场发布 / 审核入口（工具管理员，本期 admin 兼）

- 在现有 MCP/API 连接器配置体系**旁挂**"工具市场"管理区（不改连接器配置页本身）：
  - **发布入口**：工具管理员从已接入的 MCP/API 工具中选 toolCode → "发布到市场" → 写 `tool_market_listing` (status=`PENDING_REVIEW`)。
  - **审核台**：列出 `PENDING_REVIEW` 工具 → 工具管理员逐项确认 `write_class`(READ/WRITE) 与 `requires_confirmation` → 通过(→`PUBLISHED`) / 驳回(→`REJECTED`，填 `review_comment`)。
  - **生命周期**：上架/下架(`PUBLISHED`↔`DELISTED`)、修改 listing 元数据；下架不删用户收藏行（§3.2 被动响应）。
- 新增后端接口（**走 `/api/fde/market/...` 前缀**，本轮实现）：
  - `POST /api/fde/market/listings`（提交发布）
  - `GET /api/fde/market/listings?status=PENDING_REVIEW`（审核台列表）
  - `POST /api/fde/market/listings/{id}/review`（通过/驳回 + 配 write_class/requiresConfirmation；通过时回写连接器侧 §6.4）
  - `POST /api/fde/market/listings/{id}/delist` / `relist`（下架/重新上架）
  - `DELETE /api/fde/market/listings/{id}`（`PENDING_REVIEW` 撤回删行，§3.5③）
- **角色 / 鉴权（B3 修订要点）**：**复用现有 `/api/fde/**` 角色门，不新建权限点框架**。market 接口挂在 `/api/fde/market/...` 前缀下 → 自动被现有 `AdminRoleGuard`（ADMIN/FDE 可访问）覆盖；`admin` 本就是 ADMIN 角色 → **零新增鉴权代码**。本期"工具管理员"是**概念角色**（由 admin 兼任），不落地为独立权限点。"工具管理员"细粒度权限点拆分（独立账号/权限）**留 backlog（§9）**。

### 5.2 与现有连接器配置页关系

- 连接器(MCP/API)接入与 `PUT /api/fde/connectors/mcp/{id}/tools/{toolName}/confirmation`（`AdminMcpController.java:99`）等现有端点**完全不动**。
- "发布到市场"是在已接入工具之上的**新动作**，不替代、不修改接入流程。
- listing 的 `requires_confirmation` 与连接器侧 confirmation 配置：**审核通过时把 listing 结论回写连接器侧**（§6.4），连接器侧为单一真相，运行时统一从连接器侧快照取值；二者口径一致由回写机制保证、不再双源漂移。

### 5.3 使用端（收藏 / plan）

- 收藏关系建表本期完成；**收藏与 plan 的使用端 UX 依赖上层应用，列入后续**（§7）。本期可提供最小后端接口（`POST /api/user/favorites` / `DELETE` / `GET /api/user/favorites`）以备上层接入，但不交付前端页面。

### 5.4 前端落点（工具市场后管页，FB1/FB2/FB3 修订要点）

> 仅约束本期工具管理员侧（发布管理 / 审核台）的前端落点；收藏/plan 使用端 UX 仍属后续（§7）。

- **菜单与路由（FB1，落点写死，不塞进连接器容器）**：
  - 在 `AdminRail` **新增一级菜单「工具市场」**，与「连接器」平级独立。
  - **独立路由 `market`**（不复用、不嵌入连接器路由）。
  - 页内用 **`el-tabs` + `?tab=` 模式**（**复用 `AdminConnector` 既有写法**）分两个 Tab：**发布管理**（已发布/在审/下架列表 + 提交发布 + 上下架/撤回/编辑元数据）、**审核台**（`PENDING_REVIEW` 列表 + 通过/驳回 + 配 write_class/requiresConfirmation）。
  - **禁止**塞进连接器容器再加 Tab——职责不清且会改动现存连接器页。
- **前端门禁（FB2，与后端 B3 一致）**：market 路由 **沿用 `meta.roles: ['ADMIN','FDE']`**，**不引入新角色 meta**，与后端 `/api/fde/**` 角色门同口径。
- **状态 → 可见操作映射表（FB3，与 §3.5 流转矩阵对齐）**：

| listing status | 审核台可见操作 | 发布管理可见操作 |
|---|---|---|
| `PENDING_REVIEW` | **通过**（→PUBLISHED）/ **驳回**（填 `review_comment` →REJECTED）；可改元数据 | **撤回**（删行，§3.5③）；编辑元数据（仍在审） |
| `PUBLISHED` | （不出现在审核台） | **下架**（→DELISTED）；**编辑元数据**：仅改名/描述原地生效，**改 `write_class`/`requires_confirmation` 触发退回 `PENDING_REVIEW` 重审**（§3.5④） |
| `REJECTED` | （只读，展示 `review_comment`） | **重提**（resubmit→同行 reset 回 PENDING_REVIEW，§3.5①）；重提前可改元数据 |
| `DELISTED` | （不出现在审核台） | **重新上架**（relist→PUBLISHED，§3.5②）；可改元数据 |

> 该表为前端按钮可见性的唯一依据，与 §3.5 后端合法流转矩阵一一对应；前端不得放出矩阵中标 ✗ 的动作（如对 `PUBLISHED` 放"重新上架"）。

---

## 6. 安全 / 鉴权

### 6.1 鉴权：仅"平台对平台"（口径③）

- MCP/API 调用使用**共享平台凭证**（现状），plan 路径**不引入**"个人对平台"凭证。
- plan 工具来自"当前用户收藏的 PUBLISHED 工具"，集合本身即授权边界；执行期沿用现有 run/session/user 上下文校验（回调 `ToolExecuteRequest` 带 runId/userId，`contracts.py:127`）。

### 6.2 二次确认：plan 与技能一视同仁（口径④，从简）

- 运行时**不区分** plan / 技能，统一按工具的 `requiresConfirmation` 决定是否弹确认：
  - 技能路径：沿用现状（工具快照/连接器侧的 requiresConfirmation）。
  - plan 路径：审核通过后 listing 结论已**回写连接器侧**（§6.4），运行时从连接器侧同一份快照取值——与技能路径**同源**，非两套来源。
  - 二者到 `ToolExecutionService.execute()` 是**同一条拦截链路**、`ConfirmApprovalStore.consume()` 同一份一次性凭证逻辑（`ToolExecutionService.java` / `ConfirmApprovalStore.java`），**本期不改执行服务**（B2）。
- **本期明确不做**：plan 专属强制确认、fail-safe 过度确认、不可逆工具特殊处理、MCP annotation 强制。安全保证**完全依赖"发布时全量人工审核把 requiresConfirmation 标对"**。
- **显式声明**：本期不实现任何"plan 比技能更严"的确认逻辑；若审核漏标，则该风险由审核流程兜底，不在代码侧加额外门禁（这是用户已接受的体验取舍）。

### 6.4 单一真相：审核时回写连接器侧确认标志（B1 修订要点）

> 问题：listing 的确认结论（`tool_market_listing.requires_confirmation`）与连接器侧（MCP `tools_cache` 内逐工具 `requiresConfirmation` / `api_def.requires_confirmation`）是**两处来源**，二者可能漂移（如审核标 true、连接器侧仍 false）。

- **机制**：审核 `approve` 时（以及 §3.5④ 改安全字段重审通过时），**把 listing 的 `requires_confirmation` / `write_class` 结论回写到连接器侧**——
  - MCP：调用现有逐工具确认落库逻辑（端点 `PUT /api/fde/connectors/mcp/{id}/tools/{toolName}/confirmation` 背后的 service），按 `tool_name` 定位单个工具写入（**这正是 M1 新增 `tool_name` 列的用途之一**）；
  - API：写 `api_def.requires_confirmation`。
- **效果**：连接器侧成为**单一真相**，listing 上的两个安全字段只是"审核态的工作副本/可追溯记录"。运行时无论技能路径还是 plan 路径，都从连接器侧同一份快照取确认标志 → **彻底消除漂移**，且天然满足"同一 toolCode 同一结论"。
- 由此 §6.2 中"plan 路径采信 listing 值"精确表述为：**审核通过后 listing 值已回写连接器侧，运行时统一从连接器侧快照取值**，二路径同源。

### 6.3 范围隔离

- TABLE / 业务系统结构性不进 plan：`tool_market_listing.tool_type` 约束只允许 MCP/API（§3.1），收藏与 plan 工具集均派生自 PUBLISHED listing → TABLE/业务系统**物理不可达** plan。
- TABLE 仍走现有 skill-bound + 执行期 run/岗位强校验（`数据表管理-技术方案.md`），本设计不动。

---

## 7. 分期：本轮范围 vs 后续

> 用户口径："先保证**后端有"发布到市场"的概念**，收藏/使用端 UX 依赖上层应用。"

### 7.1 本轮范围（M1）

1. **数据模型**：新建 `tool_market_listing`、`user_tool_favorite` 两表（§3.1/3.2）。
2. **工具市场发布 + 审核后端**：发布申请、审核台、通过/驳回、上架/下架/撤回接口与服务（§5.1）；**审核状态机按 §3.5 合法流转矩阵实现**（驳回重提同行 reset、relist 仅从 DELISTED、改安全字段重审）；鉴权**复用 `/api/fde/**` 角色门**、admin 兼任工具管理员（**不新建权限点框架**，B3）。
3. **审核时配对** `write_class` + `requires_confirmation` **按工具粒度**落库（§3.1），并**审核通过回写连接器侧确认标志**（§6.4，单一真相）。
4. **最小收藏后端接口**（建表 + CRUD 接口，无前端 UX）。
5. **工具市场后管前端**（FB1）：`AdminRail` 新增「工具市场」一级菜单 + `market` 独立路由 + 页内 Tab（发布管理 / 审核台），门禁 `meta.roles:['ADMIN','FDE']`，状态→操作按 §5.4 映射表。
6. 约束：market 只收 MCP/API（TABLE/业务系统禁入）；listing 粒度 = 单工具（`tool_code` = 运行时限定名，§3.1 M1）。
7. **不动**：`EffectivePositionView`、`EffectiveExpert`、编排器 runner/nodes/prompt、现有连接器配置页与服务、ADR-02 物理层。→ **本轮对运行时链路零回归、零 wire 变更。**

### 7.2 后续

- **plan 编排接入**：二分类分流落点（§4.1）、plan 分支喂收藏工具（§4.2）、plan 提示词协议（AI 专家）、`EffectiveExpert.favoriteTools` 扩展 + wire 锁定 + 契约测试（§3.4）。
- **收藏 / plan 使用端 UX**（依赖上层应用）。
- 审计埋点（route_mode、调用来源 SKILL/PLAN、市场审核日志）。
- 更强安全兜底（§9）。
- plan 工具相关性收窄 / 排序（§8/§9）。
- 个人对平台鉴权（§9）。

---

## 8. 已知风险（plan 工具不收窄带来，列入 backlog）

1. **讯飞 / Qwen function-calling 能力受限**：当前模型对多工具 function-calling 的稳定性有限，plan 把"收藏的全部工具"一次性给模型，工具数偏多时风险更高。
2. **工具多会掉准 + 口头代办**：工具集越大，模型越易选错工具，或"口头声称已办"而未真正发起 tool_call（口头代办）。
3. **暂不收窄的取舍**：口径⑤明确本期不做相关性收窄/排序（收藏多少给多少），以上风险**已知并接受**；缓解（语义收窄 / Top-K / 重排）入 §9 backlog。

---

## 9. 后续 backlog（暂缓项集中清单）

| 类别 | 项 | 说明 |
|------|----|------|
| 更强安全兜底 | plan 专属强制确认 | 本期不做（口径④） |
| 更强安全兜底 | 不可逆工具管控 | 本期不特殊处理 |
| 更强安全兜底 | 模型两阶段 + 守门器 | 本期不做 |
| 更强安全兜底 | 完成态校验器 | 防"口头代办"，本期不做 |
| 更强安全兜底 | 三态 writeClass | 本期 write_class 只二态(READ/WRITE) |
| 更强安全兜底 | MCP annotation 强制 | 本期不强制 |
| 工具收窄 | plan 工具相关性收窄 / 排序 / Top-K | 缓解 §8 风险 |
| 鉴权 | 个人对平台鉴权 | 本期仅平台对平台 |
| 可观测 | 审计埋点（route_mode、SKILL/PLAN 来源、审核日志） | plan 接入后补 |
| 角色 | 工具管理员细粒度权限点拆分（与 FDE 拆为独立账号/权限） | 本期复用 `/api/fde/**` 角色门、admin 兼，不新建权限点框架（B3） |

---

## 10. 改动清单（带现状锚点）+ 风险 + 兼容性

### 10.1 本轮改动清单

| 层 | 文件 / 位置（现状锚点） | 改动点 | 风险 |
|----|------------------------|--------|------|
| 数据-新表 | 新建 Flyway **`V29__tool_market.sql`**（当前最大版本 V28，已核实 `backend/src/main/resources/db/migration/`）。**不要**写成 `position-schema.sql`（那是 `src/test/resources` 测试建表，非生产迁移） | `tool_market_listing`、`user_tool_favorite` | 低（纯新增表） |
| 数据-实体/仓储 | `backend/.../tooldef/entity/`，实体用 Hibernate `@Entity` + `@Table(name=...)`，注解风格参照 `McpDef.java`（`@Entity`/`@Table`/`@Column`/`@JdbcTypeCode`）、`SkillMcpRef.java` | 新增 listing/favorite Entity + Repository | 低 |
| 后台-发布审核 | 新建 `MarketController` + Service（风格参照 `tooldef/controller/AdminMcpController.java`），挂 `/api/fde/market/...` | 发布/审核/上下架/撤回/列表接口 + 审核通过回写连接器侧确认标志（§6.4） | 中（审核状态机正确性、tool_type 仅 MCP/API 约束、回写一致性） |
| 后台-收藏 | 新建 `UserFavoriteController` + Service | 收藏 CRUD（无前端） | 低 |
| 鉴权 | **复用现有 `/api/fde/**` 角色门（`AdminRoleGuard`，ADMIN/FDE）** | market 接口落 `/api/fde/market/...` 前缀自动覆盖，**零新增鉴权代码**；不新建权限点框架（B3） | 低 |
| 前端-工具市场页 | `AdminRail` + 新增 `market` 路由 + 页内 `el-tabs`（`?tab=`，复用 `AdminConnector` 模式） | 「工具市场」一级菜单 + 发布管理/审核台两 Tab，门禁 `meta.roles:['ADMIN','FDE']`，操作可见性按 §5.4（FB1/FB2/FB3） | 中（不得改动现存连接器页；操作可见性需对齐 §3.5 矩阵） |
| 运行时链路 | `runner.py` / `nodes.py` / `prompt.py` / `EffectivePositionView.java` / `contracts.py` | **本轮不改** | — |
| 测试 | — | 状态机流转测试（§3.5：驳回重提同行 reset 不撞唯一键 / relist 仅 DELISTED / 改安全字段重审）、tool_type 约束测试、单工具粒度 `(tool_type,tool_code)` 唯一测试、收藏⋈PUBLISHED 有效集测试、下架被动剔除测试、审核通过回写连接器侧一致性测试（§6.4） | — |

### 10.2 后续（plan 接入）改动清单

| 层 | 位置 | 改动点 | 风险 |
|----|------|--------|------|
| 编排-分流 | `orchestrator/app/runner.py:58`（`_build_initial_state` 最前置） | `_classify_route` + plan 分支 `_favorite_tools` | 中（分流正确性、技能分支零回归） |
| 编排-推理 | `orchestrator/app/graph/nodes.py:208` | **无逻辑改动**（依赖 state 已填好的 tool_whitelist） | 低 |
| 编排-prompt | `orchestrator/app/graph/prompt.py:224` | 按 `_route_mode` 渲染 plan 协议（措辞 AI 专家） | 中 |
| 契约-Java/Python | `contracts.py:71` `EffectiveExpert` + Java `EffectiveExpertPayload` | （通道甲）新增 `favoriteTools`，wire 名两侧字面一致 + 契约测试 | 中（N1 风险，必加测试） |
| 装配 | Java OrchestrateRequest 装配侧 | 按 userId 填个人工具箱（收藏⋈PUBLISHED）→ payload | 中 |

### 10.3 风险

- **N1 类 wire 漏改**：本轮规避（不动 wire）；plan 接入引入 `favoriteTools` 时必须 Java↔Python lockstep + 契约测试。
- **审核漏标 requiresConfirmation**：本期安全唯一兜底是人工审核，漏标即可能漏弹确认（已知取舍，口径④）。
- **状态机一致性 + 唯一键防撞**：已由 §3.5 合法流转矩阵固化——同一 `tool_code` 全生命周期单行原地流转、驳回重提同行 reset（不撞 `(tool_type,tool_code)` 唯一键）、relist 仅从 DELISTED、改安全字段强制重审。需保证收藏⋈PUBLISHED 始终给出正确有效集；以状态机测试覆盖各非法流转被拒。
- **确认结论双来源漂移**：已由 §6.4 审核通过回写连接器侧消除——连接器侧为单一真相，listing 安全字段为审核工作副本；需回写一致性测试覆盖。
- **plan 工具过多掉准**（§8）：本期接受，缓解入 backlog。

### 10.4 兼容性

- **运行时零回归**：本轮不触碰编排器与 EffectivePositionView/契约层，纯技能驱动链路逐字节不变。
- **后台向后兼容**：现有连接器配置页/端点/服务不动，市场为旁挂新模块。
- **前端纯加法**：工具市场为 `AdminRail` 新增的独立一级菜单 + 独立 `market` 路由，**不嵌入、不改动现存连接器容器页**（FB1）；门禁沿用 `meta.roles:['ADMIN','FDE']`，不引入新角色 meta（FB2）。
- **ADR-02 不动**：物理层 expert_id 不重命名；新表用户/工具维度独立建模，不引入 position↔expert 物理改名。
- **plan 接入阶段**：`favoriteTools` 默认空列表 → 老请求/未收藏用户零回归。

---

## 11. 开放问题（仅列真正待用户拍板项）

> 口径已定项不再询问。以下为实现细节中可能需用户/产品确认的点（若无异议则按本设计默认推进）：

1. **个人工具箱注入通道甲/乙的取舍**（§3.4）属技术实现细节，倾向通道甲（复用 expert payload），**到 plan 接入阶段由架构+AI 专家定，不需用户拍板**——除非用户对"收藏变更实时性"有硬要求（通道甲随 expert 装配，可能有缓存延迟）。
2. 暂无需用户拍板的口径分歧——整体模型与逐项口径用户均已拍板。

---

## 附：决策摘要表

| 决策 | 选择 | 理由 |
|------|------|------|
| 整体模型 | 工具市场 + 个人工具箱（替代旧"岗位级并集"） | 用户已彻底改口径并拍板 |
| 市场范围 | 只放 MCP/API；业务系统/TABLE 禁入 | 口径① + 业务系统运行时未接通 |
| 数据模型 | 新建 `tool_market_listing` + `user_tool_favorite` 两表 | 纯加法，承载发布元数据与跨岗位收藏 |
| listing 粒度 | **单个工具**：`tool_code`=运行时限定名（MCP=`mcp__{mcpCode}__{toolName}`/API=`api_def.code`）+ `tool_name` 列，`source_def_id` 仅展示回链，唯一键 `(tool_type,tool_code)` | M1：对齐 MCP 逐工具 toolCode/requiresConfirmation，避免确认能力倒退 |
| 审核状态机 | 单行原地流转矩阵（§3.5）：驳回重提同行 reset、relist 仅从 DELISTED、改安全字段重审、PENDING 撤回删行 | M2：避免 REJECTED 重提撞唯一键、补全流转 |
| 确认结论真相源 | 审核通过回写连接器侧，连接器侧为单一真相（§6.4） | B1：消除 listing/连接器双来源漂移 |
| 有效集 | 收藏 ⋈ status=PUBLISHED | 生命周期以后管为准，下架/修改被动响应（口径②） |
| 审核 | 发布前工具管理员人工全量审核，**逐工具**配 write_class + requiresConfirmation | 本期唯一安全兜底（口径④） |
| 角色 / 鉴权 | 工具管理员=概念角色，admin 兼；**复用 `/api/fde/**` 角色门，不新建权限点框架**（B3），细粒度拆分入 backlog | 口径② + 零新增鉴权 |
| 鉴权（凭证） | 仅平台对平台（共享凭证） | 口径③ |
| 运行时确认落点 | plan 接入时在 run 装配阶段写进 run 注册表、复用现有门禁，**不改 `ToolExecutionService`**（B2） | 复用单一执行/确认链路 |
| 前端落点 | `AdminRail` 新增「工具市场」一级菜单 + `market` 独立路由 + 页内 Tab（发布管理/审核台），`meta.roles:['ADMIN','FDE']`（FB1/FB2/FB3） | 职责清晰、不动现存连接器页 |
| 二次确认 | plan 与技能一视同仁，按 requiresConfirmation；无 plan 专属强制确认 | 口径④从简，不接受体验代价 |
| plan 工具 | 收藏多少给多少，不收窄/排序 | 口径⑤；已知风险入 backlog |
| 编排骨架 | 前置二分类分流：命中→技能SOP，未命中→plan | 用户拍板的编排层模型 |
| 本轮范围 | 市场发布+审核后端 + 数据模型（不动运行时链路） | 用户"先保证后端有发布到市场的概念" |
| 运行时改动 | 本轮不动 runner/nodes/prompt/EffectivePositionView/契约 | 零回归、零 wire 风险 |
| ADR-02 | 物理层不动 | 约束 |
