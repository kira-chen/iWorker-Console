# API 连接器数据结构扩展 + 真实外呼运行时 — 设计文档

> 状态：**最终定稿 · 设计先行门禁已通过 · 用户与 PM 已对全部开放问题拍板 · 可放行编码**。本步只写设计，不改任何代码、不建迁移文件。
> 作者：架构师 · 日期：2026-06-24 · 定稿修订：v2（并入门禁拍板 + AI 专家 6 项必修）
> v2 修订要点：① code **系统生成、对用户隐藏**（去 ApiEditor code 输入框，新增 code 生成规则 §1.2）；② 列表 code **保留 VO 字段、前端不渲染**（不物理移除）；③ schema 本期不强校验，仅校 url 中 `{name}` 占位符必填；④ AI 专家 6 项必修钉死（非 2xx 不回灌 body / QUERY 密钥不进日志 / AAD 借用 3 前置 / 成功耗时口径=now-callStart / 大响应体先截断防内存 / 非文本 Content-Type 兜底）；⑤ 单一上报点表述澄清（record* 是封装 try/catch+warn 的同一私有方法，各分支调同一封装）。
> 适用入口：管理后台「系统配置员 → 连接器 → API」。遵循「管理后台改动设计先行 + 人工门禁」铁律之 ③先改设计文档。
> 镜像基准：`docs/architecture/MCP数据结构扩展与使用统计-设计.md`（统计口径/埋点/DTO additive/迁移纪律直接对齐）。
> **迁移号：取 V32**（仓库现状最新为 **V31** `V31__mcp_struct_and_usage_stats.sql`，由并行的 MCP 会话占用；本次顺延到 V32，**与 MCP 会话 V31 不冲突**——两份各改各表、不交叠）。
> **⚠️ 落地订正（2026-06-24，编码后回填）：实际迁移号为 V33。** 编码时仓库已新增 `V32__biz_system_biz_pages.sql` 占用 V32，按「最新+1」顺延 **V33**（`V33__api_def_desc_url_authkey_usage_stats.sql`）。**下文 §0/§2/§10 凡 `V32` 字样，一律按 `V33` 理解。**
> **本轮一并把 API 工具从占位执行器升级为真实外呼运行时**：`UnconnectedApiToolExecutor` → 真实 `ApiToolExecutor`（REST 直呼）。

> **📌 校准标注（2026-07-17）**：本篇的真实外呼执行器三件（`ApiToolExecutor`/`ApiUsageRecorder`/`ApiResultMapper`）已随主版本运行时剥离，不在本仓（`skill/tool/api/` 下仅存零注入方的 `ApiToolProperties`，`ToolExecutor` 接口无任何实现类）；数据结构/迁移（V33）与管理端部分（`AdminApiService`、DTO、检活、统计列与 `ApiDefRepository.recordSuccess/recordFailure`）已落地。详见《设计文档校准审计-20260717.md》。

---

## 0. 现状基线核对（file:line）

| 项 | 文件:line | 现状 |
|----|----------|------|
| 实体 | `tooldef/entity/ApiDef.java` | 有 code/name/**base_url**/**path**/method/request_schema/response_schema/auth_type/**auth_config(jsonb)**/status/requires_confirmation/**check_status**/consecutive_failures/last_check_at/last_check_error/**health_check_path**/created_at/updated_at/deleted。**无** description / url（单列）/ 任何统计列 |
| 占位执行器 | `skill/tool/unconnected/UnconnectedApiToolExecutor.java:13` | 继承 `UnconnectedToolExecutor`，仅 override `type()=API`；execute 恒 `success=true`+`errorCode=TOOL_NOT_CONNECTED`，**不真发 HTTP**（父类 `UnconnectedToolExecutor.java:33-40`） |
| MCP 真实执行器（同模式范本） | `tooldef/mcp/McpToolExecutor.java:68-130` | execute 主流程 + 错误二分 + 单一出口埋点（recordSuccess/recordFailure，§4.4 try/catch + 必 warn） |
| 路由 | `skill/tool/ToolExecutionService.java:111-113`、`skill/tool/ToolRegistry.java:80-87 executorForType(type,toolCode)` | typeHint=API 且 Registry 不含 code → `executorForType(API)` 取 `executors.get(API)` Bean。**换 executor Bean 即生效，路由零改** |
| toolCode 形态 | `admin/support/OrchestrationAssembler.java:90-95 / 207-212 resolveApi` | **API 工具 code = 原始 `api_def.code`**（无 `mcp__..__..` 式限定名，无 split）。`SkillApiRef` 按 api_def_id 引用。executor 内 `apiDefRepository.findByCode(inv.toolCode())` 直接定位 |
| 检活控制器 | `tooldef/controller/ToolHealthController.java:44-49` | `{type}`∈`mcp|api|biz-system`，API 走 `healthService.checkApiNow/apiStatus` |
| 检活服务 | `tooldef/health/ToolHealthService.java:227-256 probeApi / 261-277 buildProbeUrl` | API 检活：`base_url`+`health_check_path` 轻量 GET，2xx/3xx/401/403/405=可达=健康；超时/5xx/其它 4xx=失败。**已是真实连通探测**（非占位） |
| 控制器 | `tooldef/controller/AdminApiController.java` | CRUD `/api/fde/connectors/apis`；list/detail/create/update/delete |
| 服务 | `tooldef/service/AdminApiService.java:77`(list)/`:101`(detail)/`:169 apply` | 列表/详情构造点 + create/update 落库；`apply` 落 baseUrl/path/method/authType/authConfig 等 |
| 请求 DTO | `tooldef/dto/ApiDefRequest.java` | 有 code/name/**baseUrl(@NotBlank)**/**path(@NotBlank)**/method/requestSchema/responseSchema/authType/authConfig/status/requiresConfirmation/healthCheckPath；**无 description / url** |
| 列表 DTO | `tooldef/dto/ApiDefListItem.java` | 含 code（列表项带 code）/name/method/status/referencedBySkillCount/updatedAt/displayStatus/redDot/lastCheckAt；**无统计字段** |
| 详情 DTO | `tooldef/dto/ApiDefDetailVO.java` | 含 code/name/**baseUrl/path**/method/schemas/authType/**authConfigMasked(boolean)**/status/healthCheckPath/displayStatus/redDot/lastCheckAt/referencedBySkills；**无 description/url/统计** |
| 仓储 | `tooldef/repository/ApiDefRepository.java` | findByCode/searchAdmin/findByStatus/countGroupByCheckStatus；**无 recordSuccess/recordFailure**（需新增，对齐 `McpDefRepository:44-60`） |
| 加密器（复用基准） | `bizsystem/crypto/CredentialCryptoService.java:50/66`、`bizsystem/crypto/GcmCipherService.java` | AES-256-GCM：`encrypt(plain,userId,bizSystemId)` → 密文 `keyAlias:base64(iv):base64(cipher+tag)`；AAD=`userId|bizSystemId`。**安全铁律：不打印/不返回明文与密钥** |
| 结果映射范本 | `tooldef/mcp/McpResultMapper.java:40-63` | data **只放 text** + max-chars 截断 + 空文本兜底（防 token 爆炸） |
| 统计上报器范本 | `tooldef/mcp/McpUsageRecorder.java` | `@Transactional(REQUIRES_NEW)` 封装 recordSuccess/recordFailure（一次原子自增=一次独立事务） |
| 迁移目录 | `db/migration/` | 最新 **V31**（`V31__mcp_struct_and_usage_stats.sql`，MCP 会话占用）；本次取 **V32** |

### 0.1 事务边界关键判断（决定埋点方案，对齐 MCP §0）
真实 `ApiToolExecutor.execute(...)` 所在类为 `@Component`，方法上**无 `@Transactional`**，调用链来自对话/编排运行时，**execute 整体不在数据库事务中**。因此统计写不是「挂主事务的脏写」，可独立成一次短事务的原子 UPDATE，与主调用结果天然解耦（详见 §5）。**与 MCP 完全同构**。

### 0.2 关键事实校正（相对 backlog 的纠偏）
- backlog 推测 API toolCode 为 `api__{code}__{op}`——**实际不是**：`OrchestrationAssembler.resolveApi` 用原始 `api_def.code` 作 toolCode，1 个 ApiDef = 1 个 tool（1 endpoint→1 tool 语义）。**executor 无需 split，直接 findByCode**。
- API 检活当前**已是真实 GET 探测**（`ToolHealthService.probeApi`），非占位。本轮检活真实化的工作量主要是「URL 合并后探测 URL 拼接随之改造」+「可选用真实鉴权探测」，见 §6。

---

## 1. 字段总表（口径定稿）

来源标注：`用户填` / `系统生成` / `派生` / `累计统计`。
展示列：✓=展示，✗=不展示，—=不适用。

| # | 展示名 | 字段(API) | 来源 | 存储列 / 类型 | 状态 | 列表 | 详情 | 编辑 |
|---|--------|-----------|------|---------------|------|------|------|------|
| 1 | API 名称 | `name` | 用户填 | `name` varchar NOT NULL | 已有 | ✓ | ✓ | ✓ |
| 2 | API id | `code` | **系统生成(唯一,不可改)** | `code` varchar NOT NULL UNIQUE | 已有(改来源) | **✗（列表隐藏，VO 保留字段不渲染）** | ✓ | **✗(对用户隐藏，编辑器去输入框；仅详情只读展示)** |
| 3 | **API 描述** | `description` | **用户填（选填/nullable）** | `description` text NULL | **新增** | ✗ | ✓ | ✓ |
| 4 | 请求方式 | `method` | 用户填 | `method` varchar | 已有 | ✓ | ✓ | ✓ |
| 5 | **API 地址** | `url` | **用户填（base_url+path 合并）** | `url` text NULL（存量回填 base_url‖path） | **新增** | ✗ | ✓ | ✓ |
| 6 | 鉴权方式 | `authType` | 用户填(NONE/API_KEY) | `auth_type` varchar | 已有(重定义枚举) | ✗ | ✓ | ✓ |
| 7 | 鉴权配置 | `authConfig` | 用户填(API_KEY 时) | `auth_config` jsonb（密钥 AES 加密）| 已有(重构结构) | ✗ | ✗(masked) | ✓(masked) |
| 8 | 入参 | `requestSchema` | 用户填 | `request_schema` jsonb | 已有 | ✗ | ✓ | ✓ |
| 9 | 出参 | `responseSchema` | 用户填 | `response_schema` jsonb | 已有 | ✗ | ✓ | ✓ |
| 10 | 服务状态 | `status`+`displayStatus` | 用户启停 + 检活四态派生 | `status` / `check_status` 等 | 已有 | ✓ | ✓ | ✓(启停) |
| 11 | 被引用技能数 | `referencedBySkillCount` | 派生(SkillApiRef) | 无独立列 | 已有 | ✓ | ✓ | — |
| 12 | **调用次数** | `callCount` | **累计统计**（真正发起的：成功+真实失败） | `call_count` bigint NOT NULL DEFAULT 0 | **新增** | ✓ | ✓ | — |
| 13 | **平均执行时间** | `avgExecMs` | **派生** `sum_success_ms/success_count`（仅成功） | 读时算，无独立列 | **新增** | ✓ | ✓ | — |
| 14 | 成功率 | `successRate` | **派生** `success_count/call_count` | 读时算，无独立列 | **新增** | ✓(按需) | ✓ | — |
| — | （内部累计）成功数 | — | 累计统计 | `success_count` bigint NOT NULL DEFAULT 0 | **新增**(内部) | ✗ | ✗ | — |
| — | （内部累计）成功总耗时 | — | 累计统计 | `sum_success_ms` bigint NOT NULL DEFAULT 0 | **新增**(内部) | ✗ | ✗ | — |
| — | 检活预设端点 | `healthCheckPath` | 用户填 | `health_check_path` varchar | 已有(保留) | ✗ | ✓ | ✓ |
| — | 检活态/连续失败/检活时间/失败摘要 | check 系列 | 检活 | `check_status`/`consecutive_failures`/`last_check_at`/`last_check_error` | 已有(保留) | ✓(红点) | ✓ | — |
| ~~—~~ | ~~base_url~~ | ~~baseUrl~~ | ~~用户填~~ | `base_url`（**保留旧列**，不再写入，以 url 为准） | 弃用展示 | — | — | — |
| ~~—~~ | ~~path~~ | ~~path~~ | ~~用户填~~ | `path`（**保留旧列**，不再写入，以 url 为准） | 弃用展示 | — | — | — |

> **`code` 系统生成、对用户隐藏**（门禁拍板）：新建时系统自动生成唯一 code（§1.2），用户**不再手填**，`ApiEditor` 去掉 code 输入框；仅**详情态只读展示**（供排障/技能引用比对），列表与编辑态均不展示输入。技能引用 API 仍用 code（`SkillApiRef` / toolCode=原始 code 不变）。**列表 VO 保留 code 字段、前端不渲染**（PM 拍板，纯 additive 不物理移除，§7.2）。存量 code 不变。
> 单条耗时口径：API 无 MCP 那种「握手 vs 纯调用」二分（REST 一次往返），故**不设 `avgCallMs`/`sum_success_call_ms`**，只保留 `avgExecMs` + `sum_success_ms`（= 单次整体往返耗时）。这是 API 与 MCP 统计列的**唯一差异**，理由：API 无 JSON-RPC 握手阶段，整次耗时即调用耗时，再拆纯调用平均无信息增益。

### 1.2 code 生成规则（门禁拍板：系统生成、唯一、稳定、不可改）

**方案（定稿）**：`api_` 前缀 + 8 位 base36 短随机 slug（小写字母 a–z + 数字 0–9），如 `api_k3m9q1zt`。生成在 `AdminApiService.create` 内，**生成后唯一性校验 + 至多重试 N 次（如 5 次）**，命中已存在则重生成；建库后写死，update/编辑路径**绝不重算**（不可改）。

| 要求 | 本方案如何满足 |
|------|---------------|
| **唯一** | 8 位 base36 ≈ 2.8万亿空间，碰撞概率极低；落库前 `findByCode` 校验，撞了重试（DB `code` 唯一约束兜底，重试穷尽极端情况抛 `BUSINESS_ERROR`） |
| **稳定/不可改** | 仅 `create` 生成一次，`update`/`apply` 路径不触碰 code（沿用现状 `apply(a,req)` 注释「code 只读」）；编辑器无入参 |
| **与技能引用 `api__{code}` 兼容** | ⚠️ **关键**：现状技能引用底层 toolCode = **原始 `api_def.code`**（`OrchestrationAssembler.resolveApi` 直取，无 `api__` 限定名前缀，§0.2 已核实）。生成的 code 必须满足现有 `CODE_PATTERN = ^[a-z0-9_]+$`（`AdminApiService:43`）——`api_` + base36 slug **天然满足**（全小写字母数字下划线）。SkillApiRef 按 `api_def_id` 引用、不直接存 code 字符串，故 code 形态变化对引用零影响 |

**为何选随机 slug 而非「`api_` + 自增 id/序列」**：
- ✅ **不暴露规模/可枚举性**：自增 id（`api_1`/`api_2`…）会泄漏「系统里有多少 API」、且可被枚举遍历；随机 slug 不可预测、不可枚举，更安全。
- ✅ **生成时机无依赖**：随机 slug 在 `new ApiDef()` 即可定，无需先 save 拿自增 id；而 `api_{id}` 必须 save 后才知 id（与 §4.3 密钥加密的「先 save 拿 id」是两件事，不应耦合——code 用随机 slug 在 save 前就定好，AAD 才用真实 id，职责清晰）。
- ✅ 长度短、可读、可在详情态展示给 FDE 排障。
- 备选（自增/UUID）已否决：自增暴露规模可枚举；UUID 太长不利展示且非 `^[a-z0-9_]+$`（含连字符）。

> 实现注：生成工具方法 `generateUniqueApiCode()` 放 `AdminApiService`，`create` 内 `a.setCode(generateUniqueApiCode())` 替代现状 `req.code()`；`ApiDefRequest.code` 字段**保留但忽略**（前端不再传；后端 create 不读 req.code，update 本就不改 code）。

### 1.1 URL 合并口径（决策 2）
- 现 `base_url`(如 `https://api.x.com`) + `path`(如 `/v1/orders`) 两列拼成单一 **`url`**（`https://api.x.com/v1/orders`）。
- 用户在编辑态只填一个「API 地址」`url`；method 单选 GET/POST/PUT/DELETE/PATCH。
- `url` 内可含 Path 参数占位符（`{id}`），由鉴权/入参注入机制替换（§3.3 / §4.3）。

---

## 2. V32 迁移 DDL 设计（仅设计，不落 .sql）

文件名（确认后由后端创建）：`V32__api_def_desc_url_authkey_usage_stats.sql`
表：`api_def`（沿用 V14/V24 的 `ALTER TABLE ... ADD COLUMN IF NOT EXISTS ...` + `COMMENT ON COLUMN` 风格；存量回填 url 用一次 `UPDATE`）。

```sql
-- V32: API 描述 + url 合并(base_url||path 回填) + api_key 鉴权结构 + 使用统计
-- 设计依据：docs/architecture/API数据结构扩展与真实外呼运行时-设计.md
-- 迁移纪律：已应用迁移(最新 V31)不再编辑；本次表结构变更新开 V32（与 MCP 会话 V31 不冲突，各改各表）
-- 仅「增列 + 一次存量 url 回填」；统计列 NOT NULL DEFAULT 0 自动物化，base_url/path 旧列保留不删

-- (1) 业务/元信息列
ALTER TABLE api_def ADD COLUMN IF NOT EXISTS description TEXT;   -- API 描述，用户填，选填(nullable)
ALTER TABLE api_def ADD COLUMN IF NOT EXISTS url         TEXT;   -- 单一 API 地址（base_url||path 合并；新写入只动 url）

-- (1b) 存量 url 回填：base_url 与 path 拼接（任一为空安全兜底；幂等——仅在 url 仍为空时回填）
UPDATE api_def
   SET url = COALESCE(base_url, '') || COALESCE(path, '')
 WHERE url IS NULL
   AND (base_url IS NOT NULL OR path IS NOT NULL);

-- (2) 使用统计累计列（原始累计量，派生指标读时算）
ALTER TABLE api_def ADD COLUMN IF NOT EXISTS call_count     BIGINT NOT NULL DEFAULT 0;  -- 真正发起的调用次数(成功+真实失败)
ALTER TABLE api_def ADD COLUMN IF NOT EXISTS success_count  BIGINT NOT NULL DEFAULT 0;  -- 成功返回次数(平均/成功率分母)
ALTER TABLE api_def ADD COLUMN IF NOT EXISTS sum_success_ms BIGINT NOT NULL DEFAULT 0;  -- 成功调用整次往返耗时累计(ms)

COMMENT ON COLUMN api_def.description    IS 'API 描述（用户填，选填，可空）';
COMMENT ON COLUMN api_def.url            IS '单一 API 地址（base_url||path 合并；新版只写 url，base_url/path 旧列保留兼容不再写入，以 url 为准）';
COMMENT ON COLUMN api_def.call_count     IS 'API 级真正发起的调用累计次数（真实发起 HTTP 的成功+真实失败均计；未接入/BAD_CODE 短路不计；原子自增）';
COMMENT ON COLUMN api_def.success_count  IS 'API 级成功返回累计次数（平均/成功率分母；超时/失败/非 2xx 不计）';
COMMENT ON COLUMN api_def.sum_success_ms IS 'API 级成功调用整次往返耗时累计(ms)；平均执行时间=sum_success_ms/success_count，读时计算';

-- 回滚反向脚本（单独执行）：
--   ALTER TABLE api_def DROP COLUMN IF EXISTS description;
--   ALTER TABLE api_def DROP COLUMN IF EXISTS url;
--   ALTER TABLE api_def DROP COLUMN IF EXISTS call_count;
--   ALTER TABLE api_def DROP COLUMN IF EXISTS success_count;
--   ALTER TABLE api_def DROP COLUMN IF EXISTS sum_success_ms;
```

设计要点：
- **base_url/path 旧列去留 = 保留不删（以 url 为准）**。理由：① **降风险**——`api_def` 已是存量表、`ToolHealthService.buildProbeUrl` 等多处引用 base_url/path，本轮一次性 DROP 列改面过大、回滚困难；② **零数据丢失**——保留旧列，回填 url 失败也可追溯原值；③ 新版读写一律走 `url`，`apply()` 不再 set base_url/path（保持旧值不动），运行时/检活/契约全部切到 url（§3/§6/§7）。旧列 DROP 留待后续独立清理迁移（§9 开放问题）。
- **回填幂等**：`WHERE url IS NULL` 守卫，重复执行（Flyway 已记录则不重跑；手动重跑也安全）不覆盖已有 url。`COALESCE` 防 base_url/path 任一为 NULL 时拼出 `NULL`。
- **null 性**：`description`/`url` 可空（url 理论上业务必填，但迁移期允许存量空值，应用层校验 @NotBlank 兜底）；三个统计列 `NOT NULL DEFAULT 0`，读时 `+1`/求平均不出现 null 运算。
- **不建索引**：统计列仅按 id（或唯一 code）定位单行自增/读取，不做范围/排序检索；建索引徒增高频自增写放大（对齐 MCP §2）。
- **auth_config 不改列**：仍是 jsonb 单列，结构由应用层定义（§4），无 DDL 变更。

---

## 3. 真实 ApiToolExecutor 运行时设计（核心）

> 新建 `skill/tool/api/ApiToolExecutor.java`（`@Component`，`implements ToolExecutor`，`type()=API`），**删除/替换** `UnconnectedApiToolExecutor`（同一个 type=API Bean，Spring 容器内唯一）。运行时契约（`ToolExecutor`/`ToolInvocation`/`ToolResult`/编排器 act/内部 `/api/internal/tool/execute` 端点）**一行不改**，与 MCP 轮完全同模式。

### 3.1 主流程（对齐 `McpToolExecutor.execute`）

> **耗时口径钉死（AI 专家必修 4）**：成功均值用 **`execMs = now - callStart`（纯外呼往返）**，**不用** `elapsed(t0)`。`t0→callStart` 之间是本地装配（buildRequest）/密钥解密开销，**不应混入外呼均值**（否则均值被本地开销污染、与 §1 表注「单次整体往返耗时」自相矛盾）。`latencyMs`（回 ToolResult 的总延迟）仍可用 `elapsed(t0)`，但**进 `sum_success_ms` 的只能是 `execMs`**。
> **单一上报点（AI 专家提醒，澄清）**：下方 `recordSuccess(...)` / `recordFailure(...)` 是 `ApiToolExecutor` 内**封装了 `try/catch + 必 warn` 的同一对私有方法**（见 §5.4），各分支只是**调用同一封装**，**不是**在每个 catch 里裸写统计 UPDATE。编码者勿把 record 逻辑散进各 catch。

```
execute(inv):
  t0 = now                                          // 仅用于 latencyMs（回 ToolResult 的总延迟）
  apiCode = inv.toolCode()                           // API toolCode = 原始 api_def.code（无 split）
  if (!props.enabled) return notConnected(t0)        // 总开关（新增 ApiToolProperties.enabled，默认 true）
  def = apiDefRepository.findByCode(apiCode)          // 直接定位（与 OrchestrationAssembler.resolveApi 同源）
  if (def == null || !"active".equals(def.status)) return notConnected(t0)   // 未接入短路（不计数）
  if (!hasText(def.url)) return notConnected(t0)     // 无地址 = 未配置完成 → 未接入语义（不计数）

  // 请求装配（本地开销，不计入外呼均值）：含 url 占位注入 + 鉴权解密注入。
  // 占位缺参等构造失败 → API_NOT_CONFIGURED，「未真正发出 HTTP」→ 不计数（§5.2 分支 2）
  request = buildRequest(def, inv.args())            // 失败抛 → catch 归 API_NOT_CONFIGURED（不计数分支）

  // ===== 此处起「已发起」区域：每条返回路径必计数（成功 recordSuccess，失败 recordFailure；均为 §5.4 封装方法）=====
  callStart = now                                    // 外呼计时起点（紧贴 exchange，排除本地装配/解密开销）
  try:
    response = restClient.method(...).exchange(...)  // 同步直呼，复用 RestClient.Builder（零新依赖）
    execMs = now - callStart                          // 纯外呼往返耗时（进 sum_success_ms 的唯一口径）
    if (2xx) { recordSuccess(def.id, apiCode, execMs); return resultMapper.map(response, t0) }   // 成功：均值用 execMs
    else     { recordFailure(def.id, apiCode);          return classifyHttp(status, t0) }         // 非 2xx 真实失败
  catch (ResourceAccessException / timeout):  recordFailure(def.id, apiCode); return fail(API_TIMEOUT/API_CONN_FAILED)
  catch (RuntimeException):                    recordFailure(def.id, apiCode); return fail(API_CALL_ERROR)  // 脱敏
```

### 3.2 请求模板（inputSchema → 请求）
- **method**：取 `def.method`（GET/POST/PUT/DELETE/PATCH）。
- **url + Path 占位注入**：`def.url` 内 `{name}` 占位符用 `inv.args()` 同名值 URL-encode 后替换；占位未命中 → 视为请求构造失败（`API_BAD_REQUEST`，已发起前的构造错也计为已发起失败？见 §5.2 边界——**构造失败归「未真正发出 HTTP」，按未接入语义不计数**，避免污染统计）。
- **入参分发（与现有 request_schema 字段语义对齐，单层扁平）**：
  - GET/DELETE：args 非 Path 占位部分 → **Query 串**；不带 body。
  - POST/PUT/PATCH：args 非 Path 占位部分 → **JSON body**（`Content-Type: application/json`）；可选 query（本轮简化：写类一律 body，不混 query，§9 列为可扩展）。
- **超时**：`ApiToolProperties.connectTimeoutMs/callTimeoutMs`（配置化，对齐 `McpProperties`/`ToolHealthProperties`），通过 `RestClient` requestFactory 设置。

### 3.3 鉴权注入（静态附加，详见 §4）
`buildRequest` 在请求装配阶段按 `auth_type`：
- `NONE`：不附加。
- `API_KEY`：解密密钥 → 按 `位置(in)` 注入：
  - `HEADER`：`headers.set(paramName, secret)`
  - `QUERY`：url 追加 `?paramName=secret`（与业务 query 合并）
  - `BODY`：仅对有 body 的 method（POST/PUT/PATCH）有效，注入 JSON body 字段 `paramName=secret`
  - `PATH`：把 url 内 `{paramName}` 占位替换为 secret（少见，但保留）
- 解密**用业务系统那套 AES**（§4.3），密钥仅在内存装配期短暂明文存在，**绝不进日志/结果/异常 message**。

### 3.4 响应映射（复用 MCP 范式，防 token 爆炸 + 防内存）
新建 `ApiResultMapper`（仿 `McpResultMapper`）：
- 成功(2xx)：response body → **data 只放 `text`**（body 字符串化）+ **max-chars 截断** + 空 body 兜底短语。**不**把结构化 body 整体回灌（编排器 nodes.py 原样 `json.dumps` 回灌，必须收口）。
- **大响应体先截断防内存（AI 专家必修 5）**：stringify 后**立即截断**到 `props.result.maxChars`（对齐 `McpResultMapper.truncate`，§0 范本 `:89-98`），**绝不**把整个超大 body 全量留在内存里再回灌。落地优先用**有上限的读取**——`RestClient` 取 body 时限制读取长度（或读出后即刻 substring 截断并丢弃原引用），避免恶意/异常第三方回 100MB body 撑爆堆。截断追加固定提示尾「…（结果过长已截断）」。
- **非文本 Content-Type 兜底（AI 专家必修 6）**：按响应 `Content-Type` 判断——`application/json`、`text/*`、`application/xml` 等**文本类**才 stringify 进 `text`；`image/*`、`application/octet-stream`、`application/pdf` 等**二进制/非文本类**给**兜底短语**（如「接口返回了图片/二进制内容，当前版本暂不支持解析」，对齐 `McpResultMapper.NON_TEXT_HINT`），**绝不**把二进制字节回灌进 text（防乱码/token 爆炸/内存）。Content-Type 缺失时按文本宽松处理但仍受 max-chars 截断兜底。
- `response_schema` 仅用于契约带出/前端展示，**不参与运行时强校验**（本轮 additive，避免对真实第三方响应过严，§9-6 收口）。

### 3.5 错误二分 + 脱敏（决策 1 铁律）
| 情形 | success | errorCode | message 口径 | 计数 |
|------|:-:|------|------|:-:|
| 总开关关 / def 为 null / 非 active / url 空 | **true** | `TOOL_NOT_CONNECTED` | 「该能力暂未接入，将在后续版本上线」 | ✗ |
| 请求构造失败（占位缺参等） | **true** | `API_NOT_CONFIGURED` | 「该能力配置不完整」（不含 url/参数名） | ✗ |
| 调用成功(2xx) | **true** | （null/可带标记） | 映射后的 text | ✓ success |
| 非 2xx（4xx/5xx 真实失败） | **false** | `API_HTTP_4XX`/`API_HTTP_5XX` | 「外部接口返回错误(HTTP {status})」**仅状态码，绝不回灌任何 response body** | ✓ failure |
| 连接超时 | **false** | `API_TIMEOUT` | 「外部接口连接超时，请稍后重试」 | ✓ failure |
| 连接失败(DNS/拒绝) | **false** | `API_CONN_FAILED` | 「外部接口连接失败，请稍后重试」 | ✓ failure |
| 其它运行时异常 | **false** | `API_CALL_ERROR` | 「工具调用失败」 | ✓ failure |

**非 2xx 一律不回灌 response body（AI 专家必修 1）**：非 2xx 分支 message **只含 HTTP 状态码**（`API_HTTP_4XX`/`API_HTTP_5XX` + 「HTTP {status}」），**绝不把第三方错误 body 任何片段拼进 message 或 data**——第三方错误 body 不可信（可能含其内网地址/栈/敏感回显/超大内容），且对模型转达无价值。仅成功(2xx)分支才经 `ApiResultMapper` 映射 body 进 data.text（且截断+非文本兜底，§3.4）。

**脱敏铁律 + QUERY 密钥不进日志（AI 专家必修 2）**（与 `McpToolExecutor`/`CredentialCryptoService` 一致）：
- 对外 `message`、回灌 data、`tool_call_log.error_code` **绝不含** url / 密钥 / 密钥参数名值 / 堆栈 / 内网地址 / response body 片段。
- **凡日志/异常涉及 url，必须用「去掉 query 串的 url」或仅 `apiCode`**：当鉴权位置=`QUERY` 时密钥被拼进 url 的 query（`?apikey=xxx`），若日志原样打 url 全文 → 密钥泄漏进日志。**落点写死**：`ApiToolExecutor` 与 `ApiResultMapper` 内**任何** `log.warn/error/debug`、异常 message **一律不打 url 全文**——只打 `apiCode` + HTTP 状态码 + 异常类名（`e.getClass().getSimpleName()`）；确需 url 排障时只打 `去 query 的 url`（scheme+host+path，剥离 `?` 之后全部）。RestClient/底层 HTTP 客户端若有自带请求日志，须确认其不在 INFO 级打全 url（DEMO 默认不开启 wire log，注明勿开）。

### 3.6 路由（共享文件，仅追加）
- `ToolExecutionService.execute(...,typeHint=API)` → `ToolRegistry.executorForType(API, code)` → `executors.get(API)`。**只要把 type=API 的 Bean 从 `UnconnectedApiToolExecutor` 换成 `ApiToolExecutor`，路由零改**（`executors` map 按 `ToolExecutor.type()` 自动装配）。
- ⚠️ `ToolExecutionService` 为**跨会话共享文件**——本轮 API 侧**无需改动它**（路由是数据驱动）。若因故要动，**改前先读最新、只追加 API 相关**（§跨会话）。

---

## 4. 鉴权数据结构与脱敏

### 4.1 `auth_type` 枚举重定义（决策 3）
- 取值收敛为：**`NONE`（不鉴权）/ `API_KEY`（API KEY 静态附加）**。
- 去掉任何「鉴权地址 / OAuth 换 token」概念（非本轮范围）。
- 存量 `auth_type` 兼容：旧值若非这两者，运行时按 `NONE` 处理（容错，§9）。

### 4.2 `auth_config`(jsonb) 结构
`API_KEY` 时：
```json
{
  "in": "HEADER",            // 参数位置：HEADER | QUERY | BODY | PATH
  "name": "X-Api-Key",       // 参数名（字段名），明文存
  "valueCipher": "k1:<iv>:<cipher+tag>"   // 参数值(密钥) → AES-256-GCM 密文，绝不明文存
}
```
- `NONE` 时 `auth_config = null`。
- **`name` 明文、`valueCipher` 密文**：参数名不敏感（如 `X-Api-Key`/`apikey`），密钥值敏感必加密。
- 编辑态回显：返回 `{"in","name","valueMasked": true}`（**不回 valueCipher、不解密**）；未改密钥时前端不回传 value，后端保留旧密文（详见 §4.4）。

### 4.3 密钥加密（复用业务系统 AES-256-GCM）

- 复用 `CredentialCryptoService.encrypt(plain, userId, bizSystemId)` / `decrypt(...)`，密文格式 `keyAlias:base64(iv):base64(cipher+tag)`，AAD 防挪用。
- **AAD 取值适配**：`CredentialCryptoService` 的 AAD = `userId|bizSystemId`。API 密钥**不归属某个 user/biz**（是 FDE 配置的系统级密钥），故需一组**固定 AAD 上下文**。
- **方案（门禁拍板：AAD 借用放行）**：约定 API 密钥用 `encrypt(secret, SYSTEM_API_KEY_USER_ID, def.getId())`——userId 槽用具名常量占位、bizSystemId 槽用 `api_def.id` 绑定到本 API（防密文跨 API 挪用）。零改 crypto 层、复用现成签名、密文绑定 api_def.id 语义清晰。备选 B（给 crypto 加 `encryptSystem` 重载）**否决**：动 crypto 共享层改面大，A 已够用。

**AAD 借用的 3 个前置（AI 专家必修 3，编码必须落实）：**

1. **create 两步 save = 安全必需（非性能优化）**：AAD 必须绑定真实 `api_def.id`，而 create 时 id 由 `GenerationType.IDENTITY` 在 **insert 后**才生成。故 create 路径**必须**：① 先 `save` 非密钥字段（含 code/name/url/authType/in/name，auth_config 暂不含密文）拿到真实 id；② 再用该 id 作 bizSystemId 加密密钥、回写 auth_config，第二次 `save`。两步在**同一事务**内。**这是 AAD 正确绑定的安全前提，不可省、不可用 id=0 占位**（用 0 会让所有 API 密钥 AAD 相同、丧失跨 API 防挪用，破坏安全语义）。代码注释须标「两步 save 为 AAD 安全绑定所必需，勿合并优化」。
2. **`0L` 占位用具名常量 + 注释命名空间隔离**：userId 槽的占位值定义为 `private static final long SYSTEM_API_KEY_USER_ID = 0L;`（放 `AdminApiService` 或专用常量类），**禁止散落裸 `0L`**。注释说明：「系统级 API 密钥无 user 归属，userId 槽用固定保留值 0 作命名空间隔离——真实用户 id 从 1 起（IDENTITY），永不与 0 冲突，故 API 密钥密文与任何用户凭据密文的 AAD 空间天然不交叠，杜绝跨域解密挪用」。加解密两侧**必须引用同一常量**。
3. **解密侧 def 同源**：`ApiToolExecutor` 解密时 `decrypt(valueCipher, SYSTEM_API_KEY_USER_ID, def.getId())` 的 `def` **必须是 executor 内 `apiDefRepository.findByCode(inv.toolCode())` 取到的同一行**（即密文存储行）——`def.getId()` 与加密时绑定的 id 同源，AAD 才匹配。**严禁**用 toolCode/外部传入 id 另查或硬编码 id 解密（id 不一致→GCM 标签校验失败→解密抛异常→鉴权注入失败）。

> **📌 校准标注（2026-07-17，订正）**：全线 ID 字符串化（V45–V53）后 `api_def` 主键为应用层预生成的 `ap_` 前缀字符串句柄，id 于 insert 前已知——**前置 1「create 两步 save 为 AAD 安全绑定所必需、不可省」的前提不再成立**，`AdminApiService` 已合并为一步入库（`AdminApiService.java:172` 注释：「id 先于 insert 已知 → 密文 AAD 在首次 save 前即可算，合并为一步入库」）；前置 2 的占位常量实际为 String：`SYSTEM_API_KEY_USER_ID = "0"`（`AdminApiService.java:76`），非 `0L`。AAD 绑定与防挪用语义本身不变。详见《设计文档校准审计-20260717.md》。

- **安全铁律**：解密仅在 `ApiToolExecutor.buildRequest` 内存装配期发生；密钥明文不进日志/结果/异常/审计（§3.5 必修 2）。审计 `auth_config` 变更只记「鉴权方式变更」事件，不记密钥。

### 4.4 编辑态不回显明文（masked）+ 不改密钥保留旧值
- 详情/编辑 VO：`authConfig` 仅出 `{in, name, valueMasked:true}`，**绝不出 valueCipher/明文**。
- update 语义（对齐业务凭据「留空=不改」）：
  - 请求 `authConfig.value` **非空** → 视为「设置/更换密钥」→ 加密覆盖 `valueCipher`。
  - 请求 `authConfig.value` **空/缺省** 但 `authType=API_KEY` 且原有密钥 → **保留旧 valueCipher**（仅更新 in/name）。
  - `authType` 从 `API_KEY` 改 `NONE` → `auth_config=null`（清空密钥）。

### 4.5 「参数位置 × method」合法/提示规则
| 位置 `in` | GET | DELETE | POST | PUT | PATCH | 规则 |
|-----------|:-:|:-:|:-:|:-:|:-:|------|
| HEADER | ✓ | ✓ | ✓ | ✓ | ✓ | 任意 method 合法（最通用，**推荐默认**） |
| QUERY | ✓ | ✓ | ✓ | ✓ | ✓ | 任意 method 合法（密钥进 URL 有泄漏到日志风险，**前端提示**「密钥置于 URL 可能被中间层日志记录」） |
| BODY | ✗ | ✗ | ✓ | ✓ | ✓ | **GET/DELETE 无 body → 非法**，前端禁选/后端校验拒绝（`BAD_REQUEST`，field=authConfig.in） |
| PATH | ✓ | ✓ | ✓ | ✓ | ✓ | 仅当 `url` 含同名 `{name}` 占位符才有意义；无占位 → 前端提示「url 中需含 {参数名} 占位符」 |

- 校验落点：`AdminApiService.apply`（保存时）+ 前端 `ApiEditor` 实时禁选（双保险）。
- BODY×GET/DELETE 为**硬校验**（拒绝保存）；PATH 无占位、QUERY 泄漏为**软提示**（不拦截）。

---

## 5. 使用统计埋点设计（对齐 MCP §4）

### 5.1 数据落点
`api_def` 三个累计列（`call_count`/`success_count`/`sum_success_ms`），按 **id 定位行**（execute 内已 `findByCode` 拿到 `def`，直接用 `def.getId()`）。

### 5.2 调用计数边界 —— 每个 return 分支判定表（钉死，对齐 MCP §4.2）

口径：**只有真正发起 HTTP 调用（走到 `restClient.exchange`）的路径才计 `call_count`**。逐分支：

| # | 分支 / 返回 | 性质 | 计 `call_count`？ | 计 `success_count`+耗时？ |
|---|-------------|------|:----:|:----:|
| 1 | 总开关关 / def==null / 非 active / url 空 → `notConnected` | 未发起·未接入短路 | ✗ | ✗ |
| 2 | 请求构造失败（Path 占位缺参等）→ `API_NOT_CONFIGURED` | 未发起·配置短路 | ✗ | ✗ |
| 3 | **2xx 成功** | **已发起·成功** | **✓** | **✓**（**execMs=now-callStart 纯外呼往返**→sum_success_ms；**不用 elapsed(t0)**，§3.1 必修 4） |
| 4 | **非 2xx（4xx/5xx）** | **已发起·真实失败** | **✓** | ✗ |
| 5 | **连接超时 / 连接失败** | **已发起·真实失败** | **✓** | ✗ |
| 6 | **其它运行时异常**（exchange 中抛） | **已发起·真实失败** | **✓** | ✗ |

实现要求：
- **计数起点 = `restClient.exchange` 调用**（即 `callStart` 之后）。分支 1/2 在发出 HTTP 前 return（含 buildRequest 构造失败的 `API_NOT_CONFIGURED`），**不 record**。
- 分支 3 走 `recordSuccess(id, apiCode, execMs)`（execMs=now-callStart）；分支 4/5/6 走 `recordFailure(id, apiCode)`。
- **埋点收口到单一上报点（澄清，AI 专家提醒）**：`recordSuccess`/`recordFailure` 是 `ApiToolExecutor` 内**封装了 `try/catch + 必 warn` 的同一对私有方法**（§5.4）；「已发起」区域各返回分支**只调这对封装方法之一**，**不是**在每个 catch 里裸写统计 UPDATE。这样既「每条已发起路径都计数」又「统计写容错收口在一处」，编码者勿散写。

### 5.3 更新方式：原子 SQL（行级 `column = column + n`，对齐 MCP §4.3）
`ApiDefRepository` 新增（镜像 `McpDefRepository:44-60`，**无 sum_success_call_ms**）：
```java
/** 成功调用：次数+1、成功数+1、整次往返耗时累加。行级原子自增，并发安全，需事务上下文（ApiUsageRecorder REQUIRES_NEW 提供）。 */
@Modifying
@Query("""
        UPDATE ApiDef a
           SET a.callCount = a.callCount + 1,
               a.successCount = a.successCount + 1,
               a.sumSuccessMs = a.sumSuccessMs + :execMs
         WHERE a.id = :id
        """)
int recordSuccess(@Param("id") Long id, @Param("execMs") long execMs);

/** 已发起但真实失败/超时/异常：仅次数+1（不进成功数/耗时均值）。 */
@Modifying
@Query("UPDATE ApiDef a SET a.callCount = a.callCount + 1 WHERE a.id = :id")
int recordFailure(@Param("id") Long id);
```
- 实体 `ApiDef` 补 `callCount/successCount/sumSuccessMs` 字段（`long`，默认 0L）+ getter/setter；JPQL 用属性名，故字段必须存在。
- `@SQLRestriction("deleted = false")` 对 `@Modifying` JPQL 不生效（仅作用实体查询）；id 来自 active 且未删 def，无影响；严谨可在 WHERE 加 `AND a.deleted = false`（对齐 MCP §4.3 注）。

> **📌 校准标注（2026-07-17）**：ID 字符串化后 `recordSuccess`/`recordFailure` 实际签名为 `String id`（`ApiDefRepository.java:61/66`），非上述 `Long id`。详见《设计文档校准审计-20260717.md》。

### 5.4 事务、解耦与「统计写失败必 warn」（对齐 MCP §4.4）

- 新建 `skill/tool/api/ApiUsageRecorder.java`（镜像 `McpUsageRecorder`），方法标 `@Transactional(propagation = REQUIRES_NEW)`，封装 `recordSuccess(apiId, execMs)` / `recordFailure(apiId)`（recorder 层不带 apiCode，apiCode 仅用于 executor 的 warn 日志）。
- **单一上报点 = `ApiToolExecutor` 内封装 try/catch + 必 warn 的同一对私有方法**（§3.1/§5.2 澄清；各已发起分支只调这对方法，不散写）：

```java
/** 成功统计上报：独立事务(recorder REQUIRES_NEW) + try/catch + 失败必 warn，绝不影响工具调用返回。 */
private void recordSuccess(Long apiId, String apiCode, long execMs) {     // execMs = now - callStart（纯外呼往返）
    try { usageRecorder.recordSuccess(apiId, execMs); }
    catch (RuntimeException ex) {
        log.warn("API 使用统计写入失败 apiCode={}（不影响调用结果，已忽略）", apiCode, ex);   // 必 warn 不静默；不打 url/密钥
    }
}
/** 已发起但真实失败/超时/异常上报：仅 call_count+1，同样独立事务 + try/catch + 必 warn。 */
private void recordFailure(Long apiId, String apiCode) {
    try { usageRecorder.recordFailure(apiId); }
    catch (RuntimeException ex) {
        log.warn("API 使用统计写入失败 apiCode={}（不影响调用结果，已忽略）", apiCode, ex);
    }
}
```

解耦三道保险（对齐 MCP）：① 统计写独立于主调用结果（try/catch 不改 ToolResult）；② **必 warn 不静默**（带 apiCode，**不带 url/密钥**，§3.5 必修 2）；③ REQUIRES_NEW 自成事务。
- **异步不采用**：单条原子 UPDATE 极快，DEMO 体量同步开销可忽略（对齐 MCP §4.4 权衡）。

### 5.5 派生指标（读时算，统一除零兜底，对齐 MCP §4.6）
读取（DTO 映射）时计算，`success_count==0` / `call_count==0` 返回 `null`（前端展示「—」）：
- 平均执行时间：`avgExecMs = successCount > 0 ? round(sumSuccessMs / successCount) : null`
- 成功率：`successRate = callCount > 0 ? successCount / (double) callCount : null`（0~1 小数，前端格式化百分比）

---

## 6. 检活真实化方案

> 现状：API 检活**已是真实 GET 探测**（`ToolHealthService.probeApi`），非占位。本轮主要做「URL 合并后的探测 URL 拼接改造」，并明确「真实外呼上线后检活与统计并存」（决策 5）。

### 6.1 探测 URL 切换到 `url`（必做）
- `buildProbeUrl(def)`（`ToolHealthService:261-277`）当前用 `base_url`+`health_check_path`。改造为：
  - 优先 `health_check_path`（绝对 URL 直用；相对路径基于 `def.url` 的 origin 拼接）。
  - 否则探测 `def.url` 本身（合并后地址）。
- 兼容期兜底：`def.url` 空时回落旧 `base_url`（存量未回填行的兜底，回填迁移后理论上不发生）。
- 探测仍是**轻量 GET**，判活口径不变（2xx/3xx/401/403/405=可达=健康）。

### 6.2 是否带真实鉴权探测（可选增强，本轮建议「轻量探测，不带密钥」）
- **建议本轮保持「不带鉴权的轻量 GET 探测」**（现状口径）：401/403 已视为「可达」，足以判断「服务在线」；带密钥探测会触发真实业务调用、有副作用风险（尤其写类端点），且密钥注入到检活链路扩大泄漏面。
- 若 FDE 配置了 `health_check_path`（通常是无鉴权健康端点）→ 探它最准。
- ⏭ 真实鉴权探测留作 §9 可选项（需评估副作用 + 脱敏）。

### 6.3 检活与统计并存（决策 5 确认）
- 保留 API 页检活四态/立即检活/红点角标（`check_status`/`consecutive_failures`/`last_check_at`/`last_check_error` 列**全部保留**）。
- line2 新增「调用次数 · 平均执行时间」展示（来自 §5 统计）。两者数据源独立、互不耦合。

---

## 7. DTO / 接口契约改点（additive，不破坏现有前端）

### 7.1 `ApiDefRequest`（入参，create/update）
```java
// 移除 baseUrl/path 的 @NotBlank（合并为 url）；新增 url、description；authConfig 结构按 §4.2
@NotBlank(message = "API 地址必填") String url,            // 替代 baseUrl+path
@Size(max = 1000, message = "API 描述不超过 1000 字") String description,   // 选填/nullable
// authType: NONE|API_KEY；authConfig: {in,name,value?}（value 为明文密钥，仅设置/更换时传，留空=保留旧密钥）
```
- 兼容过渡：**保留 `baseUrl`/`path` 字段为可选**（去 @NotBlank），旧前端仍可传；后端 `apply` 优先用 `url`，url 空时回退 `baseUrl+path` 拼（双写兼容一个迭代），但**只写 url 列**。或直接弃用旧字段——**推荐保留可选一个迭代再清**（§9）。
- **code 系统生成**：`ApiDefRequest.code` 字段**保留但后端忽略**（前端不再传、编辑器无输入框）；create 由 `generateUniqueApiCode()` 生成（§1.2），不读 `req.code()`；update 本就不改 code。
- 校验：`url` @NotBlank；**url 中 `{name}` 占位符对应入参必填**（缺参→运行时 `API_NOT_CONFIGURED` 不计数，§5.2 分支 2；保存态可前端提示）；`authConfig.in`×method 合法性（§4.5）；密钥不做格式校验（第三方各异）。schema 本期不强校验（§9-6）。

### 7.2 `ApiDefListItem`（列表出参）
```java
// code 保留字段、前端不渲染（PM 拍板，不物理移除，纯 additive）；尾部追加统计
// 现有字段全保留（含 code）
long callCount,        // 调用次数
Long avgExecMs,        // 平均执行时间(ms)，可空(success_count==0→null)
Double successRate     // 成功率(0~1)，可空(call_count==0→null)；前端按需展示
```
> ✓ **列表 code = 保留 VO 字段、前端不渲染（PM 拍板定稿）**：`ApiDefListItem` **不移除** code 字段（避免破坏性变更，纯 additive），由前端 `AdminApis.vue` 列表**不渲染 code 列**实现「隐藏」。与 MCP 列表口径一致（都隐藏 code）。统计字段追加到尾部。

### 7.3 `ApiDefDetailVO`（详情出参）
```java
// 移除 baseUrl/path（合并 url）；新增 url/description；authConfig 改结构化 masked
String url,            // 单一地址（编辑回填）
String description,    // 可空 → 映射兜底
// authConfigMasked(boolean) → 升级为结构化：{in,name,valueMasked} 或保留 boolean + 另出 authInfo
long callCount,
long successCount,
Long avgExecMs,        // 可空
Double successRate     // 可空
```
- `auth_config` 详情出参：返回 `{in, name, valueMasked:true}`（**不解密、不回明文/密文**）。

### 7.4 `AdminApiService` 映射改动点
- `list`(:77)：补 `callCount`/`avgExecMs(a)`/`successRate(a)`；**code 字段保留照传**（前端不渲染，§7.2）。
- `detail`(:101)：补 url/description/统计；code 照传（详情只读展示）；`auth_config` 出结构化 masked。
- `create`(:110)：**code 由 `generateUniqueApiCode()` 生成**（§1.2），不读 `req.code()`；**两步 save**——先 save 非密钥字段拿真实 id，再用 id 作 AAD 加密密钥回写 auth_config 二次 save（§4.3 前置 1，AAD 安全绑定所必需）。
- `apply`(:169)：`setUrl(req.url())`（url 空时兼容回退 base+path 拼）；`setDescription(blankToNull)`；`auth_config` 按 §4.4 加密/保留旧密钥逻辑（需注入 `CredentialCryptoService`，加密用 `SYSTEM_API_KEY_USER_ID` + `api_def.id`）；**code 不触碰**（只读）。
- 新增常量 `private static final long SYSTEM_API_KEY_USER_ID = 0L;`（§4.3 前置 2）+ 私有方法 `generateUniqueApiCode()`（§1.2）。
- 新增私有派生工具方法 `Long avgExecMs(ApiDef)` / `Double successRate(ApiDef)`，封装除零，list/detail 共用。
- 实体 `ApiDef` 增 url/description/callCount/successCount/sumSuccessMs 字段 + getter/setter。

### 7.5 空值兜底（对齐 MCP §5.5）
- `description`/`url` 可空：映射/展示不得 NPE；前端展示占位。
- 派生指标可空：`null`=「无样本」，前端「—」。

### 7.6 兼容性结论

- 出参：统计字段为**追加**（additive）；`url`/`description` 追加；**列表 code 保留字段、前端不渲染**（不破坏 VO，§7.2 定稿）。**出参全 additive。**
- 入参：`url` 新增必填（前端同步改）；`baseUrl`/`path` 转可选（兼容过渡）；`code` 字段保留但后端忽略（前端去输入框）；`authConfig` 结构变化（前端同步改）。
- **结论：出参纯 additive；入参需前后端协同改（url 合并 + code 系统生成去输入 + auth 结构），非纯兼容——属预期内的配套改造。**

---

## 8. 对外契约文档改点（仅指明，不在本文档替改）

> 真相源守护：契约文档与代码 DTO 必须一致；改完代码后须同步。

| 文档 | 改点 |
|------|------|
| `docs/architecture/数字员工管理后台-双模块重构设计.md`（API 契约 §3 现所在） | ① API 字段说明：`base_url`+`path` → 合并 `url`（单一 API 地址）；新增 `description`(用户填,选填,可空)。② 鉴权：`auth_type` 收敛为 `NONE`/`API_KEY`；`auth_config` 结构 `{in,name,valueCipher}`（密钥 AES 加密，编辑 masked 不回显）；「位置×method」合法规则表（§4.5）。③ 列表/详情字段表：列表移除 code（或保留隐藏）+ 追加 callCount/avgExecMs/successRate；详情补 url/description/统计/结构化 authInfo。④ 新增「真实外呼运行时」小节：错误二分(未接入 success=true / 真实失败 success=false)、message 全脱敏、响应只回 text+截断。⑤ 新增「使用统计」小节：口径(call_count=真实发起的成功+失败；平均=仅成功整次耗时；成功率=success/call；3 累计列派生读时算除零返回 null)。 |
| `docs/api/管理后台-对外服务调用指南.md` | 同步 API 字段口径（url 合并、code 列表隐藏约定）、鉴权方式与 masked 说明、新增统计字段展示矩阵；去除任何「base_url/path 双列」「鉴权地址」表述。 |
| `docs/api/MCP真实运行时-接口契约.md`（可选） | 如该文档含「连接器通用错误码表」，追加 API_* 错误码（API_TIMEOUT/API_CONN_FAILED/API_HTTP_4XX/API_HTTP_5XX/API_CALL_ERROR/TOOL_NOT_CONNECTED）。 |

---

## 9. 开放问题 / 风险（已拍板✓ / 待确认❓ / 扩展位⏭）

1. ✓ **调用计数边界**（§5.2）：真实发起 HTTP（exchange 起）的成功+真实失败计 `call_count`；未接入/配置短路不计。判定表见 §5.2。
2. ✓ **URL 合并 + 旧列保留**（§2）：新增 `url` 列回填 `base_url||path`，base_url/path 旧列**保留不删**（降风险），新版只读写 url。
3. ✓ **密钥 AES + masked**（§4.3/§4.4）：复用 `CredentialCryptoService`，AAD=`0L|api_def.id`，create 先 save 拿 id 再加密回填；编辑不回显明文。
4. ✓ **code 系统生成、对用户隐藏**（门禁拍板，§1.2）：新建系统生成唯一 code（`api_`+8 位 base36 随机 slug），用户不手填、编辑器去输入框，仅详情只读展示；技能引用仍用 code（toolCode=原始 code、SkillApiRef 按 id，零影响）。
4b. ✓ **列表 code = 保留 VO 字段、前端不渲染**（PM 拍板，§7.2）：不物理移除（纯 additive），前端列表不渲染 code 列。
5. ✓ **AAD 借用放行**（门禁拍板，§4.3）：`encrypt(secret, SYSTEM_API_KEY_USER_ID(=0L 具名常量), api_def.id)`，零改 crypto 层。3 前置已写进设计：① create 两步 save（安全必需非优化）；② 具名常量 + 命名空间隔离注释；③ 解密侧 def 与 findByCode 同源。
6. ✓ **schema 本期不强校验**（PM 拍板，§3.4/§7.1）：`request_schema`/`response_schema` 仅契约带出/前端展示，**不参与运行时强校验**；运行时**仅校 url 中 `{name}` 占位符对应入参必填**——缺参 → `API_NOT_CONFIGURED`（success=true 未接入语义，**不计数**，§5.2 分支 2）。入参其余字段不做必填/类型强校验（避免对真实第三方过严）。
7. ⏭ **base_url/path 旧列物理 DROP**：留待后续独立清理迁移（确认全链路切 url、无回退需求后）。本轮不删。
8. ⏭ **真实鉴权探测检活**（§6.2）：本轮检活不带密钥（轻量 GET）；带鉴权真探测有副作用 + 泄漏面，留作可选增强。
9. ⏭ **逐次明细日志 `api_call_log`**：对齐 MCP §7-3 的扩展位思路，本轮不建表；埋点已用单一上报点结构，未来平滑追加。
10. ⏭ **统计清零入口**：本轮无清零接口（对齐 MCP §7-4）。
11. **高并发同行原子自增热点**（已知不处理，对齐 MCP §7-7）：`column=column+1` 对同一 api_def 行并发被行锁串行化，DEMO 体量可接受。
12. **QUERY 位置密钥泄漏到 URL 日志**（§4.5）：软提示不拦截；脱敏铁律保证我方日志不记 url 全文，但第三方/中间层日志不可控——前端明示风险。
13. **铁律守护**：技能引用工具零影响——`code` 不删、toolCode=原始 code 不变、`SkillApiRef`/`OrchestrationAssembler.resolveApi`/`ToolPicker`/`@tool` 红线**一律不碰**。

---

## 10. 落地改动清单（确认后编码用，按文件）

| 文件 | 改动 | 独占/共享 |
|------|------|-----------|
| `db/migration/V32__api_def_desc_url_authkey_usage_stats.sql` | **新建**：description/url 增列 + url 回填 UPDATE + 3 统计列 + COMMENT（§2） | 独占 |
| `entity/ApiDef.java` | 增 url/description/callCount/successCount/sumSuccessMs + 列映射 + getter/setter（统计 `long` 默认 0） | 独占 |
| `dto/ApiDefRequest.java` | url(@NotBlank) 替 baseUrl/path（转可选）；加 description(@Size)；authConfig 结构（§4.2） | 独占 |
| `dto/ApiDefListItem.java` | 追加 callCount/avgExecMs/successRate；**code 字段保留**（前端不渲染，§7.2） | 独占 |
| `dto/ApiDefDetailVO.java` | url/description 替 baseUrl/path；code 保留(详情只读)；authConfig 结构化 masked；追加统计字段 | 独占 |
| `service/AdminApiService.java` | **create 生成 code(`generateUniqueApiCode`,§1.2)+两步 save(AAD 安全绑定,§4.3-1)**；apply 写 url/description + auth 加密(注入 CredentialCryptoService,用 `SYSTEM_API_KEY_USER_ID`+id)+留空保留旧密钥；新增常量 `SYSTEM_API_KEY_USER_ID=0L`(§4.3-2)；list/detail 补统计 + 派生方法；§4.5 位置×method 校验 + url 占位必填校验 | 独占 |
| `repository/ApiDefRepository.java` | 增 `recordSuccess(id,execMs)`/`recordFailure(id)` `@Modifying` 原子自增（§5.3） | 独占 |
| 新建 `skill/tool/api/ApiUsageRecorder.java` | `@Transactional(REQUIRES_NEW)` 封装 recordSuccess(id,execMs)/recordFailure(id)（镜像 McpUsageRecorder） | 独占 |
| 新建 `skill/tool/api/ApiToolExecutor.java` | 真实 REST 执行器（type=API）：buildRequest(url 占位注入+鉴权解密注入,解密 def 同源 §4.3-3)+exchange+错误二分(**非 2xx 不回灌 body,必修1**)+耗时口径 `execMs=now-callStart`(必修4)+单一出口埋点(封装 try/catch+必 warn,日志**不打 url 全文/密钥**,必修2)（§3/§5） | 独占 |
| 新建 `skill/tool/api/ApiResultMapper.java` | 响应 → data.text + **stringify 后立即 max-chars 截断防内存**(必修5) + **非文本 Content-Type 兜底不回灌二进制**(必修6) + 空兜底（镜像 McpResultMapper） | 独占 |
| 新建 `skill/tool/api/ApiToolProperties.java` | enabled / connectTimeoutMs / callTimeoutMs / result.maxChars 配置化（对齐 McpProperties） | 独占 |
| **删除** `skill/tool/unconnected/UnconnectedApiToolExecutor.java` | type=API Bean 由真实 ApiToolExecutor 取代（容器内唯一） | 独占 |
| `health/ToolHealthService.java` | `buildProbeUrl` 切到 `def.url`（url 空回落 base_url），探测口径不变（§6.1） | 独占 |
| `ToolExecutionService.java` | **无需改动**（路由数据驱动）；如必须动→**先读最新、只追加 API 相关** | ⚠️**共享** |
| `controller/ToolHealthController.java` | **无需改动**（已支持 api type）；如必须动→**先读最新、只追加 API 相关** | ⚠️**共享** |
| `frontend/src/api/admin.js` | API 相关请求若需调整字段→**先读最新、只追加 API 相关** | ⚠️**共享** |
| 前端 `views/admin/AdminApis.vue`/`components/admin/ApiEditor.vue` | **ApiEditor 去掉 code 输入框**（系统生成，§1.2，新建不展示/不录入）；url 单字段；description；鉴权 NONE/API_KEY（参数名/值/位置）+ masked + 位置×method 提示；**AdminApis 列表不渲染 code 列**（§7.2）；列表统计列（调用次数·平均执行时间）（前端会话） | 独占(前端) |
| `docs/architecture/数字员工管理后台-双模块重构设计.md`、`docs/api/管理后台-对外服务调用指南.md` | 同步字段/鉴权/统计/错误码口径（§8） | 独占(文档) |

> 编码完成后须按 CR 矩阵交叉审查：后端代码→架构师；AI 调用/executor 埋点·脱敏·错误二分·统计写安全→AI 专家+架构师；并验证 V32 迁移在存量库幂等应用（url 回填幂等）。

---

## ⚠️ 跨会话协同提示（与并行 MCP 会话）

- **迁移号**：本设计取 **V32**（MCP 会话已占 V31）。编码前再核对 `db/migration/` 最新号，若 MCP 已超 V31 则顺延（始终取「最新+1」，避免撞号）。
- **共享文件（改前必先读最新、只追加 API 相关，无 Git 兜底，后保存覆盖前）**：
  - `backend/.../skill/tool/ToolExecutionService.java`（API 侧本轮**无需改**，路由数据驱动）
  - `backend/.../tooldef/controller/ToolHealthController.java`（已支持 `api` type，本轮**无需改**）
  - `frontend/src/api/admin.js`（两会话都可能加字段，additive）
- **各自独占**：API 侧 `ApiDef`/`ApiDefRequest`/`ApiDefListItem`/`ApiDefDetailVO`/`AdminApiService`/`ApiDefRepository`/新建 `ApiToolExecutor`/`ApiUsageRecorder`/`ApiResultMapper`/`ApiToolProperties`/`V32`/`AdminApis.vue`/`ApiEditor.vue`；MCP 侧对应文件归对方。
- **红线零碰**：`ToolPicker`/`SkillApiRef`/`OrchestrationAssembler.resolveApi`/`TableToolCodec`/`@tool`——技能引用工具零影响铁律。
</content>
</invoke>
