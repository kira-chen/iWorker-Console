# MCP Server 数据结构扩展 + 使用统计 — 设计文档

> 状态：**设计稿 · 已按用户逐条决策定稿修订（待用户最终确认后编码）**。本步只写设计，不改任何代码、不建迁移文件。
> 作者：架构师 · 日期：2026-06-24 · 修订：v2
> v2 修订要点：① 整体移除 `server_title`（协议版本不支持）；② 钉死 `call_count` 计数边界（逐分支判定表）；③ 增 `sum_success_call_ms`（纯 callMs 累计）+ 成功率派生；④ 落 AI 专家「本期必做」项（空值兜底/握手整次成功才覆盖/统计写失败必 warn/mcp_call_log 扩展位/原子热点注明）。
> 适用入口：管理后台「系统配置员 → 连接器 → MCP」。遵循「管理后台改动设计先行 + 人工门禁」铁律之 ③先改设计文档。
> 迁移纪律：已应用的 Flyway 迁移不再编辑；本次表结构变更一律**新开 V31**（仓库现状最新为 V30，已确认无 V31）。

---

## 0. 现状基线核对（file:line）

| 项 | 文件 | 现状 |
|----|------|------|
| 实体 | `tooldef/entity/McpDef.java` | 有 code/name/transport/endpoint/auth_config/tools_cache/status/protocol_version/server_version/conn_status/last_checked_at/check_status/consecutive_failures/last_check_at/last_check_error/时间戳。**无** description / server_name / 任何统计列 |
| 解析 | `transport/StreamableHttpTransport.java:166-177 applyServerInfo` | 解析 protocolVersion、serverInfo.name→serverName、serverInfo.version→serverVersion |
| 协商协议版本 | `transport/McpRpc.PROTOCOL_VERSION` | **"2025-03-26"**（关键：`serverInfo.title` 自 2025-06-18 才有 → 当前协商版本下 server 不返回 title，几乎恒空，本期不做 title） |
| 会话 | `transport/McpSession.java:22-24` | 有 serverName/serverVersion/protocolVersion |
| 回写（巡检） | `mcp/McpHealthScheduled.java:67-71` | 成功分支写 connStatus/protocolVersion/serverVersion；**未写 server_name** |
| 回写（拉取/测连） | `mcp/McpProvisionService.java:188-197 updateConnState` | 写 connStatus/lastCheckedAt/protocolVersion/serverVersion；**未写 server_name** |
| 埋点 | `mcp/McpToolExecutor.java` | `t0`=line66、`handshakeMs`=line98、`callMs`=line104、total=`elapsed(t0)`=line149-150；callTool try/catch=line101-118 可分成功/失败。**当前无任何调用计数/耗时聚合** |
| 请求 | `dto/McpDefRequest.java` | 有 code/name/transport/endpoint/tools/authConfig/status；**无 description** |
| 列表 DTO | `dto/McpDefListItem.java` | 列表已隐藏 code（前端未展示）；无新字段 |
| 详情 DTO | `dto/McpDefDetailVO.java` | 有 protocolVersion/serverVersion 等；无新字段 |
| 映射 | `service/AdminMcpService.java:77`（list）/ `:109`（detail）/ create-update | 列表与详情构造点；create/update 落库点 |
| 迁移 | `db/migration/` | 最新 V30，**无 V31**；列命名/注释参考 V14（`mcp_def` 加列）、V24（`IF NOT EXISTS`+DEFAULT） |

> 注：`call_count` / `success_count` 字符串在 `V1__init.sql:368-369` 已用于**另一张表**（工具/技能指标），与本次 `mcp_def` 无冲突——表不同，列同名不影响。

### 事务边界关键判断（决定埋点方案）
`McpToolExecutor.execute(...)` 所在类 `@Component`，**方法上无 `@Transactional`**，调用链来自对话/编排运行时，**execute 整体不在数据库事务中**。因此统计写不是「挂在主事务上的脏写」，可独立成一次短事务的原子 UPDATE，天然与主调用结果解耦（详见 §4）。

---

## 1. 字段总表（口径定稿）

来源标注：`用户填` / `MCP-<字段>`（server initialize 返回）/ `派生` / `累计统计`。
列表/详情/编辑展示列：✓=展示，✗=不展示，—=不适用。

| # | 展示名 | 字段(API) | 来源 | 存储列 / 类型 | 状态 | 列表 | 详情 | 编辑 |
|---|--------|-----------|------|---------------|------|------|------|------|
| 1 | 服务名称 | `name` | 用户填 | `name` varchar NOT NULL | 已有 | ✓ | ✓ | ✓ |
| 2 | 我方 id | `code` | 用户填(唯一) | `code` varchar NOT NULL UNIQUE | 已有 | ✗（列表隐藏） | ✓ | ✓ |
| 3 | 传输协议 | `transport` | 用户填 | `transport` varchar | 已有 | ✓ | ✓ | ✓ |
| 4 | 服务版本 | `serverVersion` | MCP-serverInfo.version | `server_version` varchar(64) | 已有 | ✗ | ✓ | ✗(只读) |
| 5 | MCP 协议版本 | `protocolVersion` | MCP-**protocolVersion** | `protocol_version` varchar(32) | 已有 | ✗ | ✓ | ✗(只读) |
| 6 | 服务状态 | `status`+`displayStatus` | 用户启停 + 检活四态派生 | `status` varchar / `check_status` 等 | 已有 | ✓ | ✓ | ✓(启停) |
| 7 | 工具数量 | `toolCount` | 派生(tools_cache.size) | 无独立列（运行时算） | 已有 | ✓ | ✓ | — |
| 8 | 工具清单 | `tools[{name,description}]` | tools_cache | `tools_cache` jsonb | 已有 | ✗ | ✓ | ✓ |
| 9 | **服务描述** | `description` | **用户填（选填/nullable）** | `description` text NULL | **新增** | ✗ | ✓ | ✓ |
| 10 | **server 自报 id** | `serverName` | **MCP-serverInfo.name** | `server_name` varchar(128) NULL | **新增** | ✗ | ✓ | ✗(只读) |
| 11 | 工具调用次数 | `callCount` | **累计统计**（真正发起的：成功+握手失败+调用失败） | `call_count` bigint NOT NULL DEFAULT 0 | **新增** | ✓ | ✓ | — |
| 12 | 平均执行时间(含握手) | `avgExecMs` | **派生** `sum_success_ms/success_count`（仅成功） | 读时算，无独立列 | **新增** | ✓ | ✓ | — |
| 13 | 纯调用平均(排障) | `avgCallMs` | **派生** `sum_success_call_ms/success_count`（仅成功） | 读时算，无独立列 | **新增** | ✗ | ✓ | — |
| 14 | 成功率 | `successRate` | **派生** `success_count/call_count` | 读时算，无独立列 | **新增** | ✓(按需) | ✓ | — |
| —  | （内部累计）成功数 | — | 累计统计 | `success_count` bigint NOT NULL DEFAULT 0 | **新增**(内部) | ✗ | ✗ | — |
| —  | （内部累计）成功含握手总耗时 | — | 累计统计 | `sum_success_ms` bigint NOT NULL DEFAULT 0 | **新增**(内部) | ✗ | ✗ | — |
| —  | （内部累计）成功纯调用总耗时 | — | 累计统计 | `sum_success_call_ms` bigint NOT NULL DEFAULT 0 | **新增**(内部) | ✗ | ✗ | — |
| ~~—~~ | ~~服务 title~~ | ~~serverTitle~~ | ~~serverInfo.title~~ | — | **不做/移除**（协议版本 2025-03-26 不返回，详见 §1.1） | — | — | — |
| ~~—~~ | ~~最后更新时间~~ | ~~lastModified~~ | — | — | **不做/删除**（MCP 协议不返回） | — | — | — |

> **`code` 与 `server_name` 均不在列表展示**（仅详情/编辑态可见），口径与现状「列表隐藏 code」一致。
> `avgCallMs`（纯调用平均）仅详情展示，供排障比对「整次 vs 纯调用」耗时差（差值≈握手开销）。

> **📌 校准标注（2026-07-17）**：V75 起工具清单只读化——上表第 8 行「工具清单 · 编辑 ✓」按此收窄理解：`name/description/inputSchema` 的唯一来源是 server `tools/list` 拉取，FDE 不再手动登记/编辑工具项，仅可标注 `writeClass`（READ/WRITE）；`bizName ≡ name`、`requiresConfirmation ≡ (writeClass=='WRITE')` 为派生兼容值。详见《设计文档校准审计-20260717.md》。

### 1.1 关于 server_title（本期移除，原因 + 复活条件）
- **移除原因**：`serverInfo.title` 是 **MCP 2025-06-18** 规范才引入的可选展示名；我方 `McpRpc.PROTOCOL_VERSION = "2025-03-26"`，当前协商版本下 server **不会返回 title**，存了也几乎恒空。
- 因此本期**整体不做 title**：不加 `server_title` 列、不解析 `serverInfo.title`、无「title 缺失回退到 name」的展示规则。展示名一律直接用 `name`（用户填）。
- **复活条件（待办）**：待我方协商协议版本升级到 **≥2025-06-18** 后再议是否引入 title 及其回退规则。已记入 §7 开放问题。

### 1.2 server_name 口径
`server_name`（serverInfo.name）是 server **自报标识**，与我方 `code` 区分，存库、**不在列表展示**，详情/编辑态可见，仅作展示与排障比对。

---

## 2. V31 迁移 DDL 设计（仅设计，不落 .sql）

文件名（确认后由后端创建）：`V31__mcp_def_desc_servername_usage_stats.sql`
表：`mcp_def`（沿用 V14/V24 的 `ALTER TABLE mcp_def ADD COLUMN IF NOT EXISTS ...` 风格 + `COMMENT ON COLUMN`）。

```sql
-- V31: MCP 服务描述 + serverInfo.name + server 级使用统计
-- 设计依据：docs/architecture/MCP数据结构扩展与使用统计-设计.md
-- 迁移纪律：新增列均带默认值/可空，存量行兼容（统计列 DEFAULT 0 自动回填，无需 UPDATE 回填语句）
-- 注：本期不引入 server_title（serverInfo.title 需协议 >=2025-06-18，当前协商 2025-03-26 恒空）

-- (1) 业务/元信息列
ALTER TABLE mcp_def ADD COLUMN IF NOT EXISTS description TEXT;            -- 服务描述，用户填，选填(nullable)
ALTER TABLE mcp_def ADD COLUMN IF NOT EXISTS server_name VARCHAR(128);   -- serverInfo.name（server 自报 id，握手整次成功才覆盖）

-- (2) server 级使用统计累计列（原始累计量，派生指标读时算，增量更新才准）
ALTER TABLE mcp_def ADD COLUMN IF NOT EXISTS call_count           BIGINT NOT NULL DEFAULT 0;  -- 真正发起的调用次数（成功+握手失败+调用失败）
ALTER TABLE mcp_def ADD COLUMN IF NOT EXISTS success_count        BIGINT NOT NULL DEFAULT 0;  -- 成功返回次数（仅成功；平均/成功率分母）
ALTER TABLE mcp_def ADD COLUMN IF NOT EXISTS sum_success_ms       BIGINT NOT NULL DEFAULT 0;  -- 成功调用「含握手整次耗时」累计(ms)
ALTER TABLE mcp_def ADD COLUMN IF NOT EXISTS sum_success_call_ms  BIGINT NOT NULL DEFAULT 0;  -- 成功调用「纯 callMs」累计(ms)

COMMENT ON COLUMN mcp_def.description IS '服务描述（用户填，选填，可空）';
COMMENT ON COLUMN mcp_def.server_name IS 'MCP serverInfo.name（server 自报标识，与我方 code 区分；握手整次成功才覆盖式更新，连不上保留旧值不清空）';
COMMENT ON COLUMN mcp_def.call_count          IS 'server 级真正发起的工具调用累计次数（成功+握手失败+调用失败均计；BAD_CODE/未接入/transport 不支持的短路不计；原子自增）';
COMMENT ON COLUMN mcp_def.success_count       IS 'server 级成功返回累计次数（平均/成功率分母；超时/失败不计）';
COMMENT ON COLUMN mcp_def.sum_success_ms      IS 'server 级成功调用「含握手整次耗时」累计(ms)；平均执行时间=sum_success_ms/success_count，读时计算';
COMMENT ON COLUMN mcp_def.sum_success_call_ms IS 'server 级成功调用「纯 callMs」累计(ms)；纯调用平均=sum_success_call_ms/success_count，读时计算，供排障';
```

设计要点：
- **null 性**：`description`/`server_name` 可空；四个统计列 `NOT NULL DEFAULT 0`，保证读时 `+1`/求平均不出现 null 运算。
- **默认值与存量兼容**：统计列 `DEFAULT 0`，Postgres 加列即对存量行物化默认值，**无需额外 UPDATE 回填**；元信息列 NULL 即「尚未获知」，符合语义。
- **索引**：统计列**不建索引**——只按主键 id（或唯一 code）定位单行更新与读取，不做范围/排序检索；建索引反而增加高频自增的写放大。`code` 已有唯一约束、`id` 主键，足够。
- **类型**：累计用 `BIGINT` 防溢出（INT 上限约 21 亿，长期累计可能触顶）；两个 `sum_*_ms` 同理 BIGINT（毫秒累计增长快）。
- **不新增**：不加 `server_title`/`last_modified`/`avg_exec_ms`/`success_rate` 列（title 本期不做；平均/成功率派生、最后更新不做）。

---

## 3. 解析与回写设计（server_name；不含 title）

### 3.1 解析：`StreamableHttpTransport.applyServerInfo`（line 166-177）
**保持现状即可**——已解析 `serverInfo.name → serverName`、`serverInfo.version → serverVersion`。本期**不增加** `serverInfo.title` 解析（§1.1）。

### 3.2 会话：`McpSession`
**无需改动**——已有 serverName/serverVersion/protocolVersion。本期**不增加** serverTitle。

### 3.3 回写时机与幂等（AI 专家：握手整次成功才覆盖）
两处回写点统一「**整次握手成功才覆盖，任一步失败保留旧值不清空**」：

| 回写点 | 文件:line | 改动 |
|--------|-----------|------|
| 巡检 | `McpHealthScheduled.probe` :64-71 | initialize **整次成功**分支内：在现有 setProtocolVersion/setServerVersion 同位置增 `def.setServerName(s.serverName())`（非空守卫）；catch（任一步失败）分支**不动** server_name/server_version/protocol_version |
| 拉取/测连 | `McpProvisionService.updateConnState` :188-197 | 入参或方法内增 serverName 回写，`if (xxx != null) def.setXxx(...)` 守卫；仅在握手成功路径调用 |

幂等与覆盖语义（AI 专家本期必做项）：
- **整次握手成功才覆盖**：`server_name`（连同已有 protocolVersion/serverVersion）只在 `initialize` 完整成功返回后才覆盖式更新——握手中途任一步失败（连接/协议/RPC 异常）一律走 catch，**不触碰**这些列。
- **非空守卫**：仅当 session 取到非 null 才 set（沿用现状 `if (s.serverVersion() != null)` 的写法），避免某次握手未带 serverInfo 把已有值抹成 null。
- **失败不清空**：连接失败（catch 分支）只改 connStatus/check 相关，**保留** server_name/server_version/protocol_version 上一次成功值供展示。
- **覆盖式更新**：每次成功连接用最新 serverInfo 覆盖（server 改了 name 能跟随）；多次探活幂等——同输入产生同结果。

> 漂移日志：现有 `detectDrift` 仅对 serverVersion 打日志，本次不扩展到 server_name（避免噪声）。

---

## 4. 使用统计埋点设计（重点：计数边界 + 并发 + 解耦）

> **📌 校准标注（2026-07-17）**：`McpUsageRecorder` 与 `McpDefRepository.recordSuccess/recordFailure` 已就位，但运行时执行器（`McpToolExecutor`）已随主版本运行时剥离不在本仓，本节埋点未在本仓接线（`McpUsageRecorder` 当前无注入方，§4.2 分支判定表所指 execute 行号代码不在本仓）。详见《设计文档校准审计-20260717.md》。

### 4.1 数据落点
`mcp_def` 四个累计列，按 **id 定位行**（execute 内已 `findByCode` 拿到 `def`，可直接用 `def.getId()`，免二次查询）。

### 4.2 调用计数边界 —— 每个 return 分支判定表（钉死，实现零歧义）

口径：**只有真正发起调用（走到 `getOrCreate` 握手及之后）的路径才计 `call_count`**。逐分支：

| # | 分支 / 返回 | execute 行 | 性质 | 计 `call_count`？ | 计 `success_count` + 耗时？ |
|---|-------------|-----------|------|:----:|:----:|
| 1 | `MCP_BAD_CODE`（splitMcpCode==null） | line 71 | 未发起·防御短路 | ✗ | ✗ |
| 2 | `notConnected`（总开关关 / def 为 null / 非 active） | line 79、83 | 未发起·未接入短路 | ✗ | ✗ |
| 3 | `unsupported`（transport 不支持，如 stdio） | line 86 | 未发起·不支持短路 | ✗ | ✗ |
| 4 | **握手失败**（getOrCreate 抛 McpTransportException） | line 96 | **已发起** | **✓** | ✗ |
| 5 | **调用失败/超时**（callTool 抛 McpTransportException） | line 112 | **已发起** | **✓** | ✗ |
| 6 | **调用异常**（callTool 抛 RuntimeException） | line 117 | **已发起** | **✓** | ✗ |
| 7 | **成功返回**（resultMapper.map） | line 107 | **已发起·成功** | **✓** | **✓**（total → sum_success_ms，callMs → sum_success_call_ms） |

实现要求：
- **计数起点 = 握手开始（line 88-91 之前）**。分支 1/2/3 在握手前 `return`，直接 return、**不 record**。
- 分支 4/5/6/7 都在「已发起」区域，**必须 record**（成功走 recordSuccess，失败走 recordFailure）。
- **埋点收口到单一上报点**：不要把 record 散落进各 catch（易漏埋）。重构 execute，使「已发起」区域的所有返回路径先得到 result/区分成功失败，再在**统一出口**记一次后返回（见 §4.4）。

### 4.3 更新方式：原子 SQL（行级 `column = column + n`）
不走「读实体→改字段→save」（有读改写竞态，并发会丢更新），用 `@Modifying` 原子自增。Repository 设计（`McpDefRepository`）：

```java
/** 成功调用：次数+1、成功数+1、含握手 total 累加、纯 callMs 累加。原子自增，避免读改写竞态。 */
@Modifying
@Query("""
        UPDATE McpDef m
           SET m.callCount = m.callCount + 1,
               m.successCount = m.successCount + 1,
               m.sumSuccessMs = m.sumSuccessMs + :totalMs,
               m.sumSuccessCallMs = m.sumSuccessCallMs + :callMs
         WHERE m.id = :id
        """)
int recordSuccess(@Param("id") Long id,
                  @Param("totalMs") long totalMs,
                  @Param("callMs") long callMs);

/** 已发起但失败/超时/异常：仅次数+1（仍计入调用次数，但不进成功数/耗时均值）。 */
@Modifying
@Query("UPDATE McpDef m SET m.callCount = m.callCount + 1 WHERE m.id = :id")
int recordFailure(@Param("id") Long id);
```
- 两条独立方法（成功一条、失败一条），语义清晰、JPQL 简单，优于「一条带条件参数」。
- 实体需补 `callCount/successCount/sumSuccessMs/sumSuccessCallMs` 字段（`long`，默认 0L）+ getter/setter；JPQL 用属性名，故实体字段必须存在。
- `@SQLRestriction("deleted = false")` 对 `@Modifying` JPQL **不生效**（仅作用于实体查询），本场景 id 来自 active 且未删的 def，无影响；如需严谨可在 WHERE 增 `AND m.deleted = false`。

> **📌 校准标注（2026-07-17）**：全线 ID 字符串化（V45–V53）后 `mcp_def` 主键为 String（`mc_` 前缀句柄），`recordSuccess`/`recordFailure` 实际签名为 `String id`（`McpDefRepository.java:83/90`），非上述 `Long id`；§8 落地清单同此理解。详见《设计文档校准审计-20260717.md》。

### 4.4 事务、解耦与「统计写失败必 warn」（推荐方案）
- **现状**：`execute` 不在事务中（§0 判断），故每个统计 UPDATE 自身就是一次独立短事务（`@Modifying` 默认需事务上下文）。
- **推荐**：把「记一次统计」封装到一个**独立小服务**（`McpUsageRecorder`），方法标 `@Transactional(propagation = REQUIRES_NEW)`，在 `execute` 统一出口以 **try/catch 包裹调用**：

```java
// execute「已发起」区域统一出口，成功/失败分支都走到这里记一次
try {
    if (success) {
        usageRecorder.recordSuccess(def.getId(), totalMs, callMs);  // REQUIRES_NEW
    } else {
        usageRecorder.recordFailure(def.getId());                   // REQUIRES_NEW
    }
} catch (RuntimeException ex) {
    // AI 专家必做项：禁止静默吞，必须带 mcpCode/tool 的 warn，避免指标静默丢失
    log.warn("MCP 使用统计写入失败 mcpCode={}, tool={}（不影响调用结果，已忽略）", mcpCode, toolName, ex);
}
```
解耦三道保险：
1. **统计写独立于主调用结果**：record 失败被 try/catch 捕获，**绝不改变 ToolResult 返回**。
2. **必 warn 不静默**（AI 专家本期必做项）：catch 中**必须** `log.warn`，带 `mcpCode`/`tool`，杜绝指标静默丢失。
3. **REQUIRES_NEW**：统计写自成事务，与主链路互不牵连。

> 异步（@Async）权衡：**不采用**。单条原子 UPDATE 极快，DEMO 体量同步开销可忽略；引入异步线程池增加复杂度（线程池满/丢任务/上下文传递），得不偿失。未来高频再演进为异步批量。

### 4.5 耗时口径（成功分支同时累加 total 与 callMs）
- **含握手 total**：`System.currentTimeMillis() - t0`，即现有 `elapsed(t0)`（line 149-150）。
- **纯 callMs**：`System.currentTimeMillis() - callStart`，即现有 line 104 已算的 `callMs`。
- **成功分支（#7）同时累加两者**：`recordSuccess(id, total, callMs)`。代码里 handshakeMs(line98)/callMs(line104)/total 都已分别算好，直接取用。
- 失败分支（#4/5/6）只 `recordFailure(id)`，不累加任何耗时。

### 4.6 派生指标（读时算，不写时算，统一除零兜底）
读取（DTO 映射）时计算，`success_count==0` 或 `call_count==0` 时返回 `null`（前端展示「—」）：
- 平均执行时间（含握手，展示）：`avgExecMs = successCount > 0 ? round(sumSuccessMs / successCount) : null`
- 纯调用平均（排障，仅详情）：`avgCallMs = successCount > 0 ? round(sumSuccessCallMs / successCount) : null`
- 成功率：`successRate = callCount > 0 ? successCount / (double) callCount : null`（建议返回 0~1 的小数，前端格式化为百分比；或后端定为保留 4 位小数）

---

## 5. DTO / 接口变更（additive，不破坏现有前端；含空值兜底）

### 5.1 `McpDefRequest`（入参，create/update）
增可选字段：
```java
@Size(max = 1000, message = "服务描述不超过 1000 字")
String description   // 选填/nullable
```
- 校验：仅长度上限，不 NotBlank（选填）。`serverName`/统计列**不进请求**（server 返回 / 系统累计）。

### 5.2 `McpDefListItem`（列表出参）
新增字段（追加到尾部，additive）：
```java
long callCount,        // 真正发起的调用次数
Long avgExecMs,        // 平均执行时间(含握手, ms)，可空（成功数0→null）
Double successRate     // 成功率(0~1)，可空（call_count==0→null）；前端按需展示
```
- **不加** `code`/`serverName`/`description`/`avgCallMs` 到列表（口径：列表不展示 code 与 server_name；纯调用平均仅排障用，放详情）。

### 5.3 `McpDefDetailVO`（详情出参）
新增字段（追加到尾部）：
```java
String description,    // 可空 → 映射层兜底（见 §5.5）
String serverName,     // 可空
long callCount,
long successCount,
Long avgExecMs,        // 含握手平均，可空
Long avgCallMs,        // 纯调用平均，可空（排障）
Double successRate     // 成功率，可空
```
- 详情/编辑态可展示 code、server_name、description、全部统计。

### 5.4 `AdminMcpService` 映射改动点
- `list`（:77 构造 `McpDefListItem`）：补 `m.getCallCount()`、`avgExecMs(m)`、`successRate(m)`。
- `detail`（:109 构造 `McpDefDetailVO`）：补 description/serverName/callCount/successCount/avgExecMs/avgCallMs/successRate。
- `create`/`update`：把 `req.description()` 落到 `def.setDescription(...)`（blank→null）。
- 新增私有派生工具方法 `Long avgExecMs(McpDef)` / `Long avgCallMs(McpDef)` / `Double successRate(McpDef)`，封装除零逻辑，list/detail 共用。
- 实体 `McpDef` 增 description/serverName/callCount/successCount/sumSuccessMs/sumSuccessCallMs 字段 + getter/setter（统计字段 `long`，默认 0；与 JPQL 属性名对齐）。

### 5.5 空值兜底（AI 专家本期必做项）
- `description` 可空：映射/展示**不得 NPE**。后端 DTO 允许返回 null；前端展示空串或「无描述」占位。工具项 `tools[].description` 同理可空 → 现有 `asStr(...)` 已做兜底，沿用，**不新增 NPE 风险**。
- `server_name` 可空：同样允许 null，展示占位。
- 派生指标可空：`null` 表示「无样本」，前端展示「—」。

### 5.6 兼容性
- 出参均为**追加字段**（JSON additive），旧前端不读不受影响。
- 入参 `description` 可选，旧调用不传不报错。
- **结论：对现有前端非破坏性变更（additive）。**

---

## 6. 对外契约文档需要怎么改（仅指明改点，不在本文档替改）

> 真相源守护：契约文档与代码 DTO 必须一致；本次改完代码后须同步下列两份。**均去掉 server_title 相关。**

| 文档 | 改点 |
|------|------|
| `docs/api/MCP真实运行时-接口契约.md` | ① MCP 定义字段说明表：新增 `description`(用户填,选填,可空)、`server_name`(serverInfo.name,可空,不在列表)；**明确不引入 server_title（协议 <2025-06-18）**；标注「不再有 lastModified」。② 详情 VO 字段表：补 description/serverName/callCount/successCount/avgExecMs/avgCallMs/successRate。③ 列表项字段表：补 callCount/avgExecMs/successRate；明确 code 与 server_name 不在列表。④ 新增「使用统计」小节：口径（call_count=真正发起的成功+失败，含分支判定要点；平均=仅成功；含握手 avgExecMs 与纯调用 avgCallMs 各自口径；成功率=success/call；存储 4 累计列，派生读时算，除零返回 null）。 |
| `docs/api/管理后台-对外服务调用指南.md` | 同步 MCP 字段口径与新增统计字段的展示说明（列表/详情展示矩阵、code/server_name 不在列表展示的约定）；去掉任何 title 相关表述。 |

---

## 7. 开放问题 / 风险（已拍板项标 ✓，未来扩展位标 ⏭）

1. ✓ **调用计数边界**（§4.2）：已钉死——真正发起（握手起步及之后）的成功+握手失败+调用失败计 `call_count`；BAD_CODE/未接入/transport 不支持的短路不计。分支判定表见 §4.2。
2. ⏭ **server_title 待协议升级再议**：`serverInfo.title` 需协商协议 ≥2025-06-18，当前 2025-03-26 恒空，本期整体不做；待升级后再议 title 字段与「缺失回退 name」规则。
3. ⏭ **逐次明细日志 `mcp_call_log`（未来扩展位，本期不实现）**：对齐项目 `LlmCallLog` 范式，记录每次调用的 tool / handshakeMs / callMs / success / errorCode / 来源(对话or定时) / 时间戳。**本期不建表、不实现**，但本期埋点已采用「单一上报点」结构（§4.2/§4.4），未来在该上报点旁平滑追加一条明细插入即可，无需重构调用链。
4. **统计是否可重置（运营清零）**：当前无清零入口。若需「重新统计」，另设管理端置零接口（`UPDATE ... SET call_count=0,success_count=0,sum_success_ms=0,sum_success_call_ms=0`）。**本期不做**。
5. **来源是否区分（对话侧 / 定时任务侧）**：已定=**合计不区分**（server 级单一累计）。若后续要分来源，借 #3 的 mcp_call_log 明细维度实现，本期不做。
6. **total 含握手在 session 复用下的冷热差异**：平均把「首次建连(含握手)」与「复用会话(几乎无握手)」混在同一均值；本期已用 `avgCallMs`（纯 callMs）作为排障对照缓解（详情可见整次 vs 纯调用差≈握手开销）。展示主指标仍为含握手 avgExecMs。
7. **高并发同一 mcp_def 行原子自增热点（已知，本期不处理）**：原子 `column=column+1` 对同一行并发更新会被 Postgres 行锁串行化。DEMO 体量（单 server 并发有限）**可接受**；极端高频热点 server 可能成写瓶颈，届时再演进（异步批量 / 分桶累加 / 借 mcp_call_log 明细离线聚合）。本期注明、不优化。
8. **空值兜底（已落 §5.5）**：description、tools[].description、server_name、派生指标均可空，映射/展示不得 NPE。

---

## 8. 落地改动清单（确认后编码用，按文件）

| 文件 | 改动 |
|------|------|
| `db/migration/V31__mcp_def_desc_servername_usage_stats.sql` | **新建**：6 列 ALTER（description/server_name/call_count/success_count/sum_success_ms/sum_success_call_ms）+ COMMENT（§2） |
| `entity/McpDef.java` | 加 description/serverName/callCount/successCount/sumSuccessMs/sumSuccessCallMs + 列映射 + getter/setter（统计 `long` 默认 0） |
| `transport/McpSession.java` | **无需改动**（不做 title） |
| `transport/StreamableHttpTransport.java` | **无需改动**（保持现有 name/version 解析，不解析 title） |
| `mcp/McpHealthScheduled.java` | 整次握手成功分支回写 server_name（非空守卫；失败不动） |
| `mcp/McpProvisionService.java` | updateConnState 在握手成功路径回写 server_name（非空守卫） |
| `repository/McpDefRepository.java` | 增 `recordSuccess(id,totalMs,callMs)` / `recordFailure(id)` `@Modifying` 原子自增 |
| 新增 `mcp/McpUsageRecorder.java` | `@Transactional(REQUIRES_NEW)` 封装 recordSuccess/recordFailure |
| `mcp/McpToolExecutor.java` | 重构为单一出口埋点：分支 1/2/3 短路不计，分支 4/5/6 recordFailure，分支 7 recordSuccess(total,callMs)；统计写 try/catch + **必 warn** |
| `dto/McpDefRequest.java` | 加 description（选填，`@Size(max=1000)`） |
| `dto/McpDefListItem.java` | 加 callCount/avgExecMs/successRate |
| `dto/McpDefDetailVO.java` | 加 description/serverName/callCount/successCount/avgExecMs/avgCallMs/successRate |
| `service/AdminMcpService.java` | list/detail 映射补字段 + 3 个派生工具方法（除零兜底）+ create/update 落 description（空值兜底） |
| `docs/api/MCP真实运行时-接口契约.md`、`docs/api/管理后台-对外服务调用指南.md` | 同步字段与统计口径（§6），去 title |

> 编码完成后须按 CR 矩阵交叉审查（后端代码→架构师；AI 调用相关→AI 专家+架构师），并验证迁移在存量库可幂等应用。
