# 全线 ID 改造（方案 B）· 迁移模板与约定（B0 沉淀，供 B1-B5 套用）

> 类型：可复用迁移模板 / 工程约定
> 来源：承接 `全线ID改造-方案B详细设计.md` §1.3 / §3.1 / §3.2，把三段式迁移与引用完整性门禁沉淀为模板。
> 性质：**B0 只沉淀模板与工具，不对任何业务表执行 PK 迁移**。各表真正迁移在 B1-B4 各业务片（**含 Bu 用户切片**），弱审计列横切归 B5（§1.6），均套用本模板。
> 切片序（7 片，2026-07-01 app_user 单独成 Bu）：**B0 → B1 provider → B2 expert/agent/数据表 → Bu 用户切片（app_user + 认证/隔离链路） → B3 技能+wire → B4 凭证三表+重加密 → B5 审计归属收尾**。Bu 的专属约定见 §1.7（认证链路 + 隔离 user_id 列 + user_biz_credential 仅切 FK 列）。
> Flyway 编号：本改造从 **V45** 起（现网最高 V44，已应用迁移一律不改）。

---

## 0. B0 已交付的可复用基础件

| 基础件 | 位置 | 用途 |
|---|---|---|
| `PublicIdGenerator` | `common/id/PublicIdGenerator.java` | 生成 `<前缀>_<11位 base58 去混淆>`，含查重重试；各表迁移生成 new_id 的单一来源 |
| `PublicIdType` | `common/id/PublicIdType.java` | 逐实体前缀常量（sk_/ps_/ag_/mc_/ap_/bz_/dt_/df_/pv_/tk_…） |
| `StringIdEntity` | `common/id/StringIdEntity.java` | `@MappedSuperclass` + `Persistable<String>` 基类；各被改实体在业务片 `extends` 它（H3，save 走 INSERT 不退化 merge） |
| `MigrationIntegrityGate` | `common/id/migration/MigrationIntegrityGate.java` | 阶段 B 切换前门禁：(a) 漏映射 COUNT + (c) 游离脏值 LEFT JOIN（B0 CR S1）+ (b) 错配反向 JOIN（M4）**三道** + PK 影子回填 |

> 铁律：B0 这些件**不接入任何业务实体 save 路径、不改任何业务表**。接入与迁移在 B1+。

---

## 1. 三段式迁移模板（对每张被改实体表 `T`，设计 §3.1）

> 占位符：`T`=被改实体表，`<prefix>`=该实体前缀（`PublicIdType`），`child`=引用 T 的子表，`fk`=子表 FK 列。
> 拓扑顺序：**被引用表（父）先准备 new id → 引用表（子）FK 影子回写 → 最后统一切 PK/FK**（设计 §2.3）。
>
> **⚠️ 套用前先判 FK 类型（设计 §8 铁律 3，2026-07-01）**：对父表 `T` 的每个引用列，先判**有无 DB 外键约束**：
> - **结构性 FK（有 DB 约束）** → 用本模板，**与 `T` 的 PK 同片**做影子回写 + 切列（不同片即破结构完整性 / 重建约束失配）。
> - **弱审计/归属列（无 DB 约束：`created_by`/`updated_by`/逻辑 `user_id`/`owner_user_id`/`submitter`/`reviewer` 等）** → **不在 `T` 的 PK 片处理**，归**审计归属收尾片 B5**（见 §1.6）。它们不影响结构完整性，只影响审计归属正确性，故解耦延后、集中处理。

### 阶段 A：建映射表 + 生成新 id（纯加法，零破坏，可即时回滚）

```sql
-- V45_a__id_map_<T>.sql（示例编号；实际按片顺延）
CREATE TABLE id_map_<T> (
    old_id    BIGINT       PRIMARY KEY,
    new_id    VARCHAR(20)  UNIQUE NOT NULL,
    mapped_at TIMESTAMPTZ  NOT NULL DEFAULT now()
);
```

**new_id 生成范式（P2-2 定稿，B1 已落，B2/B4 沿用）：首选 Java、SQL 生成仅应急兜底。**

- ✅ **首选**：用 **Java Flyway 迁移**（`BaseJavaMigration`）或受控启动期 Java 任务调 `PublicIdGenerator.generateUnique(PublicIdType.<T>, dedup)` 为 `id_map` 填 new_id——**单一算法来源 + SecureRandom（CSPRNG）**，与运行时同算法。`PublicIdGenerator` 无状态，迁移内可直接 `new` 实例化（无需 Spring 装配）。B1 的 `V45__provider_system_pk_to_string.java` 是参考实现：阶段A 在 Java 内生成 new_id 逐行 INSERT id_map，阶段B/C 的 DDL/回填经 JDBC `Statement` 执行，门禁经 `MigrationIntegrityGate`。
- ❌ **禁止**：SQL `RANDOM()` + `SUBSTRING(字母表)` 拼 base58（非 CSPRNG、双来源易与 `PublicIdGenerator` 字母表/长度漂移）。仅在「确无法走 Java（如纯 DBA 手工迁移）」时作应急兜底，且必须复刻 `BASE58_ALPHABET`（去 0/O/I/l，58 字符）+ 11 位 + `pv_/sk_/…` 前缀，并加 `UNIQUE(new_id)` 兜底碰撞。
- 覆盖**全量行（含软删）**（被 FK 引用的软删行也需映射）；生成器 dedup（批内 Set + id_map 唯一约束）双保险。

### 阶段 B：加影子列 + 回填本表 PK 影子 + 回写所有 FK 影子（纯加法）

```sql
-- 1) 本表 PK 影子列 + 回填
ALTER TABLE <T> ADD COLUMN id_new VARCHAR(20);
UPDATE <T> t SET id_new = m.new_id FROM id_map_<T> m WHERE t.id = m.old_id;

-- 2) 每个指向 T 的 FK 列：影子列 + 回写（可空 FK 的 NULL 保持 NULL）
ALTER TABLE <child> ADD COLUMN <fk>_new VARCHAR(20);
UPDATE <child> c SET <fk>_new = m.new_id FROM id_map_<T> m WHERE c.<fk> = m.old_id;

-- 3) 自引用（如 skill.parent_id）同法：
-- UPDATE skill s SET parent_id_new = m.new_id FROM id_map_skill m WHERE s.parent_id = m.old_id;
```

**切换前强制门禁（阶段 C 之前必过，设计 §3.1 步骤 6 + M4）——用 `MigrationIntegrityGate`：**

```java
// 受控迁移任务里，对每个 FK 列调一次；任一抛 MigrationIntegrityException 即停在阶段 B、不进阶段 C。
gate.verifyPrimaryKeyBackfill("<T>", "id", "id_new", "deleted = false");   // 本表 PK 影子全回填
gate.verifyForeignKey("<child>", "<fk>", "<fk>_new", "id_map_<T>");        // (a)漏映射 + (c)游离脏值 + (b)错配反向JOIN
// …对 T 的每个引用子表 / 每个 FK 列重复
```

- **(a) 漏映射**：`COUNT(fk非空) == COUNT(fk_new非空)`，防回填不全。
- **(c) 游离脏值（B0 CR S1）**：`LEFT JOIN id_map ON fk_new = new_id WHERE fk_new IS NOT NULL AND new_id IS NULL` 零行——补 (a)+(b) 盲区：fk/fk_new 均非空但 fk_new 是不在 id_map 的游离脏值时，(a) COUNT 仍相等、(b) INNER JOIN 会丢弃该行而误放行。
- **(b) 错配（M4）**：`child.fk_new = m.new_id AND m.old_id <> child.fk` 零行，防「UPDATE…FROM JOIN 错填把 A 行 fk 填成 B 的 new_id」——这是 (a) 的 COUNT 查不出来的错。

> **📌 校准标注（2026-07-17）**：本节原只写「(a)(b) 两道门禁」，与 `MigrationIntegrityGate.java` 实现（三道：(a)+(c)+(b)）及本文 §3.5/§3.6「三道门禁/三门禁」表述不符，已按实现订正为三道，补入 (c) 游离脏值检查（B0 CR S1 引入）。详见《设计文档校准审计-20260717.md》。

### 阶段 C：切主键 + 切外键 + 收尾（受控切片，按拓扑顺序，保留旧列回滚窗口）

```sql
-- 0) 断 DB FK 约束：显式名直接 DROP；无显式名先查真实名（C1，不硬编码默认名）
--    SELECT conname FROM pg_constraint WHERE conrelid='<child>'::regclass AND contype='f';
--    P1-2：重建前先核对原约束级联语义（confdeltype/confupdtype），重建时保持一致（无子句=NO ACTION）。
ALTER TABLE <child> DROP CONSTRAINT <fk_constraint_name>;

-- 1) FK 列切换（旧列改名保留作回滚窗口，不立即 DROP）
ALTER TABLE <child> RENAME COLUMN <fk> TO <fk>_old;
ALTER TABLE <child> RENAME COLUMN <fk>_new TO <fk>;
-- 🔴P0-1（范式通则·必修，与 DROP IDENTITY 并列）：RENAME→*_old 后【必须紧跟 DROP NOT NULL】。
--   RENAME 保留原列的 NOT NULL 约束；*_old 是回滚保留列、应用层从不写 → 凡向本表 INSERT 新行都会因
--   *_old NOT NULL 违约失败（办事链路截断级）。故每个 *_old 列都要 DROP NOT NULL（无论原列是否 NOT NULL，统一可空）。
ALTER TABLE <child> ALTER COLUMN <fk>_old DROP NOT NULL;

-- 2) PK 切换
-- 🔴P1-1（C1 铁律）：PK 约束名动态核取，禁止硬编码默认名 <T>_pkey（默认名可能因历史而异）。
DO $$ DECLARE pk TEXT; BEGIN
  SELECT conname INTO pk FROM pg_constraint WHERE conrelid='<T>'::regclass AND contype='p';
  IF pk IS NOT NULL THEN EXECUTE 'ALTER TABLE <T> DROP CONSTRAINT '||quote_ident(pk); END IF;
END $$;
-- 🔴P0-1（范式通则·必修）：源表 id 多为 GENERATED ... AS IDENTITY；RENAME 前【必须】DROP IDENTITY，
--   否则 RENAME id→id_old 残留 identity 属性 + 底层 sequence，污染 pg_dump、留悬挂序列。
--   已改应用层赋字符串 id（PublicIdGenerator），不再需要 IDENTITY/sequence。
ALTER TABLE <T> ALTER COLUMN id DROP IDENTITY IF EXISTS;
ALTER TABLE <T> RENAME COLUMN id TO id_old;
ALTER TABLE <T> RENAME COLUMN id_new TO id;
ALTER TABLE <T> ALTER COLUMN id SET NOT NULL;
ALTER TABLE <T> ADD PRIMARY KEY (id);
-- 🔴P0-1（同上必修）：id_old 原为 PRIMARY KEY 故必 NOT NULL；RENAME 后须 DROP NOT NULL（应用不写 id_old）。
ALTER TABLE <T> ALTER COLUMN id_old DROP NOT NULL;

-- 3) 重建 DB FK 约束（VARCHAR 对齐；级联语义同 P1-2 核对结果）+ 重建受影响索引（M3）
ALTER TABLE <child> ADD CONSTRAINT <fk_constraint_name> FOREIGN KEY (<fk>) REFERENCES <T>(id);
-- 🔴🔴 P0-2（范式通则·必修，与 DROP IDENTITY / DROP NOT NULL 并列，Bu 对抗排查逮到）：
--   **索引随 RENAME 漂移**——PG 索引绑物理列不绑列名。上面 `RENAME <fk>→<fk>_old; <fk>_new→<fk>` 后，
--   原建在该列的【所有】索引（普通 idx_* / 部分索引 / 复合唯一索引 / UNIQUE 约束）会**全部跟到 <fk>_old**（BIGINT 回滚列），
--   转正的新 VARCHAR 列**无索引** → 高频查询全表扫、唯一性约束落在废列上（H2 flyway关测不出、CR/QA 潜逃，仅真 PG 暴露）。
--   故每个被 RENAME 的 fk / id 列，必须：① 逐个 DROP 旧索引（若由 UNIQUE 约束支撑：先 ALTER TABLE ... DROP CONSTRAINT）；
--   ② 在【当前正式列】上 CREATE（部分索引带回 WHERE 谓词、复合索引用当前列名、DESC 等修饰保留）。真 PG `pg_indexes WHERE indexdef ~ '_old'` 逐个核，一个不漏。
--   反例：V47/B2 漏了 19 个漂移索引（idx_skill_agent/idx_skill_position/idx_agent_position/idx_data_field_def_table/
--   idx_skill_table_ref_table/idx_exec_task_*/idx_llm_call_expert_created/idx_ueb·ueo·uso_user_expert/expert_*_key/uq_exec_task_inflight 等），
--   由补偿迁移 V50 统一重建。B3/B4 阶段C **内联做**，别再靠补丁迁移。
-- 含被改 FK 列的部分唯一索引：DROP→以新 VARCHAR 列 CREATE（M3：uk_data_table_def_alive / uk_expert_resource_alive /
--   uk_ueo_user_expert_active / uk_uso_base_active 等，逐条随片重建 + 唯一性回归）

-- 4) JPA 实体此时已是 @Id String（extends StringIdEntity），代码切片与 DB 切片同发布（设计 §8）
```

> **🔴🔴 P0-1 血泪通则（QA 真 PG 验收逮到，B1+B2 共有）：`*_old` 回滚列 RENAME 后必须 DROP NOT NULL。**
> RENAME 列会**保留原列的 NOT NULL 约束**。`*_old` 是回滚保留列、应用层从不写 → 凡向迁移表 INSERT 新行（绑定/建岗/建表/办事写记录/建任务…）都会因 `*_old` NOT NULL 违约失败，**办事链路截断级**。
> **教训：H2 测不出（项目集成测试 `flyway.enabled=false`、用 schema.sql 直建无 `*_old` 列的表），仅真 PostgreSQL 跑全套 Flyway 后才暴露。** 故各片阶段C **内联**对每个 `*_old`（id_old + 各 FK 的 *_old）紧跟 `DROP NOT NULL`（与 `DROP IDENTITY` 并列为阶段C 通则）；Bu/B3/B4 **务必内联做，不要再靠补丁迁移**。B1/B2 已落地的 V45/V47 因已发布不可改 checksum，由 **V48** 统一补丁（信息_schema 兜底扫 `%_old` + 显式清单，幂等）。
>
> **回滚约定补充（P0-1）**：回滚反向 RENAME 时**不恢复 IDENTITY/sequence**——已统一改应用层 `PublicIdGenerator` 赋 id，回滚也维持应用层赋值口径（旧数字 id 仅作历史值在 `id_old` 留存）。
> **审计底座（V46，B2 前已落）**：`audit_log.target_id` 已 `BIGINT→VARCHAR(20)`，`AuditLogService.record` 有 `String targetId` 重载（旧 `Long` 重载 `String.valueOf` 收敛）。各实体字符串化后审计直接记字符串主键，无需 targetId=null+detail workaround。

- **skill.path 重建**（§4）在 skill 切 PK 后同片执行：根 `'/' || id || '/'`、子 `parent.path || id || '/'`，自顶向下逐层；重算后 broken=0 校验 + REINDEX；并改 `rootIdOf`（H1，按 `/` 切分取首段字符串、返回 String）+ LIKE 加 `ESCAPE` 转义 `_/%/\`（H2）。这些归 **B3**。

---

## 1.5 ⚠️ B1 实施前阻断结论（凭证 AAD 耦合 + 跨片 FK 孤儿，待用户/PM 拍板）

> 经 B1 实施前源码核实，发现两条**必须先拍板**的耦合，未澄清前不得对这些表执行 PK 迁移。详见 PM 收到的「B1 实施前分析」。

**① 凭证 AAD 不可逆耦合（最高风险）**：`mcp_def`/`api_def` 的 PK 一旦迁成字符串，存量密文的 AAD 解不开：
- `api_def.auth_config` 密钥 AAD = `0L|api_def.id`（`AdminApiService:286`、运行时 `ApiToolExecutor:278`，用 `def.getId()`）。
- `mcp_def.env_config` 每 value AAD = `mcpId|-1L`（`AdminMcpService:364`、运行时 `StdioTransport:385`，`def.getId()`）。
- AAD = `(id + "|" + 域)` 的字符串值，PK 数字→字符串后 AAD 字符串变（`"5|-1"`→`"mc_xxx|-1"`）→ GCM 标签校验必失败 → 存量凭证全解不开。
- **结论（B1 实施前已重排，现以裁决落定）**：`mcp_def`/`api_def`/`biz_system_def` 三表 PK + 三类凭证重加密**全部收进 B4**（重排后不再 B1，铁律 1）。`data_table_def`/`service_provider_system` **无任何 AAD 耦合**，可纯走三段式（provider→B1、data_table_def→B2）。
- **`user_biz_credential` 双段 AAD（2026-07-01 Bu 裁决补全）**：其 AAD=`userId\|bizSystemId` **两段都是会迁移的主键**——`userId`=`app_user.id`（**Bu** 迁）、`bizSystemId`=`biz_system_def.id`（**B4** 迁）。按**铁律 1′**（AAD 跨多片主键时重加密落"最后那片"一次完成），其重加密**只在 B4 一次做**（旧数字双段解密→新字符串双段重加密），**Bu 只切 `user_biz_credential.user_id` FK 列、不动密文**（可回滚）。**严禁在 Bu 就地重加密**（会与 B4 双重重加密 + 让 Bu 成不可逆片）。Bu→B4 窗口冻结业务凭证读写（或 userId AAD 段临时取旧数字 shim）——设计 §5.5/§4.4。

**② 跨片 FK 孤儿（拓扑约束）**：父表 PK 迁了、子表 FK 列还指向旧数字 id → 即时破引用完整性。`data_table_def(id)` 被 `data_field_def`/`data_record`（B2 第4层）+ `skill_table_ref`（B3 第5层）以 NOT NULL FK 引用。**结论**：要么 `data_table_def` PK 迁移延后到 B2（与其子表同片），要么 B1 迁 `data_table_def` 时把这三个子表的 FK 影子回写+切换也拉进 B1。建议**前者**（data_table_def 移到 B2，B1 只做 mcp/api/biz/provider）。

---

## 1.6 审计归属收尾片 B5 模板（弱审计列横切，设计 §8.0 / 铁律 3）

> 用途：承接全库**无 DB FK 约束**的弱审计/归属列（`created_by`/`updated_by`/逻辑 `user_id`/`owner_user_id`/`submitter`/`reviewer` 等，~32 列 / 9+ 表，含 B3/B4 所属表）。与审计底座 V46（`audit_log.target_id → VARCHAR`）一脉相承。
> 时序硬约束：**B5 须晚于 B1~B4 全部 PK 片**，因重映射值要用各实体 id_map（主要 `id_map_app_user`，归属链涉哪个实体就用哪个 map）；**各 id_map 保留至 B5 用完，清理片不得早于 B5**。

弱审计列**无 FK 约束**，故迁移比结构性 FK **少了切 PK / 断约束 / 重建约束**三步，只做"列改类型 + 值重映射 + 门禁"：

```sql
-- 对每张含弱审计列的表 T、每个弱审计列 <auditcol>（指向某实体 E，用 id_map_<E>）：
-- 1) 影子列（纯加法，可即时回滚）
ALTER TABLE <T> ADD COLUMN <auditcol>_new VARCHAR(20);
-- 2) 按 id_map 重映射值（旧数字 → 新字符串 id；NULL/0/系统占位值按约定保持或映射）
UPDATE <T> t SET <auditcol>_new = m.new_id FROM id_map_<E> m WHERE t.<auditcol> = m.old_id;
-- 3) 切换（保留旧列回滚窗口，无 PK/约束动作）
ALTER TABLE <T> RENAME COLUMN <auditcol> TO <auditcol>_old;
ALTER TABLE <T> RENAME COLUMN <auditcol>_new TO <auditcol>;
```

**门禁（M4 同款，逐列调）**：

```java
// 弱审计列只查"已重映射的值是否错配"，漏映射判定按业务容忍（历史脏值/已删用户的归属可能无 map → 按约定保留旧值或置 NULL，不强制 COUNT 相等）。
gate.verifyForeignKey("<T>", "<auditcol>", "<auditcol>_new", "id_map_<E>");  // (b) 错配反向 JOIN：凡有 _new 的行，反查 old 必等于原值
```

> 与结构性 FK 门禁的差异：结构性 FK 用 (a) 漏映射 COUNT 严格相等（非空必须全有 new）；弱审计列因可能引用已删/历史用户，**漏映射不强制相等**（按"无 map 的归属值保留旧数字串 or 置 NULL"约定处理，CR 时定），但 **(b) 错配反向 JOIN 仍强制零行**（有映射的必须映对）。
> B5 无凭证、可回滚；JPA 侧把对应实体的 `Long createdBy/updatedBy`（11 个实体）等审计字段类型改 `String`，随 B5 同发布。

---

## 1.7 Bu 用户切片模板（app_user.id + 认证/隔离链路，设计 §8.0u / §4.4 / §5.5）

> 用途：承接 `app_user.id`（全库扇出最大，user_id 遍布 30+ 表）+ 全部指向 app_user 的结构性/隔离 user_id FK + 认证链路（`SecurityUtils.requireUserId()` Long→String、JWT `uid` claim 数字→usr_xxx，sub=username 不动）。**位次 B2 之后、B3 之前。**
> 性质：**可回滚片、无不可逆活**（`user_biz_credential` 密文不动，重加密下沉 B4，铁律 1′）。但**触认证主体与用户数据隔离，是全程最敏感片**，护栏最严（仅次于 B4 的不可逆护栏）。

### 1.7.1 DB 迁移（套用 §1 三段式，T=app_user）

- 对 `app_user` 走标准三段式（阶段 A 建 `id_map_app_user` + 生成 `usr_xxx`；阶段 B 加 `id_new` + 全部 user_id 子列 `<fk>_new` 回填；阶段 C 切 PK + 切全部 user_id FK 列 + 重建约束/索引）。
- **收哪些 user_id 列（判定线：有 DB 约束 OR 参与运行时隔离过滤 → 入 Bu；纯归属审计 → 归 B5；CR 已逐列定档）**：
  - DB 约束 FK（8 条，V1）：`user_role.user_id`、`user_expert_binding.user_id`、`user_expert_override.user_id`、`user_skill_override.user_id`、`session.user_id` 等。
  - 无约束但隔离过滤的结构逻辑列：`scheduled_task.user_id`、`memory_item.user_id`、`personal_doc.user_id`、`memory_extract_cursor.user_id`、`user_tool_favorite.user_id`、`task_execution.owner_user_id`、**`memory_import_job.user_id`（CR 补：findByUserIdAndIdempotencyKey + getUserId().equals(userId) 过滤）**、`user_biz_credential.user_id`（仅切 FK 列，密文留 B4）。
  - **CR 定档 B5（非 Bu，纯归属）**：`skill_publication.submitter/reviewer`、`tool_market_listing.submitter_id/reviewer_id`（**该表无 user_id 列**——CR 订正前误列的 `tool_market_listing.user_id` 不存在）、`audit_log.user_id`（纯写入归属、无 userId 过滤方法）。
  - `user_expert_binding/override/skill_override`：本片只切 `user_id` 列（expert_id 侧 B2 已建影子、自身代理 PK 留 B4）。
- **跨表 JOIN 硬约束（CR 补）**：`memory_extract_cursor.user_id` 与 `session.user_id` 有 `ON c.user_id=s.user_id` + `ON CONFLICT(user_id,session_id)`——**两列必须 Bu 同窗口同切 VARCHAR**，阶段 C 切换后**显式断言两列均为 VARCHAR 才放行**（一列切了另一列还 BIGINT → JOIN 类型失配 / ON CONFLICT 失效）。
- **门禁**：结构性/隔离 user_id 列一律用 `MigrationIntegrityGate` 严格 (a) 漏映射 COUNT 相等 + (b) 错配反向 JOIN 零行（**不走弱审计的漏映射容忍口径**——隔离列漏一行即用户数据查不到）。
- **M3 部分唯一索引**：含 user_id 的部分唯一索引（`uk_ueo_user_expert_active(user_id,expert_id)` 等）随本片 user_id 列切换 DROP→VARCHAR 列 CREATE + 唯一性回归。

### 1.7.2 user_biz_credential 特例（仅切 FK 列、不动密文）

```sql
-- Bu 对 user_biz_credential 只切 user_id FK 列（影子回写），credential_cipher 密文一字不改：
ALTER TABLE user_biz_credential ADD COLUMN user_id_new VARCHAR(20);
UPDATE user_biz_credential c SET user_id_new = m.new_id FROM id_map_app_user m WHERE c.user_id = m.old_id;
-- 阶段 C 切 user_id 列；credential_cipher 留到 B4 用双段新 AAD 一次重加密（设计 §5.5）
```

> ⚠️ **严禁 Bu 重加密 user_biz_credential**（会与 B4 双重重加密 + 让 Bu 成不可逆片）。**AI CR 利好：当前全后端仅 3 处 decrypt（均 api/mcp），无 user_biz_credential 解密消费方** → 窗口风险"低/潜在"，**护栏采纳①冻结写入**（②userId-段-旧数字 shim 仅"未来出现解密消费方且不可冻结"时备选，启用则 B4 后强制拆除）。

### 1.7.3 认证/隔离链路代码改造（与 DB 切 PK 同发布同回滚，设计 §4.4，CR 订正）

1. `SecurityUtils.requireUserId()` **及 `requireAdminUserId()`** `Long → String`；CR 实测 **126 调用点 / 228 声明 / 79 文件 + requireAdminUserId 11 处 + 30 测试文件 + 按 user_id 过滤仓储**随之改（漏改处编译失败暴露）。**工作量是全库最大扇出 + 认证核心，不拆片但当独立大工作量排期。**
2. **JWT 订正（CR）**：userId 在 **`uid` claim（非 sub；sub=username 不动）**。改动点 = `JwtAuthFilter` L45-46 `claims.get("uid", String.class)` + `JwtTokenProvider.generate(...)` 签发 uid `Long→String`。**无 refresh-token / remember-me** → 存量旧 token（uid=数字）失效、**强制全员重登可行、零兼容层**（不做数字 uid→usr_xxx 兼容）。
3. **数字注入点（CR 补）**：`InternalMemoryController` 的 `@RequestParam @NotNull Long userId`（旁路 requireUserId 的应用态内部 API）改 `String`，且**其 Python 调用方同步改 int→str（Java/Python 同提交）**——纠正"userId 都走 requireUserId、无遗漏数字注入点"的旧表述。
4. **隔离回归红线（QA 必跑，CR 补凭证断言）**：以"切换前已有数据的真实用户"登录，断言其 `memory_item`/`personal_doc`/`session`/`memory_import_job`/历史会话**全部可见**，**且 `user_biz_credential` 托管凭证 status 按新 `usr_xxx` 可命中**（防切 user_id FK 列丢归属——托管列表/status 走 user_id 过滤）。非新建用户 happy-path。任一历史数据/凭证条目查不到 → 隔离破裂 → 立即回滚。
5. wire `userId` int→str 随本片（Java/Python 同提交，N1 锁区；其余 wire 字段在 B3，按字段所属片切——设计 §6.3）。

> **回滚**：Bu 无不可逆活。回滚 = app_user.id + 全部 user_id 列反向 RENAME 恢复 BIGINT + 恢复旧 FK 约束 + 回退认证链路代码 + **强制全员重登**（JWT `uid` 回退数字）。若 B4 已执行（其 user_biz_credential 重加密依赖 Bu 产 `id_map_app_user`，且 `id_map_app_user` 同时是 B5 弱审计重映射依赖），回滚 Bu 须连带回滚 B4（备份恢复）。

---

## 2. 回滚约定（设计 §3.2）

| 阶段 | 回滚手段 | 业务影响 |
|---|---|---|
| A / B（加表 / 加列 / 回填） | `DROP` 影子列 / 映射表，即时回到原状 | 无感 |
| C（切换） | **保留 `id_old`/`fk_old` 旧列**作回滚窗口；回滚 = 反向 RENAME（`id`→`id_new`、`id_old`→`id`）+ 恢复旧 FK 约束 | live 回归窗口内可逆 |
| 旧列清理 | 阶段 C live 回归通过、稳定 N 天后，独立「清理切片」DROP `*_old` 列 | 清理后该表不可逆 |
| Bu 用户切片 | 无不可逆活（密文不动）。回滚 = app_user.id + 全部 user_id 列反向 RENAME 恢复 BIGINT + 恢复旧 FK 约束 + 回退认证链路代码（requireUserId/JWT）+ **强制全员重登**；若 B4 已执行（依赖 Bu 产 id_map_app_user 重加密 user_biz_credential）则回滚 Bu 须连带回滚 B4 | live 回归窗口内可逆；回滚后需重登 |
| B4 凭证片 | 备份（pg_dump）是唯一回滚手段；清理备份后进入不可逆 | 单独最重护栏，见设计 §5 |
| B5 审计归属收尾 | 弱审计列无约束，回滚 = 反向 RENAME（`<auditcol>`→`<auditcol>_new`、`<auditcol>_old`→`<auditcol>`），无约束重建；纯加列/回填阶段可即时弃 | 可逆；无凭证、无不可逆活 |

> **铁律**：代码（JPA `@Id String` / wire 改动）与 DB 迁移**同切片发布同回滚**，避免代码-Schema 错配。

---

## 3. JPA 实体改造约定（H3，各业务片落地）

各被改实体在其业务片：
1. `extends StringIdEntity`（去掉原 `@Id @GeneratedValue(IDENTITY) Long id`，改继承基类的 `@Id String id`）。
2. Service 层 save 前赋 id：`e.setId(publicIdGenerator.generateUnique(PublicIdType.<T>, repo::existsById))`。
3. Repository 主键类型 `JpaRepository<E, Long>` → `JpaRepository<E, String>`；下游 `findById`/`@PathVariable` 等连改（B1-B4 各片）。
4. **M1 收益**（api_def/mcp，B1）：String id 在 insert 前已确定 → AAD 可一次算定 → 删「先 save 取 IDENTITY 再加密二次 save」两步、删「勿合并优化」注释、改单测。

> **🔴 范式强制自查（铁律·B2 实战血泪，供 Bu/B3/B4 多创建点套用）**：去 IDENTITY 后 `StringIdEntity` **不自动生成 id**，漏一处 `setId` = 运行时 `IdentifierGenerationException`（编译期不报、单测 mock 不暴露，只在真 DB persist 时炸）。**切片落地前，对每个被改实体逐点核**：
> - `grep -rn "new <Entity>()" src/main`：每个 `new` 后到 `save()/saveAndFlush()` 前必须有 `setId(generateUnique(...))`（含「`orElseGet(Entity::new)` 后 `if(getId()==null)`」分支、批量/种子/导入路径）。
> - `grep -rn "INSERT INTO <table>"`：每条 **native INSERT** 必须显式带 `id` 列 + 应用赋值（不能依赖已删除的 RETURNING id/IDENTITY）；唯一 native INSERT 路径用 `generateUnique + existsById 预检`（撞键直接抛 DB 冲突而非重试）。
> - **真 DB 集成测试的 fixture 同样要 setId**（`@DataJpaTest`/`@SpringBootTest` 里 `new Entity()+save` 的造数 helper）。B2 实测：PositionService/AgentService/DataTableDefService/TaskService/SalesPositionImportService/DataRecordService(native) + ~3 个集成测试 fixture 全部漏赋 id，回归时一次性暴露 19 处 `IdentifierGenerationException`。
> - 服务新增 `PublicIdGenerator` 构造参数后，**直接 `new Service(...)` 的单测构造点同步补参**（`new PublicIdGenerator()`）。

> 反面教材：`MemoryImportJob`（`@Id String` 但**未**实现 Persistable）会让 save 退化为 merge（先 SELECT 再 INSERT）。务必 `extends StringIdEntity` 或自行实现 `Persistable<String>` + isNew 标记。
> **弱审计字段（B5）**：实体侧 11 个有 `Long createdBy/updatedBy`（Agent/DataFieldDef/DataRecord/DataTableDef/Position/PositionResource/Skill/SkillFile/SkillReference/SkillResource/SkillTableRef）等审计/归属字段的类型 `Long → String`，**随 B5 同发布**——不随各实体 PK 片改（铁律 3：弱审计列解耦延后）。
> **认证链路（Bu，设计 §4.4/§1.7.3，CR 实测）**：`AppUser` extends StringIdEntity 时，**同发布**改 `SecurityUtils.requireUserId()` 及 `requireAdminUserId()` `Long→String`（级联 **126 调用点/228 声明/79 文件 + requireAdminUserId 11 处 + 30 测试文件** + 按 user_id 过滤仓储 `@Query` 绑定 `Long→String`）、JWT **`uid` claim**（非 sub）签发(JwtTokenProvider.generate)/解析(JwtAuthFilter L45-46) `Long→String`、`InternalMemoryController` 数字注入点 + 其 Python 调用方、wire `userId` int→str（N1 锁区，Java/Python 同提交）。这些是 Bu 的代码面，**与 app_user DB 切 PK 同片同回滚**；且**结构性/隔离 user_id 列必须与 app_user 同片切 VARCHAR（铁律 4）**，否则字符串 currentUserId 过滤 BIGINT 列 → 隔离破裂。全库最大扇出 + 认证核心，当独立大工作量排期。

---

## 3.5 B2 落地纪要（expert/agent/数据表链，已实施）

- **范围（最终）**：6 父表 PK→VARCHAR(20)（expert ps_ / agent ag_ / data_table_def dt_ / data_field_def df_ / data_record dr_ / scheduled_task tk_）。**app_user 整体移出 B2 → 用户切片（Bu）**（裁决：在 B2 迁 app_user 破坏运行期 user 隔离）。本片**不碰 user_id / created_by / updated_by**。
- **迁移文件**：`db/migration/V47__expert_chain_pk_to_string.java`——以 `record Parent(table, PublicIdType, List<Fk>)` 通用化驱动 6 父表的三段式；`lookupFkConstraintNames`（pg_constraint join pg_attribute 按列名动态核取**内联 REFERENCES 的 PG 默认约束名**）+ `columnExists`（information_schema，观测/弃用列缺失时优雅跳过）。
- **观测/弃用 DB-FK 全切**：message/memory_item/expert_metric_daily/expert_skill/scheduled_task(弃用)/**llm_call_log** 的 expert_id（llm_call_log 为补充发现的观测链：TraceContext.positionId→LlmCallLog.positionId）。
- **expert wire 同片（方案甲，N1 锁区）**：`OrchestrateRequest.EffectiveExpertPayload @JsonProperty("expertId")` 值 Long→String（key 不变）；运行期 EffectivePositionView/PositionConfigView/PositionRouter positionId Long→String；Python `contracts.py` EffectiveExpert.expertId int→str（仅声明字段，无 Python 逻辑消费，纯透传）。**⚠ Java↔Python wire 需 QA 真机起 orchestrator 验 e2e（自动套件不含 Python）。**
- **混合唯一索引结论（已 H2 PG 实测）**：`(user_id BIGINT, expert_id VARCHAR)` 异类型部分唯一索引 **PG 允许原地重建**（唯一索引对列类型无同型要求）；uk_ueo_user_expert_active / uk_uso_base_active 随 expert_id 切换重建、user_id 维持 BIGINT，**无需拆分/延后**。验证见 `ExpertChainPkMigrationTest.mixedTypePartialUniqueIndex_*`。uk_ueb_user_active 仅 (user_id) 不含 expert_id，免重建。
- **迁移逻辑测试**：`src/test/.../position/migration/ExpertChainPkMigrationTest.java`（H2 PG 模式，阶段A/B/C + 三道门禁 + 混合索引，逐段同构 V47；脚本本体真 PG 验）。
- **遗留 MIGRATION-REVIEW**：历史「销售专家 id==5」数字门在字符串 id 下失效——① `IntentClassifyProperties.SkillSelect.positionIds` 默认 `List.of(5L)`→`List.of()`（灰度需按新 ps_* 配）；② `SalesPositionImportService` idIs5 恒 false，建议改 code+名称含「销售」为身份门。

---

## 3.6 Bu 落地纪要（用户切片 app_user + 隔离 user_id，已实施）

- **范围**：`app_user.id` BIGINT→VARCHAR(20)（`usr_` 前缀，extends StringIdEntity）+ **13 个隔离 user_id/uid/owner_user_id 列**同片切 VARCHAR（铁律 4）。迁移文件 `db/migration/V49__app_user_pk_to_string.java`。
- **隔离列清单（13）**：真 DB FK（7）user_role/user_expert_binding/user_expert_override/user_skill_override/session/personal_doc/scheduled_task 的 user_id；逻辑 FK（6）memory_item.user_id、memory_extract_cursor.user_id、user_tool_favorite.user_id、memory_import_job.user_id、task_execution.owner_user_id、user_biz_credential.user_id。
  - **★实施期补漏（初版 FK 清单遗漏）**：`data_record.uid`——TABLE 行数据「归属用户」隔离核心（V18 注释：运行时由 ToolTraceContext.userId 注入、查询恒带 uid 谓词、越权核心防线）。命名为 `uid` 非 `user_id` 故清单漏，按铁律 4 必与 app_user 同片切（否则字符串 currentUserId 过滤 BIGINT uid → TABLE 行隔离破裂）。**范式教训：隔离列穷举不能只 grep `user_id`，须含 `uid`/`owner_user_id` 等别名 + 语义（运行时按 currentUser 过滤）判定。**
- **复合主键处理**：`user_role` 是复合 PK `(user_id, role_id)`（非单列代理 PK）——切 user_id 需 DROP 复合 PK → 切列 → 重建复合 PK（单列代理 PK 表无此步）。
- **跨表同切硬约束（设计 §4.4.2-2）**：`session.user_id` ⇔ `memory_extract_cursor.user_id`（有 `ON c.user_id=s.user_id` JOIN + `ON CONFLICT(user_id, session_id)`）两列必同窗口同切；V49 阶段C 后**显式断言两列均 `character varying`**（`assertCrossTableSameSlice`），否则抛异常回滚。
- **混合唯一索引**：9 个含 user_id 的唯一索引（多为 user_id VARCHAR + session_id/biz_system_id/role_id BIGINT / expert_id VARCHAR 混合）——切列前 DROP、切列后按新 VARCHAR 列重建（PG 允许异类型唯一索引，B2 已验）。修正 B2 遗留：`idx_data_record_table_uid` 因 RENAME 跟到了 `table_def_id_old`，V49 重建到当前 `table_def_id`。
- **认证链路（最高风险，代码与 DB 同发布）**：`SecurityUtils.requireUserId()/requireAdminUserId()` Long→String；`AuthPrincipal.userId`→String；JWT `uid` claim 签发(`JwtTokenProvider.generate` String)/解析(`JwtAuthFilter` `get("uid", String.class)`，旧数字 uid 的 token → uid=null → 401 强制重登，零兼容层)；`InternalMemoryController @RequestParam userId` Long→String；~128 调用点 / 12 隔离实体 / 全部按 user_id 过滤仓储 `@Param` 同发布。
- **userId wire（N1 锁区，Java+Python 同提交）**：Java `OrchestrateRequest.UserContext.userId` + `internal/dto/ToolExecuteRequest.userId` + `OrchestrationRun.userId` + 6 memory DTO → String；Python `contracts.py` UserContext/ToolExecuteRequest userId int→str，`nodes.py:547` 去 `_to_int` 透传字符串（否则 usr_ 串经 _to_int → None → 工具执行回调丢用户归属 → 隔离破裂）。
- **凭证片护栏（①冻结，设计 §8.0u③/§5.5）**：`user_biz_credential` **只切 user_id FK 列、密文/AAD 不动**（重加密下沉 B4）。`CredentialCryptoService.encrypt/decrypt` 保持 `Long userId` AAD 参数不变；`UserBizCredentialService.hostCredential` **写路径冻结**（迁移窗口抛 BusinessException，不再调 encrypt），读路径（listStatus/status 走 user_id 过滤）正常。B4 重加密后解冻。
- **B5 边界统一处理（MIGRATION-REVIEW(B5)）**：`created_by`/`updated_by`/`operatorId`（45 控制器站点）+ `reviewer_id`/`submitter_id` + `audit_log.user_id` 均为 Long/B5——current-user 已 String、usr_ 非数字不可 parseLong，故本片这些**审计/归属 Long 列一律传 `null`**（B5 收口时按 id_map 重映射恢复归属 + 用户名解析）。`PlatformPublicationService/ReviewAggregationService` 的用户名解析（loadNames）本片返回空 Map、兜底显示「用户#{id}」。data_record INSERT 去掉 created_by/updated_by 列（留 NULL）。
- **前端**：userId 在前端为**不透明值**（无 Number()/parseInt/=== 数字比较），故 userId 字符串化**前端零代码改动**；仅 `companion.js` localStorage 昵称键值由数字变 usr_ 串（展示态、自愈，不阻断）。
- **迁移逻辑测试**：`src/test/.../auth/migration/AppUserPkMigrationTest.java`（H2 PG，阶段A/B/C + 三门禁 + P0-1 DROP NOT NULL + 跨表同切 + 隔离红线断言）。
- **QA 真机待办（无法自动全验，验收硬门槛）**：① 切换前已有数据的**真实老用户**登录 → memory/personal_doc/session/memory_import_job/scheduled_task/TABLE 行/user_biz_credential status **全部可见**（隔离红线，任一查不到即回滚）；② 旧 token 强制重登生效；③ Java↔Python userId wire 办事链路 e2e（工具执行回调用户归属正确）；④ 凭证托管写入已冻结提示正确、读/status 可见。

---

## 4. 待各片复核项（迁移前实测，设计「待核实项」）

- 现网最大技能树深度（path VARCHAR(512) base58 后 ~36 层上限；逼近则扩 1024）—— B3。
- UI 是否依赖 path 字典序展示顺序 —— B3 CR 复核。
- 断 DB FK 约束前查 `information_schema`/`pg_constraint` 拿运行库真实约束名（C1）—— 各片。
- 部分唯一索引按运行库实际逐条核名重建（M3）—— 各片。
- 凭证片时序锁定：先切三表 PK、后同窗口重加密（M2）—— B4。
- 弱审计列穷举核名（按运行库实际逐列核 `created_by`/`updated_by`/逻辑归属 user_id 的表与列名）+ "无 map 归属值（已删/历史用户）保留旧串 or 置 NULL"约定定稿（M4 门禁中漏映射容忍口径）—— B5。
- 各实体 id_map 的保留期：必须覆盖到 B5 重映射用完，清理片不得早于 B5 —— 各片 + B5。`id_map_app_user`（Bu 产）还供 B4 重加密 user_biz_credential，**须保留至 B5 用完** —— Bu + B4 + B5。
- **Bu 专项核（CR 已大部定档，迁移前复核运行库实际）**：① →app_user 引用列定档已 CR 逐列核（隔离过滤→Bu：含 memory_import_job.user_id；纯归属→B5：skill_publication.submitter/reviewer、tool_market_listing.submitter_id/reviewer_id、audit_log.user_id）——迁移前按运行库实际列名复核；② `requireUserId`(126 调用点/228 声明/79 文件)+`requireAdminUserId`(11)+JWT `uid` 签发解析(JwtAuthFilter/JwtTokenProvider)+InternalMemoryController 注入点+30 测试文件逐一核改类型；③ 含 user_id 的部分唯一索引（`uk_ueo_user_expert_active` 等）随片重建；④ **memory_extract_cursor.user_id 与 session.user_id 两列同窗口同切断言**（JOIN/ON CONFLICT 硬约束）；⑤ Bu→B4 窗口护栏=冻结凭证写（shim 仅备选）；⑥ 隔离回归用真实存量用户（非新建）验历史 memory/session + user_biz_credential status 全可见 —— Bu。
