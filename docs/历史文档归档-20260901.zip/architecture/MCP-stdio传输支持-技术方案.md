# MCP stdio 传输真实支持 + 连接配置按 transport 分流 — 技术方案

> 状态：**门禁已过 · 编码前最终定稿（可放行编码）**。设计先行门禁已通过；Q1-Q5 已拍板、AI 专家 10 项编码前必修已并入正文（详见 §8 决议表、§2/§3 各小节、§9 改动清单）。本文仍只改设计文档，落地阶段才动代码/迁移。
> 作者：架构师　|　目标读者：后端 / 前端 / AI 专家 / QA
> 适用范围：管理后台「系统配置员 → 连接器 → MCP」编辑器**真实支持 stdio 传输**（现状仅 streamable-http）。
>
> **拍板结论速览（编码前必读）**：
> - **Q1 命令白名单**：预留配置位 `mcp.stdio.allowed-commands`，**默认空 = 不限制**；非空时 spawn 前比对 command **基名（basename）**，不在单内则拒绝（CONN_FAILED）。（§3.2a）
> - **Q2 env 对 http**：Environment 字段**仅 stdio 显示/存储**；streamable-http 不显 env、后端忽略 env。（§1.2 / §6）
> - **Q3 进程生命周期**：长驻复用（按 code 挂 `McpSessionManager`）+ `mcp.stdio.max-processes` **默认 8 可配**，超限拒新建返回 CONN_FAILED；超时 + `destroyForcibly` + `@PreDestroy` 清理。（§2.2 / §3.4）
> - **Q4 env 加密**：**全部 value 加密**（非部分），出参一律 masked。（§1.3）
> - **Q5 加密复用**：方案 A（复用 `CredentialCryptoService`），域常量第二参取专用不碰撞值 **`MCP_ENV_AAD_DOMAIN = -1L`**，并在 `CredentialCryptoService` 旁注释登记该域被 MCP env 占用。（§1.3）

---

## 0. 现状基线核对（file:line）

下列为本设计的事实基线，落地时以代码现状为准（行号为撰写时点）。

| 关注点 | 文件 | 关键事实 |
|---|---|---|
| 实体仅 transport/endpoint | `backend/src/main/java/com/aiassistant/tooldef/entity/McpDef.java:37-39` | 仅 `transport`/`endpoint`；**无 command/args/env**。`tools_cache`(L53-55)、`auth_config`(L49-51) 为 jsonb。`@SQLRestriction("deleted = false")`(L24)。 |
| transport SPI 预留 stdio 不实做 | `backend/.../tooldef/mcp/transport/McpTransport.java:12-13` | 注释明写「本轮仅实现 streamable-http；**stdio SPI 预留不实做**」。SPI 方法：`transport()`(L18)、`initialize`(L21)、`callTool`(L24)、`listTools`(L27)、`close`(L30，默认空实现)。 |
| 唯一实现（stdio 范式参照） | `backend/.../tooldef/mcp/transport/StreamableHttpTransport.java` | `@Component`(L33)、`transport()` 返回常量(L37,L52)、`initialize` 走握手 1(initialize)+握手 2(notifications/initialized)(L57-83)、`callTool`(L86)、`listTools`(L95)；异常归一 `classify`→`McpTransportException`(L192)，message 不透 endpoint(L31)。 |
| 执行器 stdio 短路为 unsupported | `backend/.../tooldef/mcp/McpToolExecutor.java:87-89` | `if (!"streamable-http".equals(def.getTransport())) return unsupported(t0);` → `unsupported`(L162) 返回 `success=true` + `MCP_TRANSPORT_UNSUPPORTED`（不计 call_count，§4.2 短路区）。**本设计要把它改为真实路由**。错误二分：未接入 `notConnected`(L154) success=true；真实失败 `classify`(L170) success=false。已发起区计数 `recordSuccess`/`recordFailure`(L114,L121)。 |
| 会话管理（按 code 复用 + 空闲清理） | `backend/.../tooldef/mcp/McpSessionManager.java` | `getOrCreate`(L63) 按 code 分段锁 + 双检 + transport 路由 initialize；`invalidate`(L96) 调 `close`；`cleanup`(L106) 按 `idleMinutes` 空闲清理；`@PreDestroy destroy`(L123) 全关。**stdio 进程生命周期可直接挂这套机制**。 |
| 会话对象 | `backend/.../tooldef/mcp/transport/McpSession.java` | 字段：mcpCode/endpoint/transport/authConfig + volatile sessionId/protocolVersion/serverName/serverVersion/lastUsedAt。**无进程句柄字段**——stdio 需扩展（见 §2.2）。 |
| 异常分类 | `backend/.../tooldef/mcp/transport/McpTransportException.java:20-31` | `ErrorKind`：CONN_FAILED / TIMEOUT / TOOL_NOT_FOUND / RPC_ERROR / PROTOCOL_ERROR。message 仅日志、不透出(L7-8)。 |
| JSON-RPC 报文 | `backend/.../tooldef/mcp/McpRpc.java` | `initializeRequest`(L40)/`initializedNotification`(L49)/`callToolRequest`(L58)/`listToolsRequest`(L66)；`extractJsonBody`(L90) 兼容 SSE/JSON；`requireResult`(L128) 错误码二分。**stdio 可直接复用报文构造 + requireResult**，仅自管帧分隔（见 §2.3）。 |
| 注册侧服务 | `backend/.../tooldef/service/AdminMcpService.java` | `TRANSPORTS = List.of("stdio","streamable-http")`(L43)；`validateTransport`(L268) 已含 stdio；`apply`(L187) 落库——**当前不落 command/args/env**；`create`(L121)/`update`(L156)。 |
| 检活/探测 | `backend/.../tooldef/mcp/McpProvisionService.java` | `TRANSPORT_HTTP` 常量(L40)；`testConnection`(L67)/`fetchToolsForExisting`(L92)/`fetchToolsForDraft`(L123) **均以 `!TRANSPORT_HTTP.equals` 短路成「该接入方式暂未支持」**(L70,L95,L125)。`toProbeDef`(L165) 仅 set transport/endpoint/auth。 |
| 巡检 | `backend/.../tooldef/mcp/McpHealthScheduled.java:57-59` | `if (!TRANSPORT_HTTP.equals(...)) continue;`——stdio 不巡检。默认 `mcp.health.enabled=false`。 |
| 配置 | `backend/.../tooldef/mcp/McpProperties.java` | 前缀 `mcp`：enabled(L18)/connectTimeoutMs(L21)/callTimeoutMs(L24)/Result.maxChars(L80)/Session(L92)/Health(L117)/auth 别名映射(L31)。**无 stdio 段**。 |
| 鉴权解析 | `backend/.../tooldef/mcp/McpAuthResolver.java` | `resolveHeaders`(L51) 按别名引用解析 HTTP 头（bearer/header/none）；密钥来源 `mcp.auth.<alias>`/环境变量(L93-98)，DB/日志只见别名。**env 注入可参照此「别名引用」范式**。 |
| AES-256-GCM 加密门面 | `backend/.../bizsystem/crypto/CredentialCryptoService.java` | `encrypt(plain,userId,bizSystemId)`(L50)/`decrypt(...)`(L66)；密文格式 `keyAlias:base64(iv):base64(cipher+tag)`(L22)；**AAD = userId\|bizSystemId**(L92)——绑定用户/业务系统防挪用。 |
| DTO | `McpDefRequest.java`(无 command/args/env)、`McpDefDetailVO.java`(无)、`McpDefListItem.java`(无)、`McpTestConnRequest.java`(仅 transport/endpoint/auth) | additive 扩展见 §5。 |
| 前端编辑器 | `frontend/src/components/admin/McpEditor.vue` | form 字段 code/name/description/transport/endpoint/status(L36-44)；transport 下拉(L372-376)；endpoint 输入「streamable-http 必填」(L416)；buildPayload(L270)/buildProbePayload(L173)；MCP_TRANSPORTS 来源 defValidate。 |
| 前端校验 | `frontend/src/utils/defValidate.js:8,70-98` | `MCP_TRANSPORTS=['stdio','streamable-http']`；`validateMcpForm` **当前不按 transport 分流**（endpoint「可选，不做连通校验」L81）。 |
| 检活四态口径 | `backend/.../tooldef/health/ToolCheckStatus.java` | `displayStatus(status,checkStatus)`：disabled 盖过；否则取 check_status。 |
| 最新迁移 | `backend/src/main/resources/db/migration/` | **最新 = V35**（V35__connector_origin.sql）。本设计新开 **V36**（ADD COLUMN IF NOT EXISTS）。V31 已为 mcp_def 增 description/统计列（范式参照）。 |
| 部署拓扑 | `docs/_archive/test/MCP真实运行时-测试报告.md:80` | **后端 JVM 跑在宿主机 `*:8080`**；orchestrator 在 Docker；PG 在 Docker。→ **stdio `spawn` 的子进程落在宿主机**（与后端同进程空间），命令可达性取决于宿主机 PATH/可执行文件。 |

> **📌 校准标注（2026-07-17）**：上表中 `McpToolExecutor.java` 相关 file:line 基线（执行器 stdio 短路、错误二分、recordSuccess/recordFailure 调用点等）所指代码已随主版本运行时剥离，不在本仓（`ToolExecutor` 接口无任何实现类，`ToolExecutionService` 不存在）；`McpSessionManager`、transport SPI（含已实做的 `StdioTransport`/`StdioChannel`）、`McpProvisionService`、`McpHealthScheduled` 等连接器客户端与注册/检活链路仍在。详见《设计文档校准审计-20260717.md》。

> 零影响面已核对：本设计不碰 ToolPicker/SkillToolRef/TableToolCodec/`@tool`；运行时契约（`ToolExecutor`/`ToolInvocation`/`ToolResult`/编排器 act/内部 execute 端点）一行不改——stdio 只在 `McpTransport` SPI 之下新增一个实现 + 执行器去掉短路，对上层透明。

---

## 1. 字段 / 数据模型

### 1.1 新增字段（mcp_def）

| 字段 | 列类型 | 含义 | transport 条件 |
|---|---|---|---|
| `command` | `TEXT` | stdio 启动可执行命令（如 `npx`、`node`、绝对路径）。**不含参数**。 | stdio **必填**；http 不用 |
| `args` | `JSONB`（字符串数组 `["-y","@modelcontextprotocol/server-foo"]`） | stdio 启动参数，**逐项独立元素**（不是单字符串切分）。 | stdio 选填；http 不用 |
| `env_config` | `JSONB`（对象 `{"API_KEY":"<密文>","DEBUG":"1"}`） | stdio 子进程环境变量。**含密钥的值加密存储**（见 §1.3）。 | stdio 选填；http 不用 |

**args 存法决策：`JSONB` 字符串数组（非 `text[]`、非空格切分单字符串）。**
- 理由 1（避免命令注入面）：逐元素数组直接喂 `ProcessBuilder(List<String>)`，**不经 shell**，从根上杜绝「`-y; rm -rf /`」这类 shell 注入（详见 §3）。若存单字符串再切分，必须自己做引号/转义解析，风险高且易错。
- 理由 2（与项目范式一致）：`tools_cache`/`auth_config` 已是 jsonb（实体用 `@JdbcTypeCode(SqlTypes.JSON)`，McpDef.java:49-55），数组用 jsonb 同源、Hibernate 映射成熟，比 `text[]` 跨库/映射更省事。
- 理由 3：前端 Environment / args 编辑天然是「多行/多项」结构，jsonb 数组/对象与之同构。

**env 存法决策：`JSONB` 对象（KEY → VALUE）。** 每个 value 独立加密（见 §1.3），KEY 明文（KEY 名本身不是秘密，且需展示）。

### 1.2 transport 取值口径

- 合法值：`streamable-http` | `stdio`（与 `AdminMcpService.TRANSPORTS` L43、前端 `MCP_TRANSPORTS` 一致，无需改）。
- **条件必填校验**（后端 `validateTransport` 之后新增 `validateTransportFields`）：
  - `streamable-http` → `endpoint` 必填（迁移现有「endpoint 必填」隐含口径到显式校验；注：现状 create 不强校 endpoint，仅在 provision 时校，本设计在 create/update 即按 transport 强校，见 §5.3）。
  - `stdio` → `command` 必填（`@NotBlank` 等价的服务端校验；args/env 选填）。
  - 互斥：**streamable-http 不显示也不存储 env（Q2 拍板）**，后端对 http 一律忽略 command/args/env（落库置空）；stdio 配了 endpoint 落库置空。

### 1.3 env 脱敏存储方案（复用 AES-256-GCM · Q4/Q5 拍板）

**采用方案 A（拍板）：复用项目既有 `CredentialCryptoService`（AES-256-GCM）加密 env 的 value，不新建加密门面。**

- 现有 `CredentialCryptoService.encrypt(plain, userId, bizSystemId)` 的 AAD = `userId|bizSystemId`（CredentialCryptoService.java:92），绑定「用户的业务系统凭据」，语义 per-user。
- MCP env 是**平台级连接器配置**（McpDef.origin 默认 PLATFORM），不归属 end-user，归属的是 `mcp_def` 这条记录本身。
- **AAD 绑定（Q5 拍板）**：调用 `encrypt(value, mcpId, MCP_ENV_AAD_DOMAIN)`，AAD = `mcpId | MCP_ENV_AAD_DOMAIN`。其中：
  - 第一参 = **真实 mcpId**（绑定到具体连接器记录，防「把 A 的密文挪到 B」）。
  - 第二参 = **域常量 `MCP_ENV_AAD_DOMAIN = -1L`**（专用不碰撞值）——业务系统凭据的 `bizSystemId` 恒为正数主键，取 `-1L` 与任何真实 `bizSystemId` 不可能碰撞，杜绝跨域（MCP env ↔ 业务系统凭据）AAD 重合导致的误解。
  - **登记要求**：在 `CredentialCryptoService` 旁（类注释或同包常量处）**注释登记 `-1L` 这个 bizSystemId 域已被「MCP env」占用**，防后续他人复用该值造成 AAD 碰撞。
- **新建场景 mcpId 尚未生成**：先 `save` 取得自增 id，再以该 id 为 AAD 加密 env 后二次 `save`（或同事务内拿到生成 id 再 set 后 flush）。落地由后端选实现细节，**但加/解密两侧的 mcpId 必须同源**（见 §3 必修 8）。

> **📌 校准标注（2026-07-17）**：全线 ID 字符串化（V45–V53）后，`mcp_def` 主键为应用层预生成的 `mc_` 前缀字符串句柄，insert 前 id 已知——「先 save 取自增 id 再二次 save 加密 env」已无必要，现实现为加密后一步入库；AAD 域常量现用 String 版 `CredentialCryptoService.MCP_ENV_AAD_DOMAIN_STR = "-1"`。详见《设计文档校准审计-20260717.md》。

**存储形态**（env_config jsonb，value = `CredentialCryptoService` 密文格式 `keyAlias:base64(iv):base64(cipher+tag)`）：
```json
{ "API_KEY": "keyAlias:base64(iv):base64(cipher+tag)", "DEBUG": "keyAlias:base64(iv):base64(cipher+tag)" }
```
- **全部 value 一律加密（Q4 拍板）**（含 `DEBUG=1` 这类非密钥）——理由：① 实现无歧义；② 配置者无法可靠区分哪些是密钥，统一加密最安全；③ env value 数量少、加解密开销可忽略。**不做「标记式部分加密」**。
- 出参一律 `masked`（见 §5），**绝不回明文也不回密文**。

---

## 2. stdio 传输实现（实做 McpTransport 的 stdio SPI）

### 2.0 与 streamable-http 的根本差异

| 维度 | streamable-http | stdio |
|---|---|---|
| 连接 | 无状态，每次 POST 独立（可带 Mcp-Session-Id） | **有状态长进程**：一个子进程 = 一个会话，stdin/stdout 是该进程独占管道 |
| 会话载体 | `Mcp-Session-Id` 头（可选） | **OS 进程 + stdin/stdout 流**（`McpSession` 需持进程句柄） |
| 失效 | 调用异常 → invalidate，下次重 POST | 进程退出/管道断 → invalidate + **必须 destroy 进程**，下次重 spawn |
| 并发 | RestClient 天然并发安全 | **单进程 stdin/stdout 串行**：同一会话的 RPC 必须串行（一问一答），需 per-session 锁 |
| 鉴权 | 每次请求带 header（McpAuthResolver） | spawn 时一次性注入 env（不是 per-call header） |
| 资源风险 | 网络层 | **宿主机进程**（CPU/内存/句柄/僵尸进程，§3 重点） |

### 2.1 新增类：`StdioTransport implements McpTransport`

`backend/.../tooldef/mcp/transport/StdioTransport.java`（`@Component`，与 StreamableHttpTransport 同包同范式）。

- `transport()` → `"stdio"`。
- 注入 `McpRpc`（复用报文构造/解析）、`McpProperties`（超时/资源限制）、env 解密门面（§1.3）、`JsonUtil`。
- **不注入 McpAuthResolver**（stdio 鉴权走 env 注入，不走 HTTP 头）。

### 2.2 子进程生命周期

**进程模型决策（Q3 拍板）：每个 MCP（按 code）维持一个长驻子进程，复用握手会话（与 streamable-http 的会话复用对齐），空闲由 `McpSessionManager.cleanup` 回收。**

- 理由：MCP stdio server 的 initialize 握手有成本，每次调用都 spawn+握手会拖慢且压宿主机；长驻复用与现有 `McpSessionManager`（按 code 缓存 + 空闲清理 + PreDestroy 全关）天然契合，零新增调度。
- **最大常驻进程数 `mcp.stdio.max-processes` 默认 8（可配）**：spawn 前检查当前 stdio 会话缓存数，达上限则**拒绝新建并返回 `McpTransportException(CONN_FAILED)`**（不挤掉已有会话、不无限增长）。计数口径 = `McpSessionManager` 缓存中 transport=stdio 的会话数。
- 不取「每次新起进程」（更隔离但慢、短时高频会 spawn 风暴）。

**`McpSession` 扩展（stdio 专用，可空）**：新增封装 `StdioChannel`（持 `Process` + stdin writer + stdout reader + stderr drain 线程句柄 + **一把 channel 读写锁**）。http 路径该字段恒空。`close(McpSession)` 对 stdio 实现：停 stderr drain 线程 → 关流 → `process.destroy()` → 兜底超时 `destroyForcibly()`（覆盖 `McpTransport.close` 默认空实现）。

> **必修 3（锁与销毁解耦，防死锁）**：channel 的读写锁**只在 `callTool`/`listTools` 的短临界区持有**（一次「写请求→读响应」）。`close`/`destroy` **绝不重入同一把锁**——否则「超时线程要杀进程拿锁」与「另一线程正阻塞在 `readLine` 持锁」会互等死锁。销毁靠直接 `destroyForcibly()`（OS 关管道）让阻塞的 `readLine` 抛异常自行退出临界区释放锁，而非等锁。

**spawn（在 initialize 内）**：

1. 用 `ProcessBuilder(command + args)`（**List 形态，不经 shell**），`redirectErrorStream(false)`（stderr 单独读，不混入 stdout JSON-RPC）。
2. **命令白名单校验（Q1，必修前置）**：若 `mcp.stdio.allowed-commands` **非空**，spawn 前比对 command 的**基名（basename）**是否在单内；不在则 `McpTransportException(CONN_FAILED)`，不 spawn。**默认空 = 不限制**（§3.2a）。
3. `environment()`：**先 `pb.environment().clear()`**，再按**继承白名单**（必修 6，下文）放入继承变量，最后注入解密后的 env value（配置的 env 覆盖继承同名项）。
4. `pb.directory(...)`：限定工作目录（`mcp.stdio.work-dir`，默认临时目录），不在后端工作目录下跑。
5. `pb.start()`；**必修 5（stderr drain 线程）**：spawn 成功后**立即为该进程启一个常驻 drain 线程**持续读 stderr（防 stderr 缓冲写满反压阻塞子进程），仅 `log.debug`/尾部 `warn` 落服务端日志；进程销毁时停该线程。
6. **必修 7（spawn 失败脱敏）**：`pb.start()` 抛 `IOException`（命令不存在常含 command 路径）→ catch 后仅以固定文案 `"MCP stdio 启动失败"` 构造 `McpTransportException(CONN_FAILED)`，**cause 仅落服务端日志，绝不进对外 message / rpcMessage**。

**继承环境最小白名单（必修 6）**：`pb.environment().clear()` 后只继承 `PATH`/`HOME`/`LANG`/`TMPDIR`（可经 `mcp.stdio.inherit-env` 配置覆盖）。

- 必须继承 `PATH` 等：否则 `npx`/`node` 找不到可执行文件，stdio 全失败。
- **白名单绝不含 `*_SECRET`/`*_PASSWORD`/`*_TOKEN`/`*_KEY` 等**：否则后端 JVM 的 `DB_PASSWORD`/`JWT_SECRET` 会泄给子进程 `process.env`。

**握手（spawn 后，必修 4：失败自销毁）**：整个握手放在 `initialize` 内的 **`try { ... } catch/finally`**——握手任一步失败（超时/解析失败/IO）**在 `initialize` 内即 `destroyForcibly()` 自销毁进程**，不依赖 `McpSessionManager` 缓存兜底（此刻进程尚未 put 进 cache，cache 无从清理）。

1. 写 `McpRpc.initializeRequest()` → stdin（换行分隔，见 §2.3）→ flush。
2. 读一行 → `McpRpc.extractJsonBody` + `requireResult` → `applyServerInfo`（protocolVersion/serverInfo）。
3. 写 `McpRpc.initializedNotification()` → stdin（通知无响应，失败不致命，照 StreamableHttpTransport.java:76-81 容错）。
4. 整个握手受 `connectTimeoutMs` 约束：spawn + 首条响应未在超时内到达 → `destroyForcibly()` + `McpTransportException(TIMEOUT)`。

### 2.3 JSON-RPC over stdin/stdout 帧

- **帧格式：行分隔 JSON（NDJSON / `Content-Length` 二选一）。** MCP stdio 规范用「换行分隔的单行 JSON」（每条 JSON-RPC 消息一行，不含内嵌换行）。**采用行分隔**：写消息时 `writer.write(jsonString); writer.write('\n'); writer.flush();` 读时 `reader.readLine()`。
  - `McpRpc` 输出的是 `Map`，落地需 `JsonUtil.toJson(map)` 序列化为单行（Jackson 默认不带换行，安全）。
  - 读到的行交 `McpRpc.extractJsonBody(line, null)`（SSE 分支不会命中，按纯 JSON 解析）+ `requireResult`，**完全复用现有解析/错误二分**。
- **单响应字节上限（必修 1，stdio 独有 OOM 风险）**：`readLine` 侧设 `mcp.stdio.max-response-bytes` 上限——单条响应（单行）累计字节超限即 **`McpTransportException(PROTOCOL_ERROR)` + 销毁进程**。http 走 RestClient 有框架级缓冲约束，stdio 自管流没有，恶意/异常 server 可一行打爆堆内存，故必须自设上限（用带计数的逐字符/分块读，或自实现限长 readLine，不可无界 `BufferedReader.readLine`）。
- **请求-响应配对**：stdio 是串行管道，同一会话**必须持 per-session channel 锁**，一次只发一条请求、读一条响应，按 id 朴素配对（本轮单飞，不做并发多路复用）。`McpSessionManager.getOrCreate` 已是 per-code 锁建会话，**调用期（callTool）也需 per-session channel 串行锁**——在 `StdioTransport.callTool/listTools` 内对该 session 的 channel 加锁（短临界区，见 §2.2 必修 3）。
- stderr：由常驻 drain 线程读（§2.2 必修 5），**仅 `log.debug`/`warn` 落服务端日志**（可能含上游报错细节，绝不透出给模型）。
- **跳过非 JSON 行**：有些 server 会往 stdout 打印 banner。读到无法解析为 JSON-RPC 的行 → 记 debug 跳过，继续读下一行直到拿到匹配 id 的响应或超时（防 banner 污染）；跳过累计也受 max-response-bytes/超时双重约束，不无限读。

### 2.4 callTool / listTools / 错误与超时映射

- `callTool(s, name, args, callTimeoutMs)`：持 channel 锁 → 写 `McpRpc.callToolRequest` → 在 `callTimeoutMs` 内限长读响应（读超时见下）→ `extractJsonBody` + `requireResult` 返回 result 节点（与 http 实现签名/返回完全一致，executor 无感）。
- `listTools` 同理（注册侧拉取用）。
- **读超时解除手段（必修 2）**：`Process` 的 stdout 流是**阻塞 IO，`Future.cancel(true)`/线程 interrupt 无法中断阻塞中的 `readLine`**（JVM 阻塞 IO 不可中断）。超时的唯一可靠解除手段 = **`process.destroyForcibly()` 关闭管道**，使阻塞的 `readLine` 抛 IO 异常退出。实现：读跑在带超时的 `Future`（`CompletableFuture.get(callTimeoutMs)`）做**计时**，超时后**先 `destroyForcibly()`** 再走 TIMEOUT 异常路径——绝不只 `future.cancel` 就以为线程会退出（会泄漏挂死线程 + 僵尸进程）。
- 异常归一（照 StreamableHttpTransport.classify 范式）：
  - spawn 失败 / 进程已死 / 管道 IOException → `CONN_FAILED`
  - 读/握手超时 → `TIMEOUT`（已 `destroyForcibly`）
  - 单响应超 `max-response-bytes` / JSON 解析失败 / 协议不符 → `PROTOCOL_ERROR`（已销毁进程）
  - JSON-RPC error -32601 → `TOOL_NOT_FOUND`；其余 error → `RPC_ERROR`（均由 `McpRpc.requireResult` 现成抛出）
  - **message 仅落日志，不含 command/args/env/堆栈**（照 McpTransportException 铁律；spawn IOException 见 §2.2 必修 7 固定文案）。
- **可观测（必修 10）**：进程 spawn（pid）/退出码/超时销毁均记日志（**脱敏，不含 env 值**）；`close` 时附 stderr 尾部摘要 `warn` 便于排障。

---

## 3. 安全面（本设计重点 · 门禁核心）

> 在宿主机 `spawn` 任意进程是本设计**最高风险点**。后端 JVM 跑在宿主 8080（非容器），子进程与后端同权限运行在宿主机上。下列区分「**必做防护**」与「**需用户拍板的安全口径**」。

### 3.1 命令注入防护（必做，已由设计消除主要面）

- **不经 shell**：`ProcessBuilder(List<String>)` 直接 exec，args 逐元素传递，**无 `/bin/sh -c`**——`;`、`|`、`&&`、`$()`、反引号等 shell 元字符**不会被解释**，从根上杜绝命令拼接注入。这是 args 用「数组」而非「单字符串」的核心安全理由。
- 禁止任何「把 command/args 拼成字符串再交 shell」的实现。

### 3.2 谁能配（权限边界，已有约束）

- 仅 **SYS_CONFIG（系统配置员）** 能进「连接器 → MCP」编辑器（沿用现有 `/fde/connectors/mcp` 鉴权，V30 role_sysconfig）。普通用户/FDE 无法配 stdio command——**配置权 = 在宿主机执行任意命令的权**，必须收口在受信角色。
- 全程审计：create/update 记 `MCP_CREATE`/`MCP_UPDATE`（已有 `auditLog.record`，AdminMcpService.java:150,164），command/args 进审计 detail（env 仅记 KEY 名不记值）。

### 3.2a 命令白名单（Q1 拍板：预留配置位，默认不限制）

- 配置位 `mcp.stdio.allowed-commands`（List），**默认空 = 不限制**（信任受信角色 SYS_CONFIG，符合最小方案）。
- **非空时收紧**：spawn 前比对 command 的**基名（basename，即去目录后的可执行名，如 `/usr/local/bin/npx` → `npx`）**是否在单内；不在则**拒绝 spawn 并返回 `McpTransportException(CONN_FAILED)`**。
- 比基名而非全路径：兼容不同机器 PATH/安装位置差异，运维只需维护「允许哪些可执行」（如 `npx`/`node`/`uvx`），不必枚举绝对路径。
- 收紧路径已就绪：安全合规升级时把 `allowed-commands` 配上即可，无需改代码。

### 3.3 env 注入（含密钥）安全传递且不落日志（必做）

- env value 加密存储（§1.3，全 value 加密），DB 落密文，日志/审计/出参只见 KEY 名 + `masked`。
- spawn 时解密后经 `ProcessBuilder.environment()` 注入子进程（OS 级，不进命令行——**绝不把密钥拼进 args**，否则 `ps`/进程列表可见）。
- 解密明文仅在 spawn 瞬间存在于内存，不写日志、不入异常 message。
- **清空继承环境 + 最小白名单**（§2.2 必修 6）：`clear()` 后只继承 `PATH/HOME/LANG/TMPDIR`，白名单绝不含 `*_SECRET/*_PASSWORD/*_TOKEN/*_KEY`——既保证 `npx`/`node` 可达，又防后端 JVM 敏感环境变量泄给子进程。
- **AAD 同源（必修 8）**：解密用真实 mcpId；探测/草稿态须携带真实 mcpId（§7.1）；「留空保留旧值」重存仍用同一 mcpId，否则解密 GCM 标签校验失败。

### 3.4 进程资源 / 超时限制（必做 · Q3 拍板）

- 握手 `connectTimeoutMs`、调用 `callTimeoutMs` 复用现有 `McpProperties`（McpProperties.java:21,24），stdio 同样适用：超时即 `destroyForcibly()` 销毁进程，防挂死（必修 2）。
- 新增 `mcp.stdio.*` 配置段（§9）：**`max-processes` 默认 8（超限拒绝新建返回 CONN_FAILED）**、`max-response-bytes`（单响应上限，必修 1）、`work-dir`、`inherit-env`（继承白名单）、`allowed-commands`（命令白名单，默认空）、`force-destroy-timeout-ms`（destroy 兜底超时）。单进程空闲回收复用 session `idleMinutes`。
- `@PreDestroy` 全量销毁（McpSessionManager.destroy 已有 close 钩子，stdio close 实现 destroy 进程 + 停 drain 线程）——后端关停不留僵尸进程。
- stdout（调用线程读）/ stderr（常驻 drain 线程读，必修 5）持续读取，避免管道缓冲区写满导致子进程阻塞。

### 3.5 沙箱可行性（评估）

- 本机栈无内建容器化 spawn 能力（后端在宿主 JVM，不在容器内）。真正沙箱化（每个 stdio server 跑独立容器/受限用户）需新机制，超出本轮「最小方案」。
- **本设计采取的安全姿态**：不经 shell（数组 args）+ 命令配置权收口 SYS_CONFIG + 全审计 + 清空继承环境最小白名单 + 资源/超时/响应字节上限 + 命令白名单（预留，默认不限制，可收紧）。
- 命令白名单口径已由 Q1 拍板（§3.2a）：默认不限制 + 收紧路径预留。

### 3.6 可接受风险 vs 必做防护（小结）

| | 内容 |
|---|---|
| **必做防护** | 不经 shell（数组 args）；env 全 value 加密 + 出参 masked + 不落日志；spawn 清空继承环境（最小白名单，剔除 secret 类）；密钥走 env 不进命令行；超时/响应字节超限即 `destroyForcibly`，`@PreDestroy` 防僵尸；max-processes=8 上限；命令白名单预留（默认空）；权限收口 SYS_CONFIG + 全审计；stderr 仅服务端日志 + spawn IOException 脱敏。 |
| **可接受残余风险**（已知会并已被用户接受） | 白名单默认空时 SYS_CONFIG 仍可配任意宿主机命令（信任受信角色，可随时配 `allowed-commands` 收紧）；无操作系统级沙箱；子进程与后端同权限。 |

---

## 4. 执行器路由（McpToolExecutor）

- 把 `McpToolExecutor.java:87-89` 的 stdio「unsupported 短路」**删除**——改为：transport 合法（http/stdio）即进入「已发起区」，由 `sessionManager.getOrCreate` → `transports.get(def.getTransport())` 真实路由（执行器已是按 `def.getTransport()` 取 transport 的通用写法，L108，**无需再硬编码 streamable-http 分支**）。
  - 保留 `unsupported`(L162) 方法仅作防御：当 `transports.get(transport)==null`（无对应实现）时，`getOrCreate` 已抛 CONN_FAILED（McpSessionManager.java:80-82）走 classify。可保留 unsupported 作为「transport 值既不是 http 也不是 stdio」的兜底（理论不达，因 create 已校验）。
- **计数/统计**：stdio 走与 http 完全相同的「已发起区」计数路径——握手失败/调用失败 `recordFailure`（仅 call_count），成功 `recordSuccess`（call+success+耗时）。`McpUsageRecorder` 零改动。
- **检活四态对齐（stdio 的「检活」= 能否 spawn + 握手）**：
  - 立即检活 / 巡检对 stdio：`transport.initialize(def, connectTimeoutMs)` 成功（spawn + initialize 握手通）→ `conn_status=ok` / `check_status=HEALTHY`；失败 → failed / 连续失败累加至 UNHEALTHY。与 http 同口径（`ToolCheckStatus`/`displayStatus` 不变）。
  - 注意：**运行态走 `McpSessionManager` 缓存复用**（命中已驻进程不重 spawn）；**探测态（test-connection/草稿 fetch-tools）独立 spawn + `finally` `destroyForcibly`、不进缓存**（必修 9，详见 §7.1）——避免 `__probe__` 进程或临时探测污染运行缓存、占用 max-processes 名额。

---

## 5. DTO / 契约（additive · 出参脱敏）

### 5.1 `McpDefRequest`（入参）additive

新增三字段（沿用 record，jakarta validation 用自定义校验，因 NotBlank 是条件性的，放 Service 层）：
```java
String command,                 // stdio 必填（Service 校验）；http 忽略
List<String> args,              // stdio 选填；逐项独立
List<EnvItem> env               // 或 Map<String,String>：KEY=VALUE；value 明文入参，落库前加密
```
- env 入参形态建议 `List<EnvItem{key,value}>`（保序、便于前端多行映射），后端转 jsonb 对象。
- **「留空保留旧值」语义**（对齐 API 密钥范式 defValidate.js:174-177）：编辑态 env 某 value 传空 → 保留该 KEY 旧密文不覆盖；传新值 → 加密覆盖；KEY 被移除 → 删除该项。具体合并由 Service 实现（参照 AdminMcpService.apply 的 merge 思路）。

### 5.2 `McpDefDetailVO` / `McpDefListItem`（出参）additive

- Detail 新增：`String command`、`List<String> args`、`List<EnvMaskedItem{key, valueMasked}>`（**只回 KEY + 是否已配置，绝不回明文/密文**）。
- List 无需加 command/args/env（列表不展示进程细节，保持精简）。
- transport 已在两 VO 中（无需改）。

### 5.3 `AdminMcpService` 映射 + 落库

- `apply`(L187) 新增：按 transport set command/args/env（http 路径将三者置空，stdio 路径校验 command 必填）。
- `validateTransportFields`（新增，在 `validateTransport` 后调）：http→endpoint 必填；stdio→command 必填。
- env 加密：`apply` 内对每个 env value 调 §1.3 加密门面（new 场景先 save 取 id），masked 合并保留旧值。
- create/update/detail 均经此路径，三写口径统一。

> **📌 校准标注（2026-07-17）**：「new 场景先 save 取 id」已过时——ID 字符串化后 id 应用层预生成、insert 前已知，env 加密一步入库，无需两步 save（同 §1.3 校准标注）。详见《设计文档校准审计-20260717.md》。

### 5.4 `McpTestConnRequest`（探测入参）additive

- 新增 `command`/`args`/`env`（草稿态 stdio 探测用，传 id 则回退库值，照 `resolveDraft` L145 范式）。
- env 在草稿态：前端可传明文（探测用）或仅传 id 回退库内密文解密——**草稿明文不落库**（testConnection 不写库，McpProvisionService.java:67 注释）。
- **必修 8（AAD 同源）**：已存对象探测须解密库内 env 密文，**`toProbeDef` 当前不 set id（McpProvisionService.java:165-172），必须补 set 真实 mcpId**，否则解密 AAD（mcpId|-1L）对不上，GCM 标签校验失败。草稿态无 id 的纯明文 env 不涉及解密。

---

## 6. 前端条件字段方案（McpEditor.vue · 增量不重构）

> 另一会话已改完 McpEditor.vue，本设计仅给字段/校验规约；落地以那会话为准，本节为契约对齐。

### 6.1 transport 切换驱动字段显隐

- `form` 新增：`command:''`、`args:[]`（多项）、`env:[]`（`[{key,value,valueMasked}]`）。
- 现有「传输方式」下拉(McpEditor.vue:372)不变；**新增 `v-if` 条件区块**：
  - `transport==='streamable-http'` → 显示现有 Endpoint 输入(L416)，placeholder 灰色示例 `https://example.com/mcp`。
  - `transport==='stdio'` → 隐藏 Endpoint，显示：
    - **Command**（单行输入），placeholder `npx`。
    - **Arguments**（多行 / 多项，每项一个 arg），placeholder 示例 `-y @modelcontextprotocol/server-foo`（每行一个参数，前端拆成数组）。
    - **Environment**（多行 textarea，`KEY=VALUE` per line），placeholder 灰色示例 `API_KEY=secret\nDEBUG=1`。
- **保持现有设计语言**：复用 `md-sec`/`el-form label-position="top"`/Notion 令牌（var(--c-*)），不删现有字段、不动布局骨架。

### 6.2 Environment 解析 / 校验

- 多行 textarea → 按行 split → 每行首个 `=` 切 KEY/VALUE（VALUE 可含 `=`）；空行忽略；KEY 去空格。
- KEY 校验：非空、符合 env 变量名规范（建议 `^[A-Za-z_][A-Za-z0-9_]*$`），重复 KEY 报错。
- 回填编辑态：后端只回 `{key, valueMasked}`——前端展示 KEY + `••••（已配置）` 占位，value 留空；用户重填该行 = 覆盖，留空 = 保留旧值（与 API 密钥 valueMasked 范式一致）。

### 6.3 `validateMcpForm` 按 transport 分流（defValidate.js）

- 现状 endpoint「可选不校验」(L81) → 改为**按 transport 分流**：
  - http：endpoint 必填（且建议 `http(s)://` 开头，可参照 BIZ URL_RE）。
  - stdio：command 必填；args 每项非空；env 每行 KEY 合法且不重复。
- 工具清单校验(L82-96)不变。

### 6.4 env 对 streamable-http 的语义（Q2 拍板）

- http 无子进程，env 无注入对象 → **Environment 字段仅 stdio 显示（§6.1 已按此设计），http 模式不显示**；后端对 http 一律忽略 env（落库置空，§1.2）。已定，无残留。

---

## 7. 检活 / 探测对 stdio 的适配

### 7.1 `McpProvisionService`（测试连接 / 拉取工具）

- `TRANSPORT_HTTP` 单值短路(L70,L95,L125) → 改为「transport 有对应实现即放行」：`requireTransport`(L180) 已按 transports map 取实现，stdio 注册后自然命中。删除/放宽 `!TRANSPORT_HTTP.equals` 短路，改为统一走 `requireTransport`（无实现才报「暂未支持」）。
- `toProbeDef`(L165)：新增 set command/args/env（草稿态从请求取，已存从库回退）+ **set 真实 mcpId（必修 8）**，使库内 env 密文能按 AAD(mcpId|-1L) 解密。
- `testConnection`：stdio = spawn + initialize 握手 → 成功回 protocolVersion/serverName/serverVersion + latency；失败脱敏（`failReason` L275 复用，不透 command/env）。
- `fetchToolsForExisting`/`fetchToolsForDraft`：stdio = spawn + initialize + tools/list → 回填 tools_cache（合并保 bizName/requiresConfirmation，merger 不变）。

  > **📌 校准标注（2026-07-17）**：V75 起工具清单只读化——`bizName ≡ name`、`requiresConfirmation ≡ (writeClass=='WRITE')` 均为派生兼容值，merger（`McpToolsCacheMerger`）合并保留的是 FDE 标注的 `writeClass`，不再是 bizName/requiresConfirmation。详见《设计文档校准审计-20260717.md》。
- **必修 9（探测态即用即销，不进缓存）**：探测**不走 `McpSessionManager.getOrCreate`**（否则 `__probe__` / 临时进程进缓存、占 max-processes 名额、污染运行态）。探测在 `McpProvisionService` 内**直接调 `transport.initialize(probe,...)` 拿临时 session，`try { ... } finally { transport.close(session) /* destroyForcibly */ }`** 即用即销。这与 §4 运行态缓存复用不矛盾——**运行态复用，探测态独立销毁**，两条路径分开。

### 7.2 `McpHealthScheduled`（巡检）

- `!TRANSPORT_HTTP.equals(...) continue`(L57-59) → 放宽为「有 transport 实现就巡检」（stdio 含在内）。
- 巡检对 stdio = initialize 握手（spawn+握手通）→ conn_status=ok / 漂移检测同 http；失败 failed。
- 仍默认 `mcp.health.enabled=false`（保守，不动）。
- **资源**：巡检对 active stdio 起进程握手——巡检**复用 `McpSessionManager.getOrCreate`**（命中已驻进程不重 spawn），避免进程风暴；新建仍受 max-processes=8 约束。巡检默认关，启用时由运维评估进程开销。

---

## 8. 决议（Q1-Q5 已拍板）与残留风险

### 8.1 拍板结论（已并入正文，编码以此为准）

| # | 问题 | 拍板结论 | 落点 |
|---|---|---|---|
| Q1 | 命令白名单 / 可执行目录限制 | **预留配置位 `mcp.stdio.allowed-commands`，默认空 = 不限制**；非空时 spawn 前比对 command **基名**，不在单内拒绝（CONN_FAILED）。 | §3.2a / §2.2 step2 |
| Q2 | env 对 streamable-http 是否暴露 | **Environment 仅 stdio 显示/存储**；http 不显 env、后端忽略 env。 | §1.2 / §6 |
| Q3 | 进程生命周期 / 资源 | **长驻复用（按 code 挂 SessionManager）+ `mcp.stdio.max-processes` 默认 8 可配**，超限拒新建返回 CONN_FAILED；超时 + `destroyForcibly` + `@PreDestroy` 清理。 | §2.2 / §3.4 |
| Q4 | env 加密范围 | **全部 value 加密**（非部分），出参一律 masked。 | §1.3 |
| Q5 | env 加密复用 | **方案 A（复用 `CredentialCryptoService`）**，域常量第二参 = **`MCP_ENV_AAD_DOMAIN = -1L`**（专用不碰撞），在 `CredentialCryptoService` 旁注释登记该域被 MCP env 占用。 | §1.3 |

> **📌 校准标注（2026-07-17）**：Q5 拍板后随全线 ID 字符串化演进——AAD 域常量现为 String 版 `MCP_ENV_AAD_DOMAIN_STR = "-1"`（long 常量保留兼容），且 mcpId 应用层预生成后 §1.3「先 save 取 id 再二次 save 加密」两步已合并为一步入库。详见《设计文档校准审计-20260717.md》。

### 8.2 AI 专家 10 项编码前必修（已钉进 §2/§3，均细节非方案推翻）

高危 4：① 单响应字节上限 `max-response-bytes`，超限 PROTOCOL_ERROR + 销毁（§2.3）；② 超时解除靠 `destroyForcibly` 关管道使阻塞 readLine 退出，不能只 `future.cancel`（§2.4）；③ channel 锁只在 callTool 短临界区持有，close/destroy 不重入同锁防死锁（§2.2）；④ 握手中途失败在 initialize 内 try/finally 自销毁，不依赖 cache（§2.2）。
必修 6：⑤ stderr 常驻 drain 线程，spawn 起、销毁停（§2.2）；⑥ 继承环境最小白名单 `PATH/HOME/LANG/TMPDIR`，绝不含 secret 类（§2.2/§3.3）；⑦ spawn IOException 固定文案脱敏、cause 仅落日志（§2.2）；⑧ env 加解密 AAD 同源，探测态携真实 mcpId（§5.4/§7.1）；⑨ 运行态缓存复用、探测态独立 spawn + finally destroy 不进缓存（§4/§7.1）；⑩ 可观测：spawn/退出码/超时记日志（脱敏），close 时 stderr 尾部 warn（§2.4）。

### 8.3 残留风险（已知 · 落地必测，非阻塞）

| 风险 | 说明 | 处置 |
|---|---|---|
| R1 子进程僵尸/泄漏 | close/destroy/`@PreDestroy`/超时 destroyForcibly 已覆盖。 | QA 真机验证：kill 后端、调用超时、进程崩溃、max-processes 上限四场景。 |
| R2 stdout banner/日志污染 | 已设计「跳过非 JSON 行」+ max-response-bytes 双约束。 | 多种 server 实测（npx 系/python uvx 系）。 |
| R3 安全残余 | 白名单默认空时 SYS_CONFIG 可配任意命令；无 OS 沙箱；子进程同后端权限。 | 已被接受（受信角色 + 可随时配 allowed-commands 收紧）。 |

---

## 9. 落地改动清单（按文件 · 仅供实现期参照，本阶段不改）

**后端（新增）**
- `backend/.../tooldef/mcp/transport/StdioTransport.java` —— **新增**，实做 stdio SPI（§2）：spawn + 命令白名单 + 继承环境最小白名单 + 限长读 + 超时 destroyForcibly + spawn IOException 脱敏 + 可观测。
- `backend/.../tooldef/mcp/transport/StdioChannel.java` —— **新增**，封装 `Process` + stdin writer + 限长 stdout reader + stderr drain 线程 + channel 锁（锁与 destroy 解耦，§2.2 必修 3/5）。
- ~~`McpEnvCryptoService.java`~~ —— **不新建**（Q5 取方案 A，复用 `CredentialCryptoService`）。仅需在 `CredentialCryptoService` 旁注释登记 `bizSystemId = -1L` 域被 MCP env 占用（§1.3）。

**后端（改）**
- `db/migration/V36__mcp_stdio_fields.sql` —— **新增迁移**：
  ```sql
  ALTER TABLE mcp_def ADD COLUMN IF NOT EXISTS command    TEXT;
  ALTER TABLE mcp_def ADD COLUMN IF NOT EXISTS args       JSONB;
  ALTER TABLE mcp_def ADD COLUMN IF NOT EXISTS env_config JSONB;
  COMMENT ON COLUMN mcp_def.command    IS 'stdio 启动命令（不含参数）；transport=stdio 必填，http 不用';
  COMMENT ON COLUMN mcp_def.args       IS 'stdio 启动参数（jsonb 字符串数组，逐项独立，不经 shell）';
  COMMENT ON COLUMN mcp_def.env_config IS 'stdio 子进程环境变量（jsonb 对象，value 经 AES-256-GCM 加密，DB/日志/出参不见明文）';
  ```
  存量兼容：三列可空，http 行恒空，无需回填。回滚反向脚本（单独执行）：`DROP COLUMN IF EXISTS command/args/env_config`。
- `McpDef.java` —— 加 `command`/`args`/`envConfig` 字段（args/envConfig 用 `@JdbcTypeCode(SqlTypes.JSON)`）+ getter/setter。
- `McpToolExecutor.java:87-89` —— 删 stdio unsupported 短路，走真实路由（§4）。
- `McpSession.java` —— 加 stdio 进程句柄字段（transient，http 恒空）（§2.2）。
- `McpProvisionService.java:70,95,125` —— 放宽 `TRANSPORT_HTTP` 短路为 `requireTransport`；`toProbeDef` 带 command/args/env（§7.1）。
- `McpHealthScheduled.java:57-59` —— 放宽巡检 transport 短路（§7.2）。
- `McpProperties.java` —— 新增 `Stdio` 内部段：`max-processes`(默认 8)、`max-response-bytes`、`work-dir`(默认临时目录)、`inherit-env`(默认 `PATH,HOME,LANG,TMPDIR`)、`allowed-commands`(默认空=不限制)、`force-destroy-timeout-ms`；getter 负值/缺省安全兜底（沿用现有范式）（§3.4）。
- `McpDefRequest.java` / `McpDefDetailVO.java` / `McpTestConnRequest.java` —— additive command/args/env（出参 masked；McpTestConnRequest 探测态须能带真实 mcpId 用于解密，必修 8）（§5）。
- `AdminMcpService.java` —— `apply` + `validateTransportFields` + env 全 value 加密(AAD mcpId|-1L)/留空保留旧值；detail 出 masked env（§5.3）。
- `McpProvisionService.java` —— `toProbeDef` 补 set 真实 mcpId（必修 8）；探测态独立 spawn + finally destroyForcibly、不进缓存（必修 9）（§7.1）。

**前端（改 · 另一会话主导，本设计为契约对齐）**
- `frontend/src/components/admin/McpEditor.vue` —— transport 条件字段 + Environment 多行 + placeholder（§6）。
- `frontend/src/utils/defValidate.js` —— `validateMcpForm` 按 transport 分流（§6.3）。
- `frontend/src/api/admin.js` —— **additive**：createMcp/updateMcp/testMcpConn/fetchMcpToolsDraft payload 带 command/args/env（接口路径不变，仅请求体字段增量）。

**跨会话共享文件（标注）**
- `frontend/src/components/admin/McpEditor.vue`（另一会话已改完，本会话只读不动）
- `frontend/src/utils/defValidate.js`（前端校验，additive 分流）
- `frontend/src/api/admin.js`（additive，仅请求体字段）
- `McpDefRequest.java` / `McpDefDetailVO.java` / `McpTestConnRequest.java`（前后端接口契约对接面）

**零改动确认**：`ToolExecutor`/`ToolInvocation`/`ToolResult`/编排器 act/内部 execute 端点、`McpRpc`/`McpUsageRecorder`/`McpToolsCacheMerger`/`McpResultMapper`/`McpSessionManager`（仅 close 行为对 stdio 生效，接口不变）、`ToolExecutionService` 路由、ToolPicker/SkillToolRef/TableToolCodec/`@tool` —— **均不改**。`McpSessionManager` 的 getOrCreate/cleanup/destroy 机制天然承载 stdio 进程生命周期，无需改其结构。

---

## 10. 测试要点（落地阶段交 QA · 非 happy-path 全覆盖）

- stdio 正例：spawn + initialize + tools/list + tools/call 全通；会话复用（二次调用不重 spawn）。
- 失败/边界：命令不存在（CONN_FAILED，message 脱敏不含路径，必修 7）；握手中途失败进程被自销毁（必修 4）；握手超时（TIMEOUT + destroyForcibly，必修 2）；调用超时（destroyForcibly 解阻塞，无挂死线程）；进程中途崩溃（invalidate + 重 spawn）；stdout banner 污染（跳过非 JSON 行）；**单响应超 `max-response-bytes`（PROTOCOL_ERROR + 销毁，必修 1）**；JSON-RPC error（-32601 → TOOL_NOT_FOUND，其余 → RPC_ERROR）。
- 安全：args 含 shell 元字符（`;`/`$()`）不被解释（不经 shell 反例）；env 密钥不落日志/审计/出参（grep 验证）；spawn 子进程拿不到后端继承的 `*_SECRET/*_PASSWORD/*_TOKEN/*_KEY`（最小白名单验证，必修 6）；**密文换 mcpId 解密失败（AAD mcpId|-1L 防挪用）**；命令白名单非空时基名不在单内被拒（Q1）。
- 并发/死锁（必修 3）：一线程阻塞 readLine 时另一线程触发超时销毁，不互等死锁、进程被杀、阻塞线程退出。
- 资源：kill 后端无僵尸进程（含 stderr drain 线程停，必修 5）；**max-processes=8 上限触发拒绝（CONN_FAILED）**；空闲回收销毁进程。
- 探测态（必修 9）：test-connection/草稿 fetch-tools spawn 后即销、不进运行缓存、不占 max-processes 名额；已存对象探测能解密库内 env（toProbeDef 带真实 mcpId，必修 8）。
- 零回归反例：http 路径不受影响；总开关关 / 未配 / disabled → 对话正常；transport=http 配了 command/env 被忽略（不存不注入）。
- transport 分流校验：http 缺 endpoint 拒绝；stdio 缺 command 拒绝；前后端校验口径一致；http 模式前端不显 Environment 字段（Q2）。
