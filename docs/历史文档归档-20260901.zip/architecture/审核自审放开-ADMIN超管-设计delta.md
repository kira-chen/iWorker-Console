# 设计 Delta：放开 ADMIN 超管的发布审核自审限制

> 状态：用户已拍板（选②）。本文件仅为**设计 delta**，不改既有设计文档正文，不含代码。
> 作者：架构师。需配套同步的正文章节在文末「需同步章节」列出。
> 关联真相源：
> - `docs/architecture/平台级技能与发布-技术方案.md` §3.3（审核端点收紧到 ADMIN / 审查人≠作者）
> - `docs/architecture/工具市场-发布审核扩展-技术方案.md`（工具审核 §5.1 / §3.5）

---

## 1. 决策与理由

### 1.1 决策
**放开 ADMIN 超管的自审限制**：ADMIN 可以审核（approve / reject / approveTarget / rejectTarget）自己提交的发布项（平台技能发布行、工具市场 listing），不再因 `reviewer == submitter` 被 403 拒绝。

### 1.2 背景（死锁）
- 两类审核端点均为 **ADMIN-only**（`requireAdminUserId`），即 reviewer **恒为 ADMIN**。
- 当前 §3.3 四眼原则守卫 `assertReviewerNotAuthor`：`reviewerId == submitterId` → `ResultCode.FORBIDDEN`。
- 单 admin 账号场景下：admin 自己提交的平台技能/工具发布，**只有 admin 能审，但 admin 又不能审自己提交的** → 永久 PENDING_REVIEW，发布闭环死锁。

### 1.3 关键事实（设计必须点明）
> **reviewer 恒为 ADMIN ⇒ 「对 ADMIN 放开自审」在效果上等价于该守卫变为 no-op。**

因为审核端点已收紧到 ADMIN-only，reviewer 只可能是 ADMIN。所以：
- 「reviewer 含 ADMIN 角色则跳过守卫」 ≡ 「守卫永远跳过」；
- 该守卫当前**唯一实际作用**就是拦截「admin 自发自审」——而这正是本次要放开的行为。
- 因此放开后，`assertReviewerNotAuthor` 不再有任何运行时拦截作用。

### 1.4 取舍（trade-off）
- **DEMO / 单超管下**：四眼原则（审查人≠作者）让位于「可操作性」——否则单账号无法跑通发布闭环。
- **多 ADMIN 场景下**：放开同样意味着「ADMIN 可自发自审」。即便存在多个 admin，系统也不再强制由另一个 admin 来审。**用户已明确接受此弱化**。
- 四眼原则从「**强制约束**」降级为「**组织流程建议**」（建议由非提交人 admin 审核，但系统不强制）。审计日志仍完整记录 reviewer/submitter，可事后追溯（见 §3）。

---

## 2. 修改点清单（精确到方法）

### 2.1 后端 · 技能侧 — `PlatformPublicationService`
文件：`backend/src/main/java/com/aiassistant/admin/service/PlatformPublicationService.java`

守卫方法 `assertReviewerNotAuthor(List<SkillPublication>, Long)`（L571-577），被四处调用：
- `approve`（L353）
- `reject`（L382）
- `approveTarget`（L411，传 `List.of(row)`）
- `rejectTarget`（L440，传 `List.of(row)`）

**两个候选方案：**

| 方案 | 做法 | 优点 | 缺点 |
|------|------|------|------|
| **A** | 删除四处调用 + 删除 `assertReviewerNotAuthor` 方法本体 | 零冗余、零死代码；契合 reviewer 恒 ADMIN ⇒ 守卫永远 no-op 的事实 | 语义不再显式；若未来引入「非 ADMIN 审核角色」需重新加回 |
| **B** | 守卫内改为：`reviewer 含 ADMIN 角色则跳过`，否则保留原拒绝 | 语义显式；未来加非 ADMIN 审核角色时仍生效 | 在当前 ADMIN-only 前提下是**永真跳过=死代码**；需注入角色查询，增加冗余依赖 |

**推荐：方案 A（直接移除四处调用 + 删除方法本体）。**

**理由：**
1. **零冗余 / 零死代码**（契合代码洁癖）：reviewer 恒 ADMIN，方案 B 的「含 ADMIN 则跳过」在当前架构下恒为真，等价于一段永不触发拒绝的死代码，还要额外引入「查 reviewer 角色」的依赖，纯负担。
2. **方案 B 的「未来扩展性」在当前架构下是伪需求**：审核端点收紧到 ADMIN-only 是 §3.3 的明确设计。若未来真要引入「非 ADMIN 审核角色」，那是一次需要同步改 `requireAdminUserId` 行级角色门、§3.3 整节、审计模型的较大变更，届时一并把四眼守卫加回更合理，而非现在预埋一段死代码。
3. **YAGNI**：不为一个未规划、且需配套大改的场景预留代码。

> 若团队对「保留显式语义锚点」有强诉求，可在 `approve` 等方法处保留一行注释（如 `// 四眼原则已放开：reviewer 恒 ADMIN，允许 admin 自发自审，见 设计delta`）替代死代码，作为方案 A 的轻量补充。

### 2.2 后端 · 工具侧 — `MarketService.review`（保持两类一致）
文件：`backend/src/main/java/com/aiassistant/market/service/MarketService.java`

守卫方法 `assertReviewerNotAuthor(ToolMarketListing, Long)`（L471-475），单处调用于 `review`（L232）。

**同步采用方案 A**：移除 `review` 内的 `assertReviewerNotAuthor(l, reviewerId)` 调用（L232）+ 删除方法本体（L466-475）+ 删除 L230-231 处「审查人≠作者」注释。

> 理由：两类审核必须保持同范式（现状即同范式、同 FORBIDDEN 文案）。技能侧选 A，工具侧亦选 A，避免两边语义分叉。

### 2.3 前端 — `UnifiedReview.vue` 的 `friendlyError`
文件：`frontend/src/views/admin/UnifiedReview.vue`（L108-114）

现状（403 提示）：
> `无权审核：审核人不能是该项的提交者（作者自审无效），且仅管理员可审核。`

**改为去掉「作者自审无效」语义，保留「仅管理员可审核」**（对非 admin 仍准确）。建议文案：
> `无权审核：仅管理员可审核该项。`

并更新 L108 注释（`// 自审 / 非 admin → 后端 403` → `// 非 admin → 后端 403`）。

> 理由：放开后 admin 自审不再触发 403，"作者自审无效"成为陈旧/误导信息；403 此后只剩「非 ADMIN 调用审核端点」一种来源。

### 2.4 Javadoc / 设计文档标注「ADMIN 放开」
- `PlatformPublicationService` 的 `approve`/`reject`（L345-347、L374-377）Javadoc 中「审查人≠作者（reviewer≠submitter，否则拒绝）」「审查人≠作者。」表述需删除或改注为「四眼原则已放开（ADMIN 自审允许）」。
- `MarketService.review` Javadoc 同步（若残留相关描述）。
- 设计正文 §3.3 同步（见文末「需同步章节」）。

---

## 3. 影响面

### 3.1 测试调整（受影响测试类）
现有「自审被拒 403」单测在放开后会**失败**，需改为「ADMIN 自审通过 / 守卫不再拦截」或删除：

**`PlatformPublicationServiceTest`**（`backend/src/test/java/com/aiassistant/admin/service/PlatformPublicationServiceTest.java`）：
- `approve_reviewerEqualsAuthor_forbidden`（L254）
- `reject_reviewerEqualsAuthor_forbidden`（L265）
- `approveTarget_reviewerEqualsAuthor_forbidden`（L334）
- （如存在 `rejectTarget_reviewerEqualsAuthor_forbidden` 同范式用例，一并处理）
- 类头注释 L40「审查人≠作者拒绝」需删除。

**`MarketServiceTest`**（`backend/src/test/java/com/aiassistant/market/MarketServiceTest.java`）：
- `review_reviewerIsSubmitter_forbidden`（L458）
- `review_reviewerNotSubmitter_passesGuard`（L473）已无意义（守卫删除后无守卫可过），可删或并入常规审核用例。
- L456「审查人≠作者：提交人==审核人 → 拒绝自审」分组注释需删除。

**处理建议：** 选方案 A（删守卫）后，上述「forbidden」用例应**改为断言 reviewer==submitter 时审核照常成功**（状态正确流转、save 被调用、审计被记录），以正向锁定「admin 自审已放开」这一新行为，而非简单删除（保留回归保护）。

**不受影响：** ADMIN 角色门（`requireAdminUserId` / AdminRoleGuard 相关）测试与本次无关——「非 ADMIN 不能审核」的约束**不变**。

### 3.2 审计日志
- `audit_log` 现已记录 `reviewerId`（操作人）与发布行 `submitterId`，放开后会出现合法的 `reviewerId == submitterId` 记录。
- **建议（非阻塞）**：无需新增字段。可在审计查询/展示侧对 `reviewerId == submitterId` 的记录做「自审」标识（前端徽标或查询派生字段），便于合规事后审视。是否实现取决于是否有审计审视需求——DEMO 阶段可不做。

### 3.3 契约 / 调用指南文档
- 若 API 契约文档（`docs/api/`）或调用指南中写有「审核人不可自审 / reviewer≠submitter / 自审返回 403」，需删除该约束描述，改注「ADMIN 可自审」。需在落地前 grep 确认。
- 403 错误码语义收窄：审核端点的 403 此后**仅**表示「非 ADMIN 调用」，不再表示「自审」。契约的错误码说明应同步收窄。

---

## 4. 需同步章节（落地时配套，不在本 delta 内改正文）
- `docs/architecture/平台级技能与发布-技术方案.md` **§3.3**：删除/改注「同时校验 reviewer ≠ submitter（铁律：审核人≠作者，兜底）」及其 L276 锚定说明，标注「四眼原则已放开：reviewer 恒 ADMIN，允许 ADMIN 自审，理由见本 delta」。
- `docs/architecture/工具市场-发布审核扩展-技术方案.md`：工具审核处同步标注。
- 项目级 `CLAUDE.md` 的「审查人 ≠ 作者」铁律是**团队协作流程铁律（针对设计/产出 CR）**，与本次「运行时发布审核守卫」是两回事，**不改**。本 delta 仅放开后者（运行时代码守卫），前者（团队 CR 流程）继续生效。

---

## 5. 开放问题
1. **方案 A 是否保留显式注释锚点？** 推荐保留一行注释替代死代码（见 §2.1 末），请团队确认是否需要。
2. **审计自审标识（§3.2）是否在本次实现？** 倾向 DEMO 阶段不做，待合规需求明确再补。
3. **多 ADMIN 场景的组织约定**：系统不再强制四眼，是否需要在运营手册写入「建议由非提交人 admin 审核」的软约定？属流程文档范畴，非本 delta 必须项。
