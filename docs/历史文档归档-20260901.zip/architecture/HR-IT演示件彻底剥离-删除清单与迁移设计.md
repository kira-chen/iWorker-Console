# HR/IT 演示件彻底剥离 —— FK 依赖倒序删除清单与补偿迁移设计

> 类型：架构设计（**只出设计，本轮不改任何代码/迁移**） ｜ 作者：架构师 ｜ 2026-07-03
> 承接：`project_发布物边界与测试件归位.md` backlog「HR/IT 演示件彻底剥离」 + 后端 CR「须先出 FK 依赖倒序删除清单再实施」
> 前置阅读：`V1__init.sql`、`V2__sprint1.sql`、`V4__sync_sop_softconfirm.sql`、`V21__position_agent_skill.sql`、`V54__add_fk_skill_internal_logical_refs.sql`

---

## 0. 目标与本轮边界

**目标**：把 `skill/tool/mock/hr`、`skill/tool/mock/it` 六个演示假工具移 `src/test`，并从种子彻底清除 HR/IT 演示岗位/技能/SOP，使发布物出厂只含**结构性默认**（角色、demo 用户、结构表），**无演示业务数据**。

**本轮交付**：仅本设计文档（删除清单 + 迁移设计 + 验证要点 + 风险）。**不动任何代码文件、不写迁移文件、不执行任何 DDL/DML。**

---

## 1. 取证结论：对交接假设的关键修正（务必先读）

交接 brief 基于早期整数 ID 时代的认知，实读代码与真库（`aiassistant-postgres` / 库 `ai_assistant`）后，有 **6 处必须修正的事实**，直接影响删除清单正确性：

| # | brief 假设 | 真库/代码取证结论 | 影响 |
|---|-----------|------------------|------|
| M1 | expert 主键 `id=1(HR)/2(IT)/5(销售)`（整数） | **全线 ID 已改造为 VARCHAR**（V51~V53）。现库 HR=`ps_Apbh1J9tcFi`、IT=`ps_YpX3wDetMbT`、销售=`ps_jMH7oM8fUcV`。**整数 1/2/5 已不存在**。 | 删除条件**禁止**用 `expert_id IN (1,2)`，必须按业务锚点（`name` / `expert_skill→skill.code`）定位 |
| M2 | `memory_item.expert_id` 是外键，须清理 | **`memory_item` 已无 `expert_id` 列**（被后续迁移移除；现列仅 `user_id/source_session_id` 等）。 | memory_item **不在**删除链中，剔除 |
| M3 | 无提及 `llm_call_log` | `llm_call_log.expert_id` **现有真 FK → expert**（`ondel=NO ACTION, nullable`）。 | 须纳入删除链（置 NULL 或删埋点行） |
| M4 | 当前最新 V54，走 V55+ | **真库已应用到 V55**；`V56`(position_sample_task) 文件已在仓库但**尚未 apply**。 | 新补偿迁移编号 = **V57**（V56 已占号） |
| M5 | HR/IT 技能都存活 | `hr_leave`=`sk_pWiN93tgj7Z`(deleted=false)；`it_account`=`sk_LRgPCbb9ex3`(**deleted=true**，已软删)。 | 清理须覆盖软删行；且需按 code 而非 id 定位 |
| M6 | 默认绑定仅 `(demo, HR)` 一条 | 现库 dev 环境有 **21 条** user_expert_binding、**106 session/243 message** 指向 HR/IT（含 2 个用户），另有 **1 条 user_skill_override(OVERRIDE) 挂在 hr_leave** 上。 | 这是 **dev 库历史沉淀**，非发布物；发布物只关注 V1/V2/V4 种子。运行期数据处置见 §3 |

**全库外键删除动作实测**：对 expert / skill / agent 的所有 FK **全部 `NO ACTION`（`ondel=a`），零 `ON DELETE CASCADE`** —— 与 brief 一致，**必须按依赖倒序手工清理**。

**MockSchemas / 文件工具铁律复核（必留 src/main）**：
- `MockSchemas` **被 6 个生产文件工具独占依赖**（`skill/tool/file/{GrepFileTool,RemoveFileTool,ListFileTool,ReadFileTool,ReplaceFileTool,WriteFileTool}` 全部 `import ...mock.MockSchemas`）。**误移即断编译**。→ `MockSchemas` **必须留 src/main**。
- `MockTool`（接口）、`MockToolExecutor`（`@Component`，MOCK 类型唯一执行器，构造注入 `List<MockTool>`）—— 生产能力，**必须留 src/main**。文件工具全部 `implements MockTool`，`MockToolExecutor` 按 code 分发，删空 hr/it 后 `List<MockTool>` 只剩文件工具，仍正常。

---

## 2. FK 依赖倒序删除清单（发布物种子清理口径）

### 2.1 权威 FK 拓扑（真库 `pg_constraint` 实测，指向 expert/skill/agent）

```
expert  ← (NOT NULL) agent.position_id, expert_skill.expert_id, data_table_def.expert_id,
                     expert_metric_daily.expert_id, user_expert_binding.expert_id,
                     user_expert_override.expert_id, user_skill_override.expert_id
        ← (NULL)     session.primary_expert_id, message.expert_id, scheduled_task.expert_id,
                     llm_call_log.expert_id, skill.position_id
skill   ← (NOT NULL) expert_skill.skill_id, skill_relation.parent/child_skill_id,
                     skill_mcp_ref/skill_api_ref/skill_table_ref/skill_resource/skill_file/
                     skill_biz_ref/skill_publication.skill_id, skill_reference.platform_skill_id
        ← (NULL)     skill.parent_id, user_skill_override.base_skill_id
agent   ← (NULL)     skill.agent_id, skill_reference.agent_id
```

> `skill_biz_ref/skill_file/skill_publication/skill_reference` 4 张即 **V54 新增的 RESTRICT FK**（未先清引用就删 skill 会被拦截）。

### 2.2 删除顺序（严格倒序，每条附骨架 + WHERE + 实测命中）

**锚点 CTE**（全程按业务键定位，规避 ID 漂移；发布物出厂只有 2 个 demo 岗位，命中安全）：

```sql
-- 待删演示岗位 id（HR 助理小赫 / IT 运维小图）
WITH demo_expert AS (
    SELECT id FROM expert WHERE name IN ('HR 助理小赫', 'IT 运维小图')
),
-- 待删演示技能 id（含软删行）—— hr_leave / it_account
demo_skill AS (
    SELECT id FROM skill WHERE code IN ('hr_leave', 'it_account')
),
demo_agent AS (
    SELECT id FROM agent WHERE position_id IN (SELECT id FROM demo_expert)
)
```

| 步 | 表 | 语句骨架 | WHERE | 发布物出厂命中 |
|----|----|---------|------|------|
| **A. 断 agent 层（NULL FK，先断后删）** |
| A1 | `skill.agent_id` | `UPDATE skill SET agent_id=NULL` | `WHERE agent_id IN (SELECT id FROM demo_agent)` | HR/IT 技能各挂 default_agent → 命中 |
| A2 | `skill_reference.agent_id` | `UPDATE skill_reference SET agent_id=NULL` | `WHERE agent_id IN (SELECT id FROM demo_agent)` | 出厂 0（平台技能引用无演示数据） |
| A3 | `agent`（delete） | `DELETE FROM agent` | `WHERE id IN (SELECT id FROM demo_agent)` | 2 条 default_agent（V21 每岗位建 1） |
| **B. 断 skill 的 NULL 引用** |
| B1 | `skill.parent_id` | `UPDATE skill SET parent_id=NULL` | `WHERE parent_id IN (SELECT id FROM demo_skill)` | 出厂 0（演示技能非任何父） |
| B2 | `user_skill_override.base_skill_id`（含整行删，见 C6） | 归入 C6 | — | dev 有 1 行；出厂 0 |
| **C. 删 expert 的 NOT NULL 依赖（先清子表再删父）** |
| C1 | `expert_skill`（skill_id + expert_id 双向） | `DELETE FROM expert_skill` | `WHERE skill_id IN (SELECT id FROM demo_skill) OR expert_id IN (SELECT id FROM demo_expert)` | HR/IT 各 1 绑定 |
| C2 | `data_table_def` | `DELETE FROM data_table_def` | `WHERE expert_id IN (SELECT id FROM demo_expert)` | 出厂 0 |
| C3 | `expert_metric_daily` | `DELETE FROM expert_metric_daily` | `WHERE expert_id IN (SELECT id FROM demo_expert)` | 出厂 0（运行期沉淀） |
| C4 | `user_expert_binding` | `DELETE FROM user_expert_binding` | `WHERE expert_id IN (SELECT id FROM demo_expert)` | **默认绑定 §4 单独处置** |
| C5 | `user_expert_override` | `DELETE FROM user_expert_override` | `WHERE expert_id IN (SELECT id FROM demo_expert)` | 出厂 0 |
| C6 | `user_skill_override` | `DELETE FROM user_skill_override` | `WHERE expert_id IN (SELECT id FROM demo_expert) OR base_skill_id IN (SELECT id FROM demo_skill)` | 出厂 0（dev 有 1 行） |
| **D. 断 expert 的 NULL 运行期引用（置 NULL 或删，见 §3）** |
| D1 | `session.primary_expert_id` | `UPDATE session SET primary_expert_id=NULL`（或删会话，见 §3） | `WHERE primary_expert_id IN (SELECT id FROM demo_expert)` | 出厂 0 |
| D2 | `message.expert_id` | `UPDATE message SET expert_id=NULL` | `WHERE expert_id IN (SELECT id FROM demo_expert)` | 出厂 0 |
| D3 | `scheduled_task.expert_id` | `UPDATE scheduled_task SET expert_id=NULL`（或删） | `WHERE expert_id IN (SELECT id FROM demo_expert)` | 出厂 0 |
| D4 | `llm_call_log.expert_id` | `UPDATE llm_call_log SET expert_id=NULL` | `WHERE expert_id IN (SELECT id FROM demo_expert)` | 出厂 0（**M3 新增，brief 遗漏**） |
| D5 | `skill.position_id` | 归入 E（skill 整行删，无需先置 NULL） | — | — |
| **E. 删 skill（先清 V54 四张 RESTRICT + 其余 skill 子引用）** |
| E1 | `skill_relation` | `DELETE FROM skill_relation` | `WHERE parent_skill_id IN (SELECT id FROM demo_skill) OR child_skill_id IN (SELECT id FROM demo_skill)` | 出厂 0 |
| E2 | `skill_mcp_ref` | `DELETE ...` | `WHERE skill_id IN (SELECT id FROM demo_skill)` | 出厂 0 |
| E3 | `skill_api_ref` | `DELETE ...` | 同上 | 出厂 0 |
| E4 | `skill_table_ref` | `DELETE ...` | 同上 | 出厂 0 |
| E5 | `skill_resource` | `DELETE ...` | 同上 | 出厂 0 |
| E6 | `skill_file`（V54 RESTRICT） | `DELETE ...` | 同上 | 出厂 0 |
| E7 | `skill_biz_ref`（V54 RESTRICT） | `DELETE ...` | 同上 | 出厂 0 |
| E8 | `skill_publication`（V54 RESTRICT） | `DELETE ...` | 同上 | 出厂 0 |
| E9 | `skill_reference`（V54 RESTRICT，`platform_skill_id`） | `DELETE FROM skill_reference` | `WHERE platform_skill_id IN (SELECT id FROM demo_skill)` | 出厂 0 |
| E10 | `skill`（delete） | `DELETE FROM skill` | `WHERE id IN (SELECT id FROM demo_skill)` | hr_leave + it_account（含软删行） |
| **F. 删 expert** |
| F1 | `expert`（delete） | `DELETE FROM expert` | `WHERE id IN (SELECT id FROM demo_expert)` | HR 小赫 + IT 小图 |

> **顺序纪律**：A→F 不可乱序。核心约束链：`agent.position_id`(NOT NULL)→必须 A3 删 agent 在 F1 删 expert 前；`skill.agent_id`→A1 先断；V54 四表 RESTRICT→E6~E9 必须在 E10 前；`expert_skill` 双头 NOT NULL→C1 须在 E10 与 F1 前。

---

## 3. 运行期沉淀数据处理口径（session/message/scheduled_task/metric/llm_call_log）

**结论：本轮对「发布物种子」而言这些表出厂为空**（V1/V2/V4 不 INSERT 任何 session/message/…），补偿迁移里对 D/C3 的语句**在全新库上命中 0 行、天然幂等无副作用**。故设计口径分两面：

- **发布物（fresh install）**：迁移执行时这些表本就空，`UPDATE ... WHERE expert_id IN (demo)` / `DELETE` 均命中 0，安全。
- **已污染的运维/dev 库（如当前 `ai_assistant`：106 session、243 message）**：不属于发布物，但补偿迁移会在其上执行。建议：
  - `message.expert_id`、`session.primary_expert_id`、`scheduled_task.expert_id`、`llm_call_log.expert_id`：**置 NULL**（保留历史会话可读性，仅断专家归属；这些列本就 nullable）。**推荐置 NULL 而非删会话**——删 session 会连带 message/task_execution，破坏历史，风险更大。
  - `expert_metric_daily`（NOT NULL FK）：无法置 NULL，**只能整行 DELETE**（纯聚合报表，删演示岗位指标无业务损失）。
  - `scheduled_task`：若存在指向 demo expert 的**启用中**任务，置 NULL 后其 expert 归属丢失可能影响调度语义——发布物出厂 0，dev 库建议先 `status='canceled'` 再置 NULL（本轮 dev 无此数据，标注即可）。

**幂等 & 空表安全**：所有语句用 `WHERE ... IN (SELECT ... 锚点)`，锚点为空（岗位已删）时全部命中 0 行，**重复执行不报错、空库不报错**。

---

## 4. 【开放问题·待 PM/用户拍板】默认绑定处置

**背景**：V1:429 `INSERT INTO user_expert_binding (user_id, expert_id, is_primary) VALUES (1, 1, TRUE)` —— demo 用户主绑 HR。删 HR 岗位前必删此绑定（C4）。删除后 demo 用户**无主绑定**。参照 `project_更换专家_单专家独占绑定.md` 的「单专家独占 + 首登必绑」范式，绑定缺失将触发使用端首登绑定流。

| 选项 | 做法 | 对使用端登录行为影响 | 评估 |
|------|------|--------------------|------|
| **甲** demo 用户改绑到销售岗（`ps_jMH7oM8fUcV`） | C4 后补 `INSERT user_expert_binding(demo, 销售, TRUE)` | demo 登录直接进销售岗对话，开箱即用 | **需确认销售岗是否属"结构性默认"**。销售岗当前经 `SalesPositionImportService` 运行时导入、非 V1 种子，发布物是否自带销售岗尚存疑 → 若发布物不含销售岗，此选项不成立 |
| **乙** demo 用户无主绑定，走首登绑定流 | C4 后不补绑定 | demo 首次登录进入"选择/领用岗位"引导页，自行绑定 | 最"干净"（出厂零业务绑定），符合"发布物只含结构性默认"目标；代价：demo 体验多一步 |
| **丙** 保留 demo 用户但连同一并清 | 清 demo 用户所有绑定/会话/记忆，仅留账号 | 同乙，但更彻底 | 与乙实质等价 |
| **丁** 连 demo 用户也移除 | 发布物不含任何示例用户，仅 admin | 无 demo 账号可登；需另造用户 | 偏离"结构性默认含 demo 用户"现状，改动面大 |

**架构师倾向**：选 **乙**（无主绑定 + 首登绑定流）——最贴合"出厂无演示业务数据"，且不依赖"销售岗是否入发布物"这一未决前提。**但 demo 用户是否保留、是否需开箱即用体验属产品决策，须 PM/用户拍板。** 依赖前提：需产品先明确 **发布物是否自带任何示范岗位**（若完全不带，则乙是唯一自洽解）。

---

## 5. mock/hr·it 移 src/test 清单

### 5.1 移动清单（6 个 @Component + 连带测试）

| 现路径（src/main） | 目标（src/test，同包路径） |
|-------------------|--------------------------|
| `skill/tool/mock/hr/HrGetLeaveBalance.java` | `src/test/.../skill/tool/mock/hr/HrGetLeaveBalance.java` |
| `skill/tool/mock/hr/HrCalcLeaveDays.java` | 同上目录 |
| `skill/tool/mock/hr/HrSubmitLeaveRequest.java` | 同上目录 |
| `skill/tool/mock/it/ItListAvailableSystems.java` | `src/test/.../skill/tool/mock/it/` |
| `skill/tool/mock/it/ItCheckAccountStatus.java` | 同上 |
| `skill/tool/mock/it/ItSubmitAccountRequest.java` | 同上 |

**已在 src/test 的连带件（无需移，但需复核编译）**：
- `src/test/.../mock/MockToolTest.java`（直接 `new HrGetLeaveBalance()` 等 8 例断言）
- `src/test/.../mock/hr/HrMockToolExtraTest.java`（断言 `hr_get_leave_balance` code）

移动后这两个测试仍引用同包类（现类也进 src/test），**包路径不变 → import 不改，编译通过**。

### 5.2 必留 src/main（生产能力，误移即断编译/运行时）

- `skill/tool/mock/MockSchemas.java` —— **被 6 个文件工具独占依赖**（实测 grep 命中），移走断编译。
- `skill/tool/mock/MockTool.java`（接口）—— 文件工具 `implements MockTool`。
- `skill/tool/mock/MockToolExecutor.java`（`@Component`）—— MOCK 类型唯一执行器。

### 5.3 移走后运行时影响（优雅降级已验证）

- 6 个 hr/it Bean 移出 src/main → `ToolRegistry` 运行时不再收集 → `MockToolExecutor` 的 `List<MockTool>` 只剩文件工具类（若有）。
- 若种子里仍残留引用 `hr_get_leave_balance` 等 code 的技能（本方案已在 §2 一并删除），`SkillLoader.java:154-156` 对未注册 MOCK 工具 `warn + continue` **跳过，不崩**（"优雅降级成死技能"）。**因 §2 已删 HR/IT 技能，此降级路径正常情况下不触发**——种子清理与类移动配套后，运行时零残引用。
- **零风险前提**：类移动与种子删除**必须同批交付**（否则种子留 HR/IT 技能而工具已移走 → 技能变死技能，虽不崩但语义脏）。

---

## 6. 补偿迁移 V57 设计

**编号 = V57**（真库已 apply 到 V55，V56 文件已存在未 apply，故新号取 V57 避免撞号）。

**命名**：`V57__purge_hr_it_demo_seed.sql`

**结构骨架**（单事务、幂等、H2 兼容考量）：

```sql
-- V57__purge_hr_it_demo_seed.sql
-- 彻底清除 HR/IT 演示岗位/技能/SOP/绑定及其 FK 依赖（发布物出厂无演示业务数据）。
-- 幂等：全部 WHERE ... IN (SELECT 锚点)，锚点空则命中 0 行；空库/重复执行安全。
-- 无 ON DELETE CASCADE，严格按 §2 A→F 倒序。
BEGIN;  -- Flyway 单迁移已在事务内，此处显式仅为可读性（实际由 Flyway 管控）

-- === A 断 agent ===
UPDATE skill SET agent_id = NULL
  WHERE agent_id IN (SELECT id FROM agent WHERE position_id IN
        (SELECT id FROM expert WHERE name IN ('HR 助理小赫','IT 运维小图')));
-- ... A2/A3 ...
-- === C 清 expert NOT NULL 子表 ===
DELETE FROM expert_skill WHERE skill_id IN (SELECT id FROM skill WHERE code IN ('hr_leave','it_account'))
                            OR expert_id IN (SELECT id FROM expert WHERE name IN ('HR 助理小赫','IT 运维小图'));
-- ... 逐表按 §2 顺序 ...
-- === §4 默认绑定：按拍板结果补/不补（占位，待 PM 决策后定稿）===
-- === E 清 skill 子引用（含 V54 四表）+ 删 skill ===
-- === F 删 expert ===

COMMIT;
```

**幂等要点**：
- 定位一律用业务锚点子查询（`name` / `code`），不用漂移 ID；重复执行时锚点已空 → 全 0 命中。
- 不用 `IF EXISTS`/`DO $$` 包裹 DML（DELETE/UPDATE 空命中本就不报错）；但 §4 的补绑 INSERT 若采用，须 `WHERE NOT EXISTS` 守卫防重复。

**H2 测试库兼容（关键）**：
- 项目测试若用 H2（需确认 `application-test.yml` 的 datasource），**H2 不支持 pgvector、部分 PG 特有语法**，且 **H2 不严格模拟 PG 的 RESTRICT/NO ACTION 级联语义** → V54 的守卫在 H2 上测不出。
- 本迁移**纯 ANSI DML（UPDATE/DELETE + 子查询）**，H2 可执行；无 PG 专有函数。**建议**：确认测试 profile 是否跑 Flyway；若跑，V57 在 H2 上执行应无碍（DML 语法通用）。若测试库用独立种子（非 V1 种子），则命中 0，无副作用。**须实测确认**（见 §7）。

**回滚/备份建议**：
- 迁移**不可逆**（DELETE 无法自动还原）。上生产前**必须 `pg_dump` 全库备份**（至少 expert/skill/expert_skill/agent/user_expert_binding 相关表）。
- 回滚方案 = 从备份恢复 + 手工回退 flyway_schema_history 该行（`DELETE FROM flyway_schema_history WHERE version='57'`）——**标注为高风险手工操作，须 DBA 值守**。
- 不提供反向迁移脚本（重建演示数据无意义，与"剥离"目标相悖）。

---

## 7. 真库验证要点（H2 测不到，必须真库 `aiassistant-postgres` 验证）

H2 无法验证 FK 级联/RESTRICT，以下**必须在真库执行**：

1. **补偿迁移不撞 FK**：在真库 apply V57 后，无任何 `foreign key constraint violation`（尤其 V54 四张 RESTRICT、`agent.position_id`、`expert_skill` 双头 NOT NULL）。
2. **启动不报 ValidationException**：V57 为纯新增迁移，不改已 applied 校验和；`mvn spring-boot:run` / 容器启动 Flyway 校验通过，无 `FlywayValidateException`。
3. **出厂态核对**（fresh install 或清理后）：
   - `SELECT name FROM expert WHERE deleted=false` → **不含** HR 助理小赫 / IT 运维小图。
   - `SELECT code FROM skill WHERE code IN ('hr_leave','it_account')` → **0 行**（含软删行也删净）。
   - **零孤儿核对**（每张 FK 子表）：
     ```sql
     SELECT 'expert_skill' t, count(*) FROM expert_skill es LEFT JOIN expert e ON es.expert_id=e.id WHERE e.id IS NULL
     UNION ALL ... (对 §2.1 每张 NOT NULL 子表重复);
     ```
     全部期望 0。
   - `user_expert_binding` 默认绑定 = §4 拍板结果一致。
4. **零 CASCADE 回归验证**：确认 V57 后再删任意残留 skill 仍被 V54 RESTRICT 守卫拦截（守卫未被破坏）。
5. **dev 库运行期数据**：真库有 106 session/243 message 指向 HR/IT，验证置 NULL 后这些会话仍可查询（`primary_expert_id IS NULL` 不崩使用端历史页）。

---

## 8. 零回归红线

| 红线 | 保障措施 |
|------|---------|
| **销售岗（`ps_jMH7oM8fUcV`）零回归** | §2 锚点严格限定 `name IN ('HR 助理小赫','IT 运维小图')` / `code IN ('hr_leave','it_account')`，销售岗 name/skill code 不在集内，物理隔离。销售岗经运行时导入、非 V1 种子，V57 完全不触及。 |
| **天气岗（`ps_3p9xCjWaBt4`）零回归** | 同上，不在锚点集内。 |
| **使用端其它流不回归** | 运行期表 D 组置 NULL 而非删行（§3），历史会话/消息保留可读；`primary_expert_id` 可空，使用端历史页需容忍 NULL（须核对前端）。 |
| **`SkillLoader` 优雅降级不崩** | §5.3：种子清理与类移动同批 → 运行时零残引用；即便有残引用，`SkillLoader:154-156` warn+continue 不崩（实读验证）。 |
| **`MockSchemas`/文件工具/`MockToolExecutor`/`MockTool` 留 src/main** | §1、§5.2 铁律，误移即断编译。 |

---

## 9. 实施切分 + 风险 + 工作量

| 步 | 内容 | 风险 | 工作量 | 前置 |
|----|------|------|--------|------|
| **S1** | 移 6 个 hr/it 类 src/main→src/test；复核 2 个测试编译 | 低（同包移动，import 不变） | 0.5d | — |
| **S2** | 编写 V57 补偿迁移（§2 A→F + §3 运行期口径） | **高**（FK 倒序、V54 RESTRICT、幂等） | 1d | §4 拍板 |
| **S3** | §4 默认绑定改指向（按拍板补/删 binding INSERT） | 中（依赖产品决策 + 发布物是否含销售岗前提） | 0.5d | **PM/用户拍板** |
| **S4** | 测试调整：删/改依赖 HR/IT 种子的集成测试（若有 e2e 断言 HR/IT 岗位存在，须同步） | 中（需全量搜集成测试对 HR/IT 的断言） | 0.5~1d | S1 |
| **S5** | 真库验证（§7 全项）+ dev 库运行期数据实测 | **高**（不可逆，须先备份） | 0.5d | S2/S3 |
| **S6** | Code Review（架构师非作者审 + 后端）+ 出厂态核对 | 中 | 0.5d | 全部 |

**总体高风险点**：S2（迁移正确性，一次性不可逆）、S5（真库不可逆，须 pg_dump 备份 + DBA 值守）、S3（阻塞于产品决策）。

**建议实施顺序**：先解 §4 开放问题（PM/用户）→ S1（零风险先做）→ S2 → 真库备份 → S5 干跑（先 `BEGIN; ...; ROLLBACK;` 预演命中数）→ 正式 apply → S4/S6。

---

## 10. 待决清单（阻塞实施）

1. **【产品决策】** §4 默认绑定：demo 用户改绑销售 / 无主绑定走首登流 / 移除 demo 用户 —— **须 PM/用户拍板**。
2. **【产品确认】** 发布物是否自带**任何**示范岗位（销售岗当前运行时导入，是否入发布物直接决定 §4 选项甲是否成立）。
3. **【技术确认】** 测试 profile 是否用 H2 且跑 Flyway（决定 V57 是否需 gated/兼容处理）——须读 `application-test.yml` 确认。
4. **【运维确认】** 已污染 dev 库运行期数据（106 session 等）：本轮是清理还是仅置 NULL —— §3 建议置 NULL，待确认。
