# MCP 真实运行时 — 技术方案

> 版本：v1（架构师，2026-06-12）
> 范围：把现有**占位** MCP 工具（`UnconnectedMcpToolExecutor`）升级为**真实运行时外呼**。本次**仅 MCP**，API 同模式留后续。
> 运行时契约（`ToolExecutor` / `ToolInvocation` / `ToolResult` / 编排器 act 路径 / `/api/internal/tool/execute`）**一行不改**。
> 配套接口契约见 [`docs/api/MCP真实运行时-接口契约.md`](../api/MCP真实运行时-接口契约.md)。

> **📌 校准标注（2026-07-17）**：本篇的运行时执行器部分（`McpToolExecutor`、`ToolExecutionService`、编排器 act 路径、`/api/internal/tool/execute`）已随主版本运行时剥离，不在本仓——`ToolExecutor` 接口现无任何实现类；连接器客户端库（`McpTransport` SPI、`McpSessionManager`、`McpRpc`、`McpAuthResolver`、各 Transport 实现）与注册/检活/巡检链路（`McpProvisionService`、`McpHealthScheduled`）完整保留。详见《设计文档校准审计-20260717.md》。

---

## 0. 一句话结论

在 Java 后端 `com.aiassistant.tooldef.mcp` 新增一套**自研、零新依赖**的 MCP 客户端（JSON-RPC 2.0 over streamable-http），用 `McpToolExecutor(type=MCP)` 替换占位 executor 挂到现有工具执行权威 `ToolExecutionService` 背后；**只做同步 `tools/call`**（编排循环已在 Python，无需 Flux/SSE 流式那一套）。注册侧新增**显式「测试连接 / 拉取工具」动作**真实 `initialize` + `tools/list` 回填 `tools_cache` 与连接状态。HTTP 复用项目已有 **Spring `RestClient`**（同步），不引入 OkHttp/Reactor/Redis。

**核心简化决策（务必守住）：**
- MCP executor **同步 callTool**，不搬 sample 的 `Flux callToolStream` / `McpStreamEvent` / 进度事件。理由：编排器 `act_node` 本就同步 POST 拿 `ToolResult`，运行时无任何流式消费方，流式纯属负担。
- **不引 MongoDB / Redis / Redisson / 调用统计增量 / 调用日志独立表**。调用埋点已由现有 `tool_call_log`（`ToolExecutionService.writeLog`）承载，零新增。
- transport **只实做 streamable-http**（云端 MCP 主流，且本项目部署为 Docker，stdio 价值低）；`McpTransport` SPI 预留 stdio，本轮不实现（见 §3.4）。

---

## 1. 总体方案与边界

### 1.1 模块落点

```
com.aiassistant.tooldef.mcp                 ← 新增包（运行时客户端）
├── McpToolExecutor.java                     type=MCP，替换 UnconnectedMcpToolExecutor（@Component）
├── transport/
│   ├── McpTransport.java                    SPI：initialize / callTool / close（同步）
│   ├── McpSession.java                      会话对象（sessionId / endpoint / protocolVersion）
│   ├── McpTransportException.java           传输异常（带 JSON-RPC errorCode 分类）
│   └── StreamableHttpTransport.java         streamable-http 实现（RestClient）
├── McpSessionManager.java                   按 mcpDef.code 维度缓存复用 + 失效自愈 + 空闲清理
├── McpRpc.java                              JSON-RPC 2.0 报文构造 + extractJsonBody（SSE/JSON 兼容）
├── McpAuthResolver.java                     auth_config → header 注入（密文解密/别名/探测暂态明文三源，不落明文，§4.5）
├── McpProvisionService.java                 注册侧：真实 initialize + tools/list（测试连接/拉取工具）
├── McpProperties.java                       mcp.* 配置绑定
└── McpHealthScheduled.java                  （可选）@Scheduled 连接巡检（§7）
```

> `UnconnectedApiToolExecutor` 与 `UnconnectedToolExecutor` 父类**保留不动**（API 仍占位）。仅删除 `UnconnectedMcpToolExecutor`（type=MCP 的 Bean 由 `McpToolExecutor` 接管；`ToolRegistry` 一 type 一 executor，两者不可并存）。

### 1.2 调用时序（运行时，零契约改动）

```
编排器(Python) act_node
  └─POST /api/internal/tool/execute  { toolCode, args, ... }   ← 现有内部接口，不改
       └─ ToolExecutionService.execute(toolCode, args, allowedTools, trace, typeHint=MCP)   ← 现有，不改
            ├─ 白名单二次校验（现有）
            ├─ 二次确认门禁（MCP 占位为读类 requiresConfirmation=false，不进门；现有）
            ├─ executorForType(MCP) → McpToolExecutor.execute(ToolInvocation)   ← 本方案替换点
            │     ├─ splitMcpCode(toolCode) → (mcpCode, toolName)               ← §2
            │     ├─ McpDefRepository.findByCode(mcpCode) → endpoint/transport/auth/status
            │     ├─ McpSessionManager.getOrCreate(mcpCode) → McpSession（命中复用，否则 initialize 握手）
            │     ├─ StreamableHttpTransport.callTool(session, toolName, args, timeout)  → JSON-RPC result
            │     └─ map content[] → ToolResult(success/data/errorCode/latencyMs)        ← §4
            └─ writeLog → tool_call_log（现有埋点，toolType=MCP）
       └─ ToolResult 回灌编排器 observe → 模型续推
```

### 1.3 与注册侧的解耦

沿用现状的「两条链路经表解耦」：注册侧（`McpProvisionService` 写 `mcp_def.tools_cache/status/...`）只写；运行时（`McpToolExecutor`）只读 `mcp_def`。运行时**不**读 `tools_cache`（schema 在编排前已由 `ExpertRouter.buildMcpApiSnapshots` 注入给模型）——运行时只需 `endpoint/transport/auth_config/status`，按 `toolName` 直接 `tools/call`。

---

## 2. toolCode → (McpDef + 真实工具名) 解析契约（核心）

**结论：toolCode 是自包含限定名，解析无需任何额外查询表。**

### 2.1 限定名规则（已存在，本方案沿用，不改）

运行时 toolCode = **`mcp__{mcpCode}__{toolName}`**（`OrchestrationAssembler.MCP_CODE_PREFIX="mcp__"`，分隔符 `__`）。
- `mcpCode` = `mcp_def.code`（唯一）。
- `toolName` = MCP 服务端真实工具名（= `tools/list` 返回的 `tools[].name` = `tools_cache[].name`）。

拆分工具已存在：`OrchestrationAssembler.splitMcpCode(code) → [mcpCode, toolName]`（静态方法，本方案直接复用，不重复实现）。

> **拆分约束（重要，需注册侧加校验）**：`splitMcpCode` 去掉 `mcp__` 前缀后**按首个 `__` 切分**为 `(mcpCode, toolName)`。因此：
> - **`toolName` 含 `__` 是安全的**（首个 `__` 之后整段都归 `toolName`）。
> - **但 `mcpCode` 含 `__` 会拆错**（会把 `mcpCode` 的后半段误当作 `toolName`）。
> - **现有 `AdminMcpService.CODE_PATTERN=^[a-z0-9_]+$` 允许下划线，即允许 `__`，存在拆错隐患**（已核对源码）。故在注册侧 code 校验**增「不得包含连续下划线 `__`」**（见 §5 实施说明），从源头杜绝。

### 2.2 运行时解析路径（McpToolExecutor）

```
toolCode "mcp__crm__search_customer"
  → splitMcpCode → ["crm", "search_customer"]
  → mcpDefRepository.findByCode("crm")  → McpDef{ endpoint, transport, authConfig, status }
  → 校验 status=="active"（否则 TOOL_NOT_CONNECTED 语义返回）
  → callTool(endpoint/transport/auth, toolName="search_customer", args)
```

**关键事实（已核对源码）：**
1. **toolCode 物理自带归属**——无需查 `skill_mcp_ref`，无需 run 上下文反查。`splitMcpCode` 即得 `(mcpCode, toolName)`，`findByCode` 即得 `McpDef`。这是本设计最关键的简化点。
2. **`run.typeOf(toolCode)` 已给出 type=MCP**：`ToolExecutionService` 据此路由到 `McpToolExecutor`（现有机制，见 `OrchestrationRun.toolTypes`）。executor 内部不再需要 run。
3. **本 run 允许的 MCP 工具集**已由白名单 `allowedTools` 在 `ToolExecutionService` 入口二次校验完毕（`assembled.allowedTools()` ← `OrchestrateRequestAssembler`：遍历每个 `EffectiveSkill.toolRefs()`，MCP ref 的 code 即限定名）。executor 只在被允许的 toolCode 上被调用，无需再判权限。

### 2.3 `SkillMcpRef.alias / config` 的作用

- **`alias`**：Skill 引用 MCP 时的展示别名（FDE 可读），**不参与运行时 toolCode 构造与解析**（toolCode 用 `mcp_def.code`，非 alias）。运行时无关。
- **`config`**：Skill 维度对该 MCP 的覆盖配置（JSONB，预留）。**本轮运行时不消费**——鉴权/endpoint 取 `mcp_def` 全局值。若未来需要「同一 MCP 在不同 Skill 用不同凭证」，再在此扩展（列入 §11 待确认非阻塞项，本轮 YAGNI）。

> 结论：`SkillMcpRef` 是「绑定关系 + 编辑期 schema 快照来源」，运行时解析**不依赖**它。归属信息已全部编码进 toolCode。

---

## 3. 传输层设计

### 3.1 `McpTransport` SPI（同步）

```java
public interface McpTransport {
    String transport();                                         // "streamable-http" | "stdio"
    McpSession initialize(McpDef def, int connectTimeoutMs);    // 握手：initialize + notifications/initialized
    JsonNode callTool(McpSession s, String toolName,
                      Map<String,Object> args, int callTimeoutMs);   // tools/call，返回 JSON-RPC result 节点
    JsonNode listTools(McpSession s, int callTimeoutMs);        // tools/list（注册侧拉取用）
    void close(McpSession s);
}
```

- **无 `callToolStream`**（对比 sample 删除）。理由见 §0。
- Spring 注入 `List<McpTransport>`，`McpSessionManager` 按 `transport()` 建 `Map<String,McpTransport>` 路由——**新增传输零侵入**（保留 sample 最值得借鉴的扩展点）。

### 3.2 `McpSession`（会话对象）

```java
public final class McpSession {
    final String mcpCode;            // 缓存键 = mcp_def.code
    final String endpoint;
    final String transport;
    volatile String sessionId;       // streamable-http 的 Mcp-Session-Id，可选（无则无状态）
    volatile String protocolVersion;
    volatile String serverVersion;
    volatile Instant lastUsedAt;     // 空闲清理用
    // alive 判据见 §3.5
}
```

### 3.3 `StreamableHttpTransport`（主实现）

JSON-RPC 2.0 over HTTP POST，握手 → 调用三步（协议版本 `2025-03-26`，对齐参考资料）：

| 步骤 | method | id | 备注 |
|------|--------|----|----|
| 握手 1 | `initialize` | 1 | params: `{protocolVersion, capabilities:{}, clientInfo:{name:"ai-assistant", version:"1.0.0"}}`；响应头 `Mcp-Session-Id` 存入 session（可选）|
| 握手 2 | `notifications/initialized` | — | 通知无响应；有 sessionId 则带 `Mcp-Session-Id` 头 |
| 运行 | `tools/call` | 自增 | params: `{name: toolName, arguments: args}` |
| 注册 | `tools/list` | 自增 | params: `{}` |

实现要点：
- 请求头固定 `Content-Type: application/json`、`Accept: application/json, text/event-stream`。
- **响应自动兼容（`McpRpc.extractJsonBody`）**：某些 MCP 对 `application/json` 请求也回 `text/event-stream`。按「`Content-Type` 含 `text/event-stream` 或正文以 `event:`/`data:` 开头 → 取首个 `data:` 行 JSON；否则原文」解析（逻辑同参考资料 §4.3）。单帧 JSON-RPC 足够，本轮不处理多 `data:` 行拼接（列 §11 已知边界，非阻塞）。
- HTTP 客户端：**Spring `RestClient`**（项目已用于 `OpenAiCompatibleProvider` 同步调用），`ClientHttpRequestFactorySettings` 设 connect/read 超时；**不引 OkHttp/Reactor**。
- 鉴权头由 `McpAuthResolver` 注入（§4.5）。
- **响应头/正文的取法（实现注意，勿照抄现有 provider）**：
  - **握手 `initialize` 需读响应头 `Mcp-Session-Id`** → 必须用 `.retrieve().toEntity(String.class)`，从 `ResponseEntity.getHeaders()` 取 header 后再把 body 交 `extractJsonBody`。**现有 `OpenAiCompatibleProvider` 用的是 `.body(String.class)`，拿不到响应头**——MCP 握手不能照抄。
  - **`tools/call` / `tools/list` 只需正文** → 用 `.retrieve().body(String.class)` 拿原始 body（可能是 JSON 或 SSE），交 `McpRpc.extractJsonBody` 解析。
  - 即：凡需读 sessionId 的请求走 `toEntity`，只读 body 的请求走 `body`。

### 3.4 stdio：本轮结论 = SPI 预留、不实做

**决策：不实现 `StdioTransport`。** 理由：
1. 本项目部署形态为 **Colima + Docker**，后端容器内拉起 `uvx/npx` 子进程依赖宿主工具链，运维与隔离成本高、价值低。
2. 云端/内网 MCP 一律走 streamable-http，覆盖目标场景。
3. SPI 已抽象，未来按需补一个 Bean 即可零侵入接入。

注册侧 `transport` 取值校验**保留** `["stdio","streamable-http"]`（`AdminMcpService.TRANSPORTS` 不动，FDE 仍可登记 stdio 定义占位），但**运行时遇 transport=stdio 直接返回 `MCP_TRANSPORT_UNSUPPORTED` 语义的占位结果**（success=true + errorCode），与现占位风格一致，不抛异常打断对话。

> **文案须与「完全未接入」区分**（避免模型/FDE 误判为「没配」）：
> - `MCP_TRANSPORT_UNSUPPORTED`（已登记但接入方式暂不支持）→ 文案「**该接入方式当前暂不支持**」。
> - `TOOL_NOT_CONNECTED`（未登记 / 已停用 / 总开关关 → 等同「完全未接入」）→ 沿用现占位文案「该能力暂未接入…」。

> **📌 校准标注（2026-07-17）**：stdio 已由 V37（`V37__mcp_stdio_fields.sql`）+ `StdioTransport` 真实实现（见《MCP-stdio传输支持-技术方案.md》），本节「SPI 预留不实做、运行时遇 stdio 返回 `MCP_TRANSPORT_UNSUPPORTED` 占位」的决策已被取代。详见《设计文档校准审计-20260717.md》。

### 3.5 `McpSessionManager`（会话复用 + 自愈 + 清理）

```java
@Component
public class McpSessionManager {
    // key = mcp_def.code
    private final Map<String, McpSession> cache = new ConcurrentHashMap<>();
    private final Map<String, McpTransport> transports;   // @PostConstruct from List<McpTransport>

    McpSession getOrCreate(McpDef def, int connectTimeoutMs);  // 命中且 alive 复用；否则按 transport initialize
    void invalidate(String mcpCode);                           // 调用异常即失效，下次重握手
    @Scheduled(fixedDelayString="${mcp.session.cleanup-fixed-delay-ms:300000}")
    void cleanup();                                            // 空闲 > mcp.session.idle-minutes 清理
    @PreDestroy void destroy();                                // 全清
}
```

并发要点（吸收参考资料审查发现 6.2-5）：建会话用**按 key 分段锁**（`computeIfAbsent` 内 initialize，或 per-mcpCode `ReentrantLock`），**不**用全局 `synchronized`，避免不同 MCP 首呼互斥排队。

**alive 判据**：streamable-http 仅凭「session 存在 + 未过空闲」判活（被动失效：调用抛异常 → `invalidate`）。本轮**不加主动 ping 心跳**（YAGNI；巡检 §7 已覆盖连接漂移）。

### 3.6 失效自愈

`McpToolExecutor` / transport 捕获连接类异常（连接拒绝/超时/会话失效）→ `sessionManager.invalidate(mcpCode)` → **本次**返回失败 `ToolResult`（不在单次调用内自动重握手重试，避免放大延迟；下次调用自然重建）。

---

## 4. McpToolExecutor 实现要点

### 4.1 主流程

```java
@Component
public class McpToolExecutor implements ToolExecutor {
    public ToolType type() { return ToolType.MCP; }

    public ToolResult execute(ToolInvocation inv) {
        long t0 = System.currentTimeMillis();
        String[] parts = OrchestrationAssembler.splitMcpCode(inv.toolCode());   // 复用
        if (parts == null) return fail("MCP_BAD_CODE", t0);                     // 理论不达（白名单已校验）
        McpDef def = mcpDefRepository.findByCode(parts[0]).orElse(null);
        if (def == null || !"active".equals(def.getStatus()))
            return notConnected(t0);                                            // 对齐占位语义
        if (!props.isEnabled())  return notConnected(t0);                       // 总开关关 → 退占位
        if (!"streamable-http".equals(def.getTransport())) return unsupported(t0);
        try {
            McpSession s = sessionManager.getOrCreate(def, props.connectTimeoutMs());
            JsonNode result = transport.callTool(s, parts[1], inv.args(), props.callTimeoutMs());
            return mapResult(result, t0);                                       // §4.2
        } catch (McpTransportException e) {
            sessionManager.invalidate(def.getCode());
            return classify(e, t0);                                             // §4.3
        } catch (RuntimeException e) {
            log.warn("MCP 调用异常 mcpCode={}", def.getCode(), e);              // 不打印 endpoint/堆栈到结果
            return ToolResult.fail("MCP_CALL_ERROR", "工具调用失败", elapsed(t0));
        }
    }
}
```

### 4.2 MCP `result.content[]` → `ToolResult.data` 映射

MCP `tools/call` 成功返回 `{ content: [ {type, text|json|...} ], isError? }`。映射规则：

| MCP 返回 | ToolResult |
|----------|-----------|
| `isError == true` | `ToolResult.fail("MCP_TOOL_ERROR", <拼接全部 type=text 文本，仅裁长+脱敏，不语义删减>, latency)`（见下方 ②）|
| 正常 `content[]` | `ToolResult.ok(data, latency)`，`data` = `{ "text": "<拼接所有 type=text 文本，按 §8 截断>" }` |

**回灌质量约束（已核实编排器 `act` 节点 L434/439 将整个 `resp.data` 原样 `json.dumps` 回灌给模型且无截断，故必须在后端侧把 `data` 控成「精炼、唯一、可截断」）：**

**① `data` 只放 `text`，不回灌结构化原文。**

- `data.text`：把所有 `type=="text"` 项的 `text` 换行拼接——**这是模型唯一消费的字段**（编排器把 `data` 序列化为 tool message 回灌）。
- **移除 `data.content`**：不再把 `content[]` 结构化原文（含逐项 `type/annotations` 等元信息）塞进 `data`，避免同一份文本在 `text` 与 `content` 中**重复回灌、token 翻倍**。
- 结构化原文若需保留（排障/审计），**落服务端日志或 trace（不回灌模型的通道）**，绝不进 `data`。

**② `data.text` 长度截断（新增配置 `mcp.result.max-chars`，默认 8000）。**

- 拼接后若 `text` 长度 > `mcp.result.max-chars`，**截断到该长度**并追加固定提示尾：`…（结果过长已截断，如需完整数据请缩小查询范围）`。
- 防止单次工具结果撑爆上下文 / 触发 token 上限。该配置见 §8、模型可观测影响见 §11.5。
- 同样适用于 `MCP_TOOL_ERROR` 的 `errorMessage`：拼接全部 text 后**仅裁长 + 脱敏**（沿用同一 max-chars 上限），**不做语义删减**（保留服务端给出的完整报错语义供模型转达）。

**③ 空文本结果禁回灌空串（语义兜底）。**

- 成功但 `content` 为空、或 `content` 仅含**非 text 类型**（image/audio/resource）导致拼接结果为空时，**禁止把 `data.text` 置为空串**（空串回灌会让模型误判「无结果/出错」）。
- 兜底填短语：基础兜底「工具执行成功，但未返回文本内容」；若含非 text 类型，追加「（返回了图片/资源类内容，当前版本暂不支持解析）」。

编排器/契约不变：`ToolResult.data` 仍是 `Map<String,Object>`，本映射只是收紧其内部形状为 `{ "text": ... }` 单键。

### 4.3 错误码语义（对齐现有 `TOOL_NOT_CONNECTED` 风格，message 不泄露技术细节）

| 场景 | success | errorCode | message（对话可见，脱敏）|
|------|---------|-----------|------|
| MCP 未登记/停用/总开关关（=完全未接入）| true | `TOOL_NOT_CONNECTED` | 「该能力暂未接入…」（沿用占位文案，模型如实转达）|
| transport 已登记但不支持（如 stdio）| true | `MCP_TRANSPORT_UNSUPPORTED` | 「该接入方式当前暂不支持」（与「完全未接入」区分，见 §3.4）|
| 连接失败/超时（initialize 或 call） | false | `MCP_CONN_FAILED` / `MCP_TIMEOUT` | 「外部工具连接失败/超时，请稍后重试」|
| 工具不存在（JSON-RPC -32601 / 服务端报无此工具）| false | `MCP_TOOL_NOT_FOUND` | 「该工具当前不可用」|
| JSON-RPC 业务 error（其它 code）| false | `MCP_RPC_ERROR` | 取 JSON-RPC `error.message` 裁剪后透出（不含 endpoint/堆栈）|
| tool 返回 `isError=true` | false | `MCP_TOOL_ERROR` | 拼接全部 `type=text` 文本，**仅裁长（`mcp.result.max-chars`）+ 脱敏，不语义删减**（保留服务端完整报错语义供模型转达，见 §4.2 ②）|
| 解析异常/未知 | false | `MCP_CALL_ERROR` | 「工具调用失败」|

**安全铁律**：`errorMessage` 与日志的**用户/模型可见部分**绝不含 `endpoint`、`auth` 值、Java 堆栈、内网地址。endpoint/堆栈仅落 `log.warn/debug`（服务端日志，运维可见）。

> 说明：「未接入类」保持 `success=true`（沿用现占位语义，对话最自然），便于 `tool_call_log` 按 `error_code` 筛；「真实失败类」`success=false`，由编排回灌→模型翻译为中文。

### 4.4 latencyMs

`System.currentTimeMillis()` 包裹从 `getOrCreate` 到 `callTool` 返回的整段（**含首呼握手开销**），写入 `ToolResult.latencyMs`，由现有 `writeLog` 落 `tool_call_log.latency_ms`。

> **可定位性补充（不改 `tool_call_log` 表）**：`latencyMs` 是「握手+调用」合计，首呼会偏大、命中会话则只含 call。为便于排障，在 `McpToolExecutor` 的 `log.debug/info` 中**分别打 `handshakeMs`（getOrCreate 内是否真握手及其耗时）与 `callMs`（callTool 耗时）**，避免把首呼握手开销误读为工具本身慢。表结构不动，仅日志维度细化。

### 4.5 鉴权（`McpAuthResolver`，密钥不明文）

`mcp_def.auth_config`（JSONB）存**密文或别名引用**，不存明文。约定结构：

```json
{ "type": "bearer", "tokenCipher": "<keyAlias:iv:cipher>" }
{ "type": "header", "headerName": "X-Api-Key", "valueCipher": "<keyAlias:iv:cipher>" }
{ "type": "none" }
```

存量兼容结构（别名范式，早期最小集，继续可解析）：

```json
{ "type": "bearer", "tokenAlias": "MCP_CRM_TOKEN" }
{ "type": "header", "headerName": "X-Api-Key", "valueAlias": "MCP_X_KEY" }
```

**密文范式（2026-07 起为主路径，后台可录入）**：FDE 在管理后台（McpEditor 连接/鉴权区，`MCP_AUTH_CONFIG_ENABLED` 开关）录入 Bearer Token / 自定义 Header 值，`AdminMcpService.applyAuth` 经 `CredentialCryptoService` AES-256-GCM 加密落 `tokenCipher`/`valueCipher`，**AAD = `mcpId|-2`**（「MCP auth」专用域，已在 AAD 域登记表登记；密文绑定归属 MCP，跨行挪用即拒）。编辑语义与 env / API 密钥统一：**留空=保留旧密文/别名，重填=加密覆盖，`type=none`=清空，请求未携带 `authConfig`=整体保留**；请求中的 `*Cipher` 字段一律忽略（防外部密文注入）。

> **📌 校准标注（2026-07-17）**：全线 ID 字符串化（V45–V53）后，AAD 已改为 String 拼接——`mcpId` 为 `mc_` 前缀字符串句柄，域常量取 String 版 `CredentialCryptoService.MCP_AUTH_AAD_DOMAIN_STR = "-2"`，上文「`mcpId|-2`」的 numeric 表述按 String 口径理解，语义不变。详见《设计文档校准审计-20260717.md》。

`McpAuthResolver.resolveHeaders(authConfig, mcpId)` 密钥取值**三源**（按优先级）：

1. **明文**（`token`/`value`）：仅「测试连接 / 草稿拉取工具」探测暂态携带（前端本次录入未落库先试连，与 stdio 草稿 env 明文同口径），**落库路径绝不写入**。
2. **密文**（`tokenCipher`/`valueCipher`）：按 AAD `mcpId|-2` 解密（解密链路已贯通 mcpId：`McpSession.mcpId`、`ExternalMcpsContributor`、探测 probe def）。
3. **别名**（`tokenAlias`/`valueAlias`，存量兼容）：从**环境变量 / `application-local.yml`**（`mcp.auth.<alias>`）取真实密钥。

- DB / 普通日志**只见密文或别名**，绝不落明文；前端回显恒脱敏（详情 `authInfo {type, headerName, valueMasked}`）。
- `type=none` 或 `auth_config` 为空 → 不加鉴权头。
- 密钥缺失 / 解密失败 → 视为连接不可用（`MCP_CONN_FAILED`），不把别名/密文/缺失细节透给模型。
- **下发契约零变化**：岗位包 `external_mcps.json` 的 `auth.headers` 结构不变（R2·S5/P1 明文下发口径不动），仅平台内部密钥来源由 yml 别名改为 DB 密文。

> 鉴权类型仍为**最小集**（bearer / 自定义 header）。OAuth 刷新等复杂流程列 §11，非本轮。存量别名配置零迁移可继续用，建议择机在后台重录一次密钥，自然迁移到密文范式。

---

## 5. 注册侧增强

### 5.1 决策：显式「测试连接 / 拉取工具」动作（**不**保存即异步拉取）

| 方案 | 取舍 |
|------|------|
| 保存即异步拉取（sample 默认）| 保存语义变重；异步状态回写产生「保存成功但工具空/状态加载中」中间态，前端需轮询；失败归因隐晦 |
| **显式动作（本方案选）** | 保存仍是纯 CRUD（现状不变，零回归）；FDE 点「测试连接」按钮**同步**返回握手结果 + 拉到的工具，**预览确认后**再保存进 `tools_cache`。易用、可控、失败即时可见 |

**采用显式动作**，理由：易用性（即时反馈、所见即所得）+ 简洁（保存路径零改动、无异步状态机、无轮询）。沿用现有「手动登记 `tools_cache`」入口不破坏，新增「从真实服务拉取并回填」作为增强。

> **code 校验加固（实施说明，配合 §2.1 拆分约束）**：在 `AdminMcpService` 创建/更新的 code 校验中，于现有 `CODE_PATTERN=^[a-z0-9_]+$` 基础上**追加「不得包含连续下划线 `__`」**（如再加 `if (code.contains("__")) throw BusinessException.ofField(BAD/BUSINESS, "code 不得包含连续下划线", "code")`，或收紧正则为不允许 `__`）。原因：运行时 toolCode 以 `mcp__{mcpCode}__{toolName}` 编码、`splitMcpCode` 按首个 `__` 切分，`mcpCode` 含 `__` 会拆错归属。校验码沿用现状（格式非法走 `1000`+`field=code`，与现有 BUG-003 口径一致）。

### 5.2 `McpProvisionService` 两个动作

1. **测试连接（`testConnection`）**：对给定 `endpoint/transport/authConfig`（**未保存的草稿亦可**，参数随请求传入，便于新建时先测后存）执行 `initialize` → 返回 `{ ok, protocolVersion, serverVersion, serverName, latencyMs }` 或脱敏失败原因。**不写库**。
2. **拉取工具（`fetchTools`）**：`initialize` → `notifications/initialized` → `tools/list` → 返回 `tools[]`（`{name, description, inputSchema}`）。
   - 调用方式一：**针对已存在 id**，拉取后直接回填 `mcp_def.tools_cache`（保留各工具已登记的 `bizName`，按 `name` 合并；新工具 `bizName` 缺省 = `name`）+ 刷新 `protocol_version/server_version/last_checked_at/conn_status`，并审计。
   - 调用方式二：**针对草稿**（新建未保存），仅返回 `tools[]` 给前端预览，前端带回 `create/update` 入参。
   - 「先清后填」语义：以本次拉取结果为准覆盖 `tools_cache`（对齐参考资料「先逻辑删旧再插新」，但本项目 `tools_cache` 是单 JSONB 列，直接整体替换即可，无增量比对）。

> **📌 校准标注（2026-07-17）**：V75 起工具清单只读化——`bizName ≡ name`、`requiresConfirmation ≡ (writeClass=='WRITE')` 均为派生兼容值，fetch-tools 合并（`McpToolsCacheMerger`）保留的是 FDE 标注的 `writeClass`（READ/WRITE），不再「保留已登记的 bizName」。详见《设计文档校准审计-20260717.md》。

> 鉴权脱敏：草稿/编辑态测试时，本次重填的密钥以**明文暂态**随探测请求下发试连（不落库，与草稿 env 同口径）；留空则由后端回退库内密文（已存对象）或视为无鉴权（草稿）。前端**永不回显**密钥明文（详情接口 `authConfigMasked` + 结构化 `authInfo` 恒脱敏，§4.5）。

### 5.3 接口契约（REST，写入 `docs/api/`）

新增 3 个端点（详见 [接口契约](../api/MCP真实运行时-接口契约.md)）：
- `POST /api/fde/connectors/mcp/test-connection` — 草稿/已存连接探测（不写库）
- `POST /api/fde/connectors/mcp/{id}/fetch-tools` — 对已存 MCP 真实拉取并回填 `tools_cache` + 状态
- `POST /api/fde/connectors/mcp/fetch-tools` — 对草稿拉取（仅返回，不写库；新建场景）

现有 `create/update/list/detail/delete` **保持不变**，`detail/list` 输出**新增连接状态字段**（见 §6 / §9）。

---

## 6. 数据模型 V14 迁移

在 `mcp_def` 上**最小新增 4 列**（已应用的 V1~V13 不动）。`conn_status` 与业务 `status` 分离：`status`（active/inactive）是 FDE 的启停意图（现有，运行时据此判可用）；`conn_status`（unknown/ok/failed）是**最近一次真实连通性探测结果**，纯展示/巡检用，**不**影响运行时放行（避免巡检抖动误伤对话）。

> **版本号核对（已核对 migration 目录）**：当前最新迁移是 **`V13__obs_metadata_and_memory_importance.sql`**（已应用），故 MCP 迁移取下一个版本号 **`V14__mcp_runtime.sql`**。**严禁复用 V13**（会冲突）。

### V14 SQL 草案（`backend/src/main/resources/db/migration/V14__mcp_runtime.sql`）

```sql
-- MCP 真实运行时：连接探测元数据（纯展示/巡检，不影响 status 放行语义）
ALTER TABLE mcp_def ADD COLUMN protocol_version VARCHAR(32);   -- initialize 返回协议版本
ALTER TABLE mcp_def ADD COLUMN server_version   VARCHAR(64);   -- serverInfo.version，变更检测用
ALTER TABLE mcp_def ADD COLUMN conn_status      VARCHAR(16) DEFAULT 'unknown';  -- unknown/ok/failed：最近探测结果
ALTER TABLE mcp_def ADD COLUMN last_checked_at  TIMESTAMPTZ;   -- 最近一次 test/fetch/巡检时间

COMMENT ON COLUMN mcp_def.conn_status IS '最近连通性探测结果（unknown/ok/failed），仅展示与巡检，不影响运行时放行（放行看 status=active）';
```

字段语义：
- `protocol_version` / `server_version`：`initialize` 回填，巡检比对检测上游版本漂移。
- `conn_status`：`test-connection`/`fetch-tools`/巡检写入；`ok` 成功、`failed` 失败、`unknown` 从未探测。
- `last_checked_at`：最近探测时间戳。

`McpDef` 实体相应加 4 个字段 + getter/setter（JPA，无需 `@JdbcTypeCode`，均为标量/时间）。

> **VO 映射方式（实现注意）**：`McpDefListItem` / `McpDefDetailVO` 均为 **Java `record`，通过构造器逐字段映射**（非 `BeanUtils.copyProperties`）。新增连接字段后，**必须同步改动所有 `new McpDefListItem(...)` / `new McpDefDetailVO(...)` 构造点**（如 `AdminMcpService` 的 list/detail 装配处），否则编译不过——这是 record 的优点（漏改即编译失败，不会静默丢字段）。

---

## 7. 健康/版本巡检

**决策：本轮加一个轻量 `@Scheduled` 巡检，默认开关 `false`（保守），单实例直接跑、无分布式锁。**

理由与简化：
- 项目**无 Redis/Redisson**（已核对：仅 Caffeine）。沿用本项目既有范式——`ScheduledTaskDispatcher` 注释明确「单实例串行 tick，无需分布式锁」。MCP 巡检同理：单实例部署，`@Scheduled` 直接扫 `status=active` 的 MCP，逐个 `initialize`，回写 `conn_status/protocol_version/server_version/last_checked_at`。
- **不自动改 `status`**（不因一次探测失败就停用 MCP，避免抖动误伤）；只刷 `conn_status` 供后台展示「连接异常」红点。版本漂移**不自动重拉工具**（本项目工具是 FDE 显式登记/拉取的受控资产，自动覆盖反而意外）——仅在 `conn_status` 或版本变化时打日志/置 `conn_status`，由 FDE 决定是否重新「拉取工具」。
- 默认 `mcp.health.enabled=false`：MVP 阶段连接探测靠注册侧显式动作足矣；需要时一键开启。

```java
@Scheduled(cron="${mcp.health.cron:0 0/5 * * * *}")  // enabled=false 时方法首行直接 return
```

---

## 8. 配置项（`mcp.*`，遵循现有 application.yml 风格）

```yaml
# ===== 真实 MCP 运行时（外呼，全部配置化；密钥走 application-local.yml/环境变量，严禁硬编码）=====
mcp:
  enabled: ${MCP_RUNTIME_ENABLED:true}     # 运行时总开关；false = McpToolExecutor 退回占位（TOOL_NOT_CONNECTED），对话零回归
  connect-timeout-ms: 10000                # 握手(initialize/list)连接超时
  call-timeout-ms: 30000                   # tools/call 调用超时
  result:
    max-chars: 8000                        # 回灌模型的 data.text 最大字符数；超长截断并追加「…(结果过长已截断…)」，防 token 爆炸（§4.2 ②）
  session:
    idle-minutes: 30                       # 会话空闲清理阈值
    cleanup-fixed-delay-ms: 300000         # 清理巡检间隔（5min）
  health:
    enabled: ${MCP_HEALTH_ENABLED:false}   # 连接巡检总开关（默认关，保守）
    cron: "0 0/5 * * * *"                  # 巡检周期
  auth:                                    # 密钥别名 → 真实值（仅在 application-local.yml/环境变量注入，本文件不写明文）
    # MCP_CRM_TOKEN: ${MCP_CRM_TOKEN:}     # 示例：别名 = 环境变量
```

`McpProperties`（`@ConfigurationProperties("mcp")`）绑定，校验非负超时（参考 `TaskProperties` 范式）。

---

## 9. 前后端接口契约（升级点）

详见 [`docs/api/MCP真实运行时-接口契约.md`](../api/MCP真实运行时-接口契约.md)。前端 `AdminMcp.vue` / `McpEditor.vue` 升级需要：

1. **测试连接按钮**（McpEditor）→ `POST /api/fde/connectors/mcp/test-connection`，回显 `ok/protocolVersion/serverVersion/latencyMs` 或脱敏失败。
2. **拉取工具按钮**（McpEditor）→ 已存用 `POST /api/fde/connectors/mcp/{id}/fetch-tools`；草稿用 `POST /api/fde/connectors/mcp/fetch-tools`，把返回 `tools[]` 灌入工具录入区（保留 FDE 填的 `bizName`）。
3. **连接状态字段**：`detail`/`list` 响应新增 `connStatus`(unknown/ok/failed)、`protocolVersion`、`serverVersion`、`lastCheckedAt`；列表加「连接」状态标签（绿/灰/红）。

> **📌 校准标注（2026-07-17）**：上述第 2 点「保留 FDE 填的 `bizName`」已被 V75 取代——工具清单只读化，`bizName ≡ name` 为派生值，编辑器仅可标注 `writeClass`。详见《设计文档校准审计-20260717.md》。

DTO 变更（均为 **record，新增字段须同步所有构造点**，见 §6）：
- `McpDefDetailVO` 新增 `connStatus / protocolVersion / serverVersion / lastCheckedAt`。
- `McpDefListItem` 新增 `connStatus / lastCheckedAt`（沿用 Sprint2.1 既有 `referencedBySkillCount` 等字段，本次**仅新增连接相关字段**）。
- 新增 `McpTestConnRequest`（草稿 transport/endpoint/authConfig）、`McpTestConnVO`、`McpFetchedToolsVO`。

**菜单解禁（前端，配合本功能上线）**：现 `frontend/src/layouts/AdminLayout.vue` 的 MCP 菜单项 `{ index: 'AdminMcp', ..., soon: true }`（第 18 行）标着「即将上线」占位标签。本功能落地后须**去掉该项的 `soon: true`** 解禁入口，并把 `AdminMcp` 页面的「占位/即将上线」副标题文案改为正式说明（与 AdminSkills/AdminExperts 已上线页范式一致）。

> **📌 校准标注（2026-07-17）**：`AdminMcp` 独立菜单/页面已不存在——连接器入口已收口为 `AdminConnector` 页内 Tab（MCP/API/业务系统，见 `frontend/src/router/index.js` 与 `AdminConnector.vue`），本段「去 soon 解禁」描述为历史形态。详见《设计文档校准审计-20260717.md》。

---

## 10. 实施切分（供 PM 派发）

### 后端任务（依赖顺序）

| # | 任务 | 依赖 | 风险点 |
|---|------|------|--------|
| B1 | **V14** 迁移（`V14__mcp_runtime.sql`，当前最新已是 V13）+ `McpDef` 实体加 4 字段；`McpProperties` 配置类 + application.yml `mcp.*` | — | 低；迁移只增列。**勿用 V13（已占用）** |
| B2 | `McpRpc`（JSON-RPC 报文 + `extractJsonBody`）+ `McpTransportException` + `McpSession` | — | SSE/JSON 兼容解析边界 |
| B3 | `McpTransport` SPI + `StreamableHttpTransport`（RestClient + auth header）+ `McpAuthResolver` | B2 | 鉴权别名解析、超时、不泄露 endpoint |
| B4 | `McpSessionManager`（分段锁复用 + 失效 + 空闲清理 `@Scheduled`） | B3 | 并发锁粒度（勿全局 synchronized）|
| B5 | `McpToolExecutor`（type=MCP）替换 `UnconnectedMcpToolExecutor`；content→ToolResult 映射 + 错误码语义 | B4 | **契约零改**；错误信息脱敏；占位降级路径 |
| B6 | `McpProvisionService` + 3 个 REST 端点（test-connection / fetch-tools×2）+ 回填 `tools_cache`/状态 + 审计 | B3 | 草稿测试鉴权脱敏、tools_cache 合并保 bizName |
| B7 | `McpHealthScheduled`（默认关）+ DTO 扩展（detail/list 连接字段，**同步改 record 构造点**） | B1,B3 | 巡检不自动改 status |
| B8 | 单测（见下方测试约束） | B5,B6 | 覆盖率 ≥70%；契约回归用例 |

**B8 测试约束（红线，必须遵守）：**

- **禁止引入 `MockWebServer` / `OkHttp` / `WireMock`** 等任何新测试/网络依赖（违反「不擅自新增技术栈」红线，且 MockWebServer 会拖入 OkHttp）。
- `StreamableHttpTransport` 的外呼测试用 **Spring `MockRestServiceServer`**（`spring-test` 自带，绑定到 `RestClient.Builder` / 底层 `RestTemplate` 的 request factory）—— 以此 mock HTTP 端点，断言请求报文（method/headers/body）与响应解析。
- 报文构造（`McpRpc`）、`extractJsonBody`（SSE/JSON 兼容）、`content[]→ToolResult` 映射、错误码分类、`splitMcpCode` 解析、会话复用/失效——用**纯单测 + Mockito stub**（stub `McpTransport` SPI / `McpDefRepository`），不触网。
- 契约回归用例：断言 `McpToolExecutor` 仍只实现既有 `ToolExecutor` 接口、`ToolResult` 形状不变。

### 前端任务

| # | 任务 | 依赖 |
|---|------|------|
| F1 | `api/admin.js` 增 `testMcpConn / fetchMcpTools / fetchMcpToolsDraft` | 契约定稿 |
| F2 | `McpEditor.vue`：测试连接按钮 + 拉取工具按钮（草稿/已存分支）+ 工具区灌入合并 | F1 |
| F3 | `AdminMcp.vue`：列表新增「连接」状态标签 + detail 连接元信息展示 | F1 |
| F4 | 前端单测（连接态渲染、拉取灌入、失败提示脱敏不露 endpoint）| F2,F3 |

### CR 派发建议（按 CLAUDE.md 矩阵）

- B1~B8 后端代码 → 架构师 CR（分层/契约不变/错误脱敏/并发）。
- B5 `McpToolExecutor`（含 MCP 外呼）→ AI 专家 + 架构师 CR（错误回灌→模型可懂、content→data 映射是否利于模型消费、observability 埋点）。
- F1~F4 前端 → 架构师 CR。
- 前后端契约（test-connection/fetch-tools 字段）→ 前后端交叉 CR。

---

## 11. 待 PM/用户拍板或确认的歧义点（均**非阻塞**，本方案已给默认决策可先开工）

1. **Skill 级 MCP 凭证隔离**：`SkillMcpRef.config` 本轮运行时不消费（鉴权取 `mcp_def` 全局值）。若客户需要「同一 MCP 在不同 Skill 用不同账号/凭证」，需扩展运行时按 `(skillId, mcpCode)` 解析凭证——但运行时 toolCode 当前**不带 skillId**（`mcp__{mcpCode}__{toolName}`），届时需在 run 上下文传 skillId 反查。**建议本轮按全局凭证落地（YAGNI）**，需求确认后再迭代。
2. **stdio 是否真做**：本方案结论为「SPI 预留、不实做，运行时遇 stdio 返回不支持占位」。若已有非容器化本地 MCP 接入诉求，请 PM 确认是否提前实做。
3. **巡检默认开关**：本方案默认 `mcp.health.enabled=false`（注册侧显式探测足够）。若运维要求「后台常态显示连接健康」，可改默认 `true`。
4. **多 `data:` 行 SSE 帧**：本轮只取首个 `data:` 行（单帧 JSON-RPC 足够，对齐参考资料）。极少数分帧响应的 MCP 暂不兼容，列为已知边界，遇到再补。
5. **`tools/call` 结果回灌与非文本类型**（已落 §4.2，此处记录边界）：
   - 本轮 `data` **只放 `text`**（拼接所有 `type=text`），**不再回灌 `content` 结构化原文**——消除重复回灌、token 翻倍。结构化原文如需排障落日志/trace。
   - `data.text` 受 `mcp.result.max-chars`（默认 8000）截断，超长追加「…（结果过长已截断，如需完整数据请缩小查询范围）」。**默认 8000 的合理性待真实工具上线后据上下文预算/实际输出体量复盘调参**（配置化，可随时改，非阻塞）。
   - 非文本类型（image/audio/resource）当前**不解析回灌**，仅在 `data.text` 为空时以兜底短语提示「返回了图片/资源类内容，当前版本暂不支持解析」。若未来有图像类 MCP 工具诉求，需 AI 专家定多模态回灌方案。

---

## 12. 硬约束自检（交付前对照）

- [x] `ToolExecutor` / `ToolInvocation` / `ToolResult` / 编排器 act 路径 / `/api/internal/tool/execute` **一行不改** —— McpToolExecutor 仅实现既有接口。
- [x] 不引入新技术栈/依赖 —— 复用 Spring `RestClient`（同步）、JDK time、Caffeine 无需、Flyway、`JsonUtil`、`@Scheduled`；无 OkHttp/Reactor/Mongo/Redis。
- [x] 简洁 —— 同步 callTool，无 Flux/流式/调用统计增量/独立日志表。
- [x] 安全 —— 错误 message 脱敏（不含 endpoint/堆栈）；密钥别名引用，不明文落库/日志。
- [x] toolCode 解析 —— 已核源码确认自包含 `mcp__{mcpCode}__{toolName}`，`splitMcpCode`+`findByCode` 即得，无歧义。
