# 全线 ID 改造 · B4 · 存量凭证重加密任务设计（受控启动期 data-fix · 唯一不可逆段）

> 归属：B4 切片的**不可逆核心**（PM 亲写，区别于 V52 的可逆 PK/FK 迁移）。落地形态：**受控启动期 Java data-fix**（非 Flyway，因需注入 `CredentialCryptoService`+`KeyProvider`、需 AES-GCM 逻辑）。设计依据：主设计 §5.3 / §5.5 / §8.0u、铁律 1 / 1′。

## 0. 前提与触发

- **前置**：V52 已跑（三父表 PK 切 VARCHAR、四 FK 列切 VARCHAR、三张 `id_map_*` 与各 `*_old` 回滚列就绪）；`id_map_app_user`（Bu 产）保留。`CredentialCryptoService.encrypt/decrypt` 已改 `(String, String)` AAD 签名。
- **触发**：`@Component` + `ApplicationRunner`（或显式 endpoint），**默认关闭**，仅当 `app.migration.b4-reencrypt.enabled=true` 才执行；执行前校验 `app.migration.b4-reencrypt.backup-confirmed=true`（无备份确认不启动，对应 §5.3 P1）。
- **不触碰 live 库**：与 B1~B3 同——交付=实现 + H2 + 真 PG throwaway 验收；live `ai_assistant` 停 V47。

## 1. 三类密文与新旧 AAD

| 类 | 存储列 | 旧 AAD（数字）| 新 AAD（字符串）| 旧 id 来源 | 新 id 来源 |
|---|---|---|---|---|---|
| 业务凭据 | `user_biz_credential.credential_cipher`(TEXT) | `user_id_old \| biz_system_id_old` | `user_id \| biz_system_id`（`usr_`\|`bz_`）| 行内 `*_old` 列（Bu 切 user_id、V52 切 biz_system_id 均留 old）| 行内正式列 |
| MCP env | `mcp_def.env_config`(JSONB，每 value 密文)| `id_old \| "-1"` | `id \| "-1"`（`mc_`\|"-1"）| `mcp_def.id_old` | `mcp_def.id` |
| API 密钥 | `api_def.auth_config.valueCipher` | `"0" \| id_old` | `"0" \| id`（"0"\|`ap_`）| `api_def.id_old` | `api_def.id` |

- **AAD 字节等价铁律**：旧 AAD 用 `String.valueOf(oldLong)`（如 `"7"`），与历史 `Long` 拼接的 `7|3` UTF-8 字节**逐字节相同** → 旧密文可解。域常量段 `-1`/`0` 新旧不变。
- **单迁主键 vs 双段**：mcp/api 的 AAD 只有单个会迁移主键（自身 id）+ 固定域常量 → 铁律 1（同片）。user_biz_credential 双段（userId=Bu、bizSystemId=B4）→ 铁律 1′，两 id_map/两 `*_old` 齐备后**一次**重加密（不双重）。

## 2. 逐条流程（§5.3 全护栏）

对每条密文（三类各自遍历）：

1. **幂等前置**：先用**新 AAD** 尝试 `decrypt`。成功 ⇒ 该条已重加密（或本就新），**跳过**（计 skipped）。失败 ⇒ 进入 2。
   - 幂等靠"新 AAD 能否解开"判定，**无需标记列**；任务可安全重跑。
2. **旧 AAD 解密**：用旧数字 AAD `decrypt` → 明文。失败 ⇒ **两种 AAD 都解不开**：硬错误（密文损坏/未知），**中止整个任务 + 事务回滚**（不写任何一条），并记录定位信息（列/主键/keyAlias，绝不带明文密钥）。
3. **新 AAD 加密**：用新字符串 AAD `encrypt` → 新密文。
4. **双校验（强制）**：立即用**新 AAD** `decrypt` 新密文，断言可解 **且明文 == 步骤 2 明文**。任一不成立 ⇒ 中止 + 回滚。
5. 写回（TEXT 直写 / JSONB 逐 value 重组后整列写）。

- **事务边界**：整个任务单事务（或分类事务），任一条失败 → 全回滚，不留半迁态。
- **计数核对**：结束打印 `总数 / 已跳过(幂等) / 重加密 / 失败`，三类分别列。失败>0 即整体失败。
- **冻结**：窗口内 `hostCredential` 保持冻结（Bu 起）；api/mcp admin 写入在维护窗口停。任务成功后由 PM 解冻 hostCredential（去 FORBIDDEN）。

## 3. 幂等/重入语义（关键）

密文格式 `keyAlias:iv:cipher` 不含 AAD，无法凭外观判断是否已迁。**"先试新 AAD 解"**即幂等探针：
- 已迁行：新 AAD 解得开 → skip。
- 未迁行：新 AAD 解不开、旧 AAD 解得开 → 迁。
- 坏行：两者都解不开 → abort。
→ 重跑安全、无二次加密、无标记列污染。

## 4. 验收（真 PG throwaway，加入 FreshPgFlywayVerifyManualTest 或独立 gated 测试）

构造"旧 AAD 密文 + 已切字符串主键 + 保留 old 列"的合成行，跑任务，断言新 AAD 可解且明文一致：
1. 选旧数字（如 userId_old=7, bizId_old=3；mcpId_old=11；apiId_old=22）。
2. 用 crypto（String 签名）以旧 AAD 字符串（`"7","3"` / `"11","-1"` / `"0","22"`）加密已知明文，得旧密文。
3. INSERT 三类合成行：正式列=新字符串 id（`usr_x`/`bz_y`/`mc_z`/`ap_w`），`*_old` 列=旧数字，密文=旧密文。
4. 跑重加密任务。
5. 断言：用新 AAD（`usr_x|bz_y` / `mc_z|-1` / `0|ap_w`）`decrypt` 三类新密文均成功且 == 原明文；再跑一次任务应全 skip（幂等）。

## 5. 回滚

- 任务未清备份前：整体可逆（恢复 pg_dump）。清备份后进入不可逆（§5.3 P1，单独谨慎操作、PM 确认）。
- 任一条解密/双校验失败：任务自身事务回滚（未写任何行）+ 保留备份即可整库还原。
