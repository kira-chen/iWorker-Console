# AI 调用韧性设计：跨 provider fallback / 轻量熔断 / cost 埋点 / 直答路 tier-params

> **📌 校准标注（2026-07-17）**：网关/Provider 执行层（LlmGateway / OpenAiCompatibleProvider / CircuitBreakerRegistry 等）已随主版本运行时剥离**移出本仓**（随岗位包下发客户端运行时），故 §0 取证表中的 file:line 在本仓不再可核，全文执行层改造章节属剥离前历史。配置/数据层已按本设计落地并存活于本仓：`LlmProperties.Router.fallbackChain`（fallback-chain 配置）、`LlmProperties.Pricing`、`llm_call_log.cost/currency`（LlmCallLog）。注：路由层 ModelRouter.resolveFallbacks / ProviderBinding.fallbacks 亦曾按本设计落地，但作为剥离后无消费方的空挂代码，已在 2026-07-17 死代码清理中删除（工作区改动）。详见《设计文档校准审计-20260717.md》。
>
> 作者：架构师（主笔适配层接口/边界）。策略侧由 AI 专家 CR。
> 本文**只出设计，不改代码**。所有落点均标注证据（文件:行）。
> 上位契约：`docs/architecture/ai-adapter/适配层接口契约.md`（§5 韧性、§4 配置化、§8 埋点）
> 策略输入：`docs/architecture/ai-adapter/适配层策略输入.md`（触发-动作矩阵、单价表）

---

## 0. 现状取证（实读代码）

| 能力 | 现状 | 证据 |
|------|------|------|
| 跨 provider fallback | **未实现**，backlog | `LlmGateway.java:33-35` 类头 javadoc 明示"未实现属 backlog"；`chat` 只在同 binding 循环重试 `LlmGateway.java:77-97` |
| 熔断 | **未实现** | `LlmProperties.Resilience` 无熔断字段（`LlmProperties.java:294-346`）；契约 §5:172 有承诺 |
| fallback 配置 | **无** | `Router` 只有 `defaultProvider` + `defaultTierModel` + `tierParams`（`LlmProperties.java:120-151`）；`ProviderBinding` 只有 `(providerName, modelId, timeoutMs)`（`ProviderBinding.java:6`） |
| 响应字段位 | **已预留** | `LlmResponse` 已有 `fallbackUsed / fallbackHop / circuitBroken`（`LlmResponse.java:16-18`），当前 `ok()` 恒传 `false,0,false`（:24-27）——**契约位已在、只是没人写值** |
| 直答路 tier-params | **未消费** | `DirectAnswerSupport.buildRequest` 传 `InferenceParams.empty()`（`DirectAnswerSupport.java:147`）→ provider `buildRequestBody` 中 `p` 各字段全 null → 不下发 `max_tokens`（`OpenAiCompatibleProvider.java:362-379`），直答路存在 token 敞口 |
| tier-params 唯一消费方 | 仅 Python 下发 | `InternalLlmBindingController.resolveParams`（`InternalLlmBindingController.java:65-81`）；Java 侧 chat 从不读 `router.tier-params` |
| Usage.cost | 恒 0 | `Usage.estimatedCost` 恒 `0.0`；provider 两处构造 `new Usage(...,0.0)` 带 TODO（`OpenAiCompatibleProvider.java:402-403`、`:244`） |
| RestClient | 每请求重建 | `chat`/`embed` 每次 `restClientBuilder...build()`（`OpenAiCompatibleProvider.java:96-100`、`:439-443`） |
| 错误归一 | 已就绪 | provider 已把异常归一为 errorCode（`OpenAiCompatibleProvider.classifyError` :532-552、`classifyHttpStatus` :280-291）；Gateway `retryable()` 判可重试（`LlmGateway.java:400-409`）——**fallback 复用同一归一，无需新建分类** |

**关键结论**：契约与响应模型均已为 fallback/熔断预留位，实现是"填空"而非"重构"。改动集中在 `LlmGateway`（编排）、`ModelRouter`（解析 fallback 链）、`LlmProperties`（配置）、`OpenAiCompatibleProvider`（cost 计算 + client 缓存），provider 的 `chat/chatStream/embed` 签名不变。

---

## 1. 跨 provider fallback

### 1.1 配置形态

在 `LlmProperties.Router` 新增按 tier 的 fallback 链（与现有 `defaultTierModel` 同构，复用 `"provider:model"` 解析）：

```yaml
llm:
  router:
    default-provider: iflytek
    default-tier-model:
      ORCHESTRATE: xopqwen35v35b
    # 新增：tier → 有序 fallback 链（主链路失败且 retryable 时依次尝试）
    fallback-chain:
      ORCHESTRATE:
        - deepseek:deepseek-chat        # 复用 iflytek 记忆里"deepseek 保留作 fallback"的意图
        - iflytek:xopdeepseekv4flash    # 也可同 provider 换模型
  resilience:
    fallback:
      enabled: false                    # 【零回归红线】默认关，行为与现状字节级一致
      max-hops: 2                        # 最多切几个 fallback（防雪崩链过长）
```

- 链元素沿用 `ModelRouter` 现有 `"provider:model"` / `"model"` 解析（`ModelRouter.java:43-49`），无新语法。
- `fallback-chain` 未配置或 `enabled=false` → 零 fallback，**主链路走原路径**。

### 1.2 ProviderBinding 扩展（不破坏现有构造）

`ProviderBinding` 增加一个 `fallbacks` 字段，**新增 record 分量 + 保留旧 3 参兼容构造**（`InternalLlmBindingController.java:48` 等仅用前 3 个访问器，不受影响）：

```java
public record ProviderBinding(String providerName, String modelId, int timeoutMs,
                              List<ProviderBinding> fallbacks) {
    // 兼容旧 3 参：fallbacks 缺省空
    public ProviderBinding(String providerName, String modelId, int timeoutMs) {
        this(providerName, modelId, timeoutMs, List.of());
    }
}
```

`ModelRouter.resolve` 在 `fallback.enabled=true` 时解析 tier 的 `fallback-chain` 为 `List<ProviderBinding>` 挂到主 binding；否则返回空链（现状）。解析同样做 `providers.containsKey` 校验（复用 `ModelRouter.java:55-57`），配错的 fallback 项启动即暴露/跳过（见开放问题 Q4）。

### 1.3 Gateway 编排（chat）

在 `LlmGateway.chat` 现有"同 binding 退避重试"循环之外，包一层 fallback 遍历。伪代码（保持现有内层重试/埋点不动）：

```
bindings = [主binding] + (fallback.enabled ? 主binding.fallbacks : [])   // enabled=false → 仅主，零回归
hop = 0
for binding in bindings:
    try:
        resp = 现有内层重试循环(binding)          // 完全复用 LlmGateway.java:77-97
        标记 resp.fallbackUsed=(hop>0), fallbackHop=hop   // 填 LlmResponse 已有的位
        if hop>0: log.info + 落 fallback 触发埋点
        return resp
    catch LlmException e:
        last = e
        if !retryable(e): break        // 4xx/鉴权错——换 provider 也没用，直接终止（对齐契约 §5:165）
        if hop == 最后一个: break
        hop++                          // 切下一个 fallback（退避已在内层消耗，此处立即切）
throw last                             // 全链耗尽 → 抛 LlmException（现状同）
```

要点：
- **零回归红线**：`fallback.enabled=false` 时 `bindings` 只含主 binding，外层循环仅 1 次，等价现状。**且 `LlmResponse.fallbackUsed/hop` 保持 `false/0`（provider `ok()` 已如此）**，无字节差异。
- **切换条件**：仅当同 binding 内层重试耗尽 **且 `retryable(e)`** 才切下一个（复用 `LlmGateway.java:400-409`）。`LLM_AUTH_ERROR`/`LLM_BAD_REQUEST` 不 fallback（换家也是同样的参数/鉴权错）。契约 §5:166 要求 429「立即切 fallback」——本设计**在内层重试耗尽后切**（内层对 429 已有更长退避 `backoffFor` :415-421）；是否对 429 短路内层直接切，列为开放问题 Q5（避免第一版过度设计）。
- **cost/usage**：命中 fallback 的响应仍走既有 `saveChatLog`，`vendor/model` 自然记成 fallback 的 provider（埋点天然区分）。

### 1.4 三路边界（chat / chatStream / embed）

| 路径 | 是否纳入 fallback | 理由与边界 |
|------|------------------|-----------|
| `chat`（同步） | **是** | 一次性响应，切换无副作用 |
| `chatStream`（流式） | **仅"首 token 前"可切** | `emittedAny=true` 后已向前端吐字，**不可回滚重发**（`OpenAiCompatibleProvider.java:167,201`、`DirectAnswerSupport.java:115-131` 已按 emittedAny 分流）。设计：流式 fallback **只在 provider 抛异常且尚未吐字时**切下一个 binding；一旦 `emittedAny=true` 的异常，直接抛给上层走"优雅收尾"（现状 `DirectAnswerSupport.answerStream` 已处理）。**首版建议流式 fallback 默认关**（`fallback.stream-enabled=false`），仅同步/embed 先上，降低流式复杂度（开放问题 Q3）。 |
| `embed` | **可选，建议开** | 无吐字问题，但 embedding 换 provider 有**维度/模型一致性风险**：fallback 模型维度须与 `embedding.dimensions` 一致，否则命中 `EMBED_DIM_MISMATCH`（`LlmGateway.java:290-297`）。设计：embed fallback 链元素须同维度；`EMBED_DIM_MISMATCH` **不触发 fallback**（配错不是瞬时故障，`LlmGateway.java:306` 已 break）。召回路 `-query`（maxRetries 覆盖=0 快失败，`LlmGateway.java:279-280`）**不走 fallback**（召回静默降级更合适），仅离线 index 路走。列开放问题 Q6。 |

---

## 2. 轻量熔断（自研，无新依赖）

### 2.1 目标与形态

连续失败达阈值 → 短路该 provider T 秒，期间**直接跳过它走 fallback / 快速失败**，避免持续打死机端点、堆积超时。**不引入 Resilience4j**，用 JDK `ConcurrentHashMap` + 原子计数自研。

### 2.2 数据结构（per-provider 粒度）

新增 `CircuitBreakerRegistry`（`@Component`，`llm.gateway` 包）：

```java
// key = providerName（per-provider；粒度足够，binding 内 model 差异不单独熔断）
ConcurrentHashMap<String, CircuitState> states;

class CircuitState {  // 每字段用 volatile / AtomicInteger 保证可见性与原子
    volatile Status status = CLOSED;          // CLOSED / OPEN / HALF_OPEN
    AtomicInteger consecutiveFailures;        // 连续失败计数
    volatile long openedAtMillis;             // 进入 OPEN 的时刻
    AtomicBoolean halfOpenProbeInFlight;      // 半开只放一个探测请求
}
```

线程安全：状态迁移用 CAS（`compareAndSet`），计数用 `AtomicInteger`，`status/openedAt` 用 `volatile`。全内存、无锁、单机（首版单实例，多实例状态不共享——可接受，见开放问题 Q7）。

### 2.3 状态机

```
CLOSED  --连续失败 >= failure-threshold（仅计入 retryable 的 5xx/超时/限流）--> OPEN
OPEN    --距 openedAt 已过 open-seconds--> HALF_OPEN（放行 1 个探测）
HALF_OPEN --探测成功--> CLOSED（清零计数）
HALF_OPEN --探测失败--> OPEN（重置 openedAt）
CLOSED  --任一成功--> 计数清零
```

- 只有 `retryable(e)` 的失败（`LLM_TIMEOUT/SERVER_ERROR/RATE_LIMITED/UNKNOWN`）计入熔断；`LLM_AUTH_ERROR/BAD_REQUEST`（配置/参数错）**不计**（熔断解决不了它们，且会误伤）。
- **半开幂等**：`halfOpenProbeInFlight` 用 CAS 抢占，只放一个探测请求，其余请求视同 OPEN 直接短路。

### 2.4 与 fallback 的接入点

在 §1.3 的 bindings 遍历中，每次取 binding 前先问熔断器：

```
for binding in bindings:
    if breaker.isOpen(binding.providerName):     // OPEN 且未到半开窗 → 跳过该 provider
        记熔断短路埋点; continue（直接尝试下一个 fallback）
    try:
        resp = 内层重试循环(binding)
        breaker.onSuccess(binding.providerName)   // 清零 / 半开→关
        return ...
    catch LlmException e:
        if retryable(e): breaker.onFailure(binding.providerName)  // 计数++，达阈值→开
        ...（同 §1.3 切换逻辑）
```

- **零回归红线**：`circuit-breaker.enabled=false`（默认）时 `isOpen` 恒 false、`onFailure/onSuccess` no-op，遍历行为完全等价 §1.3；`fallback` 与 `circuit` 都关时等价现状。
- 熔断**独立开关**，可单独启用（即使 fallback 关，熔断也能让某 provider 短路后快速失败，不空等超时）。

### 2.5 配置

```yaml
llm:
  resilience:
    circuit-breaker:
      enabled: false            # 【零回归红线】默认关
      failure-threshold: 5      # 连续失败几次开闸（契约 §5:150 建议 5）
      open-seconds: 30          # 开闸后短路时长（契约建议 30）
      half-open-probes: 1       # 半开放行探测数（首版固定 1）
```

---

## 3. 可观测：fallback / 熔断 / cost 埋点

### 3.1 fallback / 熔断埋点

全部落到既有 `llm_call_log`（`LlmCallLog.java`），**复用现有 `saveChatLog/saveEmbedLog` + `metadata`（JSONB）字段**（`LlmCallLog.java:72-74`），无需新表：

| 事件 | 落点 | 字段 |
|------|------|------|
| 命中 fallback | 成功那条 log 的 `metadata` | `{fallbackUsed:true, fallbackHop:2, primaryProvider:"iflytek"}`；`vendor`=实际命中 provider |
| 熔断短路跳过 | 一条 warn 日志（+ 可选 metadata `circuitBroken:true`） | provider / status / openedAt |
| 熔断开合迁移 | `log.warn/info` 事件（`CircuitBreakerRegistry` 内） | provider / CLOSED→OPEN→HALF_OPEN |

`saveChatLog` 已支持传 `metadata`（`LlmGateway.java:169-171,185-187`）——只需在命中 fallback 时构造这个 map 传进去，改动极小。

### 3.2 cost 埋点（兑现 `Usage.cost` TODO）

**单价表配置化**（`LlmProperties` 新增 `pricing`），Java 侧算 cost 落库：

```yaml
llm:
  pricing:
    # key = "provider:model"；单位 元/千 token（或美元，单位由 AI 专家定，见 Q1）
    "iflytek:xopqwen35v35b": { prompt: 0.001, completion: 0.002 }
    "deepseek:deepseek-chat": { prompt: 0.001, completion: 0.002 }
    currency: CNY
```

**接入点**：在 provider `parseResponse`（`OpenAiCompatibleProvider.java:397-404`）目前构造 `new Usage(prompt, completion, 0, 0.0)` 的位置计算 cost —— **但单价表属配置、provider 不宜持配置耦合**。更干净的落点是**在 `LlmGateway.saveChatLog` 落库前统一算 cost**：

```
cost = pricing.get(vendor+":"+model)  // 命中则 (promptTokens/1000*prompt + completionTokens/1000*completion)，未命中记 null/0 + metadata:{pricingMissing:true}
row.setCost(cost)  // 需给 LlmCallLog 加一列 cost（DB 迁移，见实施 D）
```

理由：cost 依赖 `vendor+model+token`，这三者在 Gateway 落库时都齐备，且 Gateway 已持有 `LlmProperties`（`LlmGateway.java:44,51`）。provider 的 `Usage.estimatedCost` 可保持 0（或后续同步），**cost 单一权威在 Gateway 落库口径**，避免两处算。流式 usage 兜底（估算/缺失）时，cost 相应标 `usageEstimated/usageMissing`（`resolveStreamUsage` 已产出这些 metadata，`LlmGateway.java:212-237`），成本报表据此区分真实/估算/缺失。

> DB：`llm_call_log` 现无 cost 列 → 需加 `cost NUMERIC` + `currency`（迁移脚本）。`LlmCallLog` 加对应字段。列开放问题 Q1（单价来源/币种/是否精确计费）。

---

## 4. 直答路 tier-params 消费（堵 token 敞口，兑现 javadoc）

### 4.1 问题

`DirectAnswerSupport.buildRequest` 传 `InferenceParams.empty()`（`DirectAnswerSupport.java:147`）→ provider 不下发 `temperature/top_p/max_tokens`（`OpenAiCompatibleProvider.java:362-379`），直答路（simple/knowledge）**无 max_tokens 上限**，token 成本敞口；且与 Python 侧 `router.tier-params` 下发（`InternalLlmBindingController.java:65-81`）**不同源**。

### 4.2 方案：Gateway 统一回填（不改各调用方显式传参）

在 `LlmGateway`（chat/chatStream 解析 binding 后、构造 `ProviderCall` 前）做**字段级回填**：`InferenceParams` 中为 `null` 的字段，用 `router.tier-params.get(tier)` 补上；**非 null 的字段保持不变**。

```
tp = props.getRouter().getTierParams().get(request.tier().name())   // 可空
effectiveParams = merge(request.params(), tp):
    temperature = params.temperature ?? tp.temperature
    topP        = params.topP        ?? tp.topP
    maxTokens   = params.maxTokens   ?? tp.maxTokens
    // timeoutMs / maxRetries / responseFormat 不受 tierParams 影响（tierParams 无这些字段）
用 effectiveParams 重建 LlmRequest 传下去
```

要点：
- **只回填 null，不覆盖显式值** → intent 分类（显式 `maxRetries=0`、可能显式 temperature）、title 生成、memory 抽取各自的**显式传参一律优先**，不被破坏。
- 直答路 `InferenceParams.empty()` 各字段全 null → 全部由 ORCHESTRATE 档 tier-params 回填，拿到 `max_tokens`，敞口封堵。
- **单一事实源**：Java chat 与 Python 下发（`InternalLlmBindingController`）现在**读同一份 `router.tier-params`**，口径统一，兑现契约 §3.1。
- **落点选 Gateway 而非 DirectAnswerSupport**：让所有 tier（不止直答）都受益，且 provider 层无需感知 tier（保持 provider 纯粹）。
- **零回归红线**：`router.tier-params` 若某 tier 未配置 → `tp=null` → 回填 no-op，`effectiveParams == request.params()`，行为等价现状。因此**上线此项前，须先在配置里为各 tier 补 tier-params**（尤其 ORCHESTRATE 的 max_tokens），否则只是"接线"不产生实际约束。

---

## 5. RestClient 缓存（可选优化）

### 5.1 现状与可行性

`chat`/`embed` 每请求 `restClientBuilder...requestFactory(...).build()`（`OpenAiCompatibleProvider.java:96-100,439-443`），`RestClient` 本身线程安全、可复用，重建有微开销（主要是 requestFactory/连接池初始化）。

### 5.2 方案：按 (providerName, timeoutMs) 缓存

```java
ConcurrentHashMap<CacheKey, RestClient> clientCache;   // key = (providerName, timeoutMs)
// 首次 computeIfAbsent 构建（含该 timeout 的 requestFactory + Authorization header）
```

**边界与风险**：
- key 必须含 `timeoutMs`（不同场景短/长超时不同，`effectiveTimeout` :367-372、embed query/batch :273-274 会给不同值），否则超时串味。
- **api-key 若热更**（`application-local.yml` 改 key 重启）——重启即清缓存，无问题；运行时热更 key 的场景当前不存在，不考虑。
- key 也可含 baseUrl（防同 provider 名改 baseUrl），但 provider 名→baseUrl 一对一且重启生效，`(providerName,timeoutMs)` 足够。
- **收益有限、风险低**：列为**最低优先级**，可最后做或不做。流式 `chatStream` 用 JDK `HttpClient`（`OpenAiCompatibleProvider.java:152`）同理可缓存，但流式量小，暂不动。

---

## 6. 配置化清单与默认值（零回归优先）

| 配置项 | 默认 | 说明 |
|--------|------|------|
| `llm.resilience.fallback.enabled` | **false** | 默认关 → 零回归 |
| `llm.resilience.fallback.max-hops` | 2 | 防链过长 |
| `llm.resilience.fallback.stream-enabled` | **false** | 流式 fallback 首版建议关 |
| `llm.router.fallback-chain.<TIER>` | 空 | 无配置=无 fallback |
| `llm.resilience.circuit-breaker.enabled` | **false** | 默认关 → 零回归 |
| `llm.resilience.circuit-breaker.failure-threshold` | 5 | 契约 §5 建议值 |
| `llm.resilience.circuit-breaker.open-seconds` | 30 | 契约建议值 |
| `llm.pricing.*` | 空 | 未配置=cost 记 null + metadata 标缺失 |
| `llm.router.tier-params.<TIER>` | 已存在 | §4 回填读它；**上线 §4 前须补齐各 tier（尤其 max_tokens）** |

**默认开关建议**：**fallback / 熔断首版默认关（enabled=false）**，保证合入即零回归、可灰度。理由：本项目当前**单主 provider（iflytek）+ deepseek 待作 fallback**，先把代码路径合入、配置就绪，再由运维在验证环境按 tier 开启、观测 fallback 率/熔断埋点后逐步放量。tier-params 回填与 cost 埋点**建议默认开**（它们无外部切换风险，只是把已有配置接上线 / 补一列 cost），但 tier-params 回填上线前须先补配置值（见 §4.2 红线）。→ 最终默认策略需 PM/用户拍板（开放问题 Q2）。

---

## 7. 实施切分（可独立落地，标零回归红线）

| 批次 | 内容 | 依赖 | 零回归红线 | 风险 |
|------|------|------|-----------|------|
| **A. 直答路 tier-params 回填** | §4：Gateway 字段级 merge + 补 tier-params 配置 | 无 | tier-params 未配置时 merge no-op；只回填 null 不覆盖显式值 | 低。**须先补 ORCHESTRATE max_tokens 配置**否则不生效 |
| **B. cost 埋点** | §3.2：`pricing` 配置 + `LlmCallLog` 加 cost 列 + DB 迁移 + Gateway 落库前算 cost | 无 | pricing 未配置=cost null，不影响主链路 | 中（DB 迁移）。单价来源待定（Q1） |
| **C. 跨 provider fallback** | §1：Router 解析 fallback 链 + ProviderBinding 扩展 + Gateway 外层遍历（chat；embed 可选） | 无（但与 D 协同） | `fallback.enabled=false` → 仅主 binding，字节级等价现状 | 中。流式边界须严守 emittedAny |
| **D. 轻量熔断** | §2：`CircuitBreakerRegistry` + 接入 §1 遍历 | C（接入点在 C 的遍历里）；可先做 registry | `enabled=false` → isOpen 恒 false，no-op | 中。线程安全（CAS/volatile/半开幂等） |
| **E. RestClient 缓存** | §5 | 无 | 纯优化，行为不变 | 低。最低优先级，可不做 |

**建议顺序**：A（快、独立、直接省钱）→ B（cost 可观测）→ C+D（fallback+熔断一批，熔断接入点在 fallback 遍历里，同批更自然）→ E（可选）。每批独立可回归、独立可灰度（各自 enabled 开关）。

**全局零回归红线**：
1. 所有新能力**默认 enabled=false 或配置为空即 no-op**，合入不改变现状行为。
2. `ProviderBinding` 新增分量**保留旧 3 参构造**，`InternalLlmBindingController` 等既有调用不改。
3. provider 三方法（chat/chatStream/embed）**签名不变**，fallback/熔断编排全在 Gateway 层。
4. 流式一旦 `emittedAny=true` **绝不切 fallback**（不可回滚重发）。
5. `EMBED_DIM_MISMATCH` / `LLM_AUTH_ERROR` / `LLM_BAD_REQUEST` **不触发 fallback、不计入熔断**（非瞬时故障）。
6. 每个批次须补/过既有测试：`LlmGatewayTest` / `LlmGatewayStreamTest` / `ModelRouterTest`（`src/test/java/com/aiassistant/llm/**`）默认关时全绿；新增 enabled=true 用例覆盖切换/熔断/回填/cost。

---

## 8. 开放问题（需 PM / AI 专家 / 用户拍板）

| # | 问题 | 建议 | 拍板人 |
|---|------|------|--------|
| Q1 | **cost 单价表来源与币种**：单价从哪来（vendor 报价页/合同价）、币种（CNY/USD）、是否需精确计费还是仅可观测估算？ | 首版仅"可观测估算"，单价表配置化由 FDE/运维维护；不做精确对账 | AI 专家 + 用户 |
| Q2 | **fallback/熔断默认是否开**：默认关（零回归、灰度）还是默认开（兑现 CLAUDE.md"每个核心 AI 调用必须有 fallback"口径）？ | 代码默认关，配置就绪后由运维按 tier 开；CLAUDE.md 口径与"默认关"的冲突需你确认 | 用户（涉 CLAUDE.md 口径） |
| Q3 | **流式 fallback 是否纳入首版** | 首版**不纳入**（`stream-enabled=false`），仅同步/embed；流式复杂度高、收益边际 | AI 专家 |
| Q4 | **fallback 链配错处理**：某 fallback provider 未定义时，启动即失败 vs 静默跳过？ | 启动校验 + warn，运行时跳过未定义项（不因一个坏 fallback 拖垮主链路） | 架构师内部可定，报备 |
| Q5 | **429 是否短路内层重试直接切 fallback**（契约 §5:166 要求"立即切"） | 首版仍走内层退避（已有更长退避），不额外短路；如实测限流频繁再优化 | AI 专家 |
| Q6 | **embedding 是否纳入 fallback**：召回路 vs 离线 index 路差异；fallback 模型维度须一致 | 仅离线 index 路走 fallback，召回 `-query` 路静默降级不切；fallback 模型须同维度 | AI 专家 |
| Q7 | **熔断多实例状态共享**：首版单机内存态，多实例部署时各实例独立熔断 | 首版单机内存态可接受；多实例再评估（Redis 共享或各自独立） | 架构师 + 运维 |

---

## 9. 附：涉及文件与改动性质（供实施定位）

| 文件 | 改动性质 |
|------|---------|
| `llm/config/LlmProperties.java` | 加 `Router.fallbackChain`、`Resilience.Fallback`、`Resilience.CircuitBreaker`、`Pricing`（纯配置类，加字段+getter/setter） |
| `llm/router/ProviderBinding.java` | 加 `fallbacks` 分量 + 兼容旧 3 参构造 |
| `llm/router/ModelRouter.java` | `resolve` 在 enabled 时解析 fallback 链（复用现有 provider:model 解析） |
| `llm/gateway/LlmGateway.java` | chat/embed 外层 fallback 遍历 + 熔断接入 + cost 落库前计算 + tier-params 回填；chatStream 首token前 fallback（或首版关） |
| `llm/gateway/CircuitBreakerRegistry.java` | **新增**：自研熔断器（无新依赖） |
| `llm/provider/OpenAiCompatibleProvider.java` | 填 `LlmResponse.fallbackUsed/hop`（或由 Gateway 覆写）；可选 RestClient 缓存 |
| `llm/log/LlmCallLog.java` + DB 迁移 | 加 `cost` / `currency` 列 |
| 测试 `llm/**` | 默认关全绿 + 新增 enabled 用例 |
