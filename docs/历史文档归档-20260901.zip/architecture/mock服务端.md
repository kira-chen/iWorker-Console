# 数字员工 CS · 服务端接口契约

> 🔒 **契约状态：V4.0（专家市场定版 · 2026-07-28）**。本版新增**专家市场独立接口**（`GET /api/market/experts` + `/experts/{id}/download`）——专家与岗位业务分层，专家自带独立技能/MCP/API、可被领用后 @ 委派；原有岗位市场 `GET /api/market/positions` 保留不变。新增 `expert.json` 下发物 schema（§2.7）与专家 ZIP 包结构（§2.7.1）。关联需求：F-080。逐版修订历史见 **§6**。
>
> 🔑 **全局鉴权口径（V3.5·A-2 拍板 2026-07-09）**：除 `POST /api/auth`（登录本身）外，**所有接口鉴权 = `Authorization: Bearer <token>` 请求头**（与真服务端一致）；请求体里的 `token` 字段为 mock 兼容过渡形态（客户端双带，服务端可忽略）。
>
> 📦 **岗位包附加下发物语义（2026-07-09 真服务端实测澄清）**：`external_apis.json`/`external_mcps.json` **仅当对应工具API/MCP 被该岗位的技能「关联」时才随包下发**（未关联=包里没有该文件=客户端按"该来源无下发"处理，整体替换语义下即撤空）；`cron_jobs.json` 按岗位配置有无；服务端同时会把关联 MCP 写进 config.yaml `mcp_servers` 段 + `enabled_toolsets`（双通道同步）。mock 不模拟"关联"逻辑、始终按 mock_data 文件下发——语义差异仅在"何时有"，文件格式两侧一致。
>
> 📌 **阅读对象 = 服务端 / 管理端开发**。**§1 接口契约 + §2 下发物结构契约**是要实现的对外约定；**§3 数据模型 / §4 mock 实现**是 demo 侧细节，真服务端无需照搬。客户端已按本契约消费——真服务端按本契约实现后，客户端**只改 `server_url`、代码零改**即可切换（§5）。
>
> 关联：客户端消费侧 `ext/接口文档/客户端-本地后端API.md` + `ext/接口文档/专家市场与委派.md`｜服务端对齐 `客户端接口对齐-会谈稿.md`（服务端来稿）+ `客户端接口对齐-回执.md`（我方回执）｜需求：F-001（登录/下发）/ F-003（cron 下发）/ F-007（业务系统）/ F-012（MCP）/ F-014（role_desc）/ F-016（能力市场）/ F-020（业务系统人工登录）/ F-080（专家市场与委派）。改契约须经负责人。

---

## 0.0 不由服务端提供的东西（划界——服务端开发请勿误做）

客户端**仅向服务端发起两类出站调用**：`POST /api/auth` + `POST /api/config`（核心链路），以及能力市场 `GET /api/market/*`（前端直连查询，V2.6 起）。除此之外的能力都在**客户端本地或前端直连第三方**完成，**服务端无需实现、也不该下发**：

| 不下发的东西 | 实际来源 | 代码依据 |
|---|---|---|
| **业务系统凭据 / 状态 / 关联**（`account`/`password`/`status`/`tested_at`/`associated_skills`） | 凭据由员工本地填写（F-020 起登录改人工、账密可选）；均存 `profiles/<岗位>/business_systems.json`。⚠️ 业务系统「定义」经两条通道下发——岗位包 §2.5（按 id 合并）与市场连接器列表 §1.6（F-020，`type:"BIZ_SYSTEM"`）；**凭据/状态/关联永远本地**，合并绝不覆盖 | `desktop_backend/business_systems.py`（`load_systems:25`/`save_systems:41`/合并 `:65-124`） |
| **业务系统登录 / biz skill** | F-020：安装/登录失效时客户端硬弹浏览器由**用户手动登录**（含 2FA）；biz skill 本地生成 | `desktop_backend/business_systems.py:400-452`（write_biz_skill）；F-020 技术文档 |
| **个人空间 RAG 检索 / 上传 / 建库**（F-005） | 前端**直连**公司 RAG（`10.43.107.79:30880`），按 `account`（=`/api/auth` 的 `user_id`）隔离；不经本服务端 | `RAG个人空间.md`；`apps/desktop/src/app/dw/store.ts` |
| **个人信息 / 伙伴名 / 关于 / 岗位约束** | onboarding 本地写 `SOUL.md` / USER PROFILE / `.dw_setup.json` | `desktop_backend/routes.py`（onboarding / profile-info / about 端点） |
| **对话 / 定时任务 / 提醒 / 技能枚举 / 审批** | 前端 → 本地后端 `/dw/*`（同机 8765），不出本机 | `客户端-本地后端API.md` |

> 即：服务端职责 = **登录鉴权 + 按岗位下发岗位包 + 能力市场数据**。岗位包内含什么见 §2；市场接口见 §1A。
>
> ⚠️ 命名提醒：`apps/desktop/src/hermes.ts` 里也有 `/api/config`，那是 **Hermes dashboard 自身的本地配置端点**（同机），与本文的服务端 `POST /api/config` 同名不同源，**与本契约无关**。

---

## 0. 总览

**核心两个接口**（登录 + 岗位包下发，真服务端必实现）：

| 接口 | 用途 | 出参 |
|---|---|---|
| `POST /api/auth` | 登录鉴权，返回 token + 用户名下岗位列表 | JSON |
| `POST /api/config` | 按岗位下发**岗位包（zip）** = 技能 + config + 工具 API + 业务系统定义 + cron 模板 | `application/zip` |

**能力市场六个接口**（F-016，详见 §1.3~§1.9）：

| 接口 | 用途 | 出参 |
|---|---|---|
| `GET /api/market/skill-categories` | 技能分类标签 | JSON |
| `GET /api/market/skills` | 技能列表（含依赖连接器） | JSON |
| `GET /api/market/skills/{skill_id}/download` | 下载技能包 | `application/zip` |
| `GET /api/market/connectors` | 连接器列表（**BIZ_SYSTEM 类含 `type`/`login_url` 等，F-020**） | JSON |
| `GET /api/market/connectors/{connector_id}/download` | 下载连接器包（API/REST 类用；**BIZ_SYSTEM 类客户端不调**） | `application/zip` |
| `GET /api/market/positions` | 岗位专家列表（可「领用」，见 §1.2-B） | JSON |
| `GET /api/market/experts` | **专家市场列表**（可「领用」后 @ 委派，Bearer 鉴权，见 §1.8A） | JSON |
| `GET /api/market/experts/{expert_id}/download` | **下载专家包**（技能 + expert.json + MCP/API，Bearer 鉴权，见 §1.8B） | `application/zip` |

**一次完整链路**：

```
登录页 ──POST /api/auth──▶ {token, user_id, positions[]}
  │  用户从 positions[] 单选一个 position_id
  ▼
客户端起本地后端(--profile <position_id>) ──POST /api/config {token, position_id}──▶ <岗位>.zip
  │  客户端解压岗位包，各物料落位（§2.1 消费表）：
  ├─ SKILL.md 技能树        → HERMES_HOME/skills/<岗位>/...（reload_skills 后 @ 可见）
  ├─ config.yaml            → merge 进 HERMES_HOME/config.yaml（model/web/mcp_servers/enabled_toolsets；V2.7 起模板含 auxiliary 13 任务 provider=main 钉定——auto 探测链撞 openrouter 池 402/未认证 Nous 全天试错噪声，deep merge 下发键覆盖本地，真服务端接管后保持同款段）
  ├─ external_apis.json     → HERMES_HOME/external_apis.json（构造 AIAgent 前注册成工具）
  ├─ business_systems.json  → 按 id 合并进 HERMES_HOME/business_systems.json（保留本地凭据）
  └─ cron_jobs.json         → 按「来源+id」合并进本地 cron（岗位自带）
  ▼
再 POST /api/config {position_id:"common"} 拉「通用」包（技能 + 可含 cron_jobs.json）
  ▼
专家市场（可选）：前端 GET /api/market/experts ——▶ 浏览专家列表 → 点「领用」
  │  GET /api/market/experts/{id}/download ——▶ <专家>.zip
  ├─ expert.json             → skills/expert-<id>/expert.json（元数据，@ 委派数据源）
  ├─ SKILL.md 技能树         → skills/expert-<id>/...（reload_skills 后 @ 可见）
  ├─ config.yaml             → merge 进主 profile config.yaml（MCP server）
  └─ external_apis.json      → merge 进主 profile external_apis.json（REST API）
  ▼
对话页 @ 专家 → 主 agent 调 delegate_task 委派子 agent 执行专家技能
```

> `HERMES_HOME` = 该岗位的隔离 profile 目录（Windows：`%LOCALAPPDATA%\hermes\profiles\<position_id>`）。一岗一进程一套数据，互不串。

---

## 1. 接口契约

### 1.1 `POST /api/auth` —— 登录鉴权（F-022 改·对齐服务端终版 §2.1）

**用途**：只做认证。**F-022 起不再返回岗位列表**（对齐服务端终版 §2.1；岗位改由 §1.1A `POST /api/positions` 单独下发）。

**请求体**（`application/json`）：

| 字段 | 类型 | 必填 | 含义 | 约束 |
|---|---|---|---|---|
| `username` | string | ✅ | 企业账号 | 非空 |
| `password` | string | ✅ | 密码（或 SSO 场景下的凭据） | 非空 |

**响应体 200**（`application/json`）：

| 字段 | 类型 | 必填 | 含义 | 约束 / 说明 |
|---|---|---|---|---|
| `token` | string | ✅ | 会话 token；后续接口回传（`/api/config`/`/api/positions`/`/api/config/versions` 放 body，`/api/auth/logout` 放 Bearer 头） | **登出后失效**（§1.1B）；重新登录恢复。mock token 确定性 = `mock-token-<user_id>-0001`（同人同串，demo 下 `.dw_provision_meta.json` 存的旧 token 重登后继续可用）；⚠️ 真服务端每次登录签发**新 JWT**——切服务端时后台 sync 用的旧 token 在重登后不可复用（已知差异，切换时处理） |
| `user_id` | string | ✅ | 用户唯一标识 | **后续用作个人空间 RAG 的 `account`（按人隔离）与通用模式 profile 名（F-018）**，须全局唯一稳定 |

> **F-022 移除**：~~`positions[]`~~ 不再返回——客户端 `DwAuthResult` 砍 `positions`，登录后改调 §1.1A 取岗位（服务端终版 §2.1/§2.3 口径）。

**错误响应**：

| HTTP | body | 触发条件 |
|---|---|---|
| 401 | `{"detail":"账号或密码错误"}` | 账号不存在或密码不符（mock 沿用 FastAPI detail 格式；真服务端为 `{"error":{code,message}}`，客户端两种都解析——E-1） |

**完整示例**：

```jsonc
// 请求
POST /api/auth   {"username":"zhumei","password":"123456"}
// 响应 200（F-022 起无 positions）
{"token": "mock-token-zhumei-0001", "user_id": "zhumei"}
```

> **代码依据**：客户端调用点 = **渲染层直连**（登录发生在本地后端起来之前，mock 已开 CORS），`apps/desktop/src/app/dw/api.ts`（`authenticate()`）。mock 实现点 = `mock_server.py`（校验 `accounts.json`；登录时把该 token 从「已登出集合」移除）。

### 1.1A `POST /api/positions` —— 岗位列表（岗位信息唯一下发源·F-022 新增，对齐服务端终版 §2.3）

**用途**：登录后单独调取**全部已发布岗位**（服务端不按用户过滤，客户端让用户自选）；岗位的展示与配置信息（名称/推荐问题/头像/简介/人格/采集字段）**全部由本接口下发**——「领用伙伴」页文案、「完善信息」页动态表单、岗位 SOUL 都从这里来（F-022 A/E）。

**请求体**：`{"token": "<登录 token>"}`（token 放 body）。

**响应体 200**：

| 字段 | 类型 | 必填 | 说明 |
|---|---|---|---|
| `positions` | array | ✅ | 全部已发布岗位（**不含 `common` 伪岗位**）；空数组=暂无 |
| `positions[].id` | string | ✅ | 岗位 ID（mock 为 `sales`/`kefu` 等平面 id；真服务端为 `ps_` 句柄——C-3② 切换专项） |
| `positions[].name` | string | ✅ | 岗位中文显示名 |
| `positions[].role_desc` | string | ⬜ | 岗位职责一句话（agent 路由用，F-014 沿用） |
| `positions[].recommended_questions` | string[] | ✅ | 推荐问题（目标恰 4 条；存量未配置可能空数组，按「0 或 4」容错）——「TA 能帮你做什么」页能力示例（B-3=A） |
| `positions[].avatar` | string\|null | ⬜ | emoji 或 `/api/public/icons/` 路径；异常取值按占位头像兜底 |
| `positions[].description` | string\|null | ⬜ | 展示用岗位简介（「TA 能帮你做什么」页介绍文案） |
| `positions[].persona` | string\|null | ⬜ | **岗位人格**（Markdown，可较长）→ 客户端 onboarding 时作 `position_soul` 写入 SOUL.md。**勿高频轮询本接口** |
| `positions[].intake_fields` | array | ⬜ | **采集字段定义**（≤10 个、数组序即展示序、空数组=无采集定义）。条目 `{key(^[a-z][a-z0-9_]*$), label, type(text/textarea/single_select/multi_select/number/date), required, options(单/多选必有·其余 null), placeholder, default_value(不保证匹配·容错), desc}`。**采集值客户端本地消化、服务端不收、无回传端点** |
| `total` | number | ✅ | 岗位总数 |

**错误**：token 已登出 → 401 `{"error":{"code":"UNAUTHORIZED","message":"未认证或登录已失效"}}`（终版错误格式）。

**使用场景**：登录成功后前端调一次、缓存 store；选岗位页/领用页/完善信息页/设置页个人信息 Tab 共用这份定义（F-022 E：设置页动态渲染 intake_fields，追加/修改值）。

> mock 数据源 = `mock_data/positions.json`（每岗位补 `recommended_questions`/`avatar`/`description`/`persona`/`intake_fields` 五字段，见 §3.2）；真服务端已知缺陷：本接口现 500（终版 §2.3 警示），修复前真机勿联调、mock 可全量验证。

### 1.1B `POST /api/auth/logout` —— 登出（F-022 新增，对齐服务端终版 §2.2）

**用途**：使 token 立即失效（F-022 B）。客户端三个触发点：①「退出登录」按钮；②关闭客户端 `before-quit` best-effort；③下次启动补调（sidecar 兜底）。

- **鉴权**：`Authorization: Bearer <token>`，**无请求体**。
- ⚠️ **响应格式特殊**（终版已登记例外，不走统一错误体）：
  - 成功：HTTP 200 + `{"code":0,"message":"success","data":null}` —— 判 `code == 0`。
  - 未带/已失效 token：HTTP **200** + `{"code":401,"message":"未认证或登录已失效","data":null}` —— 判 `code == 401`；登出目的已达成，客户端**同样清本地**。
- **mock 失效语义**：logout 把该 token 加入内存「已登出集合」→ 之后 `/api/positions`/`/api/config`/`/api/config/versions` 用它一律 401；**重新登录（`/api/auth`）移除**恢复可用。mock 重启集合清空（等效全部有效）。

### 1.1C `POST /api/config/versions` —— 岗位版本列表（F-022 D 新增，对齐服务端终版 §2.5）

**用途**：岗位包**分版本判更新**的比对源（F-022 D）：后台 sync 每轮先查本接口，最新整数 `version` 比本地记录大 → 才调 `/api/config` 全量重下整包（省掉「没更新也每轮下整包」）。

**请求体**：`{"token":"<token>", "position_id":"<岗位id>"}`。

**响应体 200**（按 `version` 降序、只列 ACTIVE）：

```jsonc
{
  "versions": [
    {"version": 3, "size_bytes": 20480, "published_at": "2026-07-05T10:00:00+08:00", "status": "ACTIVE"},
    {"version": 2, "size_bytes": 19870, "published_at": "2026-07-01T09:00:00+08:00", "status": "ACTIVE"}
  ],
  "total": 2
}
```

- **判更新口径**：客户端本地记 `position_version`（整数，`.dw_sync_state.json`）；列表最新 `version` > 本地 → `/api/config` 全量重下。
- **空列表**（`{"versions":[],"total":0}`）= 该岗位未配置版本（存量老岗位）→ 客户端**回落 F-017 sha256 指纹路径**（下整包比指纹），零破坏。
- **错误**：缺 token/position_id → 400；token 已登出 → 401（终版错误格式）；未知岗位 → 404。

> mock 数据源 = `mock_data/config_versions.json`：`{"<position_id>": <最新整数版本>}`。**模拟"管理端发新版"**：把某岗位数字 +1（并顺手改该岗位某 SKILL.md 内容）→ 下一轮 sync（默认 300s，`DW_SYNC_INTERVAL` 可调小）即判涨、重下整包静默更新。**文件里没有的岗位**返回空列表（用于验证 sha256 回落路径）。真服务端注意：本接口需 Bearer workaround（终版 F.4-2），切换时按其口径调。

### 1.2 `POST /api/config` —— 拉取岗位包（zip）

**用途**：按岗位返回一个 **zip 岗位包**，内含该岗位的**技能 + config 片段 + 工具 API 清单 + 业务系统定义 + cron 模板**。`common` 为伪岗位（通用技能），只返技能（可含 cron_jobs.json）。

**请求体**（`application/json`）：

| 字段 | 类型 | 必填 | 含义 | 约束 |
|---|---|---|---|---|
| `token` | string | ✅ | `/api/auth` 返回的 token，原样回传 | **F-022 起 mock 校验「已登出」**（登出的 token → 401 终版错误格式；未登出不做真伪校验）；真服务端全量校验 |
| `position_id` | string | ✅ | 岗位 ID：`positions[].id`（真实岗位）/ `"common"`（通用）/ `/api/market/positions[].id`（岗位专家，见下方 B） | 三者都不匹配 → 404 |

**响应体 200**：**二进制 zip 流**，`Content-Type: application/zip`。zip 内部结构见 **§2**。

**错误响应**：

| HTTP | body | 触发条件 |
|---|---|---|
| 404 | `{"detail":"未知岗位: <id>"}` | `position_id` 不存在 |
| 500 | `{"detail":"岗位技能目录缺失: ..."}` | 服务端该岗位技能源缺失（mock 实现态） |

> **B（岗位专家市场可下发）**：`position_id` 若不在 `positions.json`，落到 `market/positions.json` 现造轻量包（每个技能标签一个 `SKILL.md`，`mock_server.py:68-84` `_build_market_position_bundle`、分支 `:91-97`），使岗位专家可「领用」为子岗位。**协议不变**（仍 `{token,position_id}`→zip）。**一致性约束（真服务端须遵守）**：`/api/market/positions` 列出的岗位，`/api/config` 都要能下发（id 一致 + 有包），否则领用 404。
>
> **代码依据**：客户端调用点 = 本地后端 `/dw/provision` 内 `_pull_and_extract`（`desktop_backend/routes.py:175-215`：`httpx.post` `:184-189`、**`trust_env=False`** `:188`——服务间调用不走用户浏览器代理，否则 localhost 经代理 502）。一次 provision **调两次**：先按岗位（`routes.py:434`）、再固定拉 `common`（`routes.py:480`，mock 未配 common 则跳过、非致命 `:484-485`）。`mock_url` 取 env `MOCK_SERVER_URL`、缺省 `http://127.0.0.1:9999`。mock 实现点 = `mock_server.py:87-137`（`config()`：按 `positions.json` 找技能源 → 现打 zip，四保留文件入 zip 见 `:109-133`）。

---

## 1A. 能力市场接口（F-016）

> **需求编号**：F-016（能力市场）。三个子市场：技能市场 / 连接器市场 / 岗位专家市场。
>
> **与核心两端点的关系**：`/api/auth`+`/api/config` 是"登录 + 按岗位一次性下发"；能力市场是"用户**主动浏览、按需安装**额外能力"。市场数据由服务端提供、**前端直连查询**（GET，类比 RAG 直连，不经本地后端转发）。**安装动作**按类型分流：技能 = 前端下 zip → 本地后端 `POST /dw/skills/import` 落盘；API/REST 连接器 = 前端下 zip → `POST /dw/connectors/install`；**BIZ_SYSTEM 连接器 = 免下载，前端从列表 entry 直接读字段落 `business_systems.json`（F-020，见 §1.6）**。
>
> **调用方**：前端渲染层直连 `${MARKET_BASE}/api/market/*`（demo = mock `http://127.0.0.1:9999`，最终切 POC 服务端）。**认证**：暂不需要（公开市场）；⚠️ 若真服务端要求登录态（Bearer JWT），客户端需补 token 头——此分歧见 `客户端接口对齐-回执.md` 问题1/S-3，**以会谈结论为准**。`installed` 判断本项目采**客户端判断**（对比本地已装列表），服务端 `installed` 统一返回 `false`。
>
> **通用规范**：分页 `page`（从 1）/`page_size`（默认 20，最大 100），响应含 `total`/`page`/`page_size`/`total_pages`；错误格式 `{"error":{"code","message","details"}}`（§1.9）；服务端须开 CORS（同 `/api/auth`）。

### 1.3 `GET /api/market/skill-categories` —— 技能分类标签

**用途**：技能市场顶部分类筛选 chips 的数据源。

**请求参数**：无。

**响应体 200**：`{ "categories": [ ... ] }`

| 字段 | 类型 | 必填 | 含义 |
|---|---|---|---|
| `categories[].id` | string | ✅ | 分类唯一标识（查询技能时作 `category_id` 过滤） |
| `categories[].name` | string | ✅ | 分类显示名 |
| `categories[].icon` | string | ⬜ | lucide 图标名 |
| `categories[].count` | number \| null | ⬜ | 该分类下技能数量（**可空**——无真实聚合源时返 null，客户端容错） |

**示例**：
```json
{
  "categories": [
    {"id":"record","name":"记录登记","icon":"edit-3","count":12},
    {"id":"analysis","name":"分析洞察","icon":"heart-pulse","count":8},
    {"id":"retrieval","name":"检索生成","icon":"search","count":15},
    {"id":"report","name":"报告生成","icon":"file-text","count":6}
  ]
}
```

### 1.4 `GET /api/market/skills` —— 技能列表

**用途**：技能市场卡片网格数据源，支持按分类/关键词筛选、分页。

**请求参数**（query）：

| 参数 | 类型 | 必填 | 说明 |
|---|---|---|---|
| `category_id` | string | ⬜ | 分类 id（§1.3），不传返回全部 |
| `keyword` | string | ⬜ | 搜索关键词（匹配名称/描述） |
| `page` / `page_size` | number | ⬜ | 分页，缺省 1 / 20 |

**响应体 200**：`{ "skills":[...], "total","page","page_size","total_pages" }`

| 字段 | 类型 | 必填 | 含义 |
|---|---|---|---|
| `id` | string | ✅ | 技能唯一标识（下载 §1.5 的 path 参数） |
| `name` | string | ✅ | 技能显示名（中文可） |
| `slug` | string | ✅ | ASCII slug；落盘后技能名以此为基（须满足 §2.2 命名铁律） |
| `category_id` / `category_name` | string | ✅ | 所属分类 |
| `summary` | string | ✅ | 一句话简介（卡片） |
| `description` | string | ✅ | 详细描述（详情弹窗） |
| `icon` / `color` | string | ⬜ | lucide 图标名 / 卡片配色类 |
| `source` | string | ✅ | 来源：`builtin`/`skillhub`/`community` |
| `version` / `updated_at` / `author` | string | ✅ | 版本 / 更新时间 / 发布者 |
| `rating` | number \| null | ⬜ | 评分 0–5（**可空**——服务端无真实源时返 null、前端隐藏/占位，对齐回执 R5） |
| `install_count` | number \| null | ⬜ | 安装次数（**可空**，同上） |
| `download_url` | string | ✅ | 技能包 zip 下载地址（可为 §1.5 完整 URL；为空时前端按 `id` 拼 §1.5） |
| `size_bytes` | number | ✅ | 技能包大小 |
| `dependencies.connectors[]` | array | ✅ | **依赖连接器**：`{id,name,required,download_url}`——`required:true` 的须随技能一并安装（§1.7）。`download_url` 服务端组装时补全 |
| `dependencies.skills[]` | array | ⬜ | 依赖的其他技能 `{id,name,required}` |
| `permissions[]` / `tags[]` / `trigger_examples[]` / `usage_example` | — | ⬜ | 权限 / 标签 / 触发示例词 / 使用示例（展示用） |
| `installed` | boolean | ✅ | 恒 `false`（**客户端对比本地已装列表判断**） |
| `featured` | boolean | ✅ | 是否推荐 |

**示例**（单条）：
```json
{
  "id": "crm-record-v1",
  "name": "CRM 拜访记录",
  "slug": "crm-visit-record",
  "category_id": "record", "category_name": "记录登记",
  "summary": "对话中口述拜访情况，自动结构化为客户交互记录并落表。",
  "description": "识别对话中的拜访/沟通内容，抽取客户、联系人、阶段、金额、下一步等字段，写入客户主表与交互明细。",
  "icon": "edit-3", "color": "bg-cyan-100 text-cyan-600",
  "source": "builtin", "version": "2.3", "updated_at": "2026-06-18", "author": "销售运营·FDE",
  "rating": 4.8, "install_count": 1280,
  "download_url": "http://127.0.0.1:9999/api/market/skills/crm-record-v1/download",
  "size_bytes": 51200,
  "dependencies": {
    "connectors": [{"id":"crm-connector","name":"CRM 客户关系管理","required":true,"download_url":"http://127.0.0.1:9999/api/market/connectors/crm-connector/download"}],
    "skills": []
  },
  "permissions": ["connector.crm：客户/商机 读写"],
  "tags": ["CRM","记录","落表"],
  "trigger_examples": ["记一下","拜访记录","跟进一下"],
  "usage_example": "跟进一下中石油：今天见了张总，方案认可，下周二再谈报价",
  "installed": false, "featured": true
}
```

### 1.5 `GET /api/market/skills/{skill_id}/download` —— 下载技能包

**用途**：安装技能时下载 zip。客户端取 blob → 调本地后端 `POST /dw/skills/import` 解压落盘。

**请求参数**：path `skill_id`（= §1.4 的 `id`）。

**响应 200**：
- `Content-Type: application/zip`
- `Content-Disposition: attachment; filename="<slug>.zip"`
- Body：技能包 zip。**根目录须含 `skill.md`**（客户端 import **大小写不敏感**，`skill.md`/`SKILL.md` 均可识别，`desktop_backend/skill_import.py:93/198`；随包子文件树 `references/` 等一并落盘）。

**错误**：技能不存在 → 404 `SKILL_NOT_FOUND`；包缺失 → 500 `DOWNLOAD_FAILED`（错误体见 §1.9）。

### 1.6 `GET /api/market/connectors` —— 连接器列表

**用途**：连接器市场卡片数据源；技能 `dependencies.connectors` 的元数据来源；**F-020 起也是 BIZ_SYSTEM 业务系统的定义下发通道**（客户端从列表 entry 直接落 `business_systems.json`，免下载）。

**请求参数**（query）：`keyword?` / `page?` / `page_size?`（同 §1.4）。

**响应体 200**：`{ "connectors":[...], "total","page","page_size","total_pages" }`

| 字段 | 类型 | 必填 | 含义 |
|---|---|---|---|
| `id` | string | ✅ | 连接器唯一标识（下载 §1.7 path 参数；技能依赖按此 id 引用）。客户端视为**不透明句柄、原样回传** |
| `name` / `description` | string | ✅ | 名称 / 详细描述 |
| `type` | string | ⬜ | **连接器类型枚举：`API`/`MCP`/`BIZ_SYSTEM`（F-020 类型判别符）**——客户端按此分流安装路径；`BIZ_SYSTEM` = 业务系统、走人工登录落地。**勿用中文 `category`（显示分类）当类型判据** |
| `icon` / `color` | string | ⬜ | lucide 图标名 / 配色类 |
| `vendor` | string | ⬜ | 支持的厂商/系统 |
| `version` / `updated_at` | string | ✅ | 版本 / 更新时间 |
| `category` | string | ⬜ | **显示分类**（业务系统/通讯协同/数据平台…，中文，UI 筛选用；非类型判据） |
| `capabilities[]` | array | ⬜ | 能力列表（展示用） |
| `download_url` | string | ✅ | 连接器包 zip 下载地址（**BIZ_SYSTEM 类客户端不调**，见 §1.7） |
| `size_bytes` | number | ✅ | 包大小 |
| `config_required` | boolean | ✅ | 是否需配置（账号/密钥等） |
| `auth_type` | string | ⬜ | 认证类型：`oauth2`/`apikey`/`password`/`sso` |
| `installed` | boolean | ✅ | 恒 `false`（客户端判断） |
| `connected` | boolean | ✅ | 恒 `false`（客户端判断；客户端现不消费此字段） |
| `install_count` / `rating` | number \| null | ⬜ | 安装次数 / 评分（**可空**，对齐回执 R5） |
| `login_url` | string | ⬜(BIZ) | **仅 `type:"BIZ_SYSTEM"`**：业务系统登录地址（公开 URL、非凭据）。**F-020 客户端从列表 entry 直接读**、落 `business_systems.json`（**免下载**）；下载包 §1.7 不含此字段。**口径：须为服务地址**（未登录才跳登录页），勿配 `sso/login` 强制表单端点（已登录仍误弹，problems 2026-07-07） |
| `purpose` / `success_hint` | string | ⬜(BIZ) | **仅 `BIZ_SYSTEM`**：用途 / 登录成功特征（随 `login_url` 同在列表 entry；`success_hint` 客户端现用通用判据、可空） |

**示例**（单条·BIZ_SYSTEM 类，字段与 mock `connectors.json` 一致）：
```json
{
  "id": "oa-system",
  "name": "OA系统",
  "description": "内部OA系统，用于日常办公审批、流程管理。支持单点登录。",
  "icon": "contact", "color": "bg-blue-100 text-blue-600",
  "vendor": "科大讯飞",
  "version": "1.0", "updated_at": "2026-07-06",
  "type": "BIZ_SYSTEM", "category": "业务系统",
  "capabilities": ["单点登录", "审批流程", "办公管理"],
  "download_url": "http://127.0.0.1:9999/api/market/connectors/oa-system/download",
  "size_bytes": 65536, "config_required": true, "auth_type": "sso",
  "installed": false, "connected": false, "install_count": 150, "rating": 4.5,
  "login_url": "http://in.iflytek.com/",
  "purpose": "内部OA系统",
  "success_hint": "成功跳转到首页"
}
```

**V2.7 增量（F-021，2026-07-06）**：连接器按种类分流安装 no-zip，每条新增：

| 字段 | 类型 | 必填 | 含义 |
|---|---|---|---|
| `type` | string | ⬜ | 连接器种类：`mcp`/`api`/`biz`（缺省时客户端/后端按 `mcp_config`/`login_url` 兜底推断） |
| `mcp_config` | object | ⬜ | MCP 连接配置（type=mcp 时必需）：`{server_key?,url,transport?,enabled?,connect_timeout?,auth?,...}`——透传给 `config.yaml` 的 `mcp_servers[server_key]`，字段对齐 `register_mcp_servers` |
| `api_config` | object | ⬜ | API 连接配置（type=api 时优先用，缺省时后端用顶层字段兜底）：`{name?,url,method,auth?,side_effect?,description?,request_schema}`——透传给 `external_apis.json` entry |
| `login_url` | string | ⬜ | 业务系统登录 URL（type=biz 时必需）|
| `purpose` | string | ⬜ | 业务系统用途说明 |
| `success_hint` | string | ⬜ | 登录成功判定提示 |

前端不再下载 zip（§1.7 保留但不用），直接把连接器完整信息作 JSON POST `/dw/connectors/install`（见客户端-本地后端API.md §2.21.4 V2）。

### 1.7 `GET /api/market/connectors/{connector_id}/download` —— 下载连接器包

**用途**：安装 **API/REST 类**连接器（含随技能一并安装的必需连接器）时下载 zip。⚠️ **`type:"BIZ_SYSTEM"` 类客户端不调本端点**（F-020：从列表 entry 直接落 `business_systems.json`）；MCP 类落地通道待定（本期市场可不上 MCP 类）。

**请求参数**：path `connector_id`（= §1.6 的 `id`，原样回传）。

**响应 200**：
- `Content-Type: application/zip`
- `Content-Disposition: attachment; filename="<connector_id>.zip"`
- Body：连接器包 zip，**根含 `connector.json` + `schema.json`**。

**格式（客户端 `entry_from_manifest` 实际消费口径，`desktop_backend/external_apis.py:378-413`）**：
- `connector.json`：`{id（必填=列表 id）, name（必填）, url（必填）, method（必填,GET/POST）, description?, side_effect?(bool), auth?{type,key}}`——**`id` 须与列表返回的 id 一致**（客户端按它做安装/移除主键）。
- `schema.json`：**标准 JSON Schema（object）**，直接作该工具的入参 `parameters`。**不要**包成 `{tools:[...]}` 之类的多工具列表。

**错误**：连接器不存在 → 404 `CONNECTOR_NOT_FOUND`；包缺失 → 500 `DOWNLOAD_FAILED`。

> mock 实现：`mock_server.py:247+`（动态打包 connector.json + schema.json）。

### 1.8 `GET /api/market/positions` —— 岗位专家列表

**用途**：岗位专家市场，展示各岗位能帮做什么；岗位可被「领用」为子岗位（`/api/config` 一致性约束见 §1.2-B）。

**请求参数**（query）：`keyword?` / `page?` / `page_size?`。

**响应体 200**：`{ "positions":[...], "total","page","page_size","total_pages" }`

| 字段 | 类型 | 必填 | 含义 |
|---|---|---|---|
| `id` | string | ✅ | 岗位唯一标识（可作 `/api/config` 的 `position_id` 领用） |
| `name` / `description` | string | ✅ | 岗位名 / 简介 |
| `icon` / `color` | string | ⬜ | 图标名 / 配色类 |
| `line` | string | ⬜ | 业务线 |
| `buddy_name` / `buddy_avatar_url` | string | ⬜ | 默认搭子名 / 头像 URL |
| `skills[]` | array | ✅ | 岗位能力：`{label,description,icon}` |
| `skill_count` / `user_count` | number | ⬜ | 技能总数 / 使用人数 |
| `recommended_questions[]` | array \| null | ⬜ | 推荐问题示例（**可空**——无真实源时返 null、前端隐藏，对齐回执 R5） |

**示例**（单条）：
```json
{
  "id": "sales-manager", "name": "销售经理", "description": "跑客户、记 CRM、写周报、盯竞品",
  "icon": "briefcase", "color": "bg-amber-100 text-amber-700", "line": "销售线",
  "buddy_name": "小销", "buddy_avatar_url": "http://127.0.0.1:9999/avatars/sales.png",
  "skills": [
    {"label":"帮你记","description":"聊完随口说一句，自动记进 CRM、攒周报素材","icon":"edit-3"},
    {"label":"帮你查","description":"拜访前联网查客户近况、做拜访简报","icon":"search"}
  ],
  "skill_count": 12, "user_count": 320,
  "recommended_questions": ["帮我写本周拜访总结","整理客户跟进话术"]
}
```

### 1.8A `GET /api/market/experts` —— 专家市场列表（F-080·2026-07-28 定版）

**用途**：专家市场，用户可浏览并「领用」专家——领用后专家技能/MCP/API 落主岗位 profile，@ 委派时子 agent 据此执行。专家与岗位**业务分层**：岗位决定身份/权限/主 profile 运行时，专家决定可 @ 委派的 AI 能力。

**鉴权**：`Authorization: Bearer <token>`（无/失效 → 401 `UNAUTHORIZED`）。

**请求参数**（query，全部可选）：

| 参数 | 类型 | 缺省 | 说明 |
|------|------|------|------|
| `keyword` | string | — | 关键词搜索，匹配 `name` 和 `description` |
| `page` | int | 1 | 页码，从 1 开始 |
| `page_size` | int | 20 | 每页条数，最大 100（超出按 100 截断） |

**响应体 200**：

```jsonc
{
  "experts": [
    {
      "id": "sales-manager",                    // 专家句柄（稳定标识，ASCII slug）
      "name": "销售经理",                        // 中文显示名（卡片标题，14px 加粗）
      "description": "自动记录客户跟进、生成周报并监控竞品动态，助您高效拿下订单",
                                                 // 简介（卡片灰色描述文，12px，建议 ≤60 字）
      "image_url": "https://cdn.example.com/experts/sales-manager.png",
                                                 // 专家插画（卡片右侧展示，HTTPS URL）
      "skills": [                               // 技能标签列表（卡片 chip 展示，仅标签名）
        { "label": "客户跟进" },
        { "label": "销售CRM" },
        { "label": "竞品洞察" }
      ],
      "skill_count": 3                          // 技能总数（供 chip 折叠时显示 "+N"）
    }
  ],
  "total": 20,
  "page": 1,
  "page_size": 20,
  "total_pages": 1
}
```

**单条字段表**：

| 字段 | 类型 | 必填 | 含义 | 约束 |
|------|------|------|------|------|
| `id` | string | ✅ | 专家句柄，稳定标识 | ASCII slug，客户端领用/下载以此传参 |
| `name` | string | ✅ | 中文显示名 | 卡片标题 + @ picker 展示 |
| `description` | string | ✅ | 简介 | 卡片灰色描述文，建议 ≤60 字；也作专家 soul 概要 |
| `image_url` | string | ✅ | 专家插画 URL | HTTPS，卡片右侧展示（375×146 容器内右侧 122×130 区域） |
| `skills[]` | array | ✅ | 技能标签列表 | 每项含 `label`(必填，chip 文本)；`skill_count` 应与此数组长度一致 |
| `skill_count` | int | ✅ | 技能总数 | 与 `skills[]` 长度一致 |

**与 §1.8 岗位市场列表的差异**：

| 维度 | 岗位市场（§1.8） | 专家市场（§1.8A） |
|------|-----------------|-------------------|
| 用途 | 浏览 + 领用为子岗位（经 `/api/config`） | 浏览 + 领用为专家（经 §1.8B 下载 + 客户端独立落盘） |
| 图片 | `buddy_avatar_url`（头像） | `image_url`（卡片插画，更大尺寸） |
| 技能 | `skills[{label,description,icon}]` | `skills[{label}]`（精简，仅标签名） |
| 字段 | 含 `icon`/`color`/`line`/`buddy_name`/`user_count`/`recommended_questions` | **只含上述 6 字段**（卡片展示所需最小集） |
| 包结构 | ZIP 同岗位包（`/api/config` 通道） | ZIP 含 `expert.json` + 技能 + MCP/API（§1.8B 市场下载通道） |

---

### 1.8B `GET /api/market/experts/{expert_id}/download` —— 下载专家包（F-080 新增）

**用途**：客户端领用专家时调此接口拉取专家包 ZIP——含专家元数据（`expert.json`）、技能、MCP server 定义、REST API 定义。ZIP 结构与岗位包同构（技能子目录 + 根保留文件），**仅在根目录多一个 `expert.json`**（服务端可复用岗位包打包逻辑）。

**鉴权**：`Authorization: Bearer <token>`（无/失效 → 401 `UNAUTHORIZED`）。

**入参**：Path `expert_id`（来自 §1.8A 列表的 `id`）

**出参**（`200 OK`）：

- `Content-Type: application/zip`
- `Content-Disposition: attachment; filename="<expert_id>.zip"`

**ZIP 内部结构**（解压后根目录）：

```
<expert_id>.zip
├── expert.json              ← 【必含】专家元数据（id/name/role_desc/skills，schema 见 §2.7）
├── config.yaml              ← 【可选·有则下发】MCP server 定义（mcp_servers 段；空则整文件省略）
├── external_apis.json       ← 【可选·有则下发】REST API 定义（空则整文件省略）
├── external_mcps.json       ← 【可选·有则下发】MCP 连接器清单（空则整文件省略）
├── <skill-slug-1>/          ← 【≥1 个】每个专家技能一个子目录
│   └── SKILL.md
└── <skill-slug-2>/
    └── SKILL.md
```

**结构规则（铁律）**：

1. **`expert.json` 必须在 ZIP 根**——客户端落盘时由此读取专家的 name/role_desc/skills
2. **技能必须在子目录里**——`<skill-slug>/SKILL.md`，遵循 agentskills.io 标准（frontmatter 含 `name`/`description`）
3. **`config.yaml` 的 `mcp_servers` 段**仅含该专家技能关联的 MCP server——服务端负责按技能依赖关系打包，客户端 merge 进主 profile `config.yaml`
4. **`external_apis.json`** 仅含该专家技能引用的 REST API——格式同岗位包 §2.4
5. **专家技能不区分 QUERY/OPERATION**——全量下发，不适用岗位包的 scope 分级
6. **zip-slip 防护**：客户端解压时校验所有路径落在目标目录内（与岗位包同款防护）

**错误**：

| HTTP | body | 触发条件 |
|------|------|---------|
| `404` | `{"error":{"code":"EXPERT_NOT_FOUND","message":"专家不存在"}}` | `expert_id` 不存在 |
| `500` | `{"error":{"code":"DOWNLOAD_FAILED","message":"专家包缺失或损坏"}}` | 包文件不存在/损坏 |

> **EXPERT_NOT_FOUND** 加入 §1.9 能力市场错误码表。

**示例**（curl）：

```bash
curl -H "Authorization: Bearer <token>" \
  "https://api.example.com/api/market/experts/sales-manager/download" \
  -o sales-manager.zip
```

### 1.9 能力市场错误码

错误体统一：`{"error":{"code","message","details"}}` + 真实 HTTP 状态码。

| 错误码 | HTTP | 说明 |
|---|---|---|
| `INVALID_PARAMS` | 400 | 参数错误 |
| `SKILL_NOT_FOUND` | 404 | 技能不存在 |
| `CONNECTOR_NOT_FOUND` | 404 | 连接器不存在 |
| `EXPERT_NOT_FOUND` | 404 | 专家不存在（§1.8B download） |
| `DOWNLOAD_FAILED` | 500 | 下载失败（包文件缺失/损坏） |
| `INTERNAL_ERROR` | 500 | 服务器内部错误 |

> ⚠️ 客户端错误解析现只认 auth/config 族的 `{"detail":...}`（`api.ts:187-203`）；market 族 `{error:{...}}` 的文案展示为客户端待改进项（回执问题4），不影响契约。

---

## 2. 下发物结构契约（zip 岗位包）

### 2.1 zip 目录结构

`POST /api/config` 的响应体（zip）解开后，**根目录**布局：

```
<position_id>.zip   ← = POST /api/config 响应体
├── config.yaml            # 【岗位包必含；common 不含】岗位配置片段 → §2.3
├── external_apis.json     # 【岗位包可选；common 不含】工具 API 清单   → §2.4
├── business_systems.json  # 【岗位包可选；common 不含】业务系统定义   → §2.5
├── cron_jobs.json         # 【岗位包可选；common 亦可含】定时任务模板 → §2.6
├── <skill-dir-1>/
│   └── SKILL.md           # 【≥0 个】每个技能一个子目录 → §2.2
└── <skill-dir-2>/
    └── SKILL.md
```

**结构规则（铁律）**：

1. **zip 根下五个保留文件名**（F-022 C-1 起）：`config.yaml`、`external_apis.json`、`external_mcps.json`、`business_systems.json`、`cron_jobs.json`。其余**任何子目录**都被当作技能（递归找 `SKILL.md`）。
2. **技能必须在子目录里**：技能 = `<skill-dir>/SKILL.md`，不能把 SKILL.md 直接放 zip 根。
3. **路径相对**：zip 内技能路径 = 相对该岗位技能根（如 `sales-crm-record/SKILL.md`），不带 `skills/<岗位>/` 前缀。
4. **`common` 伪岗位**：只放技能，**不放** `config.yaml` / `external_apis.json` / `business_systems.json`；**唯一例外 = 可放 `cron_jobs.json`**（通用自带定时任务，§2.6）。

**客户端如何消费这个 zip**（`desktop_backend/routes.py`，**四保留文件处理均已实现**；服务端据此保证结构正确）：

| 步骤 | 行为 | 代码 |
|---|---|---|
| ① 解压 | 整包解压到 `HERMES_HOME/skills/<position_id>/`，**zip-slip 防护**（路径必须落在目标内，否则 400） | `routes.py:204-210` |
| ② 全量替换 | 解压前先 `rmtree` 该岗位技能目录——**每次下发 = 该岗位技能整体覆盖** | `routes.py:200-202` |
| ③ 抽 config | 根 `config.yaml` **merge** 进 profile config 后移出技能树 | `routes.py:218-260`（调用点 `:458`） |
| ④ 抽工具 API | 根 `external_apis.json` **整体移动**到 profile 根 | `routes.py:263-279`（调用点 `:472`） |
| ⑤ 合并业务系统 | 根 `business_systems.json` **按 id 合并**（保留本地凭据，§2.5） | `routes.py:315-336`（调用点 `:474`）→ `business_systems.py:65-124` |
| ⑥ 合并 cron | 根 `cron_jobs.json` **按「来源+id」合并**（撤下即删，§2.6） | `routes.py:339-364`（调用点 `:477`；common `:483`）→ `cron_provision.py` |
| ⑦ 刷新 | `reload_skills()` 刷新 `/skill-name` 映射（不破系统 prompt 缓存） | `routes.py:496` |

---

### 2.2 技能 `SKILL.md`

**结构**：每个技能一个子目录，目录内一个 `SKILL.md`（Markdown + YAML frontmatter）。

**frontmatter 字段**：

| 字段 | 类型 | 必填 | 含义 | 约束 |
|---|---|---|---|---|
| `name` | string | ✅ | 技能唯一标识；@ 列表 / `/skill-name` / 系统 prompt 技能索引都用它 | **见下方命名铁律** |
| `description` | string | ✅ | 技能用途（中文）；模型据此判断何时用 | 一句话讲清「什么场景用、产出什么」 |

**命名铁律（`name` 规则——不遵守会静默丢技能）**：

1. **必须是 ASCII slug**：匹配 `^[a-z0-9][a-z0-9._-]*$`（`tools/skill_manager_tool.py:168` `VALID_NAME_RE`）。**中文不行**——中文标题放 `description`。
2. **必须带岗位前缀 `<position_id>-`**（如 `sales-crm-record`）。原因：技能去重按 frontmatter `name`、在单个 `SKILLS_DIR` 内按相对路径字母序裁决、无「岗位优先」（`agent/skill_commands.py:298-299`；`agent/skill_utils.py:672`）。岗位技能与 `common`、与内置技能同住一库，同名者字母序在前的先占、后者被静默忽略。前缀使 name 永不撞。
3. **目录叶名建议 = frontmatter `name`**。原因：自建技能撞名检测按目录叶名（`skill_manager_tool.py:293`），两套键不一致会"一面命中一面漏"。
4. 前缀是**约定、非代码强制**（Hermes 只校验 slug 合法性）——**由服务端打包侧保证**。

**完整示例**（`sales-crm-record/SKILL.md`）：

```markdown
---
name: sales-crm-record
description: 销售·CRM 拜访记录——把口语化的拜访情况整理成结构化 CRM 记录（客户/联系人/要点/下一步）
---

# CRM 拜访记录

当用户口述一次客户拜访时，提取：客户名 / 联系人 / 时间 / 沟通要点 / 下一步，
整理成结构化条目返回。
```

---

### 2.3 `config.yaml`（岗位配置片段）

**总规则**：客户端**只 merge 5 个顶层键**（`desktop_backend/routes.py:244`），其余键**忽略**：

| 顶层键 | 类型 | merge 语义（`routes.py:245-252`） |
|---|---|---|
| `model` | object | **浅合并**（保留 profile 既有子键、覆盖下发的同名子键） |
| `web` | object | **浅合并** |
| `custom_providers` | object | 整体替换 |
| `mcp_servers` | object | 整体替换 |
| `enabled_toolsets` | array | 整体替换 |

#### 2.3.1 `model` —— LLM 模型

| 子字段 | 类型 | 必填 | 含义 | 约束 |
|---|---|---|---|---|
| `model.default` | string | ✅ | 默认对话模型名 | 须与 `provider`/`base_url` 匹配 |
| `model.provider` | string | ✅ | provider 标识 | 如 `deepseek`、`openai`、自定义 |
| `model.base_url` | string | ⬜ | OpenAI 兼容端点 | 切内网/自建模型时填（`hermes_cli/config.py:1262`） |

> demo：`model` 与本机克隆的 `.env` key 匹配；**config 不带密钥**，API key 走 `.env`（§2.7）。

#### 2.3.1a `custom_providers` —— **模型明文凭据下发结构（切服务端·协议定死）**

> **背景（负责人 2026-07-08 定协议·代码亲验）**：服务端要随岗位包下发**明文模型 api_key**（不再靠客户端 `.env`）。**必须用 `custom_providers` 列表 + inline `api_key`** —— 这是 Hermes 原生凭据源（`credential_pool.py:2097-2117` 的 `config:<name>` 源，实测把 inline key 灌进凭据池 PASS），客户端**零改**。
>
> ⚠️ **不要放顶层 `model.api_key`**：Hermes 的 `model_config` 源（`credential_pool.py:2119-2150`）读顶层 `model.api_key` 有**前置条件**——必须同时存在一个 `base_url` 匹配的 `custom_providers` 条目才生效（`get_custom_provider_pool_key` 只匹配 `custom_providers` 列表）。**单独放顶层 `model.api_key` 读不到 → 回落 env → 切服务端无 env 即认证失败**。

**下发结构（服务端照此产出 config.yaml）**：

```yaml
model:
  default: <模型名>              # 如 deepseek-v4-flash
  provider: <provider名>        # 与下方 custom_providers[].name 一致
custom_providers:
  - name: <provider名>          # 同 model.provider；⚠️ 禁用内置名（见下）
    base_url: <OpenAI兼容端点>   # 如 https://api.deepseek.com/v1
    api_key: "<明文 key>"        # ← Hermes 直读（config:<name> 凭据源）
    # api_mode 省略：OpenAI 兼容端点自动判 chat_completions（⚠️ 勿写 "openai"——非法值不校验直通，合法集见 runtime_provider.py:242）
    models: ["<模型名>"]         # ⬜ 该 provider 提供的模型（含 model.default）
```

> 🔴 **name 红线（2026-07-08 F-026 首验实测·A案）**：`custom_providers[].name` **禁止与 Hermes 内置 canonical provider 同名**（`deepseek`/`openai`/`anthropic`/`openrouter` 等，`hermes_cli/auth.py` 内置表）——同名条目被内置遮蔽（`runtime_provider.py:516-531` shadow check），**inline `api_key` 读不到 → 回落 env → 服务端下发的 key 失效**。命名加后缀即可，如 `deepseek-svc`、`spark-svc`。
>
> **选中语义（同批实测·D/E案）**：运行时按 `model.provider` == 条目 `name` 选中 provider；**`model.default`（模型名）不参与选中**、只作为发给该端点的模型串——所以 `model.provider` 必填且必须与目标条目 name 一致。

| 字段 | 类型 | 必填 | 说明 |
|---|---|---|---|
| `custom_providers[].name` | string | ✅ | provider 名（= `model.provider`）；**禁与内置 canonical provider 同名**（上方红线）；`credential_pool` 凭据池键 `custom:<name>` |
| `.base_url` | string | ✅ | OpenAI 兼容端点；`get_custom_provider_pool_key` 按它匹配（`config.py:4128` 合法字段集含之） |
| `.api_key` | string | ✅ | **明文** API key（Hermes 原生读取，优先于 env） |
| `.api_mode` | string | ⬜ | **建议省略**（OpenAI 兼容端点自动判 `chat_completions`）；显式合法值仅 `chat_completions`/`anthropic_messages`/`codex_responses`/`bedrock_converse`（`runtime_provider.py:242`，⚠️ `openai` 不是合法值且不校验） |
| `.models` | array/object | ⬜ | 该 provider 提供的模型；列表 `["m1","m2"]` 或字典 `{m1:{context_length:N}}`（两形都吃，可配多个·详见 §2.3.1a-①） |

- **merge 语义**：`custom_providers` **整体替换**（§2.3 表；服务端每次发全量）。轮换 key = 改 `api_key` 重发版，F-017/F-022 sync 静默生效。
- **demo/mock 现状**：mock configs 仍用 `model.provider: deepseek` + `.env`（本机无需明文 key）；**本结构是给真服务端的协议**，客户端已原生支持、切过去零改。

**真服务端下发的完整 `config.yaml` 示例**（切服务端后整包形态·所有下发段合一，服务端照此产出）：

```yaml
# ① 默认模型（model.provider 须 = 下方某 custom_providers 条目的 name）
model:
  default: deepseek-v4-flash
  provider: deepseek-svc                 # ⚠️ 非内置名（禁用 deepseek 裸名，会被内置遮蔽·§2.3.1a 红线）

# ② 模型明文凭据（§2.3.1a·必须放这里、勿放 model.api_key）——Hermes config:<name> 源直读
custom_providers:
  - name: deepseek-svc                   # = model.provider；⚠️ 禁与内置 provider 同名
    base_url: https://api.deepseek.com/v1
    api_key: "sk-明文APIKEY换成真实值"       # 明文；轮换=改此值重发版
    models: ["deepseek-v4-flash"]        # 含 model.default；api_mode 省略=自动 chat_completions

# ③ Hermes 内置搜索 provider（可选；此段 key 仍走 .env，非本协议范围）
web:
  backend: tavily
  search_backend: tavily

# ④ 声明式 MCP（真 MCP 已改走 external_mcps.json 独立下发·§2.4A；此段仅留声明式占位/样例）
mcp_servers:
  sales-knowledge-demo:
    url: http://127.0.0.1:65500/mcp
    enabled: false                       # 占位不连

# ⑤ 岗位工具白名单（F-024 起不含 web_search；⚠️ external_mcps 下发的 MCP，其 server_name 也要在此列出，否则调不到——§2.3.4 交互）
enabled_toolsets:
  - hermes-cli
  - external_apis                        # 工具API + F-024 spark_web_search 都在此 toolset
  - ps_XxYyZz11aBc                       # 岗位技能集 = position_id（含大写句柄）
  - baidu-map                            # 若 external_mcps 下发了 baidu-map，server 名须进白名单

# ⑥ 星火联网搜索凭据（F-024·§2.3.5；不需要则整段省略，撤销发空段 spark_search: {}）
spark_search:
  appid: "<星火 appid>"
  secret: "<星火 secret>"
  host: "114.118.75.223:30009"
```

> 客户端只 merge §2.3 表的 5 顶层键（`model`/`web`/`custom_providers`/`mcp_servers`/`enabled_toolsets`）+ `spark_search`（§2.3.5 F-024 已加进 merge 白名单）；`version_label` 等其余顶层键按需单读。**明文密钥仅 `custom_providers[].api_key`（模型）、`spark_search`（搜索）、external_mcps 的 `auth.headers`（MCP）三处**。

##### 2.3.1a-① 哪些段可配「多个」· 怎么配（代码依据 `config.py:3871`/`3875-3885`/`4053-4067`）

| 段 | 结构 | 能配多个？ | 加第 N 个的写法 |
|---|---|---|---|
| `model` | 单对象 | ❌ 只表达「当前默认模型」 | 多模型**不写这里** → 去 `custom_providers` |
| `custom_providers` | **列表** | ✅ 多个模型 provider（端点） | 列表再追加一条 `- name: ...`（每条 = 一个 `base_url` 端点） |
| `custom_providers[].models` | 列表 **或** 字典 | ✅ 一个 provider 挂多模型 | 简写 `models: ["m1","m2"]`；要给某模型**单配上下文长度** → 字典形 `models: {m1: {context_length: 131072}}`（`config.py:3875-3885` 两形都吃，list 会归一化成 `{m:{}}`；字典的 `context_length` 由 `config.py:4053-4067` 消费） |
| `mcp_servers` | **字典（按 server 名 key）** | ✅ 多个 MCP server | 再加一个 `<server_name>:` 键 |
| `enabled_toolsets` | **列表** | ✅ 多工具集/工具 | 列表追加 toolset 名或工具名 |
| `spark_search` | 单对象 | ❌ 单套凭据 | —（轮换=改值重发版） |
| `web` | 单对象 | ❌ 单 backend | — |

- **选中语义（2026-07-08 F-026 首验订正·实测 resolve_runtime_provider）**：运行时按 **`model.provider` == 条目 `name`** 选中 provider；`model.default` 只是发给该端点的模型串、**不参与选中**（填了别家的模型名也不会换 provider）。切换模型（跨 provider）= 同时改 `model.default` + `model.provider` 两个字段。`default_model` 是条目内 `model`(单数) 的合法别名（`config.py:3871`）。
- **多 provider + 多模型示例**（上面完整示例的增量·密钥用占位·name 一律非内置名）：

```yaml
model:
  default: deepseek-v4-flash          # 发给选中端点的模型串
  provider: deepseek-svc              # 选中哪条 custom_providers（按 name 匹配）
custom_providers:
  - name: deepseek-svc                # 第 1 个 provider（列表元素·⚠️ 禁内置裸名 deepseek）
    base_url: https://api.deepseek.com/v1
    api_key: "sk-XXX"
    models: ["deepseek-v4-flash", "deepseek-reasoner"]   # 同 provider 多模型：列表即可
  - name: spark-svc                   # 第 2 个 provider（列表再追加一条）
    base_url: http://<内网星火端点>/v1
    api_key: "XXX"
    models: ["spark-x1"]
mcp_servers:                          # 字典：每个 key = 一个 server（加多个 key = 多 MCP）
  server-a: { url: "http://...", enabled: false }
  server-b: { url: "http://...", enabled: false }
```

> 多模型下发/设置页切换的完整方案见 `ext/资料/F-026-服务端多模型下发与切换…md`（§3.1 下发格式同此键形）。

#### 2.3.2 `web` —— Hermes 内置原生搜索（可选）

> 这是 Hermes **内置** `web_search`/`web_extract` 的 provider 选择，**区别于** §2.4 管理端自定义「工具 API」。

| 子字段 | 类型 | 必填 | 含义 | 取值约束 |
|---|---|---|---|---|
| `web.backend` | string | ⬜ | web 工具通用 backend | `tavily`/`exa`/`parallel`/`firecrawl`/`searxng`/`brave-free`/`ddgs`/`xai`（`tools/web_tools.py:152`） |
| `web.search_backend` | string | ⬜ | 搜索专用 provider（覆盖 `backend`） | 同上（`web_tools.py:179`） |

> 键名是 **`backend`/`search_backend`**（不是 `search_provider`）。**API key 在 `.env`**（如 `TAVILY_API_KEY`），config 不带密钥；声明式：有 key 才真搜、无 key 容错跳过。要让 agent 真能调，还需 `web_search` 在 `enabled_toolsets`（§2.3.4）。

#### 2.3.3 `mcp_servers` —— MCP 服务（声明式）

结构：`mcp_servers.<server_name>` → 一个 server 配置对象。

| 子字段 | 类型 | 必填 | 含义 | 约束 |
|---|---|---|---|---|
| `<server_name>` | string(key) | ✅ | MCP server 逻辑名 | 工具注册后名为 `mcp_<server_name>_<tool>` |
| `.url` | string | ✅(远程) | 远程 MCP 端点 | 远程 HTTP/SSE 用 `url`；本地 stdio 改用 `command`/`args`/`env` |
| `.transport` | string | ⬜ | 传输方式（如 `sse`） | baidu-map 用 SSE |
| `.enabled` | bool | ⬜(默认 true) | 是否连接 | **`false`=声明占位、不连不报错** |
| `.headers` | object | ⬜ | 鉴权头 | 无鉴权整段省略 |
| `.connect_timeout` | number | ⬜ | 连接超时(秒) | 连不上由 Hermes 容错 reconnect-backoff、不 crash |

> **F-012 现状**：sales 岗位真接 `baidu-map`（`enabled:true`/`transport:sse`）。`enabled:true` 触发 discovery 真连（dead url 超时+错误日志，容错不 crash）。连接时机与白名单交互见 §2.3.4 两条 ⚠️。

#### 2.3.4 `enabled_toolsets` —— 岗位工具范围

| 类型 | 含义 | 取值 |
|---|---|---|
| array<string> | 本岗位 agent 可见的工具集/工具名白名单 | toolset 名或单个工具名。常用：`hermes-cli`（基础）、`external_apis`（§2.4）、`<position_id>`（岗位技能集）、MCP 的 `<server_name>`。⚠️ **F-024 起不再下发 `web_search`**（原生搜索无可用 key，联网搜索改 `spark_web_search`，见 §2.3.5——mock 四岗位已删，真服务端同口径） |

#### 2.3.5 `spark_search` —— 星火联网搜索凭据段（F-024 新增·服务端下发）

| 键 | 类型 | 必填 | 说明 |
|---|---|---|---|
| `appid` | string | ✅ | HMAC 签名 api_key |
| `secret` | string | ✅ | HMAC 签名密钥 |
| `host` | string | ✅ | 连接 host:port（如 `114.118.75.223:30009`） |
| `sign_host` | string | ⬜ | 参与签名的 host；缺省 = host 去端口（403 签名失败时可配带端口重试） |

- 客户端 `_merge_downloaded_config`（`routes.py`）把本段**整体覆盖**进 profile config.yaml → `desktop_backend/netsearch.py` 据此注册 `spark_web_search` 对话工具（external_apis toolset，契约见客户端API §2.25）。**服务端轮换凭据 = 改本段重发版**（F-017/F-022 sync 静默生效，下个新对话切新凭据）。从未下发过 → 工具不注册（不报错）。
- ⚠️ **撤销口径（重要）**：merge 对**缺失键跳过**（"缺失保留"，与 model 等段同语义）——**省略本段 ≠ 撤销**（本地旧凭据保留、工具继续可用）。要真撤销须**显式下发空段** `spark_search: {}`（整体覆盖为空 → 下个新会话工具消失）。再下发即恢复。
- 真服务端：本段由**管理端配置**、随岗位包下发；mock 四岗位 configs 已带 POC 凭据（客户环境换值即可）。

**当前 mock `configs/sales.yaml` 实况示例**（demo 形态；真服务端整包形态见 §2.3.1a）：

```yaml
model:
  default: deepseek-v4-flash
  provider: deepseek-svc            # F-026 起走 custom_providers 通道（mock 用 key_env 免真 key；真服务端 api_key 明文·§2.3.1a）
  base_url: https://api.deepseek.com/v1

custom_providers:                   # F-026：两 provider（deepseek-svc 真用 · local-svc 本地切换测试位）
  - name: deepseek-svc
    base_url: https://api.deepseek.com/v1
    key_env: DEEPSEEK_API_KEY
    models: ["deepseek-v4-flash"]
  - name: local-svc
    base_url: http://127.0.0.1:11434/v1
    models: ["qwen3:8b"]

web:
  backend: tavily
  search_backend: tavily

mcp_servers:                        # F-022 C-1 起 baidu-map 已改走 external_mcps.json 下发（§2.4A）；此段仅留声明式占位
  sales-knowledge-demo:
    url: http://127.0.0.1:65500/mcp
    enabled: false

enabled_toolsets:                   # F-024 起不含 web_search（原生搜索无 key，联网搜索改 spark_web_search）
  - hermes-cli
  - external_apis
  - sales
  - baidu-map                       # baidu-map 走 external_mcps 下发，但 server 名仍须进白名单（§2.3.4 交互）

spark_search:                       # F-024 星火联网搜索凭据（§2.3.5）
  appid: "XXX"
  secret: "XXX"
  host: "114.118.75.223:30009"
```

> ⚠️ **`enabled_toolsets` 是本后端私有约定键、非 Hermes 原生 config 键**。客户端在 `desktop_backend/chat.py:_enabled_toolsets()`（`chat.py:94-103` 读 `load_config().get("enabled_toolsets")`）→ 传 `AIAgent(enabled_toolsets=...)`（`chat.py:229`）。**缺省安全（fail-open）**：未下发该键 → `None` = 纳入全部 toolset（含 external_apis）。
>
> ⚠️ **下发生效时机**：① model/web/enabled_toolsets/.env——config 缓存按 mtime+size 失效，下发重写后下次 `load_config()` 自动读到；② MCP——provision merge 完 config 后**后台 daemon 线程**调 `discover_mcp_tools()` 真连（`routes.py:462-469`），失败只记日志不阻塞；`_build_agent` 构造前再幂等 discover 兜底。下发的真 MCP 无需手动 reload/重启。
>
> ⚠️ **`enabled_toolsets` ↔ MCP 白名单交互**：一旦某岗位下发**非空** `enabled_toolsets`，`enabled:true` 真连的 MCP 工具若 server 名不在列表里就**不进 agent 范围**（"下发了却调不到"）。**下发约定：真 MCP = `enabled:true` ＋ server 名一并写进 `enabled_toolsets`**，两者缺一不可。`external_apis` 因被强制纳入不受此影响。

---

### 2.4 `external_apis.json`（工具 API 清单）

> 管理端「编辑 API」表单逐条定义、按岗位下发的**任意 REST 工具**。后端在构造 AIAgent 前把每条 `registry.register` 成一个工具（toolset=`external_apis`），agent 即可在对话中调用（`desktop_backend/external_apis.py`）。

**结构**：一个 **JSON 数组**，每个元素 = 一个工具：

| 字段 | 类型 | 必填 | 含义 | 取值约束 / 行为（代码依据 `desktop_backend/external_apis.py`） |
|---|---|---|---|---|
| `display_name` | string | ✅ | 工具显示名（中文可） | 后端 slugify 成 ASCII function name（`:47-63`，重名加 `_2/_3`） |
| `description` | string | ⬜ | 工具用途说明（中文） | **仅供 `/dw/capabilities` 能力总览 UI 展示**（`routes.py:1150`）；**不进**给模型的工具 schema（模型侧 description 由 `display_name`+`response_example` 拼成，`:225-227`） |
| `url` | string | ✅ | REST 端点 | 空 url → 调用时 tool_error、不崩（`:158-159`） |
| `method` | string | ⬜(默认 GET) | 请求方法 | **C-5 起支持五种** `GET`/`POST`/`PUT`/`PATCH`/`DELETE`（对齐服务端终版 §3.3）。参数位置：**有体方法 `POST`/`PUT`/`PATCH` → JSON body；无体方法 `GET`/`DELETE` → query params**（`external_apis.py make_handler`）。连接器安装侧 `entry_from_manifest` 同步放宽（非上述五种 → 400）。|
| `side_effect` | bool | ⬜(默认 false) | 是否**写操作**工具 | `true` → 执行前走 approval 确认门（阻塞工具线程、SSE 推 `approval` 事件给前端确认框；deny/超时→tool_error 跳过；once/session/always→放行）。门实现 `:81-141`、判定 `:163-166` |
| `auth` | object | ⬜ | 鉴权（均走 header） | 见下；无鉴权整段省略 |
| `auth.type` | string | ⬜ | 鉴权类型 | 二选一：`bearer`→`Authorization: Bearer <key>`；`api_key`→`X-API-Key: <key>`（`:66-78`） |
| `auth.key` | string | ⬜ | 密钥 | 空 key → 不注入鉴权头 |
| `request_schema` | object | ⬜ | 入参定义 | **标准 JSON Schema（object）**，直接作工具 `parameters`（`:222/227`）；缺省 → 无参工具 |
| `response_example` | string | ⬜ | 出参示例 | 拼进工具 description 帮模型理解返回（`:223/226`） |

**规则补充**：
- 响应回灌模型前**截断 10 万字符**（`:25/:188-190`）；非 2xx → tool_error（带 status + 截断 body，`:181-187`），不崩。
- 请求 `trust_env=False` + `follow_redirects=True`（`:176`）。
- 坏 spec 只影响那一条，不带崩整批注册（`:217-219` 跳过非 dict）。
- **会话级注册**：构造 AIAgent 前注册、整个会话不变（保护系统 prompt 缓存）；重注册前先按 toolset 清残留（`:208-213` deregister）。

**完整示例**（`external_apis/sales.json`）：

```json
[
  {
    "display_name": "汇率查询",
    "description": "查询实时货币汇率（查询类工具，模型按需自动调用、不改数据）",
    "url": "https://api.frankfurter.dev/v1/latest",
    "method": "GET",
    "request_schema": {
      "type": "object",
      "properties": {
        "base":    { "type": "string", "description": "基准货币代码（USD/EUR/CNY），缺省 EUR" },
        "symbols": { "type": "string", "description": "目标货币，逗号分隔（USD,CNY），缺省全部" }
      }
    },
    "response_example": "{\"base\":\"EUR\",\"rates\":{\"USD\":1.08,\"CNY\":7.8}}"
  },
  {
    "display_name": "录入CRM拜访记录",
    "description": "把一次客户拜访记录写入 CRM。写操作工具，执行前会弹确认（approval）后才落库",
    "url": "https://httpbin.org/post",
    "method": "POST",
    "side_effect": true,
    "request_schema": {
      "type": "object",
      "properties": {
        "customer":  { "type": "string", "description": "客户名称" },
        "summary":   { "type": "string", "description": "本次拜访纪要" },
        "next_step": { "type": "string", "description": "后续跟进计划" }
      },
      "required": ["customer", "summary"]
    },
    "response_example": "{\"ok\":true,\"record_id\":\"CRM-20260629-001\"}"
  }
]
```

> **`display_name` / `response_example` 要写清楚**——它们是模型判断"何时调这个工具、返回长啥样"的唯一依据，写糊了模型就不调或乱调。建议每岗位至少配 1 个能真调通的只读 API + 1 个 `side_effect:true` 写工具（演示确认闸门）。

---

### 2.4A `external_mcps.json`（MCP 服务清单 · F-022 C-1 新增，对齐服务端终版 §3.4）

**文件位置**：zip 根 `external_mcps.json`（保留文件）。`common` 不含；岗位无 MCP 时省略整个文件（→ 客户端 no-op 保留现状）。

**结构**：JSON 数组，每条 = 一个该岗位要直连的第三方 MCP 服务（**不含 tools**——客户端拿 url+transport+auth 直连第三方自己拉，永远最新）：

| 字段 | 类型 | 必填 | 说明 |
|---|---|---|---|
| `id` | string | ✅ | MCP 连接器句柄（`mc_`；cron `connectors[]` 同源） |
| `server_name` | string | ✅ | MCP server 逻辑名（→ config.yaml `mcp_servers` 键） |
| `transport` | string | ✅ | 取值 `stdio`（本地子进程）/ `http`（远程）/ `sse`（远程·baidu-map 真连用）；客户端按此分流映射 |
| `url` | string | ⬜(http/sse) | 远程端点，**http/sse 必有**；stdio 不需要 |
| `command` | string | ⬜(stdio) | **stdio 必有**：子进程可执行命令（如 `npx`/`uvx`/`node`/绝对路径）。核心 `_resolve_stdio_command` 对裸 `npx`/`npm`/`node` 会到 `HERMES_HOME/node/bin` 等找候选 |
| `args` | array<string> | ⬜(stdio) | stdio 命令参数，默认 `[]` |
| `env` | object | ⬜(stdio) | stdio 子进程环境变量（可含明文密钥，如 `{"GITHUB_TOKEN":"ghp_xxx"}`）；**客户端落 config.yaml 时按 F-053 加密**（消费点解密还原，子进程拿明文），config.yaml 不留明文 |
| `auth.headers` | object | ⬜(http/sse) | 明文鉴权头（如 `{"Authorization":"Bearer sk-xxx"}`），客户端原样带上并 F-053 加密落盘；无鉴权省略 |

**stdio 下发样例（F-072·服务端照此规则下发）**：

```json
[
  {
    "id": "mc_github",
    "server_name": "github",
    "transport": "stdio",
    "command": "npx",
    "args": ["-y", "@modelcontextprotocol/server-github"],
    "env": {"GITHUB_TOKEN": "ghp_xxx"}
  },
  {
    "id": "mc_demo_baidu_map",
    "server_name": "baidu-map",
    "transport": "sse",
    "url": "https://mcp.map.baidu.com/sse?ak=xxx"
  }
]
```

> ⚠️ **两条附带约束**（服务端下发内容侧，非客户端代偿）：① `server_name` 须同时进 config.yaml 通道的 `enabled_toolsets` 白名单（§2.3.4）才能被 agent 调用；② stdio 命令的 runtime（node/npx/uvx 等）需客户端运行环境可用，否则子进程 execvp ENOENT——服务端按客户端环境能力下发命令。

**客户端消费**（`routes.py _merge_downloaded_external_mcps`，provision 与 F-017/F-022 sync 双挂·**F-072 起按 transport 分流**）：
- **http/sse**（有 url）→ `mcp_servers[server_name] = {url, transport, enabled: true[, headers]}`（行为不变）；
- **stdio**（有 command）→ `mcp_servers[server_name] = {command, args, transport:"stdio", enabled: true[, env]}`；无 command 的 stdio 条目**跳过并告警**；
- 写进 profile config.yaml → 现成 `discover_mcp_tools()` 起本地子进程/远程直连拉工具；
- **合并语义 = 整体覆盖**（终版 §3.8，同 external_apis）+ **sidecar 记账**（profile `.dw_external_mcps.json` 记本通道写入的 server_name·与 transport 无关）：本轮清单里消失的旧条目**删除**（工具经 sync 的 mcp deregister 差集清理），config.yaml 直发/用户本地/市场安装(F-021) 的 server **不碰**；
- 与 config.yaml `mcp_servers` 段共存：config merge（整体替换）先行、external_mcps 后行 upsert——同名以 external_mcps 为准。

> mock 数据源 = `mock_data/external_mcps/<position_id>.json`；demo 已把 **baidu-map 搬到本通道**（`external_mcps/sales.json`，configs/sales.yaml 的 mcp_servers 段仅留声明式样例）。

### 2.5 `business_systems.json`（业务系统定义 · 岗位包通道）

> **需求编号**：F-007（业务系统本体）｜F-011（`associated_skills` 系统↔SOP 关联，本地维护、本契约不含）｜**F-020 更新**：业务系统定义的**主通道改为市场连接器列表**（§1.6 `type:"BIZ_SYSTEM"`，安装即弹浏览器人工登录）；本节的岗位包通道**保留兼容**（服务端不配业务系统时下发 `[]` 或省略文件即可——客户端合并语义"缺失保留不删"天然兼容）。

**文件位置**：zip 根 `business_systems.json`（与 `config.yaml`/`external_apis.json` 同级）。`common` 不含。岗位包可选。

**结构**：JSON 数组，每条一个业务系统**定义**（仅下列 5 字段，**不得**含 `account`/`password`/`status`/`tested_at`/`associated_skills`）：

| 字段 | 类型 | 必填 | 含义 | 约束 |
|---|---|---|---|---|
| `id` | string | ✅ | 唯一标识，**合并主键** | ASCII slug `^[a-z0-9][a-z0-9-]*$`（biz skill 目录名 `biz-<id>/` 据此） |
| `name` | string | ✅ | 显示名（中文可） | — |
| `login_url` | string | ✅ | 登录地址 | 公开 URL、非凭据；**须为服务地址**（登录后能反映登录态、未登录才跳登录页），**勿配 `sso/login` 类强制表单端点**（无论有无会话都显表单 → 已登录仍误弹登录窗，OA 踩坑 problems 2026-07-07） |
| `purpose` | string | ⬜ | 用途说明 | 缺省 → biz skill 用 `login_url` 占位 |
| `success_hint` | string | ⬜ | 登录成功判据 | **F-020 起客户端用通用默认判据、可不下发**；⚠️ 若不下发请**整个省略该键**（客户端合并会把下发的空值刷进本地，见回执问题5） |

**客户端合并规则（按 `id` 合并，非全量替换——`business_systems.py:65-124`，已实现）**：

| 情形 | 行为 |
|---|---|
| 本地**已有**同 `id` | **只更新** `name`/`login_url`/`purpose`/`success_hint` 4 个定义字段；**绝不覆盖**本地凭据/状态/关联 |
| 本地**无**该 `id` | **新建**：5 定义字段 + 空凭据（`account=""`/`password=""`/`status="untested"`/`tested_at=null`） |
| 本地有、下发清单**没有**的 `id` | **保留不动**（不删——防误删员工本地新增；与技能"rmtree 全覆盖"、cron"撤下即删"语义**不同**，勿混用） |

**示例**：

```json
[
  {
    "id": "oa",
    "name": "OA 协同办公系统",
    "login_url": "https://oa.example-corp.com/login",
    "purpose": "日常审批、公文流转、待办处理"
  }
]
```

> mock 实现（**2026-07-07 更新**）：mock 岗位包**已改为不打包** `business_systems.json`（即"发 []"——F-020 §3.1 岗位不再下发业务系统，全部从连接器市场安装；`mock_data/business_systems/*.json` 保留但不下发，`mock_server.py` config 端点已注释停用）。曾预置下发致"删 profile 重进又见三系统已连接"（problems 2026-07-07）。真服务端同口径：不配业务系统即可。

---

### 2.6 `cron_jobs.json`（定时任务模板）

> **需求编号**：F-003（定时任务与提醒——本节下发"岗位自带 / 通用自带"两类模板；"员工自建"纯客户端本地）。复用 `/api/config` bundle、不新开接口。

**文件位置**：zip 根 `cron_jobs.json`。岗位包可选。⚠️ **`common` 伪岗位也可含本文件**（§2.1 铁律 4 的唯一例外——"通用自带"任务靠 common 包下发给所有岗位）。

**结构**：JSON 数组，每条一个任务**模板**（字段对齐客户端 `create_job`，`cron/jobs.py:523`）：

| 字段 | 类型 | 必填 | 含义 | 取值约束 / 行为 |
|---|---|---|---|---|
| `id` | string | ✅ | 模板唯一标识，**合并主键**（按"来源+id"去重） | ASCII slug。岗位自带建议带岗位前缀（`sales-opp-health-weekly`）、通用自带建议 `common-` 前缀。⚠️ 是"模板来源标识"，不是客户端本地 job id |
| `name` | string | ✅ | 任务显示名（中文可） | 列表 + 提醒卡标题 |
| `prompt` | string | ✅ | 到点让搭子做什么（大白话指令） | 自包含。**降噪**：想"无变化不打扰"，prompt 里写明"若无实质变化则只输出 `[SILENT]`"（客户端见 `[SILENT]` 前缀即不进提醒） |
| `schedule` | string | ✅ | 调度表达式（周期/间隔/单次三态） | 走客户端 `parse_schedule`（`cron/jobs.py:206`）：**周期→cron**（`30 8 * * 1`；逗号多时刻 `0 9,18 * * *` ✅）｜**间隔→`every 30m`/`every 2h`**｜**单次→ISO `2026-07-10T14:00`**。⚠️ **勿用月末 `L`**——客户端 cron 识别正则不含 `L`（`cron/jobs.py:242`），任务会被**静默丢弃**（回执 S-2）；月末改具体日（如 `0 9 28 * *`） |
| `skills` | array<string> | ⬜ | 执行时加载的技能名（该岗位已下发的 SKILL.md `name`） | 缺省 = 默认带当前岗位技能 |
| `connectors` | array<string> | ⬜ | 任务**锁定 + 预授权免确认**的连接器（按名引用**已下发**的连接器） | 三类取值：`external_apis`（§2.4 API 工具集）｜MCP server 名（§2.3.3，如 `baidu-map`）｜业务系统 id（§2.5，客户端映射到 `biz-<id>` 技能）。缺省 = 不锁定、继承岗位全部连接器。连接器**本体不在此下发**、只按名引用 |
| `deliver` | string | ⬜ | 结果去向 | **预留**——本期只做 in-app 提醒，缺省/任意值一律落"提醒中心" |
| `enabled` | bool | ⬜(默认 true) | 下发后是否默认启用 | `false` = 下发但默认暂停 |

**客户端合并规则（按"来源+id"合并——`cron_provision.py`，已实现；F-023 V2 改「变更转个人」）**：

| 情形 | 行为 |
|---|---|
| 本地**无**该来源+id | **新建** cron 任务，记来源映射 + 定义指纹 `sig` |
| 本地**已有**同来源+id，**定义未变**（指纹一致） | **保持原样**（不再在场刷新覆盖本地；留本地内容） |
| 本地**已有**同来源+id，**定义变了**（FDE 改过 name/prompt/schedule/skills/connectors） | 🆕 **变更转个人**（F-023 V2）——移出来源映射 → 该任务变为**员工自建**（`source=null`、可改可删），活动任务**留旧内容不套新定义**；记入释放清单，**此后不再下发新版** |
| 本地有、下发清单**没有**的同来源 id（**撤下**） | ✅ **撤下即删**——FDE 整条移除即本地删（**仅 provision 成功拉到包才删**；拉包失败一律不动，防误删）。包内无 `cron_jobs.json` = 空清单 → 删光该来源全部**未转个人**的自带任务 |
| **员工自建**任务（含已变更转个人的） | **完全不碰**（不在来源映射里，天然隔离；个人可改可删） |

> **个人不可删岗位任务**（F-023 V2）：仍在来源映射里的下发任务，客户端**只能暂停/恢复、不能删**（`DELETE /dw/cron/jobs` 对下发任务回 403）；只有已「变更转个人」脱离映射的才可删。

> **来源标识**：客户端 provision 先拉岗位包、再拉 common 包，按 bundle 归属打"岗位自带/通用自带"标签——**服务端 JSON 不需要写 source 字段**。
> **触发时机**：合并只在 provision 时跑（启动/登录/手动同步/后台自动同步 F-017）；本期不单独造轮询。
> **无人值守免确认（已拍板）**：`connectors` 选中的连接器到点**直接执行、免确认**（含写类）——确认前移到"建任务选连接器"这一刻。

**示例**（岗位自带 `cron_jobs/sales.json`）：

```json
[
  {
    "id": "sales-opp-health-weekly",
    "name": "商机健康度巡检",
    "prompt": "巡检我正在跟进的所有商机，按接触频次、推进阶段给每个商机打健康度分并给出跟进建议。若整体都无实质变化，则只输出 [SILENT]。",
    "schedule": "30 8 * * 1",
    "connectors": ["external_apis"],
    "enabled": true
  },
  {
    "id": "sales-competitor-scan",
    "name": "竞品动态扫描",
    "prompt": "扫一遍主要竞品在我在跟客户处的最新动态，整理成简报。没有值得关注的新动态则只输出 [SILENT]。",
    "schedule": "0 9 * * 1,4",
    "skills": ["sales-visit-brief"],
    "enabled": true
  }
]
```

**示例**（通用自带 `cron_jobs/common.json`，随 common 包下发给所有岗位）：

```json
[
  {
    "id": "common-daily-brief",
    "name": "每日工作简报",
    "prompt": "汇总我昨天沉淀的工作记录和今天的日程安排，生成一条简明的工作简报。如果没有新记录也没有日程，就只输出 [SILENT]。",
    "schedule": "0 8 * * *",
    "enabled": true
  }
]
```

> mock 实现：`config()` 组 zip 时把 `mock_data/cron_jobs/<position_id>.json` 以 `cron_jobs.json` 写入 zip 根，**common 同样处理**（`mock_server.py:130-133`，**已实现**——注意此文件不加 `is_position` 守卫，与另三个保留文件不同）。

---

### 2.7 `.env`（API 密钥，**不在 zip 内下发**）

> **契约约束**：zip 岗位包内的 `config.yaml` / `external_apis.json` **一律不含明文密钥**。密钥走 `.env`：
> - demo：客户端克隆本机 `~/.hermes/.env`（如 `TAVILY_API_KEY`）到该岗位 profile，服务端不下发密钥。
> - 真服务端：按企业密钥托管方案落 `profiles/<岗位>/.env`（Hermes 经 `get_env_value` 读 HERMES_HOME/.env）。

---

### 2.7A `expert.json` —— 专家元数据（F-080 新增·仅专家 ZIP 含）

**用途**：专家包里携带的元数据文件，客户端领用时由此读取专家的 name/role_desc/skills 清单——供 @ 委派时拼装子 agent 的 focus prompt（"我是谁、我该干什么、我有什么工具"）。

**必填字段**：

```jsonc
{
  "id": "sales-manager",
  "name": "销售经理",
  "role_desc": "你是CRM销售专家，专注客户关系管理与销售漏斗分析。你擅长：\n1) 拜访记录自动落表——用户口述拜访内容时自动提取关键信息并录入CRM\n2) 商机跟进与分析——实时分析销售漏斗，提醒异常商机\n3) 客户画像查询——按客户名快速汇总历史跟进记录与偏好\n\n对用户的销售类问题以数据驱动方式回答，不确定时主动查证。",
  "skills": ["CRM 拜访记录", "商机分析", "客户画像查询"]
}
```

**字段表**：

| 字段 | 类型 | 必填 | 含义 | 约束 |
|------|------|------|------|------|
| `id` | string | ✅ | 专家句柄 | 与 §1.8A 列表 `id` 一致 |
| `name` | string | ✅ | 中文显示名 | 与 §1.8A 列表 `name` 一致 |
| `role_desc` | string | ✅ | **专家的 soul / 人格描述** | 200-500 字；@ 委派时直接拼入子 agent focus prompt，告诉它"我是谁、我该干什么"。建议包含：职责范围、核心能力描述、行为风格 |
| `skills` | string[] | ✅ | 技能 name 列表 | **必须与 ZIP 内各 SKILL.md frontmatter 的 `name` 完全一致**（客户端以此做技能清单匹配与委派时的能力声明） |

**设计意图**：`role_desc` 是专家区别于岗位的核心——岗位侧重"权限/profile"，专家侧重"能力/人格"。`role_desc` 越具体，子 agent 的 focus prompt 越精准、委派质量越高。

**与 §2.1 岗位包的关系**：专家 ZIP 根目录同时含 `expert.json`（本条）和 `config.yaml`/`external_apis.json`（同 §2.3/§2.4）。`expert.json` 是元数据层，`config.yaml`/`external_apis.json` 是运行时资源层——客户端落盘时分别处理。

---

### 2.7B 专家 ZIP 下发物完整结构（速查）

```
<expert_id>.zip
├── expert.json              ← §2.7A（必含）
├── config.yaml              ← §2.3（可选·有则下发）
├── external_apis.json       ← §2.4（可选·有则下发）
├── external_mcps.json       ← §2.4A（可选·有则下发）
├── <skill-slug-1>/
│   └── SKILL.md             ← §2.2（≥1 个）
└── <skill-slug-2>/
    └── SKILL.md
```

> **服务端实现提示**：结构与岗位包同构（§2.1），仅根目录多一个 `expert.json`。可复用岗位包的 ZIP 序列化/技能递归打包/MCP 关联注入逻辑——只多写一个文件。`config.yaml`/`external_apis.json` 的「按技能关联过滤」同 §2.3/§2.4 现有规则。

---

## 3. 服务端数据模型（mock 实现，真服务端可换存储）

> 以下是 **mock 的存储形态**，真服务端按 §1/§2 契约实现即可、不必照搬目录与文件。

### 3.1 `mock_data/accounts.json` —— 账号

```json
{
  "<username>": { "password": "<pwd>", "user_id": "<uid>", "positions": ["<position_id>", ...] }
}
```

| 字段 | 含义 |
|---|---|
| key=`<username>` | 登录账号 |
| `password` | 明文密码（仅 mock） |
| `user_id` | `/api/auth` 返回的 user_id |
| `positions` | 该账号名下岗位 id 列表 |

### 3.2 `mock_data/positions.json` —— 岗位定义（F-022 补五字段）

```json
{
  "<position_id>": {
    "name": "<显示名>", "role_desc": "<职责一句话>", "skills_dir": "skills/<position_id>",
    "recommended_questions": ["…", "…", "…", "…"],
    "avatar": "🧑‍💼", "description": "<展示用简介>",
    "persona": "## 工作特征\n…（Markdown·→ SOUL.md）",
    "intake_fields": [ {"key":"…","label":"…","type":"text|textarea|single_select|multi_select|number|date","required":true,"options":null,"placeholder":null,"default_value":null,"desc":null} ]
  }
}
```

| 字段 | 含义 |
|---|---|
| key=`<position_id>` | 岗位 id（含伪岗位 `common`——但 **§1.1A 不返回 common**） |
| `name` / `role_desc` | 显示名 / 职责一句话（→ §1.1A positions[]） |
| `skills_dir` | 该岗位技能源目录（相对 `mock_data/`） |
| `recommended_questions`/`avatar`/`description`/`persona`/`intake_fields` | **F-022 新增**（→ §1.1A 五字段；缺省容错：无 recommended_questions=空数组、无 persona=null…）。`intake_fields=[]`=该岗位无采集定义（完善信息页只留伙伴名） |

### 3.2A `mock_data/config_versions.json` —— 岗位包版本（F-022 D）

```json
{ "sales": 3, "kefu": 2 }
```

- 值 = 该岗位**最新整数版本**（→ §1.1C 版本列表，mock 现造 `[latest, latest-1]` 两条降序）。
- **模拟发新版**：数字 +1（顺手改该岗位某 SKILL.md）→ 下轮 sync 判涨重下。
- **不在文件里的岗位** → §1.1C 返回空列表（客户端回落 sha256 指纹路径）。

### 3.3 mock 技能源目录（四保留文件 → zip 根，均已实现）

```
mock_data/skills/<position_id>/<skill-dir>/SKILL.md   # 改 SKILL.md 即生效（现打 zip）
mock_data/configs/<position_id>.yaml                  # → zip 根 config.yaml（common 无）
mock_data/external_apis/<position_id>.json            # → zip 根 external_apis.json（common 无）
mock_data/external_mcps/<position_id>.json            # → zip 根 external_mcps.json（common 无·F-022 C-1）
mock_data/business_systems/<position_id>.json         # → zip 根 business_systems.json（F-020 起停发）
mock_data/cron_jobs/<position_id>.json                # → zip 根 cron_jobs.json（common 亦有）
```

> `/api/config` 现打 zip：遍历 `skills_dir` 下所有 `SKILL.md` 按相对路径入 zip，再把保留文件写入 zip 根（`mock_server.py` config 端点）。业务系统 F-020 起不下发（§2.5 说明）。

### 3.4 能力市场 mock 数据（F-016）

**数据文件**：`mock_data/market/`（`skill_categories.json` / `skills.json` / `connectors.json` / `positions.json`）。

**数量与分布建议**：分类 4-8 个；技能 20-30 个（约 30% `featured:true`，至少 5 个带 `dependencies.connectors` 供测关联安装）；连接器 10-15 个（**BIZ_SYSTEM 类须带 `type`+`login_url`+`purpose`+`success_hint`**，F-020）；岗位 6-8 个。`installed`/`connected` 一律 `false`（客户端判断）。

**包格式**（下载端点动态打包）：

```
技能包 <slug>.zip                    连接器包 <connector_id>.zip（仅 API/REST 类）
├── skill.md      # 必需（§2.2）      ├── connector.json   # 必需（§1.7 格式）
├── references/   # 可选子文件树      └── schema.json      # 必需（JSON Schema）
└── ...
```

---

## 4. mock 启动与验证（demo 实现细节）

- **位置**：服务脚本 `ext/mock_server/mock_server.py`；数据 `ext/mock_server/mock_data/`（可直接编辑）。
- **启动**（单独终端）：
  ```bash
  python ext/mock_server/mock_server.py      # 监听 http://127.0.0.1:9999
  ```
- **客户端对接**：`server_url = http://127.0.0.1:9999`（demo 默认；本地后端经 env `MOCK_SERVER_URL` 覆盖）。
- **独立验证**（不依赖客户端）：
  ```bash
  # 登录
  curl -X POST http://127.0.0.1:9999/api/auth \
    -H "Content-Type: application/json" \
    -d "{\"username\":\"zhumei\",\"password\":\"123456\"}"
  # 拉岗位包
  curl -X POST http://127.0.0.1:9999/api/config \
    -H "Content-Type: application/json" \
    -d "{\"token\":\"mock-token-zhumei-0001\",\"position_id\":\"sales\"}" -o sales.zip
  # 解开 sales.zip：根含 config.yaml + external_apis.json (+ business_systems.json + cron_jobs.json) + sales-*/SKILL.md
  # 市场
  curl "http://127.0.0.1:9999/api/market/connectors?page=1&page_size=20"
  ```

---

## 5. 切换到真服务端

- demo：`server_url=http://127.0.0.1:9999` 走本 mock。
- 真服务端就绪：只改 `server_url` 为真网关地址，**客户端代码零改**（接口契约一致）。真接口差异在本文件登记；与真服务端的逐条对齐结论见 `客户端接口对齐-会谈稿.md`（服务端来稿）与 `客户端接口对齐-回执.md`（我方回执，含 3 条硬阻断与 S-1/S-2/S-3 服务端改动清单）。
- **真服务端须重点对齐的点**（回执定论）：① market 鉴权口径（公开 vs Bearer，S-3）；② 连接器下发三路（BIZ 走列表带 `type`/`login_url`、API 包格式、MCP 待定，S-1）；③ cron `schedule` 勿用月末 `L`（S-2）。

---

## 6. 修订记录

| 版本 | 日期 | 变更 |
|---|---|---|
| **V3.6** | 2026-07-24 | **F-072 stdio 协议 MCP 下发适配**：§2.4A `external_mcps.json` 加 stdio 三字段 `command`/`args`/`env`（补齐原挂账缺口）；`transport` 分流 stdio/http/sse；客户端消费 `_merge_downloaded_external_mcps` 去「无 url 跳过」、按 transport 分流映射进 config.yaml `mcp_servers`（stdio 无 command 才跳过告警）；`env` 密钥按 F-053 同口径加密落盘、消费点 `_dw_mcp_run` wrap 解密还原（子进程拿明文）；核心 `_run_stdio` 原生消费落点、核心零改。附完整 stdio 下发样例 + 两条服务端侧约束（enabled_toolsets 白名单 / runtime 可用）。安全按服务端下发可信免命令校验（用户拍板）。 |
| **V3.5** | 2026-07-09 | **鉴权口径统一 Bearer（A-2 拍板·真服务端联调实锤）**：`/api/positions`、`/api/config`、`/api/config/versions` 等**全部接口鉴权 = `Authorization: Bearer <token>` 头**（真服务端只认头、body `{token}` 401——2026-07-09 实测）；原契约的 body token 形态**降级为 mock 兼容过渡**（mock `_resolve_token` Bearer 优先、body 回落；无 token 401）。客户端已适配**双带**（头+body 同发，真/mock 均 200）：`api.ts getPositions`、`routes.py` provision、`entry.py` versions/sync 四处。mock 自测 9/9（Bearer-only/body-only/双带/无token 401/登出失效/重登恢复）。 |
| **V3.4** | 2026-07-08 | **切服务端·模型明文凭据下发协议定死（负责人定·代码亲验 PASS）**：新增 §2.3.1a——服务端下发明文模型 api_key **必须用 `custom_providers` 列表 + inline `api_key`**（Hermes 原生 `config:<name>` 凭据源直读 `credential_pool.py:2097-2117`，客户端零改）；**禁止**单独放顶层 `model.api_key`（`model_config` 源 `:2119-2150` 需匹配 custom_providers 才生效、单独放读不到→回落 env→切服务端认证失败）。§2.4A method 五种口径（C-5）同批。 |
| **V3.3** | 2026-07-08 | **F-022 C-1 落地·`external_mcps.json` 下发通道**（对齐服务端终版 §3.4/§3.8）：新增 §2.4A 契约（MCP 服务清单·不含 tools·客户端直连拉）；岗位包新增 zip 根保留文件 `external_mcps.json`（mock 源 `mock_data/external_mcps/<岗位>.json`）；客户端 `_merge_downloaded_external_mcps` 整体覆盖映射进 config.yaml mcp_servers（sidecar `.dw_external_mcps.json` 记账、只撤本通道 server、不碰 config直发/用户/市场装的）；**baidu-map 已从 configs mcp_servers 段搬到本通道**。stdio 无 url 条目跳过（终版无 command 字段·缺口待联调）。 |
| **V3.2** | 2026-07-08 | **F-022 补充·选岗位×岗位专家市场数据统一（用户定「完全同一份列表」）**：①市场条目 = 与 §1.1A 主岗位**完全同一份 4 个**（id 统一 `sales-manager→sales`/`product-manager→chanpin`/`customer-service→kefu`+补 `yanfa`；**删** frontend-dev/backend-dev/data-analyst/finance 4 个纯市场专家）；②`/api/market/positions` **服务时**用 `positions.json` 覆盖 `name/description(简介否则 role_desc)/recommended_questions/avatar`（同一取值链，JSON 漂移不生效，对齐终版 §2.3/§2.13 同源同值）；③chanpin 补齐 description/推荐问题/avatar（消除空白差异）；④「领用」同 id 岗位经 `/api/config` 得到**真实岗位包**（非现造轻量包）；⑤修 `/api/positions` 与市场端点函数同名遮蔽（改 `list_positions`，路由行为无变化）。市场卡片的 buddy_name/skills/统计等为市场 UI 装饰字段（保留，不参与对齐口径）。 |
| **V3.1** | 2026-07-07 | **F-022（对齐服务端终版 §2.1/§2.2/§2.3/§2.5）**：§1.1 `/api/auth` **移除 `positions[]`**（只返 `{token,user_id}`；岗位改 §1.1A）+ token 登出失效语义；新增 **§1.1A `POST /api/positions`**（岗位信息唯一下发源：`recommended_questions`/`avatar`/`description`/`persona`/`intake_fields`，不含 common）、**§1.1B `POST /api/auth/logout`**（Bearer·`{code,message,data}` 特殊格式·已登出集合语义）、**§1.1C `POST /api/config/versions`**（整数版本判更新·空列表回落 sha256·数据源 `config_versions.json`）；§1.2 `/api/config` 对已登出 token 返 401；§3.2 positions.json 补五字段。mock token 确定性（同人同串）与真服务端 JWT 差异已标注。 |
| **V3.0** | 2026-07-06 | **重构定版**：契约语义与章节编号不变；头部历史摘要归档本表；`client_backend`→`desktop_backend` 全量校准行号；删过时"现状未实现"注（provision 四保留文件处理 `routes.py:458/472/474/477` 与 mock 四文件入 zip `mock_server.py:109-133` 均已实现）；`rating`/`install_count`/`recommended_questions`/`count` 改**可空**（对齐回执 R5）；删 §3.4 "50% installed:true" 矛盾建议；§1.6 融入 F-020（`type` 类型判别符 + BIZ 列表带 `login_url`/`purpose`/`success_hint`、免下载）、§1.7 标注 BIZ 不走下载 + 明确 connector.json/schema.json 客户端消费口径；§2.6 `schedule` 补"勿用月末 `L`"（S-2）；§2.5 标注 F-020 后岗位包通道保留兼容 + `success_hint` 缺省勿发空值；§5 挂接会谈稿/回执。 |
| V2.7 | 2026-07-22 | 配置修缮：8 个岗位 config 模板（configs/*.yaml）追加 auxiliary 13 任务 `provider: main` 钉定段（auto 探测链撞 openrouter 共享池 402/未认证 Nous 全天试错噪声，钉主模型零探测）；config_versions bump（sales 5/kefu 4）让已领用岗位随 sync 拉到。真服务端接管下发后需在其 config 模板保持同款段。详见 problems.md 2026-07-22 auxiliary 条。 |
| V2.6 | 2026-07-03 | F-016 能力市场 6 接口（§1.3~§1.9）+ §3.4 mock 数据。契约首次超出"两端点"边界：市场数据服务端提供、前端直连；安装走本地后端落盘。 |
| V2.5 | — | F-003 定时任务模板下发：新增 §2.6 `cron_jobs.json`（复用 /api/config bundle）；按"来源+id"合并、撤下即删（仅 provision 成功才删）、员工自建不碰；`connectors` 三类命名引用 + 无人值守预授权免确认；common 可含（铁律 4 唯一例外）。 |
| V2.4 | 2026-07-02 | F-014：`/api/auth` positions[] 加可选 `role_desc`。 |
| V2.3 | 2026-06-30 | F-012：sales 真接 baidu-map MCP（enabled:true + server 名进 enabled_toolsets）。 |
| V2.2 | 2026-06-30 | F-007：新增 §2.5 `business_systems.json`（仅 5 定义字段、无凭据；按 id 合并、保留本地凭据）。 |
| V2.1 | 2026-06-29 | 字段补全+行号校准：§0.0 划界；§2.4 补 `description`/`side_effect`；补两端点调用点。 |
| V2.0 | 2026-06-26 | 定版重构：契约（§1/§2）与 mock 实现（§3/§4）分离，逐字段定义。 |
| V1.x | 2026-06 | V1.9 MCP 下发约定；V1.8 白名单交互坑；V1.7 enabled:false 占位；V1.6 鉴权/方法收敛；V1.5 external_apis 下发；V1.2-1.4 config.yaml 下发；V1.1 端口 9999；V1.0 首版。 |
