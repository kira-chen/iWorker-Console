# dev-expert 技能 · 触发指令速查

> 安装位置：`.claude/skills/dev-expert/`（v1.0.48，19 个子技能 + 31 个 reference）
> **已设为「仅显式调用」**：不会自动路由，必须用下面任一方式主动触发。
> hooks 未安装（脚本已解压在 `hooks/`，未接入 settings.json）。

---

## 一、三种触发方式

### 1. 斜杠命令（整体调用，走内部关键词路由）
```
/dev-expert 帮我看下这段登录逻辑
```

### 2. 自然语言点名
```
用 dev-expert 审一下这次改动
```

### 3. @子技能标识（推荐，直达指定模块、跳过路由匹配）
```
@code-review 审一下 SkillZipImportService
@bug-diagnosis 这个接口返回 500，日志在下面
```

**@ 用法约束**（SKILL.md:91）：
- 必须在**输入开头**或独占一段
- 标识拼错会自动回退关键词路由（不报错，静默降级）
- 邮箱、普通 @提及 不触发
- **@ 只跳过路由匹配，不跳过流程**：意图三分法、安全闸门、澄清策略、验证闭环、复盘沉淀照常执行

---

## 二、可 @ 调用的 19 个子技能

### 本仓常用（Java + Vue）

| 指令 | 用途 |
|------|------|
| `@code-review` | 代码审查：分级问题清单 + 修复建议 |
| `@bug-diagnosis` | Bug 诊断：日志/堆栈 → 根因 → 修复方案 |
| `@refactoring` | 重构建议：识别坏味道，给重构步骤 |
| `@code-generation` | 代码生成：含错误处理与边界条件 |
| `@test-generation` | 测试用例：单测/集成/边界，覆盖正常与异常路径 |
| `@task-decomposition-and-execution` | 任务拆解：原子任务按依赖分 Wave 执行 |
| `@api-design` | API 设计：版本/鉴权/限流/幂等/错误码 |
| `@frontend-design` | 前端设计：信息架构、视觉规范、响应式、可访问性 |
| `@mysql-database` | 数据建模、索引、事务边界、慢查询、迁移回滚 |
| `@doc-generation` | 文档生成：README / API 文档 / 架构说明 |
| `@performance-benchmark` | 性能基准：火焰图、benchmark、优化前后对比 |
| `@tech-selection` | 技术选型（注意：本仓技术栈锁定，选型结论须先经负责人同意） |

### 项目级 / 方法论

| 指令 | 用途 |
|------|------|
| `@software-project` | 软件项目总控：需求→架构→测试→发布→回滚 |
| `@website-project` | 网站项目总控：站点规划、SEO、部署 |
| `@spec-driven-development` | Spec 驱动：编码前对齐需求规格 |
| `@karpathy-coding-guidelines` | Karpathy 编码哲学：简洁优先、手工胜于模板 |
| `@project-memory-management` | 项目记忆沉淀与跨会话恢复 |
| `@project-knowledge-graph` | 代码依赖图谱：跨模块改动查影响面 |
| `@cms-development` | PHP + MySQL CMS 二次开发（**本仓用不上**） |

---

## 三、不可 @ 调用的专项 reference

以下由子技能按需自动加载，**不接受 @ 显式调用**，可让我直接读文件：

`java-development` · `javascript-development` · `execution-safety` · `delivery-assurance`
`error-ledger` · `style-alignment` · `architecture-decision` · `domain-driven-design`
`distributed-systems` · `laravel-development` · `laravel-testing`

---

## 四、易混场景的自动纠偏

指定的标识与任务实际性质不符时，它会**先问再切**，不会擅自改道：

| 你指定 | 任务实际含 | 它会问 |
|--------|-----------|--------|
| `@code-generation` | 审查/review/找漏洞 | 是否切到 `@code-review`？ |
| `@code-review` | 实现/写代码/补接口 | 是否切到 `@code-generation`？ |
| `@code-generation` | 报错/异常/堆栈/崩溃 | 是否切到 `@bug-diagnosis`？ |
| `@refactoring` | 新功能/新增 | 是否切到 `@code-generation`？ |
| `@bug-diagnosis` | 重构/优化/重写 | 是否切到 `@refactoring`？ |

---

## 五、与本仓约定的冲突处置（重要）

dev-expert 是第三方通用框架，**冲突时一律以本仓约定为准**：

| 它的做法 | 本仓约定 | 处置 |
|---------|---------|------|
| 「批量修改 7 防线」写 `.bak` 备份 | 改文件即完成、每日打包外发，`.bak` 会污染压缩包 | **不执行**其 .bak 机制 |
| `build_graph.py` 生成图谱缓存 | 运行落盘数据一律不入库 | 用前先确认产物路径被 .gitignore 覆盖 |
| 技术选型给新栈建议 | 技术栈锁定，新增须先经负责人同意 | 仅作参考，不擅自引入 |
| 其自有交付/收尾模板 | 每日改动记录三段式、接口契约铁律等 | 以本仓规范为准 |

PHP / CMS / Laravel 相关内容在本仓（Java + Vue）自然空转，忽略即可。

---

## 六、恢复自动路由

如需改回自动触发，编辑 `.claude/skills/dev-expert/SKILL.md` 第 3 行 `description:`，
去掉「【仅显式调用】」与末句约束，恢复为原始描述（原文见 v1.0.48 zip 包内 SKILL.md）。
