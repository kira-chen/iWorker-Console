# 连接器改造 —— 服务提供系统 + MCP 服务级发布（接口契约）

- **作者：** 架构师 | **日期：** 2026-06-26 | **状态：** 初稿（待后端 / CR 评审）
- **配套表设计：** [`docs/architecture/database/连接器改造-服务提供系统与MCP服务级发布-表设计.md`](../architecture/database/连接器改造-服务提供系统与MCP服务级发布-表设计.md)（V40 + V41 迁移）

> **★ 后注（2026-06-26 · 默认分组概念归并，与表设计 V41 同步）：** 用户拍板**取消「未分组/default 兜底分组」特例，所有分组一视同仁**。本契约据此调整：① provider-systems 列表/详情 VO **去掉 `isDefault` 字段**；② 删除规则统一为「**非空分组禁删、空分组可删**」（移除「默认分组禁删」特例）；③ 明确**零分组禁建 API** 口径（§2.2 / §6）。原 V40 种子分组（id=1）经 V41 改名为业务分组「报销系统」（已装存量报销查询 API id=6）。
- **统一响应包络** `ResultVO<T>`：`{ code, message, data }`（`code=0` 成功，沿用项目现状）。列表统一形状 `ListVO<T>` = `{ list:[...], total }`。
- **鉴权与角色门：** 全部端点挂 `/api/fde/...` 前缀，由 `AdminRoleGuard` 统一覆盖（至少 SYS_CONFIG/ADMIN，与现有连接器/市场端点一致）。
- **错误码沿用项目规范：** `400`（参数，带 `field`）、`403`（无权限/自审）、`404`（不存在）、`1000`/`BUSINESS_ERROR`（业务）。

---

## 0. 变更总览

| 类别 | 端点 | 说明 |
|------|------|------|
| **新增** | `GET/POST/PUT/DELETE /api/fde/connectors/provider-systems[/{id}]` | 服务提供系统 CRUD（API 分组层） |
| **调整** | `GET /api/fde/connectors/apis`（API 列表） | 新增 `providerSystemId` 过滤参数 + 响应回带分组字段 |
| **调整** | `POST/PUT /api/fde/connectors/apis[/{id}]`（API 增改） | 入参新增 `providerSystemId`（必填） |
| **新增** | `POST /api/fde/market/mcp-services/{mcpId}/publish` | MCP 服务级发布（一键发布整服务全部工具到多 target） |
| **新增** | `POST /api/fde/market/mcp-services/{mcpId}/delist` / `relist` / `withdraw` | 服务级下架 / 重新上架 / 撤回（批量作用于该服务全部工具 listing） |
| **新增** | `GET /api/fde/market/mcp-services/{mcpId}/publish-status` | 服务级发布状态聚合查询 |
| **调整** | MCP 编辑器工具项（`McpDefRequest.ToolItem` / `McpToolItemVO` / 工具确认端点） | 工具项新增 `writeClass` 字段（随工具定义保存/读取） |
| **调整** | `POST /api/fde/market/listings`（发布提交） | `writeClass`/`requiresConfirmation` 改为**从工具定义读取**，入参移除这两字段 |

---

## 1. 服务提供系统 CRUD（API 分组层）

> 前缀 `/api/fde/connectors/provider-systems`，风格对齐现有 `/api/fde/connectors/mcp`。`code` 系统生成、对用户隐藏（新建不传、编辑不可改）。

### 1.1 `GET /api/fde/connectors/provider-systems`（列表）

**查询参数：**

| 参数 | 类型 | 默认 | 说明 |
|------|------|------|------|
| `keyword` | string | 无 | 可选，模糊匹配 `name` |
| `status` | string | 无 | 可选，按 `status` 精确过滤（active/disabled） |

**响应** `ResultVO<ListVO<ProviderSystemListItem>>`，排序 `updatedAt DESC, id DESC`：

```jsonc
{
  "id": "pv_R8mK2nQvT7x", "code": "...", "name": "报销系统", "description": "...",
  "status": "active", "apiCount": 5,         // 其下未删 API 数量（聚合；删除规则按此判「非空禁删」）
  "updatedAt": "2026-06-26T10:00:00+08:00"
}
```

> **无 `isDefault` 字段**（归并后所有分组一视同仁）。

### 1.2 `GET /api/fde/connectors/provider-systems/{id}`（详情）

**响应** `ResultVO<ProviderSystemDetailVO>`：`id/code/name/description/status/apiCount/createdAt/updatedAt`（**无 `isDefault`**）。
`404` 不存在或已软删。

### 1.3 `POST /api/fde/connectors/provider-systems`（新建）

**入参** `ProviderSystemRequest`：

| 字段 | 类型 | 校验 | 说明 |
|------|------|------|------|
| `name` | string | `@NotBlank` `@Size(max=128)` | 名称 |
| `description` | string | `@Size(max=1000)` 可空 | 描述 |
| `status` | string | 可空，默认 `active` | active/disabled |

`code` 由后端 `generateUniqueProviderSystemCode()` 生成（对齐 `api_def.code` 现状）。
**响应** `ResultVO<{ id }>`。重名不报错（名称非唯一，`code` 唯一）。

### 1.4 `PUT /api/fde/connectors/provider-systems/{id}`（编辑）

入参同 `ProviderSystemRequest`（`code` 忽略不可改）。`404` 不存在。**响应** `ResultVO<Void>`。
所有分组一视同仁，无「默认分组」改名/停用特例（含归并后的「报销系统」分组，与普通分组同规则）。

### 1.5 `DELETE /api/fde/connectors/provider-systems/{id}`（删除，软删）

**守卫（业务规则，统一「非空禁删」，无默认分组特例）：**

- 其下仍有未删 API（`apiCount>0`）→ **禁删** → `1000` `message="该服务提供系统下仍有 N 个 API，请先迁移或删除"`，`field="id"`。
- 空分组（`apiCount==0`）→ **可删**，置 `deleted=true`。**响应** `ResultVO<Void>`。

> 删空最后一个分组后系统进入「零分组」态，此时**不能新建 API**（须先建分组，见 §2.2 / §6）。

---

## 2. `api_def` 接口归属服务提供系统后的调整

### 2.1 `GET /api/fde/connectors/apis`（API 列表）— 新增分组过滤 + 响应分组字段

**新增查询参数：**

| 参数 | 类型 | 说明 |
|------|------|------|
| `providerSystemId` | String | 可选，按所属服务提供系统精确过滤（`pv_` 前缀，全线 ID 改造方案 B，2026-07-02 上线）；不传=全部 |

（其余 `keyword/status/page/size` 等现状参数不变。）

**响应** `ApiDefListItem` 新增字段（additive，不破坏现有字段）：

```jsonc
{
  "id": "ap_Wq3Zt6yWpVn", "code": "...", "name": "...", "url": "...", "method": "POST", "status": "active",
  // ↓ V40 加列 / V41 收紧 NOT NULL
  "providerSystemId": "pv_R8mK2nQvT7x",
  "providerSystemName": "报销系统"     // 冗余回带，免前端二次查（join 出参）；NOT NULL，恒有值
}
```

> 如前端需「按分组聚合」视图，可由前端用 `providerSystemId` 分组本列表，或后续提供 `GET /provider-systems/{id}/apis` 便捷端点（本期不强制，列表过滤已够）。

### 2.2 `POST/PUT /api/fde/connectors/apis[/{id}]`（API 增改）— 入参新增 `providerSystemId`

`ApiDefRequest` 新增字段：

| 字段 | 类型 | 校验 | 说明 |
|------|------|------|------|
| `providerSystemId` | String | `@NotNull(message="所属服务提供系统必填")` | 必选（`pv_` 前缀，方案 B）；服务层校验该分组存在且未软删，否则 `400 field=providerSystemId` |

> 与表设计 §3.2 一致：DB 列 **NOT NULL（V41 收紧）** + 应用层 `@NotNull` 双重必填，保证每个 API 恒有分组归属。`providerSystemId` 指向已软删/不存在分组 → `400 message="服务提供系统不存在或已删除"`。
> API 仍各自独立配置 `url`/`authType`/`authConfig`（分组层不承载共享 URL/鉴权，现状字段全保留不变）。
>
> **★ 零分组禁建 API（契约口径）：** 系统中**无任何服务提供系统时不能新建 API**。该约束由**前端引导**（新建 API 前若无分组，引导先建分组、禁用提交）+ **后端 `providerSystemId` 必填校验**（`@NotNull` + 分组存在校验，无合法分组可填则 `400`）+ **DB NOT NULL** 三重共同保证。详见 §6。

### 2.3 `GET /api/fde/connectors/apis/{id}`（API 详情）

`ApiDefDetailVO` additive 新增 `providerSystemId` + `providerSystemName`，其余字段不变。

---

## 3. MCP 服务级发布接口

> 改造一核心：发布动作/状态**面向整个 MCP 服务**。底层仍复用工具粒度 `tool_market_listing`（表结构不动），"服务级"= 服务层批量 + 聚合。
> 前缀 `/api/fde/market/mcp-services/{mcpId}`，与现有 `/api/fde/market/listings`（工具粒度，保留）并存。

### 3.1 `POST /api/fde/market/mcp-services/{mcpId}/publish`（服务级发布）

一键把该 MCP 服务下**当前全部工具**（`mcp_def.tools_cache` 全集）逐工具发布到指定 targets。

**Path：** `mcpId` = `mcp_def.id`。

**入参** `McpServicePublishRequest`：

| 字段 | 类型 | 校验 | 说明 |
|------|------|------|------|
| `targets` | string[] | `@NotEmpty` | 发布目标，元素 ∈ `FDE_WORKBENCH`/`USER_END`；服务层去重 + 域校验 |

> **不再传** `writeClass`/`requiresConfirmation`/逐工具 displayName —— 这两个安全属性从**工具定义层**（`tools_cache` 每项的 `writeClass`/`requiresConfirmation`）读取（改造一锁定）。`displayName` 默认取工具 `bizName`。

**服务层行为：**
1. 校验 mcp 存在、`status='active'`、`origin='PLATFORM'`（复用 `MarketService` 现有 origin 硬防线），否则 `400`。
2. 遍历 `tools_cache` 每个工具，对每个 `target` 按 `(MCP, mcp__{code}__{toolName}, target)` upsert listing（复用 `createListing`/`resubmitInternal`：新建→PENDING_REVIEW；REJECTED→同行 reset；PUBLISHED/PENDING/DELISTED→跳过记 CONFLICT）。`writeClass`/`requiresConfirmation` 从该工具定义项读取写入 listing。
3. 逐 (工具×target) 独立非原子（沿用 V36 语义）。

**响应** `ResultVO<McpServicePublishResultVO>`：

```jsonc
{
  "mcpId": "mc_9Xy3KdQvT7p", "mcpCode": "crm", "toolTotal": 3,
  "results": [   // 逐 (工具, target) 结果
    { "toolName": "create_lead", "toolCode": "mcp__crm__create_lead", "target": "USER_END",
      "outcome": "CREATED", "listingId": 101 },        // CREATED | RESUBMITTED | CONFLICT
    { "toolName": "list_leads",  "toolCode": "mcp__crm__list_leads",  "target": "USER_END",
      "outcome": "CONFLICT", "listingId": 88, "message": "已在市场（状态=PUBLISHED）" }
  ]
}
```

**错误：** mcp 不存在 `404`；非 active/非 PLATFORM `400`；`tools_cache` 为空（无工具可发布）`1000 message="该 MCP 服务下无可发布工具"`；某工具缺 `writeClass` 且无法启发式补全 `1000`（实际 V40 已回填，正常不触发）。

### 3.2 `POST /api/fde/market/mcp-services/{mcpId}/delist`（服务级下架）

把该服务下**全部 PUBLISHED** 工具 listing（可按 `target` 过滤）批量 `PUBLISHED→DELISTED`。

**入参** `McpServiceTargetActionRequest`：`{ "targets": ["USER_END"] }`（可空=全部 target）。
**行为：** 仅对状态合法（PUBLISHED）的行执行，跳过非法状态行并在结果汇报。逐行非原子。
**响应** `ResultVO<{ affected: 2, skipped: 1 }>`。

### 3.3 `POST /api/fde/market/mcp-services/{mcpId}/relist`（服务级重新上架）

把该服务下**全部 DELISTED** 工具 listing 批量 `DELISTED→PUBLISHED`。入参/响应同 §3.2。

### 3.4 `POST /api/fde/market/mcp-services/{mcpId}/withdraw`（服务级撤回）

把该服务下**全部 PENDING_REVIEW** 工具 listing 批量删行（撤回，沿用工具粒度 withdraw 语义）。入参/响应同 §3.2（`affected`=删除行数）。

### 3.5 `GET /api/fde/market/mcp-services/{mcpId}/publish-status`（服务级状态聚合）

返回该 MCP 服务**按每个 target** 的聚合发布状态（口径见表设计 §4.2）。

**响应** `ResultVO<McpServicePublishStatusVO>`：

```jsonc
{
  "mcpId": "mc_9Xy3KdQvT7p", "mcpCode": "crm", "toolTotal": 3,
  "targets": [
    {
      "target": "USER_END",
      "aggregateStatus": "PARTIAL",   // NOT_PUBLISHED | PARTIAL | PENDING_REVIEW | PUBLISHED | REJECTED | DELISTED
      "publishedCount": 2, "pendingCount": 0, "rejectedCount": 0, "delistedCount": 0,
      "missingCount": 1               // 当前工具集中尚无 listing 的工具数（toolTotal - 有 listing 的工具数）
    },
    { "target": "FDE_WORKBENCH", "aggregateStatus": "NOT_PUBLISHED",
      "publishedCount": 0, "pendingCount": 0, "rejectedCount": 0, "delistedCount": 0, "missingCount": 3 }
  ]
}
```

> 聚合在服务层读时计算（不持久化）：以 `tools_cache` 当前工具集为分母，与各 target 下工具 listing 集求交/差。工具新增到服务后未发布 → `missingCount>0` 且 `aggregateStatus=PARTIAL`，提示需重新发布。

> **列表/工具上不再单独展现每个工具的发布状态**（改造一锁定）：连接器 MCP 列表/详情页改为消费本聚合端点的服务级状态，不再逐工具回带 listing 状态。原工具粒度端点（`/api/fde/market/listings`）保留供审核台/API 工具使用，MCP 服务发布 UI 不再直接用它做逐工具状态展示。

---

## 4. MCP 工具 `writeClass`/`requiresConfirmation` 随工具定义保存/读取

> 改造一锁定：两个安全属性保留**工具级**，但配置位置从「发布弹窗」挪到 **MCP 编辑器**逐工具配置，成为工具定义的一部分。`requiresConfirmation` 已在工具定义层（V22）；本次补 `writeClass`。

### 4.1 `POST/PUT /api/fde/connectors/mcp[/{id}]`（MCP 增改）— 工具项新增 `writeClass`

`McpDefRequest.ToolItem` 新增字段：

| 字段 | 类型 | 说明 |
|------|------|------|
| `requiresConfirmation` | Boolean | 现状（可空：null=按 name merge 保留旧值/写类启发式默认） |
| `writeClass` | string | **新增**，`READ`/`WRITE`；可空：null=按 name merge 保留旧值，新工具无旧值时按写类启发式默认（非读类→WRITE）。服务层校验取值域，非法 `400 field=tools[i].writeClass` |

> 保存沿用 `McpToolsCacheMerger` merge-by-name：`writeClass` 与 `requiresConfirmation` 同步局部更新到 `tools_cache` 对应项，其余项原样保留。

### 4.2 `GET /api/fde/connectors/mcp/{id}`（MCP 详情）— 工具项回带 `writeClass`

`McpDefDetailVO.ToolItemVO` 新增 `writeClass`（READ/WRITE）。前端 MCP 编辑器逐工具展示/配置读写性质 + 二次确认。

### 4.3 `GET /api/fde/connectors/mcp/{id}/tools`（工具确认读回显）— `McpToolItemVO` 新增 `writeClass`

`McpToolItemVO` 由 `(name, bizName, requiresConfirmation)` 扩为 `(name, bizName, requiresConfirmation, writeClass)`。

### 4.4 工具属性写端点（二选一，推荐 4.4a）

- **4.4a（推荐）合并进 MCP 编辑保存**：`writeClass`/`requiresConfirmation` 随 `PUT /api/fde/connectors/mcp/{id}`（§4.1）整体保存，不单开端点。简单、与「配置位置挪到 MCP 编辑器」最契合。
- 4.4b（可选保留）单工具确认端点扩展：现有 `PUT /api/fde/connectors/mcp/{id}/tools/{toolName}/confirmation` 入参由 `{requiresConfirmation}` 扩为 `{requiresConfirmation, writeClass}`（两字段任一可空=不改该字段），`AdminMcpService.updateToolConfirmation` 同步写 `writeClass`。仅当前端需要「单工具即时保存」时启用。

> **采纳 4.4a 为主**（避免双写入口）；4.4b 作为前端交互需要时的备选，由后端按前端最终交互稿决定。

### 4.5 发布提交端点（`POST /api/fde/market/listings`）配套调整

改造一落地后，**发布时从工具定义读取** `writeClass`/`requiresConfirmation`（不再发布弹窗现填）：

- `PublishListingRequest` **移除** `writeClass`、`requiresConfirmation` 两字段（V39 曾把它们前移到此处，本次因「配置位置挪到 MCP 编辑器」再下沉到工具定义读取）。
- `MarketService.resolveTool` 解析 MCP 工具时，从 `tools_cache` 对应项读出 `writeClass`/`requiresConfirmation` 写入 listing；API 类型从 `api_def.requires_confirmation` 读取（API 的 `writeClass` 现无定义层字段，沿用现状由发布侧确定或后续按 method 推断——**本期 API 维度不在改造范围，保持现状**）。
- 因 `requiresConfirmation` 已是工具定义单一真相，发布提交**不再回写**连接器侧（V39 的 `writebackConfirmation` 对 MCP 分支可移除；API 分支保持现状）。

> ⚠️ 本节涉及对 V39 已落地逻辑的回调，属应用层重构。**审查重点**：确保「发布读工具定义」与「MCP 编辑器写工具定义」形成单一真相闭环，无双写漂移。具体改动以后端实现 + 架构师 CR 为准。

---

## 5. 错误码语义汇总

| 场景 | code | message / field |
|------|------|------------------|
| 入参校验失败（name 空 / writeClass 非法 / providerSystemId 缺失等） | `400` | 带 `field` |
| 零分组态新建 API（无合法 `providerSystemId` 可填） | `400` | `field="providerSystemId"` |
| 服务提供系统 / MCP / API 不存在或已软删 | `404` | — |
| 分组下仍有 API 禁删（非空禁删，无默认分组特例） | `1000` | `field="id"` |
| MCP 非 active / 非 PLATFORM 不可发布 | `400` | `field="mcpId"`/`toolCode` |
| MCP 服务下无可发布工具 | `1000` | — |
| 状态机非法流转（如对非 PUBLISHED 行下架） | 跳过记 `skipped`（批量）或 `1000`（单条） | — |
| 审核自审（沿用现有市场审核） | `403` | 审查人≠提交人 |

---

## 6. 兼容性与回归说明

- **零分组禁建 API（契约口径，归并后）：** 系统无任何服务提供系统时不能新建 API。三重保证：（1）**前端引导**——API 新建入口检测无分组时引导先建分组、禁用提交按钮；（2）**后端 `providerSystemId` 必填**——`@NotNull` + 分组存在/未软删校验，无合法分组可填即 `400 field=providerSystemId`；（3）**DB NOT NULL**（V41）——外键列非空兜底，杜绝悬挂。删空最后一个分组即进入该态。
- **默认分组概念已归并移除**：无 `is_default`、无「未分组/default」兜底、无禁删特例；所有分组一视同仁，删除统一「非空禁删」。原种子分组经 V41 改名为业务分组「报销系统」。
- **工具粒度市场端点全保留**：`/api/fde/market/listings` 等不动，API 工具与审核台继续用。服务级端点是 MCP 专属的批量/聚合**叠加层**。
- **运行时链路零回归**：服务级发布只读 `mcp_def.tools_cache` + 批量写 `tool_market_listing`，不触碰编排器/EffectivePositionView/ToolExecutionService。
- **`writeClass` 下沉**是对 V39「属性前移到发布提交」的再调整（移到工具定义读取），需配套修改 `PublishListingRequest`/`MarketService`，列入后端实现任务并经 CR。
