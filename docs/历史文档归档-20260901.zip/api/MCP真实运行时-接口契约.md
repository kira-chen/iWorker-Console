# MCP 真实运行时 — 接口契约

> 版本：v3（架构师，2026-06-24；MCP 数据结构扩展 + server 级使用统计）。CRUD 入参新增选填 `description`；列表/详情响应新增 `description` / `serverName` 及 server 级使用统计派生字段。详见 §1.1 / §1.2 / §7。配套设计：[`docs/architecture/MCP数据结构扩展与使用统计-设计.md`](../architecture/MCP数据结构扩展与使用统计-设计.md)。**本期不引入 `serverTitle`**（serverInfo.title 需协商协议 ≥2025-06-18，当前 2025-03-26 恒空）；**亦无 `lastModified`**（MCP 协议不返回）。
> 版本：v2（架构师，2026-06-21；工作2-H8 连接器前缀归一）。**全文 MCP 端点前缀由 `/api/admin/mcp` 改为 `/api/fde/connectors/mcp`**（纯路由重命名，无语义变化）。
> 版本：v1（架构师，2026-06-12）。配套设计：[`docs/architecture/MCP真实运行时-技术方案.md`](../architecture/MCP真实运行时-技术方案.md)。
> 仅新增/调整**注册侧后台接口**；运行时调用走既有 `/api/internal/tool/execute`（不在本契约，零改动）。
> 统一响应包络 `ResultVO<T>`：`{ code, message, data }`（`code=0` 成功，沿用项目现状）。鉴权与角色门由 `AdminRoleGuard` 统一覆盖（与现有 `/api/fde/connectors/mcp` 一致）。

---

## 0. 变更总览

| 类别 | 端点 | 说明 |
|------|------|------|
| 不变 | `GET/POST/PUT/DELETE /api/fde/connectors/mcp[/{id}]` | CRUD 现状不动 |
| **响应扩展** | `GET /api/fde/connectors/mcp`、`GET /api/fde/connectors/mcp/{id}` | 输出新增连接状态字段（见 §1）|
| **新增** | `POST /api/fde/connectors/mcp/test-connection` | 草稿/连接探测（不写库）|
| **新增** | `POST /api/fde/connectors/mcp/{id}/fetch-tools` | 已存 MCP 真实拉取并回填 tools_cache+状态 |
| **新增** | `POST /api/fde/connectors/mcp/fetch-tools` | 草稿拉取（仅返回，不写库；新建场景）|

错误码沿用项目规范：`400`（参数）、`403`（无权限）、`404`（不存在）、`1000`（业务，带 `field`）。连接类失败一律走 `1000`，`message` **脱敏**（不含 endpoint/堆栈/密钥）。

---

## 1. 列表 / 详情响应扩展

### 1.1 `GET /api/fde/connectors/mcp`（list）— `McpDefListItem` 新增字段

**查询参数（服务端分页，2026-06-24 升级为真·分页）：**

| 参数 | 类型 | 默认 | 说明 |
|------|------|------|------|
| `keyword` | string | 无 | 可选，模糊匹配 `code` / `name` |
| `status` | string | 无 | 可选，按 `status` 精确过滤 |
| `page` | int | `1` | 1-based 页码；越界页返回空 `list`，`total` 仍为过滤后全量总数 |
| `size` | int | `10` | 每页条数；归一化下限 1 / 默认 10（≤0 时）/ 上限 100 |

**响应**：`ResultVO<ListVO<McpDefListItem>>`，即 `data = { list: [当前页条目], total: [过滤后全量总数] }`（沿用 §0.1 `ListVO{list,total}` 统一形状，**非 PageVO**）。排序固定 `updatedAt DESC, id DESC`。

```jsonc
{
  "id": 12, "code": "crm", "name": "CRM 客户系统", "transport": "streamable-http",
  "status": "active", "toolCount": 3, "referencedBySkillCount": 2,
  "updatedAt": "2026-06-12T10:00:00+08:00",
  // ↓ 连接探测（Sprint MCP 真实运行时新增）
  "connStatus": "ok",                          // unknown | ok | failed（最近探测结果，不影响放行）
  "lastCheckedAt": "2026-06-12T09:55:00+08:00", // 可为 null（从未探测）
  // ↓ 检活四态（切片3a）
  "displayStatus": "HEALTHY",                  // DISABLED | UNKNOWN | HEALTHY | UNHEALTHY（合成四态）
  "redDot": false,                             // = displayStatus==UNHEALTHY
  "lastCheckAt": "2026-06-12T09:55:00+08:00",  // 最近四态检活时间（可空，区别 lastCheckedAt）
  // ↓ server 级使用统计（V31，2026-06-24，additive）
  "callCount": 1280,                           // 真正发起的工具调用次数（成功+握手失败+调用失败）
  "avgExecMs": 820,                            // 平均执行时间(含握手, ms)；success_count==0 → null
  "successRate": 0.992                         // 成功率(0~1)；call_count==0 → null；前端按需展示
}
```

> **字段名订正**：被引用计数字段实际名为 **`referencedBySkillCount`**（已核对 `McpDefListItem.java` 与 Sprint2.1 契约，本契约 v1 误写为 `referencedSkillCount`）。
>
> **列表字段集（与 `McpDefListItem.java` 一致）**：`id / code / name / transport / status / toolCount / referencedBySkillCount / updatedAt / connStatus / lastCheckedAt / displayStatus / redDot / lastCheckAt / callCount / avgExecMs / successRate`。
> **不在列表展示**（口径）：`serverName`（server 自报 id）、`description`、`avgCallMs`（纯调用平均仅排障，放详情）——这些仅详情/编辑态可见；`code` 字段下发但列表 UI 不渲染（沿用现状）。
> **使用统计口径见 §7**。无样本时 `avgExecMs` / `successRate` 为 `null`（前端展示「—」/「暂无调用」）。

### 1.2 `GET /api/fde/connectors/mcp/{id}`（detail）— `McpDefDetailVO` 新增字段

```jsonc
{
  "id": 12, "code": "crm", "name": "CRM 客户系统",
  "transport": "streamable-http", "endpoint": "https://crm.intranet/mcp",
  "status": "active",
  "tools": [ { "name": "search_customer", "bizName": "查客户", "description": "...", "inputSchema": {...} } ],
  "authConfigMasked": true,                    // 现有：是否配置了鉴权（不回显原值）
  "authInfo": { "type": "header", "headerName": "X-Api-Key", "valueMasked": true },  // 鉴权脱敏回显（2026-07 后台录入开放）：仅 type/headerName/是否已配置；未配置或 type=none 为 null，绝不回明文/密文/别名原文
  "referencedBySkills": [ { "skillId": "sk_iKVpHWzdXUA", "skillName": "客户查询" } ],   // skillId 为 sk_ 字符串句柄（S1 句柄化后）
  // ↓ 连接探测 / 版本元信息（Sprint MCP 真实运行时新增）
  "connStatus": "ok",
  "protocolVersion": "2025-03-26",
  "serverVersion": "1.4.0",
  "lastCheckedAt": "2026-06-12T09:55:00+08:00",
  // ↓ 检活四态（切片3a）
  "displayStatus": "HEALTHY",                  // DISABLED | UNKNOWN | HEALTHY | UNHEALTHY
  "redDot": false,
  "lastCheckAt": "2026-06-12T09:55:00+08:00",
  // ↓ 服务描述 + server 自报 id + server 级使用统计（V31，2026-06-24，additive）
  "description": "对接报销系统，提供报销单查询与提交",  // 用户填，选填，可空（null）
  "serverName": "crm-mcp",                     // serverInfo.name（server 自报标识，与我方 code 区分；可空）
  "callCount": 1280,                           // 真正发起的工具调用次数
  "successCount": 1270,                        // 成功返回次数（平均/成功率分母）
  "avgExecMs": 820,                            // 平均执行时间(含握手, ms)；success_count==0 → null
  "avgCallMs": 540,                            // 纯调用平均(ms)，仅详情供排障；success_count==0 → null
  "successRate": 0.992                         // 成功率(0~1)；call_count==0 → null
}
```

> **详情字段集（与 `McpDefDetailVO.java` 一致）**：在 v2 既有字段基础上新增 `description / serverName / callCount / successCount / avgExecMs / avgCallMs / successRate`。`description` / `serverName` 可空（前端展示占位「—」/「无描述」，**不得 NPE**）；派生指标无样本时为 `null`。
> `description` 由用户在编辑器填写（选填）；`serverName` 由 `initialize` 握手返回的 `serverInfo.name` 回写（**握手整次成功才覆盖，连不上保留旧值不清空**），均为只读展示（`serverName` 不可编辑）。

### 1.3 三态连接标签映射（前端渲染约定，与 AdminSkills/AdminExperts 范式对齐）

| connStatus | el-tag type | 颜色 | 文案 |
|------------|-------------|------|------|
| `ok` | `success` | 绿 | 连接正常 |
| `failed` | `danger` | 红 | 连接异常 |
| `unknown` | `info` | 灰 | 未探测 |

- `lastCheckedAt == null` → 时间列显示「—」。
- 该标签**仅展示最近探测结果，不代表运行时放行**（放行看 `status=active`）。

---

## 2. 测试连接（不写库）

探测一个 MCP endpoint 是否可握手。支持**草稿**（新建未保存，参数随请求传入）与**已存**（传 `id` 时用库内 endpoint/auth，草稿参数缺省）。

> **职责单一**：本接口 = **仅做 `initialize` 握手**，验证「连得上、能握手」，**不返回工具列表 / 工具数**（工具数需点「拉取工具」§3/§4）。前端按钮文案据此区分：本接口对应「**测试连接**」，工具拉取对应「**拉取工具**」，两者不可混用。
>
> **超时声明**：后端探测在 `mcp.connect-timeout-ms`（默认 10s）内**必返回成功或失败，不挂死**。前端按钮用 `:loading` + `disabled` 防重复点击即可，无需自建前端超时。

### `POST /api/fde/connectors/mcp/test-connection`

**请求体** `McpTestConnRequest`：
```jsonc
{
  "id": 12,                                    // 可选：已存 MCP；传则未填字段回退库值
  "transport": "streamable-http",              // 必填（草稿场景）
  "endpoint": "https://crm.intranet/mcp",      // streamable-http 必填
  "authConfig": { "type": "bearer", "token": "<明文，探测暂态>" }     // 可选；本次录入的明文仅随探测请求试连（不落库）；留空不传则已存对象回退库内密文/别名。存量别名引用（tokenAlias/valueAlias）亦可解析。永不回显明文
}
```

**响应** `ResultVO<McpTestConnVO>`：
```jsonc
{
  "code": 0, "message": "ok",
  "data": {
    "ok": true,
    "protocolVersion": "2025-03-26",
    "serverName": "crm-mcp",
    "serverVersion": "1.4.0",
    "latencyMs": 187,
    "failReason": null                         // ok=false 时给脱敏原因，如「连接超时」「鉴权失败」「连接被拒绝」
  }
}
```

- **不写库**。`ok=false` 时 `failReason` 为脱敏短语（不含 endpoint/堆栈）。
- transport=`stdio` 或运行时不支持 → `ok=false`，`failReason="该接入方式暂未支持"`。
- 参数缺失（如 streamable-http 缺 endpoint）→ `1000` + `field`。

---

## 3. 拉取工具（已存 MCP，回填）

对已登记 MCP 真实 `initialize → tools/list`，**回填** `tools_cache`（按 `name` 合并，保留已登记 `bizName`；新工具 `bizName` 缺省=`name`）并刷新 `protocolVersion/serverVersion/connStatus/lastCheckedAt`，记审计。

### `POST /api/fde/connectors/mcp/{id}/fetch-tools`

**请求体**：无（用库内 endpoint/transport/auth）。

**响应** `ResultVO<McpFetchedToolsVO>`：
```jsonc
{
  "code": 0, "message": "ok",
  "data": {
    "fetchedCount": 3,
    "protocolVersion": "2025-03-26",
    "serverVersion": "1.4.0",
    "tools": [
      { "name": "search_customer", "bizName": "查客户", "description": "按关键词查客户", "inputSchema": {...} }
    ],                                         // 回填后的 tools_cache 快照（bizName 已合并保留）
    "connStatus": "ok"
  }
}
```

- 成功即写库（`tools_cache` 整体以本次结果为准 + 合并 bizName；状态字段刷新），审计 `MCP_FETCH_TOOLS`。
- 握手失败 → `connStatus="failed"`、`lastCheckedAt` 刷新、**不**改 `tools_cache`，返回 `1000` + 脱敏 message。
  - **失败时 `ResultVO.data` 仍附带最新连接状态**，供前端就地更新该行连接标签（免重拉 detail）。形如：`{ "code": 1000, "message": "连接超时", "data": { "connStatus": "failed", "lastCheckedAt": "2026-06-12T10:01:00+08:00" } }`。
- `id` 不存在 → `404`。
- **超时声明**：探测在 `connect/call timeout` 内必返回（成功或 `1000` 失败），**不挂死**；前端 `:loading`+`disabled` 即可，无需自建超时。

---

## 4. 拉取工具（草稿，不写库）

新建场景：MCP 尚未保存，先用草稿参数拉一遍工具供前端预览灌入录入区。

### `POST /api/fde/connectors/mcp/fetch-tools`

**请求体** `McpTestConnRequest`（同 §2，草稿 transport/endpoint/authConfig）。

**响应** `ResultVO<McpFetchedToolsVO>`：结构同 §3，但 **`bizName` 缺省=`name`**（草稿无已登记 bizName 可合并），**不写库**、不审计。

- 前端拿 `tools[]` 灌入 McpEditor 工具录入区，FDE 可改 `bizName` 后随 `create` 一并保存。

**前端灌入合并规则（与录入区现有工具合并，按 `name` 匹配）：**

- **命中**（拉取结果与录入区同 `name`）→ **保留 FDE 已填的 `bizName` / `description`**，仅用拉取结果更新 `inputSchema` 等服务端权威字段。
- **未命中**（拉取结果有、录入区无）→ 新增该工具，`bizName` 缺省 = `name`。
- **服务端本次未返回的工具**（录入区有、拉取结果无）→ **不自动删除**（FDE 可能手动加了占位工具，由其自行决定是否删）。
- 该合并规则同样适用于 §3 已存 MCP 的回填（服务端按 `name` 合并保 `bizName`），保证草稿/已存两条路径一致。

---

## 5. 前端 `api/admin.js` 新增封装（约定）

> **📌 校准标注（2026-07-17）**：下方示例中的 `/admin/mcp/**` 为 v1 遗留路径，现行前缀为 `/api/fde/connectors/mcp`（工作2-H8 归一，前端封装经拦截器 base 拼接后实际请求 `/api/fde/connectors/mcp/**`）。详见《设计文档校准审计-20260717.md》。

```js
// 测试连接（草稿/已存）
export function testMcpConn(payload)          { return request.post('/admin/mcp/test-connection', payload, W) }
// 已存 MCP 拉取并回填
export function fetchMcpTools(id)             { return request.post(`/admin/mcp/${id}/fetch-tools`, {}, W) }
// 草稿拉取（仅预览）
export function fetchMcpToolsDraft(payload)   { return request.post('/admin/mcp/fetch-tools', payload, W) }
```
（`W` = 现有写操作配置，与 `createMcp/updateMcp` 一致。）

---

## 6. 安全与脱敏约定（契约级）

- `authConfig` 入参（2026-07 起，后台录入开放）：create/update 接受 `{type: none|bearer|header, headerName?, token?|value?}`——密钥为**明文入参、后端 AES-256-GCM 加密落库**（AAD=`mcpId|-2`，技术方案 §4.5）；**留空=保留旧密钥、`type=none`=清空、未携带=整体保留**；入参携带的 `tokenCipher`/`valueCipher` 一律忽略（防密文注入）。存量**别名引用**（`tokenAlias`/`valueAlias`）继续可解析。任何响应/详情**不回显**密钥明文/密文/别名原文（`authConfigMasked` + `authInfo.valueMasked` 仅表示「已配置」）。
- 所有连接失败 `message/failReason` 为脱敏短语，**禁止**包含 `endpoint`、内网地址、Java 堆栈、密钥别名对应的真实值。
- 运行时 `tools/call` 失败由编排回灌 → 模型翻译为用户中文，正文不出现错误码（既有约定，本契约不涉及前端直显）。

---

## 7. MCP 定义字段与 server 级使用统计（V31，2026-06-24）

### 7.1 CRUD 入参 `McpDefRequest` 新增字段

| 字段 | 类型 | 必填 | 校验 | 说明 |
|------|------|:----:|------|------|
| `description` | string | 否 | `@Size(max=1000)`，仅长度上限，不 NotBlank | 服务描述（用户填，选填/可空）。空白串提交后端归一为 `null`（不存空串），create/update 同口径。 |

> `serverName` 与四个统计列**不进请求**——`serverName` 由握手回写、统计由系统累计，均非用户可写。

### 7.2 server 级使用统计口径（钉死）

四个原始累计列存于 `mcp_def`（`call_count` / `success_count` / `sum_success_ms` / `sum_success_call_ms`，`BIGINT NOT NULL DEFAULT 0`，原子自增）；对外仅暴露派生指标，**读时计算，除零返回 `null`**。

**计数边界（按 `McpToolExecutor.execute` 每个返回分支）：**

| 分支 | 性质 | 计 `callCount` | 计 `successCount` + 耗时 |
|------|------|:----:|:----:|
| `MCP_BAD_CODE`（限定名畸形） | 未发起·短路 | ✗ | ✗ |
| 未接入（总开关关 / def 不存在 / 非 active） | 未发起·短路 | ✗ | ✗ |
| transport 不支持（如 stdio） | 未发起·短路 | ✗ | ✗ |
| 握手失败 | 已发起 | ✓ | ✗ |
| 调用失败 / 超时 | 已发起 | ✓ | ✗ |
| 调用异常（RuntimeException） | 已发起 | ✓ | ✗ |
| **成功返回** | 已发起·成功 | ✓ | ✓ |

> 即：`callCount = 真正发起的调用数（成功 + 握手失败 + 调用失败）`；短路分支（未发起）一律不计。统计写为独立短事务（`REQUIRES_NEW`）且 try/catch 包裹 + 失败必 warn，**绝不影响工具调用返回**。

**派生指标（读时算，除零兜底）：**

| 字段(API) | 公式 | 单位 | 无样本（返回 null） | 列表 | 详情 |
|-----------|------|------|------|:----:|:----:|
| `callCount` | 累计 | 次 | 恒 0（不为 null） | ✓ | ✓ |
| `successCount` | 累计 | 次 | 恒 0 | ✗ | ✓ |
| `avgExecMs` | `sumSuccessMs / successCount`（四舍五入） | ms | `successCount==0 → null` | ✓ | ✓ |
| `avgCallMs` | `sumSuccessCallMs / successCount`（四舍五入） | ms（纯调用，含握手差≈握手开销，排障用） | `successCount==0 → null` | ✗ | ✓ |
| `successRate` | `successCount / callCount` | 0~1 小数 | `callCount==0 → null` | ✓(按需) | ✓ |

- `avgExecMs` = **含握手**整次耗时均值（`System.currentTimeMillis()-t0`）；`avgCallMs` = **纯 callTool** 耗时均值。两者仅成功分支累加。
- 统计为 **server 级单一累计**，不区分来源（对话侧 / 定时任务侧）；本期无清零入口（运营重置为未来项）。

---

## 8. 变更记录

| 日期 | 变更点 | 需求来源 | 说明 |
|------|--------|---------|------|
| 2026-06-24 | ① CRUD 入参 `McpDefRequest` 加选填 `description`（`@Size(max=1000)`，空白归 null）。② 列表 `McpDefListItem` 加 `callCount / avgExecMs / successRate`（additive，尾部追加）。③ 详情 `McpDefDetailVO` 加 `description / serverName / callCount / successCount / avgExecMs / avgCallMs / successRate`。④ 新增 §7 server 级使用统计口径（计数边界判定表 + 派生指标除零兜底）。⑤ 明确不引入 `serverTitle`（协议 <2025-06-18）/ `lastModified`。`serverName` 由握手整次成功才覆盖回写。 | 优化系统配置员 MCP 页数据结构（设计先行已确认） | 全部为 additive 改动，旧前端不读不受影响、入参不传 `description` 不报错；契约↔代码（V31 迁移 / `McpDef` 实体 / 三 DTO / `AdminMcpService` 派生方法 / `McpUsageRecorder` / `McpToolExecutor` 埋点）已核对一致。后端 44 项 MCP 单测、前端 31 项 mcpMeta 单测全绿。 |
