# PRD-03 个人空间 RAG 架构设计（本轮交付）

> **📌 校准标注（2026-07-17）**：本文档描述的运行时能力已随主版本运行时剥离移出本仓（见《主版本运行时剥离-配置分发化设计.md》），本仓不含对应实现；文档保留作历史设计依据。例外：StorageService SPI 幸存但已迁包改语义——现为 com.aiassistant.storage.*，配置前缀 skill.snapshot.storage、bucket skill-packages，改为服务技能/岗位快照下载，不再服务个人空间。详见《设计文档校准审计-20260717.md》。

- **文档状态：** 待评审（架构师产出）
- **作者：** 架构师
- **日期：** 2026-06-11
- **上游依据：**
  - `docs/prd/PRD-03-个人空间-RAG就绪增订.md`（本轮范围，结论以此为准）
  - `docs/prd/PRD-03-个人空间.md`（功能基线）
  - `docs/architecture/database/数据模型设计.md` §3.5（personal_doc / doc_chunk）
  - `docs/architecture/ai-adapter/适配层接口契约.md`（LLM 适配层契约）
  - `backend/src/main/resources/db/migration/V1__init.sql`（实际 schema）
- **协同分工：** 本文主笔 **模块分包 / DB 迁移 / MinIO 接入与降级 / 解析切片流水线边界 / embed() 适配层接口契约 / orchestrator 零侵入联动**；**embedding provider 配置、embed 实现策略、切片参数、向量召回与 RAG 拼接策略由 AI 专家主笔**（本文在交界处只定接口边界）。
- **本轮范围：** F1 上传 → F2 解析切片 + 向量化 → F4 真实向量检索 → F6 非侵入接入对话；F3 随附；F5 转存后置占位。
- **强约束：** 不碰 Sprint 2（PRD-02）代码与表；P0 对主问答流程零侵入；技术栈不新增（PDFBox/POI/MinIO SDK 属普通 Maven 依赖）。

---

## 1. 设计总览

### 1.1 数据流（本轮闭环）

```
[上传/转存]
  Controller(multipart) → StorageService.put() → MinIO/LocalFs(返回 storage_key)
                        → personal_doc(parse_status=pending) 落库
                        → 触发异步流水线(@Async)

[解析切片向量化流水线]（异步，并发≤5）
  pending → parsing
     ParseService(按 mime 选 PDFBox/POI/直读) → 纯文本
     ChunkService(切片，参数由 AI 专家定) → List<chunk>
     EmbeddingService(批量 embed()，策略由 AI 专家定) → 1024 维向量
     doc_chunk(content + embedding + metadata) 批量落库
  → parsed / failed（失败原因人话化）

[RAG 检索]（内部接口，对话链路调用）
  query → embed(query) → pgvector HNSW cosine Top-K（强制 user_id + parsed + 未删除过滤）
        → List<RagChunk>(doc_id/chunk_index/content/score/sourceName)

[对话注入]（零侵入）
  ChatStreamService.buildConversation() → 开关开 & 有命中 → ragSnippets 填充
                                        → 开关关 / 无命中 / 异常 → ragSnippets=List.of()（与现状一致）
```

### 1.2 与现有系统的耦合面（最小化）

| 现有组件 | 改动性质 | 说明 |
|---------|---------|------|
| `OrchestrateRequest.Conversation.ragSnippets` | **零改动** | 字段已存在，本轮只是从 `List.of()` 变为真实填充 |
| `ChatStreamService.buildConversation(Session)` | **增量挂载（改签名）** | 唯一对话链路改动点：方法签名加 `userId+userQuery`（line 406）、内部 line 413 由 `List.of()` 改真实填充、同步改唯一调用点 line 114，详见 §7.1 |
| `LlmProvider` SPI / `LlmGateway` | **新增方法** | 加 `embed()`，不动 `chat()`，详见 §6 |
| `ModelTier.EMBEDDING` | **零改动** | 枚举值已存在；只需在 application.yml 补 EMBEDDING tier 映射 |
| `application.yml` `llm.router` | **配置补充** | 补 `EMBEDDING` provider:model 映射（值由 AI 专家给） |
| `docker-compose.yml` minio | **零改动** | 服务已定义；本轮加 Java 接入 + LocalFs 降级 |
| Sprint 2 / PRD-02 表与代码 | **绝不触碰** | — |

---

## 2. 模块分包（com.aiassistant.personalspace）

新建独立模块，沿用现有 Controller→Service→Repository 分层、ResultVO 统一响应、BusinessException + GlobalExceptionHandler 统一异常。与 chat/expert 等模块解耦（仅 RAG 检索被对话链路以接口方式调用）。

```
com.aiassistant.personalspace
├── controller
│   └── PersonalDocController            个人空间 REST 入口（上传/列表/详情/切片/删除/重试/容量）
├── service
│   ├── PersonalDocService              文档 CRUD、容量校验、删除级联、状态查询
│   ├── DocUploadService                上传编排：校验→存储→落库→触发流水线
│   ├── pipeline
│   │   ├── ParsePipeline               流水线编排（@Async）：状态机推进 parsing→parsed/failed
│   │   ├── ParseService                按 mime 选解析器提取纯文本（PDFBox/POI/直读）
│   │   ├── ChunkService                切片（参数边界，具体算法 AI 专家实现）
│   │   ├── parser/
│   │   │   ├── DocumentParser          解析器 SPI：boolean supports(mime) / String extract(InputStream)
│   │   │   ├── PdfParser               Apache PDFBox（.pdf）
│   │   │   ├── WordParser              Apache POI（.docx/.doc）
│   │   │   └── PlainTextParser         txt/md/markdown 直读（UTF-8 探测）
│   │   └── ParseFailureReason          失败原因枚举 + 人话文案
│   ├── rag
│   │   ├── PersonalRagService          RAG 检索：embed(query)→向量召回（实现策略 AI 专家）
│   │   └── EmbeddingService            切片向量化：批量调 LlmGateway.embed()（策略 AI 专家）
│   └── storage
│       ├── StorageService              存储抽象 SPI（put/get/delete/exists）
│       ├── MinioStorageService         生产实现（MinIO SDK）
│       ├── LocalFsStorageService       降级实现（本地文件系统）
│       └── StorageProperties           存储配置（@ConfigurationProperties "personalspace.storage"）
├── repository
│   ├── PersonalDocRepository          personal_doc（Spring Data JDBC/JPA，与现有一致）
│   └── DocChunkRepository             doc_chunk（含向量检索原生 SQL）
├── entity
│   ├── PersonalDoc                    映射 personal_doc
│   └── DocChunk                       映射 doc_chunk（embedding 以 String/float[] 承载，见 §3.4）
├── dto
│   ├── DocUploadResultVO              单文件上传结果（逐文件请求，见契约 §1）
│   ├── DocStatusVO                    批量状态查询项（docId/parseStatus/chunkCount/errorReason，轮询用，契约 §1.1）
│   ├── DocListItemVO / DocListQuery   列表项 + 查询条件（搜索/状态/分页）
│   ├── DocDetailVO                    详情（元信息 + 切片数 + 状态 + 失败原因）
│   ├── ChunkItemVO                    切片项（chunkIndex/content/metadata{page,title}，契约 §4）
│   ├── CapacityVO                     容量（used/total/percent）
│   ├── RagSearchRequest / RagChunkVO  内部 RAG 检索入参/出参
│   └── PageVO<T>                      分页包装（复用 chat.dto.PageVO 或新建，见说明）
└── config
    ├── PersonalSpaceProperties        模块级配置（开关/限额/切片/容量，"personalspace"）
    └── PersonalSpaceAsyncConfig       @Async 线程池（并发≤5）
```

**类职责要点：**

- `StorageService` 是存储抽象边界，上层只依赖它，不感知 MinIO/LocalFs（§4）。
- `ParsePipeline` 是流水线唯一编排者，串起 Parse→Chunk→Embedding→落库 + 状态机（§5）。
- `EmbeddingService` 与 `PersonalRagService` 是与 AI 专家的交界类：本文定其方法签名与对 `LlmGateway.embed()` 的依赖，内部参数/策略由 AI 专家实现。
- `PageVO` 现位于 `chat.dto.PageVO`，跨模块复用会引入耦合；本轮建议在 `common` 下不动，个人空间新建轻量 `PageVO`（或后续由 PM 决定下沉到 common，本轮不强求）。

---

## 3. DB 迁移 V5（增量，不碰 Sprint 2）

### 3.1 V1 现状核对（personal_doc / doc_chunk 实际列）

| 表 | V1 已有列 | PRD 需要但 **缺失** |
|----|----------|-------------------|
| `personal_doc` | id, user_id, name, mime_type, size, storage_key, source, parse_status, created_at, updated_at, deleted | **error_reason**（失败人话原因，§2.5）、**parsed_at**（可选，向量化完成时间）、**chunk_count**（冗余便于列表展示，可选） |
| `doc_chunk` | id, doc_id, chunk_index, content, metadata, created_at | **embedding vector(1024)**（核心）、**page**（页码，PRD §2.4，也可塞 metadata，但独立列便于展示）、**deleted**（逻辑删/失效标记，配合删除级联 §3.3） |

> 说明：
> - `personal_doc` 已有 `parse_status / source / deleted / size / storage_key`，**不需重复加**（prompt 中"补齐"清单按实际缺失为准 → 仅缺 `error_reason`，其余可选）。
> - `doc_chunk.metadata`（JSONB）已存在，`page` 可放 metadata；但为列表/切片展示与检索便利，DB 侧保留独立 `page INT` 列（轻量、可空）。**注：对前端的切片接口出参统一收敛到 `metadata.page` / `metadata.title`（契约 §4 取值路径统一）**，由后端组装 `ChunkItemVO` 时把 DB 列归位进 metadata，前端不感知 DB 列结构。
> - `doc_chunk` 无 `deleted` 列：删除文档时 PRD 要求"切片失效不再参与检索"。两种方案：(A) 物理 `DELETE doc_chunk`；(B) 加 `deleted` 标记 + 检索过滤。本轮采用 **(B) 逻辑删 deleted 列**，与 personal_doc 逻辑删一致，回滚/审计友好；检索 SQL 带 `dc.deleted = false`。

### 3.2 迁移文件：`V5__personal_space_rag.sql`

```sql
-- =====================================================================
-- V5 个人空间 RAG 就绪（增量）。仅动 personal_doc / doc_chunk，零碰 Sprint 2 表。
-- 依据：docs/prd/PRD-03-个人空间-RAG就绪增订.md + 本轮架构设计 §3
-- 向量维度：1024（阿里云 text-embedding-v3 实测）
-- =====================================================================

-- 1) personal_doc：补失败人话原因（其余列 V1 已有，不重复加）
ALTER TABLE personal_doc ADD COLUMN IF NOT EXISTS error_reason VARCHAR(512);
ALTER TABLE personal_doc ADD COLUMN IF NOT EXISTS parsed_at    TIMESTAMPTZ;
ALTER TABLE personal_doc ADD COLUMN IF NOT EXISTS chunk_count  INT DEFAULT 0;
COMMENT ON COLUMN personal_doc.error_reason IS '解析/向量化失败的人话原因（PRD §2.5）';
COMMENT ON COLUMN personal_doc.parsed_at    IS '流水线就绪时间';
COMMENT ON COLUMN personal_doc.chunk_count  IS '切片总数（冗余，列表/详情展示用）';

-- 2) doc_chunk：补向量列 + 页码 + 逻辑删
ALTER TABLE doc_chunk ADD COLUMN IF NOT EXISTS embedding vector(1024);
ALTER TABLE doc_chunk ADD COLUMN IF NOT EXISTS page      INT;
ALTER TABLE doc_chunk ADD COLUMN IF NOT EXISTS deleted   BOOLEAN DEFAULT FALSE;
COMMENT ON COLUMN doc_chunk.embedding IS '个人空间 RAG 向量（text-embedding-v3, 1024 维, 余弦相似度）';
COMMENT ON COLUMN doc_chunk.page      IS '来源页码（PDF/Word，无则 NULL）';
COMMENT ON COLUMN doc_chunk.deleted   IS '切片逻辑删/失效（删除文档时级联置 true，检索过滤）';

-- 3) HNSW cosine 索引（pgvector，vector_cosine_ops）
--    检索 SQL 用 <=> 余弦距离，配 ORDER BY embedding <=> :q LIMIT :k。
--    显式索引参数（m / ef_construction），与 AI 策略文档（docs/ai/model-strategy/个人空间-向量RAG策略.md §HNSW）统一，便于调优。
CREATE INDEX IF NOT EXISTS idx_doc_chunk_embedding_hnsw
    ON doc_chunk USING hnsw (embedding vector_cosine_ops)
    WITH (m = 16, ef_construction = 64);

-- 4) 检索辅助索引：按 doc_id 过滤未删切片（删除级联 + 范围过滤）
CREATE INDEX IF NOT EXISTS idx_doc_chunk_doc_active
    ON doc_chunk(doc_id) WHERE deleted = FALSE;
```

### 3.3 回滚注意

- **embedding 列存量为 NULL**：V5 仅加列，旧切片 embedding 为 NULL。本轮无存量正式数据（个人空间是新功能），无需回填脚本；HNSW 索引对 NULL 行不参与召回，安全。
- **HNSW 索引构建成本**：空表/小数据量瞬时完成；若已有大量切片，`CREATE INDEX` 会锁表。本轮新功能数据量极小，无影响。生产存量场景应改用 `CREATE INDEX CONCURRENTLY`（Flyway 需 `-- flyway:executeInTransaction=false`，本轮不需要）。
- **回滚方向**：Flyway 不自动回滚。手工回滚 = `DROP INDEX idx_doc_chunk_embedding_hnsw; DROP INDEX idx_doc_chunk_doc_active; ALTER TABLE doc_chunk DROP COLUMN embedding, DROP COLUMN page, DROP COLUMN deleted; ALTER TABLE personal_doc DROP COLUMN error_reason, DROP COLUMN parsed_at, DROP COLUMN chunk_count;`。因全部 `IF NOT EXISTS / ADD COLUMN`，对 Sprint 2 零影响。
- **版本占位**：现有迁移到 V4，本轮用 **V5**，与 Sprint 2（P0 零表变更，不占版本）互不冲突。

### 3.4 entity 映射注意（embedding 列）

`vector(1024)` 非标准 JDBC 类型。本轮不引入 pgvector 的 Hibernate 方言扩展（避免新框架风险），采用：
- **写入**：`DocChunkRepository` 用原生 SQL，把 `float[]` 序列化为 pgvector 文本字面量 `'[0.1,0.2,...]'::vector` 绑定（或用 `CAST(? AS vector)`）。
- **检索**：原生 SQL `ORDER BY embedding <=> CAST(:queryVec AS vector) LIMIT :k`，`queryVec` 同样以 pgvector 文本字面量传入。
- `DocChunk` entity 的 embedding 字段可不映射（`@Transient` 或省略），向量读写走 Repository 原生 SQL，避免 ORM 类型适配负担。

---

## 4. MinIO 接入 + 降级预案（重点）

### 4.1 抽象边界：StorageService SPI

```java
public interface StorageService {
    /** 存对象，返回 storage_key（业务层只持有 key，不感知后端）。 */
    String put(String objectName, InputStream data, long size, String contentType);
    /** 取对象流（下载/重解析用，文件已在存储不需重传）。 */
    InputStream get(String storageKey);
    /** 删除对象（删除文档时清理，可异步，失败不阻断逻辑删）。 */
    void delete(String storageKey);
    /** 探活（启动自检 / 上传前健康判断）。 */
    boolean healthy();
    /** 当前后端类型（埋点/日志用：minio / local-fs）。 */
    String backend();
}
```

两实现，由配置 `personalspace.storage.type` 切换（`minio` | `local-fs`），均通过 `@ConditionalOnProperty` 或在 `StorageProperties` 读取后由一个 `@Configuration` 选 Bean 注入：

- **MinioStorageService（生产/默认）：** 用 MinIO Java SDK（`io.minio:minio`，普通 Maven 依赖）。启动时 `bucketExists` 不存在则 `makeBucket`。`put` 用 `putObject`，`get` 用 `getObject`。
- **LocalFsStorageService（降级兜底）：** 把对象写到本地目录（`personalspace.storage.local.base-dir`，如 `./data/personal-space`）。`storage_key` 格式与 MinIO 一致（见 §4.3），仅物理落点不同。**保证 MinIO 镜像不可用时 DEMO 仍能跑通上传/转存/解析/检索全链路。**

### 4.2 降级切换策略（结论）

- **默认 `personalspace.storage.type=minio`**；FDE/运维在 MinIO 就绪后即生产可用。
- **MinIO 镜像历史坏层风险**：DEMO/本机若 MinIO 拉不起来，**改一行配置 `type=local-fs` 即整链路可跑**，无需改代码。这是对"MinIO 曾有坏层、被跳过"这一真实部署风险的兜底。
- **不做运行时自动 failover**（MinIO→LocalFs 自动切换）：会导致同一用户文件分散两处、storage_key 指向不明，复杂且易出隐患。降级是**部署期配置选择**，非运行时行为——符合"优先简单避免过度设计"。
- **MinIO 不可用时的上传错误态**：当 `type=minio` 且 `put` 失败/`healthy()=false` → 上传接口返回明确错误"存储服务暂不可用，请稍后重试"（PRD §1.7），**不静默丢文件**。

### 4.3 storage_key 方案 + bucket + 配置项

- **bucket**：`personal-space`（单 bucket，user 维度做前缀隔离）。
- **storage_key 格式**：`personal/{userId}/{yyyyMM}/{uuid}{ext}`
  - 含 userId 前缀便于排查/批量；含年月便于归档；uuid 防重名（PRD 允许同名并存）；保留扩展名便于 MIME 复核。
  - LocalFs 用同一相对路径落到 `base-dir` 下，key 字符串完全一致 → 切换后端时 DB 中 key 语义不变。
- **配置项**（`personalspace.storage.*`，密钥走 application-local.yml）：

```yaml
personalspace:
  storage:
    type: minio                      # minio | local-fs（部署期切换）
    bucket: personal-space
    minio:
      endpoint: http://localhost:9000
      access-key: ${MINIO_ACCESS_KEY:}   # 严禁硬编码，application-local.yml 注入
      secret-key: ${MINIO_SECRET_KEY:}
    local:
      base-dir: ./data/personal-space
```

> docker-compose 的 minio 默认账号是 `minioadmin/minioadmin`（见 backend/docker-compose.yml）；本机 DEMO 在 application-local.yml 注入即可，生产由 FDE 配真实凭证。

### 4.4 multipart 上传配置（实现要点，必补 —— 否则 >1MB 上传即失败）

> Spring Boot 默认 `spring.servlet.multipart.max-file-size=1MB`、`max-request-size=10MB`。**不显式放宽则任何 >1MB 的文件上传会直接被框架拒绝**（早于 Controller，业务校验根本进不来）。逐文件上传模式下单请求只含一个文件，配置如下：

```yaml
spring:
  servlet:
    multipart:
      max-file-size: 50MB        # 与单文件上限 50MB 一致
      max-request-size: 60MB     # 单文件 50MB + multipart 表单余量，逐文件模式取 ~60MB 足够
```

- **超限归一错误码：** 文件超过 `max-file-size` 时，框架在进入 Controller 前抛 `org.springframework.web.multipart.MaxUploadSizeExceededException`。需在 **`GlobalExceptionHandler` 新增对该异常的捕获**，归一为业务错误码 **1102（单文件超 50MB）**，返回 `ResultVO.fail(1102, "单文件超过 50MB 限制")`，与接口契约 §1 / §11 口径一致——不让框架默认 500 直出。
- 写入位置：本节即「实现要点」，后端实现 multipart 上传时务必先落这两项配置 + 异常归一，再做业务校验。

---

## 5. 解析切片流水线

### 5.1 解析器选型（普通 Maven 依赖，非新技术栈）

| 格式 | 解析器 | groupId:artifactId | 建议版本 |
|------|--------|--------------------|---------|
| PDF (.pdf) | Apache PDFBox | `org.apache.pdfbox:pdfbox` | 3.0.3 |
| Word (.docx) | Apache POI (XWPF) | `org.apache.poi:poi-ooxml` | 5.3.0 |
| Word (.doc 旧版) | Apache POI (HWPF, 含于 poi-scratchpad) | `org.apache.poi:poi-scratchpad` | 5.3.0 |
| txt / md / markdown | JDK 原生直读（UTF-8，BOM 处理） | — | — |
| MinIO SDK | MinIO Java | `io.minio:minio` | 8.5.12 |

> 这些是 JVM 生态成熟库，属"项目内正常依赖"，**不算新技术栈/语言/运行时**，无需用户审批。需后端在 `backend/pom.xml` 增加上述依赖。

### 5.2 DocumentParser SPI（解析器抽象）

```java
public interface DocumentParser {
    boolean supports(String mimeType, String ext);   // 双重白名单匹配
    String extract(InputStream in) throws ParseException;   // 返回纯文本
}
```

`ParseService` 持有 `List<DocumentParser>`，按 mime+ext 选第一个 `supports` 命中的解析器。新增格式 = 加一个实现，不改流水线（开闭原则）。

### 5.3 流水线（异步 + 状态机）

- **异步**：`@Async("personalSpaceExecutor")`，线程池 `core=2,max=5,queue=有界`（并发≤5，PRD §7.1，无 MQ）。`PersonalSpaceAsyncConfig` 定义，**仅供个人空间用，不影响全局**。

**异步流水线实现要点（必落，避坑）：**

1. **必须 `@EnableAsync`**：在 `PersonalSpaceAsyncConfig`（或主配置）标注 `@EnableAsync`，否则 `@Async` 不生效、方法会变同步执行（阻塞上传请求）。
2. **`@Async` + 事务分离**：`@Async` 与 `@Transactional` 都基于 Spring 代理，**同类内自调用不会生效**。流水线内的 DB 写（状态机推进、`doc_chunk` 落库）必须放在**独立 bean 的 public 方法**上显式 `@Transactional`，由 `ParsePipeline` 跨 bean 调用——**不能**指望 `@Async` 方法自身或自调用方法上的 `@Transactional` 生效。状态推进（pending→parsing→parsed/failed）按阶段拆为独立事务方法，避免长事务占连接。
3. **写 embedding 必须走独立原生 SQL**：`DocChunk` 实体的 `embedding` 字段 `@Transient`（或不映射，见 §3.4），**不能依赖实体 `save()` 落向量**——ORM 不认识 `vector(1024)` 类型。向量写入由 `DocChunkRepository` 用**原生 SQL** 完成（`INSERT ... embedding = CAST(:vec AS vector)`，`:vec` 为 pgvector 文本字面量 `'[...]'`），与切片 content/metadata 的写入分开或在同一原生 SQL 内组装。检索同理走原生 SQL（§3.4）。

- **状态机**（`personal_doc.parse_status`）：

```
pending → parsing → parsed   （解析+切片+向量化全部成功）
                 ↘ failed    （任一阶段失败，error_reason 记人话原因）
```

> 子状态（解析中/切片中/向量化中）本轮用主状态 `parsing` 表达即可（PRD 列表用主状态）；如需前端展示子态，可在 metadata/日志体现，不强制建列。

- **向量化失败处理**（PRD §4.1 硬项）：解析+切片成功但 embedding 失败 → **整体置 `failed`**，`error_reason="向量化失败，请稍后重试"`，**不可置 parsed**（避免显示为可语义检索却召不回）。重试解析即重跑全流水线。
- **失败原因人话化**（`ParseFailureReason` 枚举 → 文案，PRD §2.5）：
  - 加密/损坏 → "文件已加密或损坏，无法解析"
  - 扫描件图片 PDF（提取文本为空且为 PDF）→ "该 PDF 为扫描图片，暂不支持识别（OCR 后置）"
  - 解析超时 → "解析超时，请重试或换更小的文件"
  - 空内容 → "未从文件中提取到文本内容"
  - 向量化失败 → "向量化失败，请稍后重试"

### 5.4 重试不重传、不重复切片；删除级联

- **重试解析**（PRD §2.8）：文件已在存储（不重传）。重试前 **先清旧切片**（逻辑删该 doc 的 doc_chunk：`UPDATE doc_chunk SET deleted=true WHERE doc_id=?`，或物理删后重切），再重跑流水线 → 不产生重复切片。本轮建议重试时**物理删旧切片再重切**（重试是少见操作，物理删更干净；逻辑删主要用于"删除文档"场景）。
- **删除文档级联**（PRD §3.3）：`personal_doc.deleted=true` + `doc_chunk.deleted=true`（级联失效），检索 SQL 带 `dc.deleted=false AND pd.deleted=false` → 不再参与检索。MinIO 原文件可异步物理删（失败不阻断逻辑删，DEMO 可保留对象）。
- **解析中删除**（PRD §2.8）：流水线检查 doc 的 deleted 标记，若已删则终止并清理已产生切片。

### 5.5 向量化衔接点（交 AI 专家）

`ChunkService` 产出 `List<chunk content>` 后，由 `EmbeddingService.embedChunks(List<String>)` 批量向量化。**本文只定边界**：`EmbeddingService` 依赖 `LlmGateway.embed()`（§6），批大小/重试/速率/失败粒度由 AI 专家在 `EmbeddingService` 内实现。流水线只关心"拿到与切片一一对应的 1024 维向量数组，落 doc_chunk.embedding"。

---

## 6. embed() 适配层接口契约（架构师主笔）

在现有 `LlmProvider` SPI 与 `LlmGateway` 门面上**新增** embed 方法，复用 ModelTier.EMBEDDING 路由、Resilience（重试/超时）、LlmCallLog 埋点。**不动 chat() 任何代码。**

### 6.1 请求/响应模型（新增 record，置于 llm.model）

```java
// 统一 embedding 请求：上层只填 tier=EMBEDDING（或显式 modelId）+ 文本批
public record EmbeddingRequest(
        ModelTier tier,          // 固定 EMBEDDING
        String modelId,          // 可空，空则走 router EMBEDDING 映射
        List<String> inputs,     // 批量文本（单条=size 1）
        TraceContext trace
) {
    public static EmbeddingRequest of(List<String> inputs, TraceContext trace) {
        return new EmbeddingRequest(ModelTier.EMBEDDING, null, inputs, trace);
    }
}

// 统一 embedding 响应：向量批 + 维度 + 用量 + 埋点字段（与 LlmResponse 同口径）
public record EmbeddingResponse(
        List<float[]> vectors,   // 与 inputs 等长、同序
        int dimension,           // 期望 1024，校验用
        Usage usage,             // promptTokens 等（completion 恒 0）
        String vendor,
        String modelId,
        long latencyMs,
        boolean success,
        String errorCode
) {
    public static EmbeddingResponse ok(List<float[]> vectors, int dim, Usage usage,
                                       String vendor, String modelId, long latencyMs) {
        return new EmbeddingResponse(vectors, dim, usage, vendor, modelId, latencyMs, true, null);
    }
    public static EmbeddingResponse failed(String errorCode, long latencyMs) {
        return new EmbeddingResponse(List.of(), 0, Usage.zero(), null, null, latencyMs, false, errorCode);
    }
}
```

### 6.2 SPI 与 Gateway 方法签名

```java
// LlmProvider 新增（OpenAiCompatibleProvider 实现 embeddings，body: {model, input[], dimensions:1024}）
EmbeddingResponse embed(EmbeddingCall call);   // EmbeddingCall 与 ProviderCall 同构（含 providerConfig/timeout/providerName）

// LlmGateway 新增门面（路由 → 重试/超时 → provider.embed → 埋点 tier=EMBEDDING）
EmbeddingResponse embed(EmbeddingRequest request);
```

### 6.2.1 embed 端点路径与 base-url 去重（必明确，规避 aliyun /v1/v1 404）

> 与 AI 策略文档 `docs/ai/model-strategy/个人空间-向量RAG策略.md` §1.3 对齐的口径。

- **embed 端点路径常量：** `EMBED_PATH = "/embeddings"`（**不带 `/v1`**）。在 `OpenAiCompatibleProvider.embed()` 内单独定义，**不复用、不改** chat 的 `CHAT_PATH = "/v1/chat/completions"`。
- **base-url 去重逻辑（`normalizeBaseUrl`）：** 不同 provider 的 base-url 是否自带 `/v1` 不一致——
  - deepseek base-url = `https://api.deepseek.com`（**不含** `/v1`）；
  - aliyun base-url = `https://dashscope.aliyuncs.com/compatible-mode/v1`（**已含** `/v1`）。
  - 若 embed 也写死 `/v1/embeddings` 直接拼接 aliyun base-url → `.../compatible-mode/v1/v1/embeddings` → **404**。
- **拼接规则（`normalizeBaseUrl` 处理）：**
  - **base-url 已含 `/v1`**（结尾为 `/v1` 或 `/v1/`）→ 直接拼 `EMBED_PATH=/embeddings`，得 `.../v1/embeddings`；
  - **base-url 不含 `/v1`** → 补成 `/v1/embeddings`，得 `.../v1/embeddings`。
  - 即最终一律落到「单个 `/v1/embeddings`」，**去重 `/v1`**，避免 `/v1/v1`。
- **本轮最小落地：** aliyun（text-embedding-v3）base-url 已含 `/v1`，取 `EMBED_PATH=/embeddings` 相对拼接即可直连，**无需改 chat 逻辑**。`normalizeBaseUrl` 的去重分支保证将来切到不含 `/v1` 的 provider 仍正确。

- **批量契约**：`inputs` 为完整批，**单次 HTTP 请求**承载（OpenAI embeddings 接口原生支持 `input: [...]`）。**批大小上限由 AI 专家在 EmbeddingService 侧分批**后再逐批调 `embed()`——Gateway/Provider 不强制拆批，只忠实转发一批。响应 `vectors` 必须与 `inputs` 等长同序（Provider 按返回的 `data[].index` 排序保证）。
  > **批大小实测上限（2026-06-11，BUG-02）：** aliyun `text-embedding-v3` 经 OpenAI 兼容接口单请求 `input` 数组上限为 **10**（>10 报 `batch size should not be larger than 10`，整文档落 failed）。落地 `llm.embedding.batch-size=10`；此前 AI 策略文档误写"≤25"已同步更正为"≤10"。
- **维度校验**：Gateway 在成功返回后校验 `dimension==配置期望（1024）`，不符记 errorCode `EMBED_DIM_MISMATCH`（防模型配错）。
- **fallback / 可观测挂点（预留边界）**：
  - 复用 `LlmGateway` 现有 Resilience 退避重试 + 超时（`embed()` 走同一套 `retryable()` 错误码判定）。
  - 埋点：`embed()` 完成后写 `llm_call_log`（`tier=EMBEDDING`, `scene=PERSONAL_SPACE_EMBED` / `PERSONAL_SPACE_QUERY`, vendor/model/latency/tokens/success/errorCode）。埋点失败不阻断（与现有 persistLlmMeta 一致）。
  - 跨 provider fallback 与 chat 一样为"预留契约位"：本轮单 provider（阿里云 text-embedding-v3），fallback 策略由 AI 专家按需定，架构留好 ModelTier→多 provider 的扩展位（router 已支持 `provider:model`）。

### 6.3 配置（值由 AI 专家给）

```yaml
llm:
  providers:
    # AI 专家补充 embedding provider（阿里云 OpenAI 兼容），如：
    aliyun-embedding:
      type: openai-compatible
      base-url: https://dashscope.aliyuncs.com/compatible-mode/v1
      api-key: ${ALIYUN_EMBED_API_KEY:}
  router:
    default-tier-model:
      EMBEDDING: aliyun-embedding:text-embedding-v3   # 由 AI 专家定值
```

> 维度 1024 在两处约束一致：DB `vector(1024)` 与本契约 `dimension==1024` 校验。维度变更需同步改 V_next 迁移 + 校验常量（配置化常量，建议放 `personalspace.rag.embedding-dim`）。

---

## 7. orchestrator 零侵入联动

### 7.1 唯一改动点（精确定位，已核对源码）

实际类是 **`com.aiassistant.chat.service.ChatStreamService`**（**不是** `chat.stream`）。对话上下文唯一组装处是其私有方法 `buildConversation(Session)`（当前 **line 406-414**），现在 `ragSnippets` 恒为 `List.of()`（**line 413**：`new OrchestrateRequest.Conversation(session.getContextSummary(), history, List.of())`）。

本轮两处精确改动：

**① 改方法签名**（`buildConversation` line 406）：由 `buildConversation(Session session)` 改为携带 `userId` + `userQuery`：

```java
// line 406：方法签名改造
private OrchestrateRequest.Conversation buildConversation(Session session, Long userId, String userQuery) {
    List<OrchestrateRequest.Turn> history = ...;    // 现有 history 组装逻辑不变（line 407-412）
    // line 413：原 List.of() 改为真实填充
    List<String> ragSnippets = personalRagFacade.snippetsForChat(userId, userQuery);  // 新增
    return new OrchestrateRequest.Conversation(session.getContextSummary(), history, ragSnippets);
}
```

**② 同步改唯一调用点**（`stream()` 内 **约 line 114**：`OrchestrateRequest.Conversation conversation = buildConversation(session);`）：

```java
// stream() 内 line 114：传入 userId 与用户问题
// userId 在 line 103 已解析（Long userId = resolveUserId();）；用户问题用 req.message()（现成可用）
OrchestrateRequest.Conversation conversation = buildConversation(session, userId, req.message());
```

> 核对结论：`stream()` 内 `userId`（line 103）与 `req.message()` 均为现成变量，无需额外取数；`buildConversation` 仅此一处调用，改签名无外溢风险。现状 `ragSnippets` 恒 `List.of()` 即 line 413，本轮唯一从「恒空」变为「真实填充」之处。

- `personalRagFacade.snippetsForChat(userId, query)` 是个人空间模块对外暴露的**唯一对话集成入口**（封装：开关判断 + 空 query 判断 + 调 PersonalRagService 检索 + 把 chunk content 整形成 snippet 字符串 + 异常静默兜底）。
- 返回 `List<String>`（snippet 文本，整形/拼接格式由 AI 专家定）。`OrchestrateRequest.Conversation.ragSnippets` 字段类型已是 `List<String>`，**Python 侧 prompt.py 已消费**，无需改 DTO、无需改 Python。

### 7.2 零侵入保证（PRD §3.3 硬约束逐条对应）

`snippetsForChat` 内部实现守则（全部返回 `List.of()` = 与现状 100% 一致）：

| 场景 | 行为 |
|------|------|
| 开关 `personalspace.rag.enabled=false` | 直接 `return List.of()`（功能等于从未介入） |
| query 为空/空白 | `return List.of()`（不检索，PRD §4.7） |
| 用户无就绪文档 / 检索 0 命中 | 返回空（不附加，不报错） |
| 检索异常/超时 | **try-catch 吞掉 + 记 warn 日志**，`return List.of()`（静默降级，绝不抛到对话主链路） |
| 命中 | 返回 Top-K snippet（强制 user_id 过滤，硬隔离） |

- **不阻塞**：检索有独立超时（建议 `personalspace.rag.timeout-ms`，短超时如 1500ms），超时即返回空，不拖慢对话首字节。
- **不改 fallback 分支**：`internalProps.getOrchestrator().isEnabled()=false` 的兜底分支（line 123）不经过 RAG，行为完全不变。
- **开关粒度**：本轮先做**系统级** `personalspace.rag.enabled`（架构定，PRD §6 第 2 点倾向团队定）。用户级开关若产品要求，后续可在 app_user.profile 加字段，本轮不做（避免 Sprint 2 之外的表/字段扩张）。

### 7.3 配置

```yaml
personalspace:
  rag:
    enabled: true            # 系统级总开关；false = 对话链路与现状 100% 一致
    top-k: 5                 # 默认 Top-K（PRD §4.5）
    timeout-ms: 1500         # 检索超时，超时静默返回空，不拖慢对话
    embedding-dim: 1024      # 与 DB vector(1024) 一致，维度校验用
```

---

## 8. 新增 Maven 依赖清单（backend/pom.xml）

| 依赖 | 用途 | 是否新技术栈 |
|------|------|:---:|
| `org.apache.pdfbox:pdfbox:3.0.3` | PDF 解析 | 否（普通库） |
| `org.apache.poi:poi-ooxml:5.3.0` | docx 解析 | 否 |
| `org.apache.poi:poi-scratchpad:5.3.0` | doc(旧版) 解析 | 否 |
| `io.minio:minio:8.5.12` | MinIO 对象存储客户端 | 否 |

> 全部为 JVM 成熟库，属项目内正常依赖。txt/md 直读、embedding/向量检索均用现有栈（JDK + Spring RestClient + pgvector），无新增。

---

## 9. 风险与需 PM 决策项

1. **MinIO 镜像坏层（真实部署风险，已兜底）**：本机/DEMO 若 MinIO 拉不起，配置 `personalspace.storage.type=local-fs` 即整链路可跑，无需改码。**需 PM 知会 FDE/运维**：生产仍用 MinIO，LocalFs 仅作 DEMO/降级。
2. **.doc 旧格式（poi-scratchpad）解析质量参差**：旧二进制 Word 复杂排版提取文本可能不全。建议产品口径"优先 .docx"，.doc 作 best-effort（失败走 failed 人话提示）。**非阻塞，按现有白名单推进。**
3. **embed() 契约依赖 AI 专家补 provider 配置值**：本文已留好 `EMBEDDING` tier 映射位与签名；AI 专家未给值前，向量化/检索跑不通（属预期协同节奏，不阻塞架构定稿）。
4. **RAG 开关粒度**：本轮做系统级 `personalspace.rag.enabled`。用户级开关是否本轮要做需 PM 向用户确认（PRD §6 第 2 点）——**建议本轮系统级即可，用户级后置**。
5. **F5 转存后置**：本设计 storage_key/StorageService/流水线已为转存预留（转存=写 MinIO 独立副本 source=CHAT_GENERATED 走同流水线），接口契约标注"后置占位"。需 PM 向用户确认 F5 本轮后置（PRD §6 第 1 点）。
6. **PageVO 跨模块复用**：现位于 chat.dto，本轮个人空间新建轻量副本避免耦合。若团队希望下沉到 common 统一，属小重构，本轮可不做。

---

*（PRD-03 个人空间 RAG 架构设计 完。API 契约见 docs/api/PRD03-个人空间接口契约.md。）*
