# FDE 工作台「技能」模块改造 — 架构设计稿

> # ⛔ 本设计稿已失效 —— 归档于 2026-08-24，不作为实现依据
>
> **失效原因**：本稿的两个核心前提**均已不成立**——
>
> 1. **「平台技能只读取材 Tab + `copyFromPlatform` 复制为 FDE 技能」整条链路已下线**
>    （2026-08-23，P0-5）：`POST /skills/copy-from-platform` 端点已删
>    （`PositionSkillController` 留注释说明下线）、`CopyFromPlatformRequest` DTO 已删除、
>    前端取材入口已移除。**平台技能不再经复制进岗位。**
> 2. **本稿假设的「FDE 三页并存」信息架构已被合并**：`/admin/skills`、`/admin/platform-skills`、
>    `/admin/system-skills` 三条路由现已**全部 redirect 到合并页 `AdminSkillsUnified`**。
>
> **现行权威**：《`docs/architecture/技能管理页三合一-可行性与技术方案.md`》
> （合并页设计）与《`docs/architecture/技能页能否替代三个入口-审查结论.md`》
> （替代前的逐项清点，其结论亦已时效性失效，见该文首标注）。
>
> **下文正文全部保留作历史记录**（含 v1.1/v1.2 的 CR 修订轨迹），不再维护。
>
> 归档依据：`docs/architecture/设计文档校准审计-20260824.md` A2 项（负责人 2026-08-24 批准）。

---

> 版本：v1.2　作者：架构师　日期：2026-06-26
> v1.1 修订：纠正现状前提——`/admin/platform-skills`（SysConfigSkills）是**系统配置员**模块的平台技能源头管理页（创建/编辑/发布），不在 FDE 工作台，**原样保留不动**；本次改造只动 FDE 工作台 `/admin/skills`，平台技能 Tab 是 FDE 侧全新只读取材入口。
> v1.2 修订（后端+前端双 CR 6 Blocker + 建议项）：
> - 错误码改为真实码名（`NOT_FOUND(404)` / `BAD_REQUEST(400)` / `INTERNAL_ERROR(5000)`，无 `SKILL_NOT_FOUND`/`FILE_NOT_FOUND`）。
> - 复制流程对**懒迁移 0 文件行**源做必做兜底（`SkillFileService`/`ensureMaterialized` 均虚拟 SKILL.md，源不保证有 skill_file 行）；删「源必有技能包」断言。
> - 前端推翻「AdminSkills 内塞第三态」方案，改为**平台技能只读 Tab 独立子组件**，不共用 `isPlatform/apiList/fetchList`。
> - 给出**组件级只读关闭清单**（写入口 v-if 不渲染）；`skillFiles.js base()` 新增第三 source；候选端点无分页本期处置（前端本地过滤）。
> - 可见性守卫复用 `SkillRepository.findPlatformSkillPublishedToFde` 谓词（**不复用** `requireReferenceableSkill`，其抛引用语义 BAD_REQUEST，只读/复制需 404）。
> 范围：仅设计稿。不含业务代码、不改契约文档、不动数据库迁移。
> 决策原则：复用优先、零冗余、零迁移；可应用迁移不编辑，确需新增一律 V40。

---

## 0. 背景与需求（用户已拍板）

### 0.1 现状澄清（v1.1 关键前提，勿混淆两个界面）

| 界面 | 路由 | 所属模块 / 角色门 | 性质 | 本次处理 |
|------|------|------------------|------|---------|
| FDE 工作台「技能」页 | `/admin/skills`（AdminSkills，roles=FDE_WORKBENCH/ADMIN，module=FDE） | FDE 工作台 | 现仅显示 `origin=POSITION` 的 FDE 技能 | **本次改造对象**：拆为双 Tab |
| 系统配置员「平台技能」页 | `/admin/platform-skills`（SysConfigSkills，roles=SYS_CONFIG/ADMIN，module=SYSCONFIG） | 系统配置员「用户端配置」组 | 平台技能的**源头管理页**：创建/编辑/发布平台技能（走 SYS_CONFIG 写端点 `/api/fde/platform-skills`） | **完全不动**（删它平台技能就无法创建/发布） |

> 二者是两个不同界面、不同角色门。本次改造**不触碰**系统配置员侧管理页；FDE 工作台新增的平台技能 Tab 是一个**全新的只读取材入口**，与源头管理页彼此独立。

### 0.2 改造目标

仅改 FDE 工作台 `/admin/skills`：进入后**顶部 Tab 切换两个子页面**（系统配置员 `/admin/platform-skills` 不变）：

| 子页面 | 数据范围 | 权限 | 能力 |
|--------|----------|------|------|
| **平台技能 Tab** | `origin=PLATFORM` 且已发布到 `FDE_WORKBENCH` 且当前 `PUBLISHED` | **只读**（含技能包文件查看） | 「复制到我的工作台」 |
| **FDE 技能 Tab** | `origin=POSITION`（现有 AdminSkills 列表） | 可读可写 | 技能页创建 / 岗位配置新建 / 改 / 删 / 发布 |

### 三条不可推翻的决策

1. **并存**：新增「复制」能力，**保留**岗位白板「引用平台技能」（`skill_reference` 活链接）。二者并行。
   > **📌 校准标注（2026-07-17）**：「引用」通道已被 req3/V66/V67 关闭退役（V66 存量引用转副本、V67 硬删 `skill_reference` 表），现仅剩「复制为副本」一条路径，本条「并存」决策已不成立。详见《设计文档校准审计-20260717.md》。
2. **复制 = 独立游离副本，与源完全脱钩**：深拷贝
   `name / description / triggers / skill_md / skill_type / input_schema / output_schema`
   + `skill_file` 全部文件 + 工具引用，生成
   `origin=POSITION`、`agent_id=NULL`、`position_id=NULL`、`status=draft`、`code` 重新生成、`created_by=操作者`、`category` 重新派生
   的 FDE 技能，落 FDE 技能列表游离态。源更新不影响副本，无追溯关联。
3. **导航 = 单菜单 + 顶部两 Tab**。

---

## 1. 总体方案（IA + 数据源）

### 1.1 信息架构

```
FDE 工作台
└── 技能（单菜单，路由 /admin/skills）
    ├── Tab 1：平台技能   ← 只读浏览 + 「复制到我的工作台」
    └── Tab 2：FDE 技能   ← 现有 AdminSkills 全功能（默认 Tab）
```

- FDE 工作台「技能」仍是**单一菜单项**（`/admin/skills`），进入后用顶部 Tab 切换；不新增/不移除 FDE 工作台菜单项。系统配置员侧「用户端配置 → 平台技能」菜单项（SysConfigSkills）**保持不变**。
- 默认进入 **FDE 技能 Tab**（FDE 日常主场景），平台技能 Tab 为浏览/取材副场景。

### 1.2 数据源结论

| Tab | 列表数据源 | 结论与理由 |
|-----|-----------|-----------|
| 平台技能 | **直接复用** `GET /api/fde/platform-skill-candidates`（底层 `SkillRepository.findFdeReferenceCandidates`，已锁定 `origin=PLATFORM ∧ FDE_WORKBENCH/PUBLISHED`，角色门 `FDE_WORKBENCH`） | 候选集口径与「平台技能 Tab 可见范围」**完全一致**，无需新增列表端点。零冗余。 |
| FDE 技能 | 复用现有 AdminSkills 列表端点（`AdminSkillService.list`，`/api/fde/skills` 体系） | 现状已成立，不动。 |

> 关键判断：平台技能 Tab 的「可见集合」与岗位白板「可引用候选集合」是**同一个集合**（都是已发布到 FDE 工作台且当前在线的平台技能）。因此列表端点 100% 复用，不重复实现。

---

## 2. 后端 API 契约

> 统一约定：响应包 `ResultVO<T>`；错误码复用现有 `ResultCode`/`ErrorCode`；鉴权用户取 `SecurityUtils.requireUserId()`。
> **角色门铁律**：平台技能 Tab 的全部端点（列表/详情/文件查看/复制）均走 **`FDE_WORKBENCH`** 模块，**禁止让 FDE 走 `SYS_CONFIG`（平台技能写端点）**。复制端点产物落在 FDE 技能空间，天然属 `FDE_WORKBENCH`。

### 2.1 平台技能只读浏览（FDE 侧）

平台技能 Tab 需要三类只读数据：**列表**、**技能详情（主体字段）**、**技能包文件树/内容**。

#### 2.1.1 列表 — 复用现有，不新增

```
GET /api/fde/platform-skill-candidates?keyword=
角色门：FDE_WORKBENCH（AdminRoleGuard 现有映射 /api/fde/platform-skill-candidates/ → FDE_WORKBENCH）
响应：ResultVO<List<PlatformSkillCandidateVO>>
```

#### 2.1.2 详情 + 文件查看 — **需新增 FDE 侧只读端点**

> 判断：现有平台技能详情/文件端点在 `PlatformSkillController`（`/api/fde/platform-skills/**`），角色门 `SYS_CONFIG`，**且与写能力（增删改发布）同前缀**。若让 FDE 直接调用该前缀会越权、且违反「FDE 不走 SYS_CONFIG」铁律。
> `PlatformSkillCandidateVO`（列表项）通常为轻量摘要，**不含技能包文件树/内容**。
> 因此需在 **FDE 角色门下新增一组只读端点**，复用底层只读 service 逻辑（不复制实现）。

建议挂在 `SkillReferenceController`（已是 `FDE_WORKBENCH` 域、已专管平台技能候选只读浏览），新增同域只读子路由：

> 路径变量统一加 `{id:\d+}`（全仓铁律，防字面量误捕获；S1）。
>
> **📌 校准标注（2026-07-17）**：R2 全线 ID 字符串化（V45–V53）后，id 已是前缀句柄字符串（如 `sk_`），`{id:\d+}` 数字正则铁律已废止。详见《设计文档校准审计-20260717.md》。

```
# 平台技能详情（只读，主体字段）
GET  /api/fde/platform-skill-candidates/{id:\d+}
角色门：FDE_WORKBENCH
路径参数：id = 平台技能 skillId
校验：可见性守卫——技能存在 ∧ origin=PLATFORM ∧ FDE_WORKBENCH/PUBLISHED（不满足 → NOT_FOUND，避免暴露未发布/已下线平台技能）
响应：ResultVO<SkillDetailVO>（只读，前端禁用一切编辑动作）
错误码：NOT_FOUND(404, 技能不存在/不可见)

# 平台技能包文件树（只读）
GET  /api/fde/platform-skill-candidates/{id:\d+}/files
角色门：FDE_WORKBENCH
校验：可见性守卫（前置）
响应：ResultVO<SkillFileTreeVO>
错误码：NOT_FOUND(404)

# 平台技能包单文件内容（只读）
GET  /api/fde/platform-skill-candidates/{id:\d+}/files/content?path=relative/path.md
角色门：FDE_WORKBENCH
校验：可见性守卫 + path 合法（防越界，复用现有 path 规则）
响应：ResultVO<SkillFileContentVO>
错误码：NOT_FOUND(404, 技能或文件不存在)、BAD_REQUEST(400, path 非法)
```

> **复用策略（零冗余）**：底层读取逻辑直接复用既有 `SkillFileService.tree(skill)` / `SkillFileService.content(skill, path)` 与详情组装；新增的仅是「FDE 角色门 + 平台技能可见性守卫」这层薄包装。
>
> **可见性守卫实现（S2，重要）**：直接基于现有 repo 谓词 `SkillRepository.findPlatformSkillPublishedToFde(skillId)` 实现（与候选列表同口径），命中即可见、不命中 → **`NOT_FOUND(404)`**。
> ⚠️ **不要复用 `SkillReferenceService.requireReferenceableSkill`**：该方法虽包同一谓词，但未命中时抛的是**引用语义的 `BAD_REQUEST`**，与只读/复制需要的 404 不符。应在本只读/复制链路新写一个 `requireVisiblePlatformSkill(id)`（仅复用底层 `findPlatformSkillPublishedToFde` 谓词，未命中抛 `NOT_FOUND`）。
> 底层读 service `SkillFileService.tree/content` 对**懒迁移 0 文件行**技能会即时虚拟 SKILL.md（据 `skill.skill_md`），故只读浏览对存量平台技能天然兜底（见 §3 复制流程同款兜底）。

### 2.2 复制端点（深拷贝为游离 FDE 技能）

#### 路径选择

| 候选 | 评价 |
|------|------|
| `POST /api/fde/platform-skills/{id}/copy` | ❌ 前缀 `/api/fde/platform-skills/` 映射 `SYS_CONFIG`，违反「FDE 不走 SYS_CONFIG」铁律；语义上「复制」产物属 FDE 技能空间，不该挂在平台技能写控制器。 |
| **`POST /api/fde/skills/copy-from-platform`** ✅ | 前缀 `/api/fde/skills/` 映射 `FDE_WORKBENCH`（现有 AdminRoleGuard 映射），产物落 FDE 技能列表，语义归属正确，鉴权天然正确。**采用。** |

```
POST /api/fde/skills/copy-from-platform
角色门：FDE_WORKBENCH
请求体（DTO，platformSkillId 加 @NotNull 校验，S7）：
  {
    "platformSkillId": 123        // 必填，源平台技能 id
  }
响应：ResultVO<SkillDetailVO>（含新游离技能 id / code / name / warnings；零新增 DTO，详见下注）
校验：
  - platformSkillId @NotNull           → 缺失 BAD_REQUEST(400)
  - 可见性守卫（与 §2.1.2 同：findPlatformSkillPublishedToFde）
    源不存在/非 PLATFORM/非 FDE_WORKBENCH/PUBLISHED → NOT_FOUND(404)
    （不暴露不可见平台技能，禁止复制未发布/已下线技能）
错误码：BAD_REQUEST(400, platformSkillId 缺失)、NOT_FOUND(404, 源不存在/不可见)、INTERNAL_ERROR(5000)
建议承载：PositionSkillController（/api/fde/skills 域）+ PositionSkillService.copyFromPlatform(...)
         —— 与 createStandalone 同域同 service，复用其游离技能落库范式。
```

> 注：响应直接复用 `SkillDetailVO` 亦可（前端只需 `id`/`name`/`warnings`）。若复用 `SkillDetailVO` 则不新增 VO，更省。本稿推荐**直接复用 `SkillDetailVO`**（与 `createStandalone` 返回一致，零新增 DTO）；`CopyResultVO` 仅在产品需要精简返回时再引入。

---

## 3. 复制（深拷贝）实现设计

### 3.1 核心思路：复用 `SkillPackageWriteCore.writePackage`

深拷贝的本质 = 「读源整包文件 → 建新游离技能本体 → 整包写入新技能」。第三步与 `importZipToSkill` / zip 导入**完全同构**，已有内核 `SkillPackageWriteCore.writePackage(skill, positionId, files, operatorId, warnings)` 一次性完成：

- 落 `skill_file` 全部行（replace 语义）
- `entry ↔ skill_md` 双向同步（恒等）
- **重建工具引用 + 派生 `category`**（`syncRefsFromPackage`，最后一步）

因此**不新写文件落库 / 工具解析 / category 派生逻辑**，全部复用内核。零冗余。

### 3.2 `PositionSkillService.copyFromPlatform(platformSkillId, operatorId)` 步骤（建议 `@Transactional`）

```
1. src = requireVisiblePlatformSkill(platformSkillId)
   // 校验 origin=PLATFORM ∧ FDE_WORKBENCH/PUBLISHED；否则 404

2. 读源整包文件（必做懒迁移兜底，BB2）：
   List<SkillFile> srcFiles = skillFileRepository.findBySkillIdOrderBySortOrderAscPathAsc(src.getId())
   Map<String,String> files = srcFiles.stream() → { path -> content }（LinkedHashMap 保序）
   // ⚠️ 平台技能不保证有 skill_file 行（存在懒迁移态：SkillFileService.tree/content 与
   //    SkillPackageWriteCore.ensureMaterialized 均对 0 文件行据 skill.skill_md 虚拟 SKILL.md）。
   //    若直接拷 0 文件行会丢 SKILL.md/skill_md → 必做兜底：
   if (files.isEmpty()) {
       files.put("SKILL.md", src.getSkillMd() == null ? "" : src.getSkillMd());
   }
   // 兜底后 files 恒含 entry（SKILL.md），交 writePackage 落库时即完成源的实体化拷贝。

3. 建新游离技能本体（深拷贝主体字段，与源脱钩）：
   Skill dst = new Skill();
   dst.code        = generateUniqueSkillCode();           // POSITION 空间重新生成
   dst.name        = deriveCopyName(src.getName());       // 「xxx（副本）」，见 §3.4
   dst.description = src.getDescription();
   dst.origin      = "POSITION";                          // 游离 FDE 技能
   dst.agentId     = null;
   dst.positionId  = null;                                // 游离：无岗位归属
   dst.skillType   = src.getSkillType();                  // 深拷贝 skill_type
   dst.status      = "draft";                             // 固定 draft（不继承源 PUBLISHED）
   dst.triggers    = src.getTriggers();                   // 已是序列化串，原样拷贝
   dst.inputSchema = src.getInputSchema();                // jsonb 串原样拷贝
   dst.outputSchema= src.getOutputSchema();               // jsonb 串原样拷贝
   dst.skillMd     = src.getSkillMd();                    // 由 writePackage 用 entry 再同步定稿
   dst.sortOrder   = 0;
   dst.deleted     = false;
   dst.createdBy   = operatorId;  dst.updatedBy = operatorId;
   dst.category    = null;                                // 不拷贝，由 writePackage 重新派生
   skillRepository.save(dst);                             // 先落库拿 id（writePackage 前置）

4. 整包写入（复用内核，positionId=null）：
   WriteResult wr = packageWriteCore.writePackage(dst, null, files, operatorId, warnings);
   // 内含：落 skill_file 全行 + entry↔skill_md 同步 + 工具引用重建 + category 派生（按全部 .md 聚合）

5. reloaded = requireSkill(dst.getId());
   log.info("复制平台技能为游离 FDE 技能: srcId={}, dstId={}", src.getId(), dst.getId());
   return toDetail(reloaded, warnings);
```

### 3.3 拷贝范围对照

| 项 | 来源 | 拷贝方式 | 副本最终值 |
|----|------|---------|-----------|
| name | src.name | 派生 | 「xxx（副本）」 |
| description / triggers / skill_type / input_schema / output_schema | src 字段 | 直接拷贝 | 同源（脱钩后独立持有） |
| skill_md | src.skill_md | 拷贝后由 writePackage 用 entry 定稿（恒等） | 与源初始一致 |
| skill_file 全部文件 | `findBySkillId...` | 经 writePackage replace 落库到新 skillId | 与源初始一致 |
| 工具引用（四张 ref 表） | 不拷贝行 | **按文件 `syncRefsFromPackage` 重新派生** | 由副本自身包文件重建 |
| category | 不拷贝 | **重新派生** | 由副本包文件派生 |
| code | 不拷贝 | `generateUniqueSkillCode()` | 新唯一 code |
| origin / agent_id / position_id / status / created_by | 固定值 | 见 §3.2 | POSITION / null / null / draft / 操作者 |

> 工具引用采用「落库后按文件重建」而非「拷贝 ref 行」：与现有 zip 导入/编辑保存路径一致，保证副本工具白名单由其**自身包内容**决定，彻底与源解耦。

### 3.4 重名口径

- 副本名固定加后缀「（副本）」：`deriveCopyName(srcName) = srcName + "（副本）"`。
- **不做副本序号去重 / 名称唯一校验**：`skill.name` 无唯一约束，唯一约束在 `UNIQUE(code, origin)`（`uk_skill_code_origin`），而 code 重新生成必唯一。多次复制同名技能允许出现多个「xxx（副本）」，符合游离技能可重复创建的现状（与 `createStandalone` 一致）。

### 3.5 事务边界

- 全流程单 `@Transactional`：本体 save → writePackage（内核同事务）。任一步失败整体回滚，不产生半成品技能。
- writePackage 内部 `syncRefs` 会 detach 持久化上下文（既有行为），故步骤 5 重新 `requireSkill` 取最新态返回——与 `importZipToSkill` 完全一致。

### 3.6 缓存失效

- **无需失效任何缓存**：副本为游离态（`position_id=NULL`、`agent_id=NULL`），不进入任何岗位有效技能集 / 运行时缓存。现有岗位缓存失效逻辑（`evictPositionIfPresent`）以 positionId 为键，此处 positionId=null，跳过即可（与 `createStandalone` 一致：注释明确「无岗位 → 缓存无可失效，跳过」）。
- 注：源平台技能若为懒迁移态（0 文件行），复制是「读 + 建新副本」，**不触碰源**（不触发源的 `ensureMaterialized`，源保持原状）；副本则由 §3.2 兜底确保含 SKILL.md 后正常落库实体化。

### 3.7 迁移结论

- **零迁移**。完全复用 `origin`（V34）/ `skill_file`（V38）现有结构与 `UNIQUE(code, origin)` 约束；无新增列/表/索引。
- 当前最新迁移 V39 不变；本次改造**不引入 V40**。

---

## 4. 前端方案

### 4.1 双 Tab 落地：**平台技能只读 Tab 做成独立子组件**（v1.2 改）

> v1.1 曾推荐「AdminSkills.vue 内置 el-tabs 复用 isPlatform 切数据源」。**前端 CR（FB3）推翻该论据**，理由：
> - `AdminSkills.vue` 的 `isPlatform`（源自 `meta.skillSource='platform'`）驱动近 10 处分支（列表/新建/删除 API、编辑路由、发布列、发布管理对话框、引用计数字段），服务的是**系统配置员管理写态**，与 FDE **只读态语义相反**。强塞第三态需引入并存的 `isPlatformBrowse`，模板大量 `v-if="isPlatform"` 极易漏判。
> - `SysConfigSkills` 复用同组件，必须保证不冒出 FDE 双 Tab。
> - 候选端点返回**扁平 List 无 page/total**，与 `fetchList` 依赖的 `data.list/data.total` 结构对不上。

**决策（采用）：**

| 方案 | 评价 |
|------|------|
| ~~A：AdminSkills.vue 内塞第三态复用 isPlatform~~ | ❌ 见上，串台/漏判/结构不符。**否决。** |
| **C：新建轻容器组件内嵌 `el-tabs`，平台技能 Tab 独立子组件** ✅ | 容器只管 Tab 切换；FDE 技能 Tab 渲染**现有 AdminSkills 逻辑原样**；平台技能 Tab 是**独立只读子组件**，自带只读数据源/列表/详情，**不共用 `isPlatform / apiList / fetchList`**。彻底隔离两态语义，零串台。**采用。** |

**容器落点**：新建一个**轻容器组件**（如 `views/admin/SkillsWorkbench.vue`），路由 `/admin/skills` 指向它；容器内 `el-tabs`：
- Tab「FDE 技能」（默认）→ 内嵌**现有 `AdminSkills.vue` 原样**（FDE_WORKBENCH 自建技能态，`isPlatform=false`，不改其内部逻辑）。
- Tab「平台技能」→ 内嵌**新独立子组件**（如 `components/admin/PlatformSkillBrowse.vue`），自带候选列表 + 只读详情 + 复制，走 FDE 只读端点。

> 不直接给 `AdminSkills.vue` 外面套 el-tabs（避免它既被容器用又被 SysConfigSkills 路由直用时行为分叉）；容器**引用** AdminSkills 作为子节点，AdminSkills 自身保持单一职责不变。

#### 路由与 Tab 状态

- 路由保持单一 `/admin/skills`（roles：`FDE_WORKBENCH`/`ADMIN`），改指向新容器组件。系统配置员侧 `/admin/platform-skills`（SysConfigSkills，module=SYSCONFIG）+ AdminRail「用户端配置→平台技能」菜单项 **完全不动**——另一角色、另一界面的源头管理页，与本次 FDE 双 Tab 无关。
- Tab 状态用 **query 参数** `?tab=fde|platform`（默认 `fde`）：可分享/刷新保持、前进后退友好。
- 二态彻底隔离：FDE 技能 Tab 用 AdminSkills 既有 `isPlatform=false` 路径；平台技能 Tab 用独立子组件的只读数据源，**互不共用** `isPlatform / apiList / fetchList`，从源头杜绝把「FDE 只读」误接到「SYS_CONFIG 写端点」。

### 4.2 平台技能 Tab（独立子组件）—— 列设计与只读交互

**列表（数据源 `listPlatformSkillCandidates(keyword)`，扁平 List 无分页，恒 PUBLISHED）**——工具行单独裁剪（FB4）：

- **去掉 status 状态下拉**（候选集恒为 PUBLISHED，下拉无意义）。
- **本期不分页**：候选端点返回扁平 List，前端按 `keyword` 做**本地过滤**（名称/描述）即可；不接 `fetchList` 的分页结构。
- focus/visibility 自动刷新（S5）：刷新时按**当前 Tab 的数据源**取数——平台技能 Tab 重拉 `listPlatformSkillCandidates`，不要错调 FDE 列表接口。

**列表列**（取自 `PlatformSkillCandidateVO`）：

| 列 | 说明 |
|----|------|
| 名称 | name |
| 描述 | description（省略号截断） |
| 类别 | category（派生） |
| 操作 | 「查看」（打开只读详情）、「复制到我的工作台」 |

**只读详情（FB1 + FB2，重要——只读改造面比 v1.1 估计大得多）**：

> v1.1 误以为 `SkillFocusEditor` 是唯一写入口。实际写入口散落多组件，均为 `v-model` 双向绑定、无只读开关。必须按下表**逐组件关闭**，视觉口径统一为**写入口 `v-if` 不渲染**（不是置灰——置灰仍可能触发）。

**组件级只读关闭清单：**

| 组件 | 写入口 | 只读态处理（v-if 不渲染） |
|------|--------|--------------------------|
| `SkillFocusEditor`（自身） | 技能名 / 描述 / 触发词 / md / frontmatter 的 v-model 编辑 | 透传 `readonly` prop；只读时这些字段渲染为只读展示，保存/导入 zk 等按钮不渲染 |
| `SkillFileTree.vue` | 文件「新建/改名/删除/导出 zip」（直接调 `saveSkillFile`/`deleteSkillFile`/`renameSkillFile`/`exportSkillZip`） | 透传 `readonly`；新建/改名/删除/导出按钮与右键菜单项 **不渲染**，仅保留文件浏览/点击查看 |
| `ToolDock.vue` | 工具插入 / 拖拽 / 移除 | 透传 `readonly`；插入/移除按钮、拖拽手柄 **不渲染**，仅展示已引用工具列表 |
| `SkillMilkdownEditor` | 富文本编辑 | 透传 `readonly`，设为只读渲染模式 |
| `CodeTextEditor` | 代码/文本编辑 | 透传 `readonly`，设为只读 |
| 信息条（每处写入口） | 任何就地编辑 | 透传 `readonly`，写控件不渲染 |

- **readonly prop 传递链路**：容器 → `PlatformSkillBrowse` 详情视图（标记 readonly）→ `SkillFocusEditor(readonly)` → 向下逐层透传 `SkillFileTree(readonly)` / `ToolDock(readonly)` / `SkillMilkdownEditor(readonly)` / `CodeTextEditor(readonly)`。一处声明，链式透传，组件内统一以 `readonly` 控制写入口 `v-if`。
- **数据读取链路（FB2，避免越权 404）**：现状 `AdminSkillEditPage` 的详情/文件读写由 `isPlatform(route.meta.skillSource)` 驱动，`skillFiles.js` 的 `base(source)` 只有两前缀（`/fde/platform-skills`=SYS_CONFIG 门、`/fde/skills`），新只读端点 `/fde/platform-skill-candidates/{id}/files` 是**第三前缀**，现有 `base()` 不支持，直接复用会让 FDE 误调 SYS_CONFIG 写端点。
  - **方案**：给 `skillFiles.js` `base()` **新增第三 source**（如 `'platform-candidate'` → `/fde/platform-skill-candidates`），只读取数走此前缀；写方法（save/delete/rename/export）在该 source 下**不调用**（只读态根本不渲染写入口）。
  - **进入方式**：平台技能只读详情**不复用 AdminSkillEditPage 的可写态分支**，由 `PlatformSkillBrowse` 子组件内以只读模式挂 `SkillFocusEditor`（或一条独立只读路由/抽屉），读取走 `platform-candidate` source，杜绝落进 isPlatform 写路径。

**复制交互**：

- 列表「复制到我的工作台」与详情页「复制」按钮均调用 `copyPlatformSkill`。
- 复制成功后（**用户拍板 2026-06-26：留在平台技能 Tab + 成功提示，不跳转**）：
  - **不跳转**，停留在平台技能 Tab，便于用户连续浏览/复制多个平台技能。
  - Toast 成功提示：「已复制到 FDE 技能，可在『FDE 技能』Tab 中编辑」。
  - 不做新标签 `window.open` 也不做 `router.push`；用户需要编辑副本时自行切到「FDE 技能」Tab 打开。

### 4.3 二次确认口径

- 「复制」属**新增类操作**（产物为新游离技能，不破坏任何现有数据，可逆——副本可删）。
- 依《PRD-通用-表单填写规范.md》口径：新增/非破坏操作**无需二次确认**（无确认口径），点击即执行 + 结果 Toast。
- （对比：删除/发布/下线等破坏或状态跃迁类才需 B 级 confirm。复制不属于。）

> 待 PM/UI 复核：若产品认为「复制」需轻提示，可降级为非阻断的成功 Toast（已含），不引入确认弹窗。

### 4.4 API 层新增方法清单

**全部新方法归 `api/position.js`（S1）**——它已托管 `listPlatformSkillCandidates`，同组、同 `/api/fde` 门。**不要**放 `api/platformSkill.js`（那是 SYS_CONFIG 侧管理端点，混入会越权语义）。零新增文件。

| 文件 | 新增方法 | 对应端点 |
|------|---------|---------|
| `api/position.js` | `getPlatformCandidateDetail(id)` | GET `/api/fde/platform-skill-candidates/{id}` |
| `api/position.js` | `getPlatformCandidateFiles(id)` | GET `/api/fde/platform-skill-candidates/{id}/files` |
| `api/position.js` | `getPlatformCandidateFileContent(id, path)` | GET `/api/fde/platform-skill-candidates/{id}/files/content` |
| `api/position.js` | `copyPlatformSkill({ platformSkillId })` | POST `/api/fde/skills/copy-from-platform` |

> `listPlatformSkillCandidates(keyword)` 已存在于 `position.js`，复用不重复加。平台技能 Tab 的 FDE 只读端点均属 `/api/fde/**`，与 FDE 技能同走现有 axios 实例与拦截器，无需新实例。
> 文件只读读取链路另见 §4.2：`skillFiles.js base()` 需新增 `'platform-candidate'` source（`/fde/platform-skill-candidates`）供文件树/内容读取走对前缀。

---

## 5. 契约文档需同步条目清单（**不在本次改动，PM 经用户确认后处理**）

> 受「契约设计先行」人工门禁约束，以下两文件本稿**不修改**，仅列出待同步条目。

### `docs/api/管理后台-对外服务地图与契约.md`

- **新增**：`GET /api/fde/platform-skill-candidates/{id}`（平台技能只读详情，FDE_WORKBENCH，错误码 NOT_FOUND(404)）
- **新增**：`GET /api/fde/platform-skill-candidates/{id}/files`（只读文件树，FDE_WORKBENCH，错误码 NOT_FOUND(404)）
- **新增**：`GET /api/fde/platform-skill-candidates/{id}/files/content`（只读文件内容，FDE_WORKBENCH，错误码 NOT_FOUND(404)/BAD_REQUEST(400)）
- **新增**：`POST /api/fde/skills/copy-from-platform`（复制平台技能为游离 FDE 技能，FDE_WORKBENCH，请求体 `{platformSkillId}` @NotNull，响应 `SkillDetailVO`/新 id，错误码 BAD_REQUEST(400)/NOT_FOUND(404)/INTERNAL_ERROR(5000)）
- **修订**：标注 `GET /api/fde/platform-skill-candidates` 现额外承担「平台技能 Tab 列表数据源」（口径不变，用途补充）。

### `docs/api/管理后台-对外服务调用指南.md`

- **新增**：平台技能 Tab 只读浏览调用示例（列表 → 详情 → 文件树/内容）。
- **新增**：「复制到我的工作台」调用流程与游离副本字段说明（origin=POSITION、status=draft、code 重生、与源脱钩、category/工具引用重新派生）。
- **修订**：FDE 工作台「技能」导航说明更新为「单菜单 `/admin/skills` + 双 Tab（FDE 技能 / 平台技能）」；系统配置员侧 `/admin/platform-skills` 描述保持不变（不在本次变更范围）。

---

## 6. 开放问题

1. ~~复制后跳转方式~~（已拍板 2026-06-26）：**留在平台技能 Tab + 成功 Toast，不跳转**。
2. **平台技能 Tab 分页**（FB4 本期处置已定，下为后续）：**本期不分页**——候选端点返扁平 List，前端按 keyword 本地过滤，去 status 下拉。后续若平台技能数量大幅增长，再评估给 `platform-skill-candidates` 补分页（属候选端点既有契约变更，需另立项，非本次范围）。
3. ~~SkillFocusEditor 只读态粒度~~（FB1 已在 §4.2 定稿）：只读改造面已明确为**组件级清单**（SkillFocusEditor + SkillFileTree + ToolDock + SkillMilkdownEditor + CodeTextEditor + 信息条），视觉口径统一为写入口 **v-if 不渲染**，`readonly` prop 链式透传。仅余视觉细节（只读展示样式）待 UI 确认。
4. **源 0 文件行兜底**（BB2 已升级为**必做**）：平台技能不保证有 skill_file 行（懒迁移态，`SkillFileService`/`ensureMaterialized` 对 0 文件行虚拟 SKILL.md）。复制流程已在 §3.2 **强制**兜底（`files.isEmpty()` → `put("SKILL.md", src.skillMd)`），不再是「待评估的极端情况」。无新增开放问题。
5. ~~菜单/路由移除的回归面~~（v1.1 作废）：本次**不移除** `/admin/platform-skills`（SysConfigSkills），系统配置员管理页原样保留，故无相关死链排查需求。
