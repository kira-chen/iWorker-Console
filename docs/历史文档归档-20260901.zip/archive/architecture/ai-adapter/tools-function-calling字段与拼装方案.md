# 适配层 —— tools / function-calling 字段设计与拼装/解析方案

> **📌 校准标注（2026-07-17）**：本设计**未启动**：`LlmRequest` / `ChatMessage` 仍为 Sprint 0 精简版（LlmRequest javadoc 自述「tools / enablePromptCache 字段预留契约位但暂不实现」），`ToolCall` / `ToolSchema` / `ToolChoice` 均未创建；且 provider 执行层（OpenAiCompatibleProvider）已随主版本运行时剥离不在本仓，本文的拼装/解析落点已移至客户端运行时侧。详见《设计文档校准审计-20260717.md》。

- **阶段：** Sprint 1「设计」工序
- **作者：** 大模型专家（AI Expert）—— **提供调用语义与 OpenAI 兼容拼装/解析方案**
- **并入对象：** 架构师主笔的 `docs/architecture/ai-adapter/适配层接口契约.md`（§3.1 已预留 `tools` / `toolCalls` / `toolCallId` 字段位，本文补齐字段细节与拼装/解析逻辑，供架构师并入）
- **本 Sprint 模型：** DeepSeek（OpenAI 兼容，**原生支持 function-calling**），走现有 `OpenAiCompatibleProvider`
- **现状：** 现有代码 `LlmRequest` / `ChatMessage` / `LlmResponse` 已为 Sprint 0 精简版，tools/toolCalls 字段已在契约 §3.1 预留但**代码未承载**（`OpenAiCompatibleProvider` 有 `// TODO Sprint1: tools` 注释）。本文给出 Sprint 1 补齐方案。

> **职责边界（承 aiexpert.md）：** 我定 **tool-calling 的调用语义与归一化规则**（字段含义、拼装/解析、并行/多工具、tool result 回灌）；架构师定**承载结构**（最终 Java record 字段、tool 注册表、执行框架）。本文是策略输入，不是最终代码契约。

---

## 1. 现有代码与契约的差距

| 字段 | 契约 §3.1 已声明 | 现有代码 | Sprint 1 需补 |
|---|---|---|---|
| `LlmRequest.tools` | ✅ `List<ToolSchema>` | ❌ 无 | 加字段 + provider 请求体拼 `tools` |
| `LlmRequest.toolChoice` | ❌ 未声明 | ❌ 无 | **建议新增**（控制是否强制/禁用工具调用） |
| `ChatMessage.toolCalls` | ✅ `List<ToolCall>` | ❌ 仅 `role`/`content` | 加字段 + assistant 消息回灌 tool_calls |
| `ChatMessage.toolCallId` | ✅ | ❌ | 加字段 + role=tool 消息回灌 |
| `LlmResponse.toolCalls` | ✅ `List<ToolCall>` | ❌ | 加字段 + provider 解析 `message.tool_calls` |
| `ToolCall(id,name,argumentsJson)` | ✅ | ❌ | 新建 record |
| `ToolSchema(name,description,jsonSchema)` | ✅ | ❌ | 新建 record |

---

## 2. 字段设计（统一模型，对齐契约 §3.1）

### 2.1 LlmRequest 补 tools / toolChoice

```java
record LlmRequest(
    ModelTier tier,
    String modelId,
    List<ChatMessage> messages,
    List<ToolSchema> tools,         // 【补】function-calling 的工具 schema 列表；null/空 = 不带 tools
    ToolChoice toolChoice,          // 【建议补】auto(默认) | none | required | 指定函数名
    InferenceParams params,
    boolean stream,
    TraceContext trace
) {}
```

- `tools` 为空/null：provider 请求体**不拼** `tools` 字段（退化为纯 chat），向后兼容现有调用。
- **白名单已在引擎层收窄**：引擎只把当前 Skill 白名单工具放进 `tools`（ReAct 落地文档 §2.2 物理移除），适配层不做白名单判断，只透传。

### 2.2 ToolChoice（控制工具调用行为）

```java
enum ToolChoiceMode { AUTO, NONE, REQUIRED, FUNCTION }   // FUNCTION = 强制指定某函数
record ToolChoice(ToolChoiceMode mode, String functionName /* mode=FUNCTION 时填 */) {
    static ToolChoice auto() { return new ToolChoice(ToolChoiceMode.AUTO, null); }
}
```

- Sprint 1 两个 SOP **默认 `AUTO`**（让模型自行决定调工具还是结束/追问）。
- `NONE` 备用：强制模型只出文本（如最终汇报阶段不希望再调工具）。
- `REQUIRED`/`FUNCTION` 备用：未来确定性编排用，本 Sprint 不强依赖。

### 2.3 ChatMessage 补 toolCalls / toolCallId

```java
record ChatMessage(
    String role,                    // system | developer | user | assistant | tool
    String content,                 // tool 消息 = observation 文本/JSON 串；assistant 纯工具调用时可空
    List<ToolCall> toolCalls,       // 【补】仅 assistant 消息：模型本轮发起的工具调用（回灌历史用）
    String toolCallId               // 【补】仅 tool 消息：对应哪个 toolCall 的结果
) {
    // 便捷工厂（兼容现有 system/user/assistant 单参用法，新增两个）
    static ChatMessage assistantToolCalls(List<ToolCall> calls) {
        return new ChatMessage("assistant", null, calls, null);
    }
    static ChatMessage toolResult(String toolCallId, String content) {
        return new ChatMessage("tool", content, null, toolCallId);
    }
}
```

> **关键语义：** observation **必须**用 `role="tool"` + `toolCallId` 回灌（不是塞 user/assistant 文本）。`toolCallId` 必须与触发该结果的 `ToolCall.id` 完全一致，否则多/并行工具调用会错配。

### 2.4 ToolCall / ToolSchema

```java
record ToolCall(String id, String name, String argumentsJson) {}   // argumentsJson: 模型生成的 JSON 串
record ToolSchema(String name, String description, Map<String,Object> jsonSchema) {}  // jsonSchema = parameters
```

### 2.5 LlmResponse 补 toolCalls

```java
record LlmResponse(
    String content,
    List<ToolCall> toolCalls,       // 【补】模型选择的工具调用（多/并行）；无则 null/空
    String finishReason,            // stop | tool_calls | length | content_filter
    Usage usage, String vendor, String modelId,
    boolean fallbackUsed, int fallbackHop, boolean circuitBroken,
    long latencyMs, boolean success, String errorCode
) {}
```

> 引擎据 `finishReason == "tool_calls"` 进入执行分支，据 `== "stop"` 结束（ReAct 落地文档 §1.1）。

---

## 3. OpenAI 兼容请求体拼装（provider 出向）

在 `OpenAiCompatibleProvider.buildRequestBody` 补 tools / tool_choice / 消息的 tool 字段。

### 3.1 tools 拼装

```jsonc
// 请求体片段：req.tools -> body.tools（OpenAI/DeepSeek 标准 function 形态）
"tools": [
  {
    "type": "function",
    "function": {
      "name": "hr_get_leave_balance",
      "description": "查询员工各假别剩余余额。用户问'还有几天年假/假期余额'时调用。",
      "parameters": {                         // 即 ToolSchema.jsonSchema 原样透传
        "type": "object",
        "properties": { "userId": { "type": "string", "description": "员工ID" } },
        "required": ["userId"]
      }
    }
  }
],
"tool_choice": "auto"                          // ToolChoice 映射，见 3.2
```

拼装规则：
- `req.tools` 每个 `ToolSchema` → `{type:"function", function:{name, description, parameters: jsonSchema}}`。
- `req.tools` 为空/null → **不拼** `tools` 与 `tool_choice` 字段（向后兼容）。

### 3.2 tool_choice 映射

| `ToolChoice.mode` | OpenAI/DeepSeek `tool_choice` 值 |
|---|---|
| `AUTO`（默认） | `"auto"` |
| `NONE` | `"none"` |
| `REQUIRED` | `"required"` |
| `FUNCTION` | `{"type":"function","function":{"name":"<functionName>"}}` |

### 3.3 历史消息中的 tool_calls / tool 结果拼装

多轮回灌时，messages 数组要把 assistant 的工具调用与 tool 结果按 OpenAI 格式拼回：

```jsonc
// assistant 发起工具调用（来自 ChatMessage.toolCalls）
{ "role": "assistant", "content": null,
  "tool_calls": [
    { "id": "call_abc", "type": "function",
      "function": { "name": "hr_calc_leave_days", "arguments": "{\"startDate\":\"2026-06-15\",\"endDate\":\"2026-06-16\"}" } }
  ]
},
// 工具执行结果（来自 ChatMessage.toolResult）
{ "role": "tool", "tool_call_id": "call_abc",
  "content": "{\"workdays\":2,\"excluded\":[]}" }
```

拼装规则（在 `buildRequestBody` 的 messages 循环里按 role 分支）：
- `role=assistant` 且有 `toolCalls` → 拼 `content`（可 null）+ `tool_calls` 数组（`arguments` = `ToolCall.argumentsJson` 原样字符串）。
- `role=tool` → 拼 `tool_call_id`（= `ChatMessage.toolCallId`）+ `content`（observation，建议 JSON 串）。
- 其余 role（system/developer/user/assistant 纯文本）→ 维持现有 `{role, content}` 拼法。

### 3.4 stream

Sprint 1 两个 SOP 引擎主循环用**非流式**即可（`stream=false`，对工具编排更稳，tool_calls 一次拿全）。流式下 tool_calls 需增量拼装（契约 §3.2），列为 Sprint 1+ 前台体验增强，**不在本工序范围**。

---

## 4. OpenAI 兼容响应解析（provider 入向）

在 `OpenAiCompatibleProvider.parseResponse` 补 `message.tool_calls` 解析。

### 4.1 解析逻辑

```jsonc
// 模型响应（finish_reason=tool_calls 时）
"choices": [{
  "finish_reason": "tool_calls",
  "message": {
    "role": "assistant",
    "content": null,                          // 也可能有思考文本
    "tool_calls": [
      { "id": "call_abc", "type": "function",
        "function": { "name": "hr_calc_leave_days", "arguments": "{\"startDate\":\"2026-06-15\",\"endDate\":\"2026-06-16\"}" } }
    ]
  }
}]
```

解析规则：
- `message.tool_calls[*]` → `ToolCall(id, function.name, function.arguments)`，`argumentsJson` 保留原始字符串（**不在 provider 层解析为 Map**，交引擎/工具执行器按各工具 schema 解析，避免适配层耦合业务）。
- `finish_reason` 原样归一到 `LlmResponse.finishReason`（`tool_calls` / `stop` / `length` / `content_filter`）。
- `content` 可与 `tool_calls` 并存（模型边想边调），都保留。
- 无 `tool_calls` → `LlmResponse.toolCalls = null/空`，走纯文本路径（现有逻辑）。

### 4.2 健壮性
- DeepSeek 偶发 `arguments` 为非法 JSON → provider **不报错**，原样回传字符串；引擎/执行器解析失败时回灌"参数解析失败，请重新组织参数"让模型纠正（属引擎层处理，非适配层）。
- `tool_calls` 数组可能多个（并行工具调用）→ 全部解析为 `List<ToolCall>`，引擎按序/并行执行（Sprint 1 两个 SOP 实际为单工具/单步，但字段与解析需支持多个）。

---

## 5. 与引擎 / 架构师的对齐点

| 我定（调用语义） | 架构师定（承载结构） |
|---|---|
| observation 用 `role=tool`+`toolCallId` 回灌；id 必须对齐 | `ChatMessage` 最终 record 字段、便捷工厂 |
| `tools` 由引擎按白名单收窄后透传，适配层不判白名单 | tool 注册表、Skill→ToolSchema 解析、执行框架 |
| `argumentsJson` 在 provider 层不解析，原样透传 | 工具执行器按各工具 parameters 解析入参 |
| `tool_choice` 默认 auto；finishReason 驱动循环 | 引擎执行器循环控制（见 ReAct 落地文档 §1） |
| 业务名映射（函数名→业务名）供 trace 展示 | trace schema、落库 |

---

## 6. 对现有代码的最小改动清单（供架构师/后端落地）

1. 新建 `ToolCall`、`ToolSchema`、`ToolChoice`/`ToolChoiceMode` record/enum（`com.aiassistant.llm.model`）。
2. `ChatMessage` 加 `toolCalls` / `toolCallId` 字段 + `assistantToolCalls` / `toolResult` 工厂（保留现有 `system/user/assistant` 工厂兼容）。
3. `LlmRequest` 加 `tools` / `toolChoice` 字段（更新 `orchestrate` 工厂或新增带 tools 的工厂）。
4. `LlmResponse` 加 `toolCalls` 字段（更新 `ok` 工厂）。
5. `OpenAiCompatibleProvider.buildRequestBody`：补 tools / tool_choice 拼装（§3）+ messages 按 role 分支拼 tool_calls / tool 结果（§3.3）；移除 `// TODO Sprint1: tools` 注释。
6. `OpenAiCompatibleProvider.parseResponse`：补 `message.tool_calls` 解析为 `List<ToolCall>`（§4）。

> 改动**仅在适配层 model + provider**，`LlmGateway` 路由/重试逻辑无需改（tool-calling 对韧性层透明）。
</content>
