# `load_resource` 自动注入白名单（对齐 `skill_load_section`）— 设计

> **📌 校准标注（2026-07-17）**：本文档描述的运行时能力已随主版本运行时剥离移出本仓（见《主版本运行时剥离-配置分发化设计.md》），本仓不含对应实现；文档保留作历史设计依据。本设计落点 orchestration 包与 orchestrator/ 目录均不在本仓。详见《设计文档校准审计-20260717.md》。

> 版本：v1.0 ｜ 日期：2026-06-29 ｜ 状态：设计先行（已获用户拍板修法方向：平台/代码层修、向后兼容；待据此编码）
> 作者：架构师 ｜ 适用范围：`OrchestrateRequestAssembler` 装配 — 真实办事链路（员工对话 / 定时任务 / 效果测试 / 跨岗位只读）全覆盖
>
> **红线（用户锁定）**：除 `OrchestrateRequestAssembler` 这一处自动注入外，**不动其它链路逻辑**。`load_resource` 执行器（`LoadResourceExecutor`）、越权门控（`allowedResourceKeys`）、资源目录渲染（`resourceDir` / `expertPayload.resources`）、收窄逻辑（`selectedSkillIds`）、orchestrator **全部零改**。

---

## 1. 问题（已定性，有真链路对比证据）

`OrchestrateRequestAssembler` 把岗位的**共享资源目录**（`view.resources()` 专家级 + 各技能 `skill.resources()` 技能级，销售岗约 18 条）**全量渲染进 prompt**：

- 专家级目录采集：`OrchestrateRequestAssembler.java` L103-105（`view.resources()` → `collectResource` → `resourceDir` / `allowedResourceKeys`）。
- 技能级目录采集：L121-124（每个技能的 `skill.resources()`，**在 `narrow continue`(L126) 之前**执行 → 不随 `selectedSkillIds` 收窄，全量聚合）。
- 目录最终下发：L196-198，`expertPayload.resources = new ArrayList<>(resourceDir.values())` —— **整份目录摊给 prompt，与 active/收窄技能无关**。

但内置工具 `load_resource`（`LoadResourceTool.CODE`）**没有任何自动注入**——只有当某技能的 `skill_md` 显式声明引用了它、经 `parseToolRefs` 进入 `skill.toolRefs()` 时，才会在 L130-143 进白名单。

**张力**：资源目录是「全量摊派」的，但 `load_resource` 进白名单是「按技能各自声明」的——二者不对齐。当 **active / 收窄到的技能没声明 `load_resource`** 时（如销售 skill 13「客户交互记录」，11 个技能里唯一没声明的），prompt 摆出 18 条资源目录、模型据目录去 `load_resource` 取正文 → run 白名单不含该 toolCode → `ToolExecutionService` 白名单二次校验拦截 `TOOL_NOT_ALLOWED` → 模型「思考下一步→获取结果失败」。

**非效果测试独有**：真员工对话路由到该技能同样失败（日志已有真实对话 run 复现）。`orchestrator/app/graph/nodes.py:105 _warn_directory_tool_gap` 正是这条的既有可观测告警（「渲染了 N 个共享资源目录，但白名单缺内置工具 load_resource」）。

---

## 2. 修法：自动注入（平台层、向后兼容，仿 `skill_load_section`）

**完全仿照现有 `skill_load_section`「有子树(sections)才注入」范式**（`OrchestrateRequestAssembler.java` L153-169）：

> skill_load_section 现状：`if (!sections.isEmpty() && toolRegistry.contains(SkillSectionTool.CODE))` → 取 `definitionOf` → 该 skill 局部 `whitelist` 未含才加，同步 `allowedTools` / `toolTypes` / `toolBizNames` / `toolRequiresConfirmation` + `whitelist` 加 `ToolSchemaPayload`。

`load_resource` 注入采同款写法，**唯一差别在「注入条件」**：

- **skill_load_section 条件 = 该技能自身有子树**（`!sections.isEmpty()`，子树是技能私有的，逐技能判定天然正确）。
- **load_resource 条件 = 本 run 整体存在任一资源目录**（循环前预扫 `hasAnyResource(view)`）。因为**资源目录是全量摊给每个技能 prompt 的**（不随收窄），故凡是「本 run 有资源目录」，就对**每个进入 `skills[]` 的技能**注入 `load_resource`——与目录全量摊派对齐，而非只主技能。

### 2.1 精确注入条件与位置

- **条件**：`hasAnyResource(view) && toolRegistry.contains(LoadResourceTool.CODE)`，其中 `hasAnyResource(view)` = 「专家级 `view.resources()` 非空 ∨ 任一技能 `skill.resources()` 非空」，在 **skill 循环前**预扫一次得到的循环不变量。
  - 用「本 run 整体是否存在资源目录」作门，**不是** `allowedResourceKeys`：语义上「prompt 渲染了资源目录、模型就可能去 load」，而资源目录（`resourceDir`）来源 = 专家级 ∪ 全部技能级 = `hasAnyResource(view)` 的并集。预扫与「目录最终是否非空」等价，但不依赖判定时点 `resourceDir` 的累积进度（见下「循环前预扫」）。
- **位置**：在 skill 循环内、该技能局部 `whitelist` 构建完成之后（L143 之后），与 L153-169 的 skill_load_section 注入**并列**（前后顺序不敏感，可放其前或其后；建议紧随 skill_load_section 块之后，集中两处内置目录工具注入）。
- **去重**：与 skill_load_section 同口径——以**该 skill 局部 `whitelist` 是否已含**为准（`whitelist.stream().anyMatch(p -> LoadResourceTool.CODE.equals(p.toolCode()))`），而非全局 `allowedTools`；否则一个专家绑定多个技能时，第二个技能的局部 `whitelist` 会漏掉 schema。
- **注入门用「循环前预扫」，与循环顺序/资源来源无关（最终实现）**：注入条件**不**取即时态的 `resourceDir.isEmpty()`（它在 skill 循环中边遍历边累积，首个技能循环时可能尚未含后续技能级资源），而是在 **skill 循环前先预扫** `hasAnyResource(view)`——即「专家级资源（`view.resources()`）∪ 任一技能级资源（任一 `skill.resources()`）非空」。预扫结果是一个循环不变量，对**每个进入 `skills[]` 的技能**用同一布尔判定是否注入。
  - **这样根除了「前序技能漏注入」边角**：无论资源来自专家级还是某个（甚至靠后的）技能级、无论 skill 循环顺序如何，只要本 run 整体存在任一资源目录，**所有进入 `skills[]` 的技能都一致注入** `load_resource`——不依赖判定时点 `resourceDir` 是否已累积完整。
  - 这比设计初版「`resourceDir` 即时态」更强、更稳：判定与采集进度解耦，无时序敏感性。资源目录渲染（`resourceDir` 的累积与下发）逻辑本身**零改**，预扫只是新增一个只读的循环前布尔计算。

### 2.2 注入内容（沿用 ToolDefinition，wire 不变）

`load_resource` 是已注册 Bean（`LoadResourceDefinition implements ToolDefinition`，type=SKILL，`requiresConfirmation=false`，含完整 `inputSchema`）。注入即取 `toolRegistry.definitionOf(LoadResourceTool.CODE)` 的 `code/bizName/description/inputSchema/requiresConfirmation`，构造一个 `ToolSchemaPayload` 加入该技能 `whitelist`，并同步：
- `allowedTools.add(code)`
- `toolTypes.put(code, SKILL)`
- `toolBizNames.put(code, "取用共享资源")`
- `toolRequiresConfirmation.putIfAbsent(code, false)`

**wire 结构零变化**：只是某技能 `whitelist[]` 多一个 `ToolSchemaPayload`（既有 wire 字段），`OrchestrateRequest` 结构不变。

---

## 3. 越权 / 安全（无扩面）

`LoadResourceExecutor.execute`（`LoadResourceExecutor.java` L56-81）的越权校验**纯靠 `run.allowedResourceKeys()` O(1) 命中**，与白名单（`allowedTools`）**完全独立**：

- 自动注入只改 `allowedTools`（让模型「能调用 `load_resource` 这个工具」），**不改 `allowedResourceKeys`**（可读的 res_key 集合不变）。
- 模型调用 `load_resource(res_key=X)` 时，仍由执行器查 `allowedResourceKeys` —— X 不在其中（= 专家级 ∪ 命中技能级）即 `RESOURCE_NOT_ALLOWED` 拦截。
- 故**可读范围零放宽**：模型仍只能读「已摊给本 run 的 res_key」。注入消除的是「工具本身不可调用」的假阴性失败（模型据目录调取却被工具白名单拦），不是「读了不该读的资源」。

**结论：无越权扩面。** `allowedResourceKeys` 越权门控零改，安全边界不变。

---

## 4. 向后兼容 / 零回归论证（重点）

| 场景 | 行为 | 零回归依据 |
|---|---|---|
| ① 已声明 `load_resource` 的技能（销售 10/11 个技能） | `whitelist` 已含 → `alreadyInWhitelist=true` → **跳过、不重复** | 与 skill_load_section 去重同口径（局部 whitelist 判定）；schema 不重复、wire 不变 |
| ② 无任何资源目录的岗位（HR / IT，`view.resources()` 与各 `skill.resources()` 均空） | `hasAnyResource(view)` 恒 false → 注入条件恒 false → **完全不注入** | 与现状字节级一致；`allowedTools` / `whitelist` 无任何新增 |
| ③ 有资源目录但 active 技能未声明（销售 skill 13） | `resourceDir` 非空 → 注入 `load_resource` schema → 模型可调用 → 越权门控放行已摊 res_key → **不再 TOOL_NOT_ALLOWED** | 这正是缺陷修复点 |
| ④ 收窄（效果测试技能入口 / 对话灰度） | 资源目录不随收窄（L121-124 在 continue 前，既有行为）→ 进入 `skills[]` 的技能仍注入 `load_resource` | 收窄逻辑零改；注入只对「进入 skills[] 的技能」生效 |

**只新增一项「本就该有的内置工具 schema」**，不改：资源目录渲染（`collectResource` / `resourceDir` / `expertPayload.resources`）、收窄逻辑（`narrow` / `selectedSkillIds`）、`load_resource` 执行器、`allowedResourceKeys` 越权门控、orchestrator。

**`_warn_directory_tool_gap` 告警**：注入后，凡渲染资源目录的 run 白名单都含 `load_resource` → 该告警不再触发（resources 分支）。告警本身不删（仍守 sections 分支 + 防御未来回归），属正向。

---

## 5. 全岗位影响（真实链路改动）

| 链路 | 影响 | 评估 |
|---|---|---|
| 员工真实对话 | 路由到「有资源目录、但该技能未声明 load_resource」的技能时，不再失败 | **正向**：消除真实对话 run 的 TOOL_NOT_ALLOWED 失败（日志已复现）+ 消除告警 |
| 定时任务（headless） | 定时任务走 `TaskExecutionAssembler`（**不复用 OrchestrateRequestAssembler**，按 tool_refs 现取 schema、无 expert.resources 目录），故 `resourceDir` 概念不适用 | **零影响**：headless 装配不渲染资源目录，本注入不触发 |
| 效果测试 | 复用 `OrchestrateRequestAssembler.assemble`（含本注入）→ 技能入口/岗位入口同样受益 | **正向**：技能入口收窄到未声明 load_resource 的技能时不再失败 |
| 跨岗位只读 | `crossPosition=true` 仅剔除 OPERATION 技能（路由期），资源目录与 load_resource 注入逻辑不受其影响 | **零影响 / 正向**：只读路若渲染资源目录同样获注入，行为一致更优 |

**有无岗位下此注入不当？** 无。注入条件严格门控在「本 run 渲染了资源目录」——无资源目录的岗位不触发；有资源目录的岗位，给模型一个「读已摊资源」的工具是其本应具备的能力（目录都摊了，取用工具理应在）。不存在「渲染了目录却不该给取用工具」的合理岗位。

---

## 6. wire 契约

注入只是某技能 `whitelist[]` 多一个 `ToolSchemaPayload`（既有 wire 类型），`OrchestrateRequest` 顶层结构、`EffectiveExpertPayload`、`SkillPayload` 字段集**全部不变**。`OrchestrateRequestWireContractTest` 等 wire 契约测试**不破**（它们校验字段存在性 / 类型，不校验 whitelist 元素个数）。Python `contracts.py` 的 `ToolSchema` 照常反序列化新增的这一项。

> 注：设计初版曾把「纯技能级资源、专家级为空、仅后续技能贡献资源」列为「前序技能漏注入」边角并保守不动。**最终实现已用「循环前预扫 `hasAnyResource(view)`」根除该边角**（§2.1）：注入门是循环不变量、与循环顺序/资源来源无关，无论资源来自专家级还是任一（靠后的）技能级，所有进入 `skills[]` 的技能都一致注入。**无遗留待办。**

---

## 7. skill.md 内容问题甄别（交用户）

**做了自动注入后，skill 13「客户交互记录」是否还需要改 skill.md？**

→ **不需要**。平台层自动注入已兜住：凡渲染资源目录的 run，`load_resource` 自动进白名单，skill 13 无需在 skill_md 里补声明 `load_resource`。这正是「平台/代码层修、向后兼容」的目标——不把平台缺陷转嫁给内容。

**代码修不掉、确需用户改 skill.md / orchestration 的内容问题清单：**

→ **本次无需改任何 skill.md / orchestration。** 本缺陷的根因是**平台装配逻辑**（资源目录全量摊派 vs load_resource 按技能声明的不对齐），不是 skill 内容问题。skill 13 未声明 load_resource 不是「内容错误」——在「目录全量摊派」的平台语义下，**任何技能都不应被要求逐个声明 load_resource**（正如没有技能需要声明 skill_load_section，平台按「有子树」自动给）。

> 若后续在别处发现确属内容层的问题（如某 res_key 在 `expert_resource` / `skill_resource` 表中失效、orchestration JSON 畸形导致解析异常、skill_md 引用了不存在的资源键等），应单独挑出交用户改——但**本次自动注入修复范围内，未发现此类内容问题**。

---

## 8. 给后端的精确落点指引

| 动作 | 文件（绝对路径） | 落点 |
|---|---|---|
| 自动注入 load_resource | `backend/src/main/java/com/aiassistant/orchestration/OrchestrateRequestAssembler.java` | 循环前预扫 `hasAnyResource(view)`（专家级 ∪ 任一技能级资源非空）得布尔不变量；skill 循环内 L143 之后（建议紧随 L153-169 skill_load_section 注入块之后并列）：条件 `hasAnyResource && toolRegistry.contains(LoadResourceTool.CODE)`；局部 `whitelist` 去重（`anyMatch(toolCode==load_resource)`）；同步 `allowedTools`/`toolTypes`/`toolBizNames`/`toolRequiresConfirmation`/`whitelist`，全部仿 L160-167 写法 |
| 导入常量 | 同文件 import 区 | `import com.aiassistant.skill.tool.resource.LoadResourceTool;`（`SkillSectionTool` 已 import，照加） |
| 复用 Bean | `backend/src/main/java/com/aiassistant/skill/tool/resource/LoadResourceDefinition.java` | **零改**——`toolRegistry.definitionOf(LoadResourceTool.CODE)` 取其 code/bizName/description/inputSchema/requiresConfirmation |
| 执行器 / 越权门控 | `LoadResourceExecutor.java`、`OrchestrationRun.allowedResourceKeys` | **零改**（§3） |
| 资源目录渲染 / 收窄 | `OrchestrateRequestAssembler` L98-124 collectResource、L196-198 | **零改**（注入门用循环前只读预扫 `hasAnyResource(view)`，不改采集与下发） |
| orchestrator | `orchestrator/app/graph/nodes.py`（`_warn_directory_tool_gap`） | **零改**（注入后该告警 resources 分支自然不再触发，告警保留） |

**伪代码（与 skill_load_section L156-169 同款）：**

```java
// 循环前预扫一次（循环不变量）：专家级 ∪ 任一技能级资源非空 → 本 run 有资源目录。
// boolean hasAnyResource = (view.resources()!=null && !view.resources().isEmpty())
//     || view.skills().stream().anyMatch(s -> s.resources()!=null && !s.resources().isEmpty());

// 资源目录全量摊给每个技能 prompt（不随收窄），故凡本 run 有目录即对每个进入 skills[] 的技能注入取用工具。
// 用循环前预扫的 hasAnyResource 作门（与循环顺序/资源来源无关，根除前序技能漏注入边角）。
// 去重以局部 whitelist 为准（已声明的技能不重复）。越权仍由 allowedResourceKeys 门控，可读范围不放宽。
if (hasAnyResource && toolRegistry.contains(LoadResourceTool.CODE)) {
    ToolDefinition resDef = toolRegistry.definitionOf(LoadResourceTool.CODE);
    boolean alreadyInWhitelist = whitelist.stream()
            .anyMatch(p -> resDef.code().equals(p.toolCode()));
    if (!alreadyInWhitelist) {
        allowedTools.add(resDef.code());
        toolTypes.put(resDef.code(), resDef.type());
        toolBizNames.put(resDef.code(), resDef.bizName());
        toolRequiresConfirmation.putIfAbsent(resDef.code(), resDef.requiresConfirmation());
        whitelist.add(new OrchestrateRequest.ToolSchemaPayload(
                resDef.code(), resDef.bizName(), resDef.description(),
                resDef.inputSchema(), resDef.requiresConfirmation()));
    }
}
```

**测试建议**：①有资源目录 + 未声明 load_resource 的技能 → 白名单含 load_resource（修复验证）；②已声明的技能 → 不重复（去重验证）；③无资源目录岗位 → 白名单不含 load_resource（零回归验证）；④wire 契约测试仍绿。
