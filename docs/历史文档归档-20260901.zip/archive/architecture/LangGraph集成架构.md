# LangGraph 编排服务集成架构（架构师主笔）

> **📌 校准标注（2026-07-17）**：本文档描述的运行时能力已随主版本运行时剥离移出本仓（见《主版本运行时剥离-配置分发化设计.md》），本仓不含对应实现；文档保留作历史设计依据。详见《设计文档校准审计-20260717.md》。

- **阶段：** Path A 集成架构设计
- **作者：** 架构师（Architect）
- **日期：** 2026-06-10
- **状态：** 待 PM / AI 专家对齐
- **路线（用户拍板 Path A）：** 原版 LangGraph（Python，容器化）独立编排服务 + Java 后端
- **上游依据：**
  - `.claude/memory/project_langgraph_orchestration.md`（Path A 决策，核心依据）、`.claude/memory/project_tech_stack.md`
  - `docs/prd/PRD-00-核心概念与通用模型.md`（专家/Skill/SOP/工具通用模型 —— 编排必须对任意专家通用）
  - `docs/architecture/系统架构设计.md`、`docs/architecture/database/数据模型设计.md`、`docs/architecture/Sprint1-引擎与覆盖层设计.md`（其中"Java 内 ReAct 引擎"被本设计取代/重构）
  - `docs/api/Sprint1-接口契约.md`、`docs/architecture/ai-adapter/适配层接口契约.md`

> **本文范围（集成边界）：** 服务拓扑与职责边界、Java↔Python 接口契约、工具回调时序、状态与持久化对齐、通用性保证、部署变更、模型调用归属。
> **不在本文范围（AI 专家主笔）：** LangGraph **StateGraph 图内部**——节点/边/SOP 约束注入/工具绑定/ReAct 或 Plan 决策逻辑/人机协同节点。二者在 **§4 工具回调、§5 中断续跑、§6 状态对齐** 三处对齐。

---

## 0. 决策落地对照（Path A → 架构）

| Path A 决策 | 本架构落地 |
|------------|-----------|
| LangGraph(Python) 独立编排服务 | 新增 `orchestrator` 服务（FastAPI + LangGraph），容器化，本机不裸装 Python |
| Java 管认证/CRUD/配置/持久化/**工具执行** | Java 仍是系统主入口与**工具执行权威**；Python 不直连 MCP/API（首版） |
| Python 负责核心编排（规划路径 + 推进执行） | StateGraph 跑 ReAct/Plan；**取代** Sprint1 设计的"Java 内 ReActEngine" |
| 经 HTTP/SSE 交互 | Java→Python 发起/推进用 HTTP+SSE；Python→Java 工具回调用 HTTP |
| 工具调用回调 Java | **工具执行回调**（§4）：LangGraph 产出 tool 决策 → 回调 Java 执行 → 拿 observation 续跑 |
| 编排通用、HR/IT 仅种子 | Python 只吃"专家配置数据 + 工具 schema"，零专家硬编码（§7 可验收判定） |

> **对 Sprint1 设计的影响（重构点，需 PM/AI 专家确认）：** `Sprint1-引擎与覆盖层设计.md` §1.3 的 `ReActEngine.run(...)` 主循环、§1.5 二次确认引擎拦截、§5 reasoning_trace 生成，**由 Java 内实现迁移为"Java 编排代理(OrchestrationProxy) + Python StateGraph"**。**不变的部分**（仍归 Java）：§1.2 SkillLoader、§2 EffectiveExpertView 覆盖层合并、§3 ToolRegistry/ToolExecutor（含 Mock）、§1.4 ToolRef→ToolSchema 映射、reasoning_trace 与 message/session 落库。即：**"如何决策"挪到 Python，"用什么数据 + 谁真正执行工具 + 谁落库"仍在 Java。**

---

## 1. 服务拓扑与职责边界

### 1.1 拓扑图（文字版）

```
┌───────────────────────────────────────────────────────────────────────┐
│  前端 Vue3（使用前台 + 管理后台）                                          │
│   - 对话页：SSE 接收 ReAct/Plan 步骤折叠展示 + 正文增量 + 二次确认弹窗      │
└───────────────────────────────┬───────────────────────────────────────┘
                  HTTPS / REST(JSON) + SSE(text/event-stream)
                                │  （前端只与 Java 通信，不直连 Python）
┌───────────────────────────────┴───────────────────────────────────────┐
│  Java 后端（Spring Boot 3 / JDK21）—— 系统主入口 & 编排代理 & 工具执行权威  │
│  ┌─ 接入层：认证(JWT)/RBAC/审计/全局异常/ResultVO                          │
│  ├─ ChatService：会话定位、落库 session/message、SSE 出口（对前端）          │
│  ├─ ExpertRouter + SkillLoader：合并 EffectiveExpertView（模板⊕覆盖层）      │ ← 不变（Sprint1 §2）
│  ├─ ★ OrchestrationProxy（新增）：组装编排入参 → 调 Python；中转 SSE；        │
│  │     接 Python 的工具回调；管理中断续跑；把 Python 步骤事件落 reasoning_trace│
│  ├─ ToolRegistry + ToolExecutor：MCP/API/Mock **真正执行**（工具执行权威）    │ ← 不变（Sprint1 §3）
│  ├─ Capability：MCP Client / API Adapter（真实对接）                         │
│  ├─ Admin/Config CRUD：expert/skill/mcp_def/api_def 等                       │
│  └─ Persistence：session/message/reasoning_trace/tool_call_log/llm_call_log │
└───────┬──────────────────────────────────────────────┬────────────────┘
        │ ① 发起/推进编排                                 │ ② 工具执行回调
        │   POST /orchestrate/stream (HTTP+SSE)          │   POST /api/internal/tool/execute
        │   POST /orchestrate/resume                     │   （Python→Java，HTTP，内网，服务令牌）
        ▼                                                ▲
┌───────────────────────────────────────────────────────────────────────┐
│  Python 编排服务 orchestrator（FastAPI + LangGraph）—— 核心编排（决策）     │
│  ┌─ FastAPI 入口：/orchestrate/stream、/orchestrate/resume、/healthz       │
│  ├─ ★ StateGraph（AI 专家主笔）：规划任务路径 + 推进执行（ReAct/Plan）       │
│  │     节点：plan / reason / tool_decision / interrupt(ask·confirm) / finish │
│  │     - 只吃 EffectiveExpertView + ToolSchema 白名单（不识别 HR/IT）        │
│  ├─ Tool 绑定：把 Java 传入的 ToolSchema 注册为 LLM tools；**不本地执行**     │
│  │     工具执行 = 用 LangGraph interrupt/回调把 ToolCall 交回 Java（§4）      │
│  ├─ LLM 调用：直连客户内网模型 API（OpenAI 兼容，§8）                         │
│  └─ PostgresSaver(checkpointer)：StateGraph 状态/断点持久化（§6，复用同库）   │
└───────────────────────────────────────────────────────────────────────┘
        │ LLM 出站（仅客户内网端点）          │ checkpoint 读写
        ▼                                    ▼
   客户内网大模型 API                    PostgreSQL 16（同实例，独立 schema）
   （DEMO=DeepSeek）                      业务表(Java) + langgraph checkpoint 表(Python)
```

### 1.2 职责边界表（避免重叠的权威口径）

| 关注点 | Java 后端 | Python orchestrator |
|--------|----------|---------------------|
| 认证/鉴权/RBAC/审计 | ✅ 唯一 | ❌（只信任 Java 传入的身份上下文 + 服务令牌） |
| 前端通信（REST/SSE） | ✅ 唯一出口 | ❌ 前端不直连 Python |
| expert/skill/mcp/api 配置 CRUD | ✅ | ❌ 只读 Java 传入的快照 |
| 覆盖层合并（EffectiveExpertView） | ✅ 仍在 Java（Sprint1 §2 不变） | ❌ 只接收合并后的视图 |
| **任务路径规划 + 推进（核心编排决策）** | ❌（仅代理转发） | ✅ **唯一**（StateGraph） |
| 何时调哪个工具 / 追问措辞 / 终止 | ❌ | ✅（图内决策，AI 专家） |
| **工具真正执行（MCP/API/Mock）** | ✅ **唯一权威**（ToolExecutor） | ❌ 只产出 ToolCall 决策，回调 Java |
| LLM 模型调用 | 适配层保留（RAG embedding 等仍走 Java，见 §8） | ✅ 编排内推理调用由 Python 直连内网模型 |
| 二次确认/追问的"暂停-人答-续跑" | ✅ 承载前端确认回合 + 触发 resume | ✅ 图内 interrupt 产生中断点（§5） |
| session/message/reasoning_trace 落库 | ✅ **唯一**（持久化权威） | ❌ 不写业务库（只写自己的 checkpoint schema） |
| LangGraph 运行态 checkpoint/断点 | ❌ | ✅ PostgresSaver（§6） |
| tool_call_log / llm_call_log 埋点 | ✅（工具执行在 Java→Java 记；LLM 在 Python 调，埋点见 §8.3） | LLM 调用元数据随事件回传 Java 落库 |

**一句话边界：** **Java = 身份 + 配置 + 数据 + 工具执行 + 落库 + 对前端的唯一门面；Python = 只做"决策与推进"的纯编排大脑，无副作用执行权、无业务库写权。**

---

## 2. Java ↔ Python 接口契约

> 两个方向：**A. Java→Python**（发起/推进编排，HTTP+SSE）；**B. Python→Java**（工具执行回调，HTTP）。所有传参**通用**：只含"专家配置数据 + 工具 schema + 会话上下文 + 用户身份"，**不含任何 HR/IT 特例字段**。
> **内网信任域：** Java↔Python 在 compose 内网互通，互调带 **服务间令牌**（`X-Internal-Token`，环境变量注入，非用户 JWT）。Python 不解析用户 JWT，只接收 Java 已鉴权后下传的 `userContext`。

### 2.1 A. Java→Python：发起/推进编排（SSE 流式）

`POST {orchestrator}/orchestrate/stream` —— `Accept: text/event-stream`

> **★★【wire 名锁定说明 · 2026-06-20 阶段B校准 · P0 红线，务必先读】**
> 本请求体内的 **`effectiveExpert`** 顶层对象名、以及其下的 **`effectiveExpert.expertId`** 字段名，是 **Java↔Python 跨进程 wire 契约的「线上名」（wire name），属方案乙故意保留的边界 wire 名，不是漂移、不得"修正"为 position。**
> - **来龙去脉：** N1 改名（Expert→Position，2026-06-19）只归一了**对外标识符/包名/前端字段**；wire 契约层（`OrchestrateRequest` 的 JSON）按 ADR-02「物理/边界名保 expert」**有意保留** `effectiveExpert`/`expertId` 等 wire 名。**Java 内部口径已是 position**（DTO 字段、变量、Service 口径均 position），仅在序列化为该 wire 契约时**通过 `@JsonProperty("effectiveExpert")`/`@JsonProperty("expertId")` 锚定为 wire 名**；**Python 端按 wire 名 `effectiveExpert`/`expertId` 解析**。即：Java 内部 position ↔ wire 名 expert，靠 `@JsonProperty` 在序列化边界对齐。
> - **改名 = 办事全断（N1 P0 教训）：** 若有人"顺手"把这里的 `effectiveExpert`/`expertId` 改成 position，而 Python 解析端与 `@JsonProperty` 锚定未同步，则 Java 下发的 JSON 与 Python 期望的键名不匹配 → 编排请求体反序列化字段丢失 → **整条办事链路静默断裂**（N1 已踩过同类 P0）。**任何对这两个 wire 名的改动必须 Java `@JsonProperty` + Python 解析键名同时改、并跨进程回归验证**，否则一律不动。
>
> - **判定口径：** 在 Java 代码里看到 `EffectiveExpertView`/`expertId` 等"残留 expert"时，**先确认它是不是落在这条 wire 契约的序列化边界上**——若是，则属"有意保留的 wire 名"，**不是待修漂移**。

**请求体 `OrchestrateRequest`（通用，零专家特例）：**

```json
{
  "runId": "uuid",                  // Java 生成，幂等键，= LangGraph thread_id（§6）
  "sessionId": 123,                 // Java 会话 id（回传用，Python 不写库）
  "userQuery": "我想请 6/15 的年假",
  "userContext": {                  // Java 鉴权后下传，Python 不再校验
    "userId": 1, "displayName": "演示用户",
    "roles": ["EMPLOYEE"], "locale": "zh-CN", "timezone": "Asia/Shanghai"
  },
  "crossPositionReadOnly": false,   // ★ wire 字段（@JsonProperty 锚定）：跨岗位只读标记。true=本次为跨岗位调用、仅允许只读（引用数据表即操作类的整条剔除，见岗位两级路由设计"解读A"）；Java 下发、Python 图内据此收窄工具白名单可写性
  "effectiveExpert": {              // ★ wire 名（保留 expert）：EffectiveExpertView 的传输投影（模板⊕覆盖层，已合并）。Java 内部口径 position，经 @JsonProperty("effectiveExpert") 锚定为此 wire 名
    "expertId": 1,                  // ★ wire 名（保留 expert）：Java 内部为 positionId，经 @JsonProperty("expertId") 锚定；改名致办事全断（见上方 wire 名锁定说明）
    "persona": { "name":"HR 助理小赫", "personaConfig":"你说话专业、亲和…",
                 "expertise":"…", "welcome":"…" },
    "reasoningMode": "ReAct",       // ReAct / Plan —— 选哪张图由此驱动（图内逻辑 AI 专家）
    "skills": [                     // 有效 Skill 集（命中后注入 SOP + 工具白名单）
      { "skillId":10, "code":"hr_leave", "name":"HR 年假与请假", "type":"composite",
        "sopDoc":"<注入 prompt 的 SOP 正文（私有副本优先）>",
        "orchestration": { "steps":[ /* 结构化锚点：白名单/必填/二次确认/step 上限 */ ] },
        "inputSchema": { /* JSON Schema */ },
        "toolWhitelist": [          // ★ 该 Skill 的工具白名单（= 注册给模型的 tools）
          { "toolCode":"hr_get_leave_balance", "bizName":"查询假期余额",
            "description":"何时用/副作用/是否高风险", "jsonSchema":{…}, "requiresConfirmation":false },
          { "toolCode":"hr_submit_leave_request","bizName":"提交请假工单",
            "description":"…", "jsonSchema":{…}, "requiresConfirmation":true }
        ]
      }
    ]
  },
  "conversation": {                 // 会话上下文（短期记忆，Java 从库取）
    "contextSummary": "…滚动摘要…",
    "history": [ {"role":"user","content":"…"}, {"role":"assistant","content":"…"} ],
    "ragSnippets": [ "个人空间召回片段…" ]   // 可空：Java 侧 RAG 召回后拼入（仍在 Java）
  },
  "limits": { "maxSteps": 8 }       // 引擎硬约束（配置化），Python 强制执行
}
```

> **通用性关键：** `effectiveExpert.skills[*].toolWhitelist[*]` 已是**统一抽象的 ToolSchema**（MCP/API/Mock/子 Skill 一视同仁，来源对 Python 不可见）。Python 不知道这是"请假"还是"开账号"，只看到"一组带 schema 的工具 + 一段 SOP"。换专家 = 换这段 JSON 数据，**Python 零改动**（§7）。

**响应：`text/event-stream`**，事件（Python→Java，Java 再中转/翻译给前端）：

| event | data | 说明 |
|-------|------|------|
| `run_started` | `{ "runId":"…","threadId":"…" }` | 回传 LangGraph thread_id（=runId） |
| `step` | `OrchestrationStep`（见 2.4） | ReAct/Plan 每步：THOUGHT/PLAN/TOOL_DECISION/ASK_USER/OBSERVATION/FINISH。**Java 据此累积 reasoning_trace 并转 SSE 给前端** |
| `tool_request` | `{ "callId":"…","toolCode":"…","argsJson":"…","requiresConfirmation":bool }` | 图决定调工具 → **触发 Java 工具回调**（见 §4，可走带内/带外两模式） |
| `interrupt` | `{ "type":"ASK_USER\|CONFIRM","callId":"…","summary":"…","pendingArgs":{…} }` | 图 interrupt：需要用户追问或二次确认 → Java 暂停并向前端发 `confirm_required`/追问（§5） |
| `llm_meta` | `{ "vendor":"…","model":"…","tier":"ORCHESTRATE","promptTokens":…,"completionTokens":…,"latencyMs":…,"finishReason":"…" }` | 每次 LLM 调用元数据 → Java 落 `llm_call_log`（§8.3） |
| `delta` | `{ "text":"已为您…" }` | 最终正文增量（流式文本） |
| `run_finished` | `{ "status":"completed\|failed\|interrupted","traceSummary":"…" }` | 终态；`interrupted`=等待 resume |
| `error` | `{ "code":"…","message":"…" }` | 编排失败（Java 翻译为友好提示） |

### 2.2 A. Java→Python：中断续跑（resume）

`POST {orchestrator}/orchestrate/resume` —— `Accept: text/event-stream`

```json
{
  "runId": "uuid",                  // = threadId，定位被中断的图
  "resumeFor": "CONFIRM",           // CONFIRM / ASK_USER（对应中断类型）
  "callId": "…",                    // 对应 interrupt/tool_request 的 callId
  "payload": {                      // 续跑输入（通用）
    "approved": true,               // 二次确认结果（CONFIRM 时）
    "userAnswer": "起止 6/15-6/16"  // 追问回答（ASK_USER 时）
  }
}
```

- 复用 LangGraph `Command(resume=…)` + checkpointer，从断点继续（§5/§6）。响应同 2.1 的 SSE 事件流。
- **幂等：** 同 `runId`+`callId` 重复 resume 由 Python 按 checkpoint 状态去重（防前端重复点确认）。

### 2.3 B. Python→Java：工具执行回调（核心，工具执行权威在 Java）

`POST {java}/api/internal/tool/execute` —— Header `X-Internal-Token: <服务令牌>`

```json
// 请求 ToolExecuteRequest（Python → Java）
{
  "runId": "uuid", "sessionId": 123, "userId": 1,
  "callId": "tc-001",
  "toolCode": "hr_submit_leave_request",   // = ToolSchema.name（技术 code）
  "argsJson": "{\"type\":\"annual\",\"startDate\":\"2026-06-15\",...}",
  "confirmed": true                        // 二次确认类：true 才允许真正执行
}
```

```json
// 响应 ToolExecuteResponse（Java → Python），= ToolResult 的传输投影
{
  "callId": "tc-001", "success": true,
  "data": { "ticketId":"LV-20260610-0007","approver":"…","status":"submitted","eta":"…" },
  "errorCode": null, "errorMessage": null, "latencyMs": 200,
  "bizName": "提交请假工单"                 // 供 Python 生成 observation/trace 用业务名
}
```

- Java 收到后：**白名单校验**（toolCode 必须在本 run 的有效 Skill 白名单内，二次防越权）→ `ToolRegistry.executorFor(toolCode)` → `ToolExecutor.execute(...)`（MCP/API/Mock 真正执行）→ 记 `tool_call_log` → 返回 observation。
- Python 拿到 observation 回灌 StateGraph（作为 `role=tool` 消息）继续推理。
- **失败态**：`success=false` + 结构化 `errorCode`，Python 回灌让模型翻译为用户可懂中文（PRD §3.10 失败链路），正文不暴露错误码。

> **两种工具回调实现模式（§4 详述，二选一，建议先用 M1）：**
> - **M1 带内同步回调（推荐首版）：** Python 在 `tool_request` 时**同步**调 `/api/internal/tool/execute`，拿到 observation 再继续图，无需挂起整条 run。简单、时序清晰。
> - **M2 带外中断-续跑：** Python 把 tool_request 作为 interrupt 抛回 Java（同 §5 机制），Java 执行后用 `resume` 把 observation 送回。适合与二次确认统一为同一中断模型，但多一跳。**二次确认必走 M2**（因需人参与）；普通工具默认 M1。

### 2.4 步骤事件结构 `OrchestrationStep`（前端折叠展示契约，与现有对齐）

**与 `Sprint1-接口契约.md` §1.1 的 `ReActStep` / `reasoning_trace.steps` 同构**，保证前端零改动：

```json
{ "no": 2, "type": "TOOL_CALL", "toolCode": "hr_get_leave_balance",
  "bizName": "查询假期余额", "argsBrief": "{}", "status": "running|success|failed",
  "latencyMs": 120, "observationBrief": "年假 6.5 天" }
```

- `type` ∈ `THOUGHT/PLAN/TOOL_CALL/ASK_USER/CONFIRM/OBSERVATION/FINISH/ERROR`（在 Sprint1 集合上**增 `PLAN`**，供 Plan-and-Execute 展示规划步；前端按未知类型兜底渲染即可）。
- **Python 产步骤 → Java 累积 → Java 落 `message.reasoning_trace`（JSONB）→ Java 转 SSE 给前端**。前端对话页/记录页契约（`Sprint1-接口契约.md` §1、§2.2）**完全不变**。

### 2.5 对前端的契约：零变更

`POST /api/chat/stream`、`/api/chat/confirm`、`/api/chat`（非流式）、session 系列、my-experts 系列（`Sprint1-接口契约.md` 全部）**保持不变**。LangGraph 是 Java 背后的实现细节，**前端无感知**。Java 的 `ChatService` 内部把"调本地 ReActEngine"换成"调 OrchestrationProxy → Python"，SSE 事件名/结构对前端不变。

---

## 3. 关键时序

### 3.1 主链路（一句话办事，含同步工具回调 M1）

```
前端 ──POST /api/chat/stream──▶ Java ChatService
  Java: JWT 鉴权 → 定位/新建 session → ExpertRouter.effectiveView(user,expert)（合并覆盖层）
        → SkillLoader 装配工具白名单 → 取 contextSummary+history(+RAG)
  Java ──POST /orchestrate/stream(SSE)──▶ Python orchestrator
        │
        Python: 载入/新建 thread(runId) → StateGraph 推进
        ├─ event:step(THOUGHT)         ─▶ Java 累积 trace + SSE:step ─▶ 前端点亮
        ├─ event:tool_request(查余额)  ─▶ Python ──POST /api/internal/tool/execute──▶ Java
        │                                   Java: 白名单校验 → ToolExecutor 执行(MCP/API/Mock)
        │                                         → tool_call_log → 返回 observation
        │                                   Python: observation 回灌图
        ├─ event:step(OBSERVATION)     ─▶ Java SSE:step ─▶ 前端
        ├─ event:llm_meta              ─▶ Java 落 llm_call_log
        ├─ event:delta(正文)            ─▶ Java SSE:delta ─▶ 前端
        └─ event:run_finished          ─▶ Java: 落 message(content+reasoning_trace+trace_summary)
                                            更新 session(last_message_at,message_count,context_summary)
                                            SSE:done ─▶ 前端
```

### 3.2 二次确认（提交类动作，走 M2 中断续跑）

```
…StateGraph 推进到 submit 工具，orchestration.requiresConfirmation=true
Python: 图 interrupt ──event:interrupt(CONFIRM, summary, pendingArgs)──▶ Java
Java: SSE:confirm_required{ confirmToken, toolCode, summary } ─▶ 前端弹确认框
      （confirmToken 由 Java 生成，绑定 runId+callId，一次性防重放）
前端 ──POST /api/chat/confirm{ confirmToken, approved }──▶ Java
Java ──POST /orchestrate/resume{ runId, resumeFor:CONFIRM, callId, payload:{approved} }──▶ Python
      approved=true: Python 续跑 → event:tool_request(submit)
                     → Java /api/internal/tool/execute(confirmed=true) 真正提交 → observation 回灌
      approved=false: Python 续跑，回灌"用户取消"，模型据 SOP 调整
…续跑 SSE 事件流同 3.1，直至 run_finished
```

> **续确认两条不变量：** ① 工具的**真正执行只在用户确认后、且只在 Java 侧发生**（Python 无副作用执行权）；② `confirmToken`/`callId` 一次性防重放（Java 生成 token，Python 按 checkpoint 去重）。

---

## 4. 工具回调机制（集成对齐点，与 AI 专家对齐）

| 项 | 约定 |
|----|------|
| **执行权威** | **Java 唯一**。Python 只产出 `ToolCall` 决策（toolCode + argsJson），从不本地连 MCP/API。 |
| **白名单双重校验** | 注册给模型的 tools = Java 下传的 `toolWhitelist`（第一道，物理收窄）；回调执行时 Java 再校验 toolCode ∈ 本 run 白名单（第二道，防模型/篡改越权）。 |
| **普通工具（无副作用/查询类）** | **M1 同步回调**：Python `tool_request` 内同步 HTTP 调 Java 执行，拿 observation 续图。延迟低、时序简单。 |
| **二次确认类（提交/高风险）** | **M2 中断续跑**：Python interrupt → Java 经前端确认 → resume 续跑 → 再回调执行（§3.2）。`requiresConfirmation` 来自 `orchestration.steps`/`toolWhitelist`，由 **Java 下传、Python 图内强制 interrupt**（不赌模型自觉）。 |
| **observation 回灌** | Java 返回 `ToolExecuteResponse` → Python 包装为 `role=tool` 消息进 StateGraph state。 |
| **埋点** | 工具执行在 Java，`tool_call_log`（tool_type/tool_code/success/latency_ms/error_code）由 Java 记，与 Sprint1 §3.4 同口径。 |
| **Mock→真实切换** | 对 Python **完全透明**：Java 侧 `ToolExecutor` 由 Mock 换 MCP/API（Sprint1 §3.3），Python 仍只看到 ToolSchema + 回 observation。 |
| **超时/重试** | 工具调用**有外部副作用，重试由 Java 控制**（与适配层契约 §5 幂等性边界一致）；Python 不自动重试工具。Python→Java 回调本身的网络重试需带 `callId` 幂等。 |

> **对齐点（与 AI 专家）：** Python 图内 `tool_decision`/`interrupt` 节点产生 `tool_request`/`interrupt(CONFIRM)` 事件的**结构与时机**由 AI 专家定，**事件 schema（callId/toolCode/argsJson/requiresConfirmation）以本文 §2 为准**。

---

## 5. 人机协同：中断—续跑（追问 / 二次确认）

LangGraph 原生 `interrupt()` + `Command(resume=…)` + checkpointer 是中断续跑的承载机制。集成层映射：

| 协同类型 | 图内（Python，AI 专家） | 集成表达（本文） | Java 侧动作 |
|---------|----------------------|-----------------|------------|
| **向用户追问**（缺信息） | `interrupt(type=ASK_USER)` | `event:interrupt{type:ASK_USER, summary}` | Java SSE 把追问作为 `step(ASK_USER)`/正文发前端；用户答 → 下一条 `/api/chat/stream`（同 session）或 `/orchestrate/resume(ASK_USER)` |
| **二次确认**（提交/高风险） | `interrupt(type=CONFIRM)` | `event:interrupt{type:CONFIRM, callId, summary, pendingArgs}` | Java SSE `confirm_required` → 前端确认 → `/api/chat/confirm` → `/orchestrate/resume(CONFIRM)` |

- **状态保持靠 checkpointer**：中断时 StateGraph 全量状态落 checkpoint（§6），`runId=thread_id` 定位；续跑从断点恢复，无需 Java 重传上下文。
- **追问的两种续法（实现选择）：** ① **轻量**——把追问当作普通对话轮：用户回答经 `/api/chat/stream`（带原 sessionId）重新发起一次推进，Python 用同 thread 续上下文；② **严格**——`/orchestrate/resume(ASK_USER)` 精确回断点。**首版建议 ①**（与现有多轮对话契约一致，少一条接口）；二次确认因需精确恢复待执行 toolCall，**必走 resume（②）**。

---

## 6. 状态与持久化对齐

### 6.1 两套状态，职责分离，靠 runId 对齐

| 状态 | 归属 | 落点 | 说明 |
|------|------|------|------|
| **业务事实**（会话、消息、ReAct 轨迹、工具/LLM 埋点） | **Java（权威）** | PostgreSQL 业务表：`session`/`message`(`reasoning_trace`)/`tool_call_log`/`llm_call_log` | 用户可见的对话记录、报表数据源；**唯一对外真相** |
| **编排运行态**（StateGraph state、断点、待续跑输入） | **Python** | PostgreSQL **独立 schema** `langgraph` 的 checkpoint 表 | LangGraph `PostgresSaver` 官方表；**进程内运行细节，不对前端暴露** |

**对齐键：`runId` = LangGraph `thread_id`。** Java 发起编排时生成 `runId`，记入本轮 assistant `message`（建议加便利列，见 §6.3），即可双向追溯：业务消息 ↔ 编排 run。

### 6.2 复用同一 PostgreSQL 实例（官方支持）

- LangGraph 官方 `langgraph-checkpoint-postgres`（`PostgresSaver`）支持 Postgres。**复用现有 `postgres` 容器**（`数据模型设计.md` / docker-compose），**独立 schema `langgraph`**，与业务表物理隔离、逻辑同库：
  - 单库单运维栈（延续架构 §5"一库一存储"原则），不新增中间件。
  - Python 用**独立 DB 账号**（仅授权 `langgraph` schema 的 DDL/DML），**无业务表权限**——强制"Python 不写业务库"边界（§1.2）。
- checkpoint 表由 `PostgresSaver.setup()` 在 `langgraph` schema 内自建（首启迁移），**不进 Java 的 Flyway**（语言/owner 分离）。Java 的 V1/V2 Flyway 不受影响、不改已执行迁移。

### 6.3 业务库增量（走 V3，不改已执行迁移）

为把编排 run 与业务消息对齐、便于追溯，建议 `message` 增一便利列（非破坏性，`ADD COLUMN IF NOT EXISTS`）：

```sql
-- V3__langgraph_integration.sql （新增，不改 V1/V2）
ALTER TABLE message ADD COLUMN IF NOT EXISTS orchestration_run_id VARCHAR(64);  -- = LangGraph thread_id，编排追溯
CREATE INDEX IF NOT EXISTS idx_message_run ON message(orchestration_run_id) WHERE orchestration_run_id IS NOT NULL;

-- langgraph 编排服务专用 DB 账号（最小权限：仅 langgraph schema）。密码经环境变量/密钥注入，不入库不入 Git。
-- 实际授权语句由部署脚本执行（含 schema 创建 + GRANT），此处仅声明设计：
--   CREATE SCHEMA IF NOT EXISTS langgraph;
--   CREATE ROLE langgraph_app LOGIN;            -- 密码外部注入
--   GRANT ALL ON SCHEMA langgraph TO langgraph_app;
--   （不授予 public/业务表任何权限）
```

> **不新增 Java 编排状态表**：编排运行态全在 Python 的 checkpoint，Java 只记业务事实 + `orchestration_run_id` 关联键。`reasoning_trace`（V1 已有 JSONB）继续承载前端可见轨迹，**由 Java 据 Python `step` 事件累积写入**——前端契约不变。

### 6.4 一致性与失败恢复

- **正常结束**：Python `run_finished` → Java 在**同一事务**落 `message`(content+reasoning_trace+trace_summary) + 更新 `session`。业务真相以 Java 落库为准。
- **编排中途失败/超时**：Python 返回 `error`/连接断 → Java 把该 assistant message 标 `status=failed`（V2 已有列），前端友好提示；checkpoint 保留可供排查（DEMO 不做自动续跑恢复）。
- **中断态**：`run_finished(interrupted)` 时 Java 不终态落库正文，等 resume 完成再落；`confirmToken` 失效（如超时/重启）则按取消处理。

---

## 7. 通用性保证（★ 红线落地与可验收判定）

**设计保证：** Python orchestrator **只吃两类输入**——① `effectiveExpert`（专家配置数据：persona + skills.sopDoc + orchestration + toolWhitelist(ToolSchema)）；② `userQuery`/会话上下文。**代码中无任何专家名、Skill code、HR/IT 分支、流程硬编码。** 工具来源（MCP/API/Mock/子 Skill）对 Python 统一为 ToolSchema，不可区分。

**可验收判定（研发自检，与 PRD §1.2 判定一致）：**

1. **删种子可运行**：把 HR/IT 种子专家/Skill 从库删除，Java 仍能发起编排（只是无内容可办）；Python 进程/图加载**无报错**（不依赖任何具体专家）。
2. **导新行业零改码**：导入一套全新行业（如"财务专家 + 报销 Skill + 报销审批工具"）的专家/Skill/工具 schema 配置，**Python 一行不改**即可规划并推进该专家的任务。
3. **代码静态扫描**：在 `orchestrator/` 源码中 grep `HR`/`IT`/`hr_`/`it_`/`leave`/`account` 等业务词，**应只出现在测试夹具/示例数据，不出现在图与节点逻辑**。
4. **工具来源无感**：把某工具从 Mock 换为真实 MCP（Java 侧改 executor），Python 输入的 ToolSchema 与行为**不变**，编排结果一致。

> 任一条不满足即违反通用性，需重构。AI 专家的 StateGraph 节点逻辑同受此判定约束（图内不得 if 专家/Skill 名）。

---

## 8. 模型调用归属方案

### 8.1 方案（推荐）：编排内推理调用由 Python 直连客户内网模型；配置与 Java 统一管理

| 调用场景 | 归属 | 理由 |
|---------|------|------|
| **编排推理**（ReAct/Plan 的 LLM 决策，含 function-calling/tool 决策） | **Python 直连**内网模型 API | LangGraph 与 LLM 调用强耦合（节点内即调模型、流式、tool_calls 解析）；若绕回 Java 适配层会多两跳且打断图的流式与状态，得不偿失。 |
| **RAG embedding**（个人空间向量化/检索） | **Java 适配层**（`embed`，适配层契约 §3.3） | embedding 与 RAG 召回在 Java（架构 §3.7），与文档解析/pgvector 同侧，无需进 Python。 |
| **其他 tier**（ROUTER/EXTRACT/JUDGE 等非编排用途） | Java 适配层 | 维持架构 §4 适配层职责；编排只用 ORCHESTRATE tier。 |

**理由总述：** Path A 选 LangGraph 正是为了用其图编排 + 原生 LLM/tool/中断能力，**编排推理放 Python 最顺**（少跳、流式直、tool_calls 不二次归一）。但**RAG 与非编排 LLM 仍归 Java 适配层**，避免把整个适配层迁到 Python。

### 8.2 配置统一管理（vendor/model/key 不双份维护）

**问题：** Java 适配层有一套 `adapter` 配置（`适配层接口契约.md` §4 YAML：vendor/model_id/endpoint/api_key_ref/参数/fallback）。Python 也要调模型，**不能各配一份导致漂移**。

**方案：单一事实源 + 启动下发。**
- **配置事实源仍在 Java 侧**（YAML/DB，FDE 在系统配置维护，符合 PRD §2 "系统级配置/内网模型 API 仅 FDE"）。
- Python orchestrator 启动时（或首次发起编排时）**从 Java 拉取编排用模型绑定**：新增内网接口 `GET /api/internal/llm-binding?tier=ORCHESTRATE`（带 `X-Internal-Token`），返回 `{ baseUrl, model, params, timeoutMs }`（**仅 endpoint/model/参数，不含密钥明文**）。
- **密钥不下发明文**：`api_key` 经**环境变量/密钥文件**注入 Python 容器（与 Java 同一别名引用 `SECRET_INTERNAL_LLM_KEY`，由部署/密钥管理统一注入两个容器），**不经 HTTP 传**、不入库、不入 Git、不入日志（延续适配层 §8）。
- 这样 **vendor/model/参数 改一处（Java 配置）即同时影响 Java 与 Python**；密钥由部署层统一注入两容器。换模型 = 改 Java 配置 + 重启/热加载 Python 拉取，不改 Python 代码。

### 8.3 Python 侧 LLM 调用的可观测对齐

- Python 每次 LLM 调用产出 `llm_meta` 事件（§2.1）→ Java 落 `llm_call_log`（vendor/model/tier/tokens/latency/finish_reason/success/error_code），**与适配层埋点同口径同表**（数据模型 §3.7），报表（办成率/调用量/时长）口径统一。
- fallback/熔断：首版编排只一个内网 provider，Python 侧实现**轻量重试**（仅推理调用、无副作用，与适配层 §5 幂等边界一致）；跨模型 fallback 复杂度后置（与适配层"首版单 provider"一致）。

> **数据不出域**：Python 出站只允许客户内网模型 endpoint（compose 网络策略 + endpoint 白名单），与 Java 同约束。DEMO 用 DeepSeek 验证（公有云），生产指向客户内网。

---

## 9. 部署变更（docker-compose 增编排服务，本机不裸装 Python）

### 9.1 compose 新增 `orchestrator` 服务（设计）

> 现 `backend/docker-compose.yml` 仅 `postgres` + `minio`（大模型为外部依赖不入 compose）。新增 `orchestrator`，复用同 `postgres`。Python **以镜像构建运行，本机不裸装**（Path A 约定）。

```yaml
# 增量服务（设计示意，落地由后端/部署补全 Dockerfile）
services:
  orchestrator:
    build: ./orchestrator            # Python 项目目录（FastAPI + LangGraph）；多阶段构建，本机不裸装 Python
    image: aiassistant-orchestrator:dev
    container_name: aiassistant-orchestrator
    depends_on:
      postgres:
        condition: service_healthy
    environment:
      # —— 编排状态库（独立 schema + 独立账号，最小权限）——
      LG_DB_URL: postgresql://langgraph_app:${LANGGRAPH_DB_PASSWORD}@postgres:5432/ai_assistant
      LG_DB_SCHEMA: langgraph
      # —— 与 Java 互信的服务令牌（非用户 JWT）——
      INTERNAL_TOKEN: ${INTERNAL_TOKEN}
      JAVA_BASE_URL: http://backend:8080        # 工具回调 / 配置拉取目标（backend 服务名）
      # —— 内网模型密钥（别名一致，部署层注入，不入库/Git/日志）——
      SECRET_INTERNAL_LLM_KEY: ${SECRET_INTERNAL_LLM_KEY}
    ports:
      - "8088:8088"                  # 仅供 Java 内网调用；不对前端暴露（可只 expose 不 ports）
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8088/healthz"]
      interval: 10s
      timeout: 5s
      retries: 5
```

**配套：**
- `backend` 服务（架构 §6 已规划，当前 compose 尚未含）需与 `orchestrator` 同 compose 网络互通；Java 配置 `orchestrator.base_url=http://orchestrator:8088`。
- **网络**：`orchestrator` 仅 `backend` 可达（建议 `expose` 而非 `ports`，或内网 only）；前端**不**直连。出站仅允许内网模型 endpoint（数据不出域）。
- **依赖顺序**：`postgres` healthy → `orchestrator` 启动 → `PostgresSaver.setup()` 自建 checkpoint 表（首启）。
- **密钥/服务令牌**：`INTERNAL_TOKEN`、`SECRET_INTERNAL_LLM_KEY`、`LANGGRAPH_DB_PASSWORD` 经环境变量/密钥文件注入，**不入 compose 明文、不入 Git**（`.env` 进 `.gitignore`）。

### 9.2 编排服务目录（新增，Python 仅在容器内）

```
orchestrator/                 # 新增 Python 项目（仅容器内运行，本机不裸装）
  Dockerfile                  # 多阶段：装 langgraph/langgraph-checkpoint-postgres/fastapi/uvicorn
  pyproject.toml / requirements.txt
  app/
    main.py                   # FastAPI：/orchestrate/stream、/orchestrate/resume、/healthz
    graph/                    # ★ StateGraph（AI 专家主笔）：节点/边/SOP 约束/工具绑定/中断
    integration/              # 集成层（架构师边界）：Java 工具回调客户端、配置拉取、SSE 编解码、埋点事件
    checkpoint.py             # PostgresSaver 装配（langgraph schema）
```

> Python 依赖（langgraph 等）属"项目内正常依赖"，经 Docker 镜像引入，符合技术栈约定；本机不裸装 Python（Path A 已获用户同意的容器化例外）。

---

## 10. 返回 PM 摘要 / 待澄清

### 10.1 关键接口清单（速查）

| 方向 | 接口 | 用途 |
|------|------|------|
| Java→Py | `POST /orchestrate/stream` (SSE) | 发起编排，流式回 step/tool_request/interrupt/llm_meta/delta |
| Java→Py | `POST /orchestrate/resume` (SSE) | 中断续跑（CONFIRM/ASK_USER） |
| Py→Java | `POST /api/internal/tool/execute` | **工具执行回调**（Java 真正执行 MCP/API/Mock，回 observation） |
| Py→Java | `GET /api/internal/llm-binding?tier=ORCHESTRATE` | 拉取编排用模型绑定（不含密钥明文） |
| 前端→Java | `/api/chat/stream`、`/api/chat/confirm` 等 | **不变**（LangGraph 对前端透明） |

### 10.2 待澄清项

- **客户内网模型 function-calling 支持（C2）**：不支持则 tool 决策退化为 prompt 模拟，归一逻辑在 Python 图内（AI 专家），不影响本集成契约。**非阻塞**。
- **追问续跑模式**（§5：轻量"当作新一轮" vs 严格 resume）：建议首版轻量、二次确认走 resume；最终由 AI 专家图内实现确定。**非阻塞**。
- **M1/M2 工具回调默认模式**：建议普通工具 M1、确认类 M2；与 AI 专家在图实现时最终对齐。**非阻塞**。

其余无阻塞项。
</content>
</invoke>
