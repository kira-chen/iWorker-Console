# PRD-03 个人空间接口契约（本轮交付）

> **📌 校准标注（2026-07-17）**：/api/personal-space/** 个人空间模块后端不在本仓（主版本运行时剥离），本文所列端点在本仓均无实现，契约由客户端运行时侧承载。详见《设计文档校准审计-20260717.md》。

- **文档状态：** 待评审（架构师产出）
- **作者：** 架构师
- **日期：** 2026-06-11
- **依据：** `docs/prd/PRD-03-个人空间-RAG就绪增订.md` + `docs/prd/PRD-03-个人空间.md` + `docs/architecture/PRD03-个人空间-RAG架构设计.md`
- **通用约定：**
  - 所有接口前缀 `/api/personal-space`（内部 RAG 接口除外，见 §10）。
  - 出参一律 `ResultVO<T>`：`{ "code": 0, "message": "success", "data": {...} }`，`code=0` 成功。
  - 鉴权：均需登录态；`user_id` **一律从登录会话取**（`SecurityUtils.currentPrincipal`），**前端不可传**、不可指定他人。
  - 错误：业务错误抛 `BusinessException(ResultCode, msg)`，由 `GlobalExceptionHandler` 归一为 `ResultVO.fail`。
  - 分页：`page`(从1起)/`size`，返回 `PageVO<T>{ total, page, size, list }`。
  - RESTful：资源名 `docs` / `chunks`。

### 0.1 枚举取值集合（固定口径，前端按此映射，禁臆造）

为避免前端枚举映射出错，本契约**显式列举**每个枚举的固定取值集合，并统一大小写口径：

| 枚举 | 字段 | 固定取值集合 | 大小写口径 | 出现位置 |
|------|------|-------------|-----------|---------|
| 来源 | `source` | `UPLOAD` / `CHAT_GENERATED` | **全大写** | 列表/详情出参 |
| 解析状态 | `parseStatus` | `pending` / `parsing` / `parsed` / `failed` | **全小写** | 上传结果/列表/详情/状态查询出参 |
| 列表筛选 | `status`（入参） | `all` / `pending` / `parsing` / `parsed` / `failed` | **全小写**（`all` 为筛选用伪值，不入库） | 列表入参 §2 |

> 口径说明：`parseStatus` 维持**小写**（与 DB `parse_status` 文本值一致）；`source` 维持**大写**（语义为常量来源类型）。两套各自取值已在上表固定，前端**不得**对二者做统一大小写转换。终态 = `parsed` / `failed`；非终态 = `pending` / `parsing`（轮询依据见 §0.2、§1.1）。

### 0.2 写接口错误处理约定（与 admin 契约 §0.3.x 对齐）

- **写接口**（上传 §1 / 删除 §5 / 重试 §6 / 后置转存 §8）一律走 **`skipGlobalError`**：前端 API 层**绕过全局错误 toast**，以 `ApiError`（携带 `code` / `message` / `data`）自行处理，便于做**逐条 / 字段级精细提示**（如 1104 容量不足单独提示、批量逐文件失败逐条回显）。此口径与 `docs/api/Sprint2-FDA配置接口契约.md` §0.3.1 的「前端 API 层绕过全局 toast、自行处理」完全对齐。
- **读接口**（列表 §2 / 详情 §3 / 切片 §4 / 容量 §7 / 状态查询 §1.1）走默认全局错误处理即可（前端可按需也加 `skipGlobalError`，非强制）。
- **字段级 / 逐条定位**：写接口业务校验错（400 / 1xxx）`data` 可携带定位信息——单文件逐文件结果见 `DocUploadResultVO`（§1）；其余写接口如需字段定位，沿用 admin §0.3.1 的 `data.field` 形态。

---

## 1. 上传文档（multipart，逐文件请求）—— F1

`POST /api/personal-space/docs`  `Content-Type: multipart/form-data`

> **【v1.1 改】上传语义为「一次一个文件」**：一个 HTTP 请求只承载**单个**文件。
> 这样才能支撑 PRD §1.6 的「单文件进度条 / 取消单个 / 单条重试」——每个文件一条请求，前端可独立追踪进度（XHR `onprogress`）、独立 `AbortController` 取消、独立重试。
> **前端职责：** 选中多文件后，前端做**并发控制**（逐文件并发上传）+ **前端预校验**（单次最多选 10 个、累计 ≤2GB、单文件 ≤50MB、白名单），不通过的文件不发请求、直接前端提示。其中「单次最多选 10 个」是**前端批量 UI 约束**（PRD §1.5 单次批量数量上限），后端**不强制**账户文档总数。
> **后端兜底校验（仍必须做，前端校验不可信）：** ① 单文件 ≤50MB（超限归一 1102）；② 用户总容量（已用 + 本文件）≤2GB（**账户上限以容量为准**，超限 1104）；③ 格式白名单（1101）；④ 空文件（1105）；⑤ 存储不可用（1106）。任一不过 → 拒绝该文件并返回对应错误码。**注：不做"账户文档总数 ≤10"的后端兜底**——账户上限只由总容量 2GB（1104）管控。

| 入参 | 位置 | 类型 | 必填 | 说明 |
|------|------|------|:---:|------|
| file | form | file | 是 | **单个**文件（pdf/doc/docx/txt/md/markdown） |

- 服务端校验：扩展名+MIME 双白名单、单文件≤50MB、空文件拒绝、容量兜底（已用+本文件≤2GB，**账户上限以此为准**）。**不做账户文档总数 ≤10 的兜底**（10 为前端单次批量选择 UI 约束）。
- 校验通过：`StorageService.put` → 落 `personal_doc(source=UPLOAD, parse_status=pending, user_id=登录态)` → 触发异步流水线。
- **错误处理：** 走 `skipGlobalError`（§0.2），前端以 `ApiError` 自行做逐条提示。

**出参 `ResultVO<DocUploadResultVO>`（单文件结果）：**
```json
{ "code":0, "message":"success", "data":
  { "docId":101, "name":"年度报告.pdf", "success":true, "parseStatus":"pending", "error":null }
}
```
失败时（如格式不支持）以 `ResultVO.fail` 返回，前端按 `code`+`message` 逐条提示：
```json
{ "code":1101, "message":"暂不支持该格式，目前支持 PDF / Word / txt / Markdown", "data":
  { "docId":null, "name":"x.exe", "success":false, "parseStatus":null, "error":"暂不支持该格式，目前支持 PDF / Word / txt / Markdown" }
}
```

> `DocUploadResultVO` 字段：`docId`(Long,可空) / `name`(String) / `success`(boolean) / `parseStatus`(枚举见 §0.1，成功恒 `pending`) / `error`(String,可空)。
> **注：** 原「一个请求传 `files[]` 批量、返回 `List<DocUploadResultVO>`」的写法已**废弃**，改为本节逐文件单结果。

**错误码（business code，走 skipGlobalError 由前端逐条处理）：**
| code | 含义 |
|------|------|
| 1000 | 通用业务失败 |
| 1101 | 格式不支持（非白名单） |
| 1102 | 单文件超 50MB |
| 1103 | 单次选择文件数超过 10（前端批量提示，后端不强制账户总数；账户上限以容量 2GB / 1104 为准） |
| 1104 | 个人空间容量不足（已用+本文件超 2GB，**账户上限**） |
| 1105 | 空文件 |
| 1106 | 存储服务暂不可用（MinIO 不可用，PRD §1.7） |

---

## 1.1 批量状态刷新（轮询，P0）—— F2 异步状态

`GET /api/personal-space/docs/status?ids=101,102,103`

> **【v1.1 新增 · P0】** 上传后文档处于**非终态**（`pending`/`parsing`），需异步流水线推进到终态（`parsed`/`failed`）。本接口为**轻量批量状态查询**，供前端对非终态文档**轮询**，避免重拉整页列表（列表项重、且会打乱滚动/选中态）。

| 入参 | 位置 | 类型 | 必填 | 说明 |
|------|------|------|:---:|------|
| ids | query | string | 是 | 逗号分隔的 docId 列表（仅本人文档，越权 id 静默忽略不返回） |

- 强制 `user_id=登录态 AND deleted=false` 过滤；非本人 / 已删 / 不存在的 id **不返回**（不报错，不泄露存在性）。
- 单次 `ids` 数量建议 ≤50（与单页 10 个文件量级匹配）。
- 读接口，走默认错误处理即可。

**出参 `ResultVO<List<DocStatusVO>>`：**
```json
{ "code":0, "message":"success", "data":[
  { "docId":101, "parseStatus":"parsed",  "chunkCount":34, "errorReason":null },
  { "docId":102, "parseStatus":"parsing", "chunkCount":0,  "errorReason":null },
  { "docId":103, "parseStatus":"failed",  "chunkCount":0,  "errorReason":"该 PDF 为扫描图片，暂不支持识别" }
]}
```

> `DocStatusVO` 字段：`docId`(Long) / `parseStatus`(枚举见 §0.1) / `chunkCount`(int) / `errorReason`(String,可空)。

**前端轮询约定（契约明确，便于前后端对齐）：**
- 上传成功 / 进入列表后，前端对**非终态**（`pending`/`parsing`）文档，按**固定间隔 2~3s** 轮询本接口，直至该文档进入**终态**（`parsed` / `failed`）后停止轮询该 id。
- **不强制重拉整页列表**：轮询只更新对应行的 `parseStatus` / `chunkCount` / `errorReason`。
- 一页内全部文档均为终态 → 停止轮询。页面切换 / 组件卸载 → 清除轮询定时器。
- 轮询入参 `ids` 仅包含当前页**非终态**文档，已终态的不再带入，降低无效查询。

---

## 2. 文档列表（搜索 / 状态筛选 / 分页）—— F3

`GET /api/personal-space/docs`

| 入参 | 类型 | 必填 | 默认 | 说明 |
|------|------|:---:|------|------|
| keyword | string | 否 | — | 按文件名模糊（仅本人） |
| status | enum | 否 | all | all / pending / parsing / parsed / failed |
| page | int | 否 | 1 | |
| size | int | 否 | 20 | |

- 强制 `user_id=登录态 AND deleted=false`，默认按 `created_at` 倒序。

**出参 `ResultVO<PageVO<DocListItemVO>>`：**
```json
{ "code":0,"message":"success","data":{
  "total":12,"page":1,"size":20,"list":[
    { "docId":101,"name":"年度报告.pdf","mimeType":"application/pdf","size":1048576,
      "source":"UPLOAD","parseStatus":"parsed","chunkCount":34,
      "errorReason":null,"createdAt":"2026-06-11T10:20:00+08:00" }
  ]}}
```

---

## 3. 文档详情 —— F3

`GET /api/personal-space/docs/{docId}`

- 校验 doc 归属登录用户（否则 403）。

**出参 `ResultVO<DocDetailVO>`：**
```json
{ "code":0,"message":"success","data":{
  "docId":101,"name":"年度报告.pdf","mimeType":"application/pdf","size":1048576,
  "source":"UPLOAD","parseStatus":"parsed","chunkCount":34,"errorReason":null,
  "createdAt":"2026-06-11T10:20:00+08:00","parsedAt":"2026-06-11T10:20:08+08:00" }}
```
| code | 含义 |
|------|------|
| 404 | 文档不存在 |
| 403 | 无权访问该文档（非本人） |

---

## 4. 切片列表（分页 / 懒加载）—— F2 §2.6

`GET /api/personal-space/docs/{docId}/chunks`

| 入参 | 类型 | 必填 | 默认 | 说明 |
|------|------|:---:|------|------|
| page | int | 否 | 1 | |
| size | int | 否 | 30 | 懒加载分页 |

- 校验归属；仅返回 `deleted=false` 切片，按 `chunk_index` 升序。

**出参 `ResultVO<PageVO<ChunkItemVO>>`：**
```json
{ "code":0,"message":"success","data":{
  "total":34,"page":1,"size":30,"list":[
    { "chunkIndex":0,"content":"……切片文本……","metadata":{"page":1,"title":"第一章"} }
  ]}}
```

> **【v1.1 改 · 取值路径统一】** 原 `page` 在切片外层、`title` 在 `metadata` 内，前端取值路径不一致。现**统一**：`page` 与 `title` 一律放 **`metadata`** 内（`metadata.page` / `metadata.title`），切片外层只保留 `chunkIndex` / `content`。契约固定层级如下：
> - `ChunkItemVO` 字段：`chunkIndex`(int) / `content`(String) / `metadata`(object)。
> - `metadata` 固定子键：`page`(int,可空，无页码概念的格式如 txt/md 为 null) / `title`(String,可空) / 其余可扩展子键由流水线写入。
> - 前端一律从 `metadata.page` / `metadata.title` 取值，**不再读外层 `page`**。
> - 注：DB 侧 `doc_chunk` 虽保留独立 `page` 列（便于检索/展示，见架构 §3.1），但**对前端的接口出参统一收敛到 `metadata.page`**，由后端组装 VO 时归位，前端无需感知 DB 列结构。

- 文档仍在解析（parsing）→ `data.list` 为空 + 前端展示"正在解析"。就绪但 0 切片（异常）→ 空列表，前端提示重试。

---

## 5. 删除文档（二次确认 / 逻辑删 + 切片失效）—— F3 §3.3

`DELETE /api/personal-space/docs/{docId}`

- 前端负责二次确认弹窗（PRD §3.3 文案）；后端执行：`personal_doc.deleted=true` + `doc_chunk.deleted=true`（级联失效，不再参与检索）+ 异步清理 MinIO 原文件（失败不阻断）。
- 防重复提交：已删返回幂等成功。
- **错误处理：** 走 `skipGlobalError`（§0.2），前端以 `ApiError` 自行处理（便于多选删除时逐条提示成功/失败）。

**出参 `ResultVO<Void>`**：`{ "code":0,"message":"success","data":null }`
| code | 含义 |
|------|------|
| 404 | 文档不存在 |
| 403 | 非本人 |

---

## 6. 重试解析 —— F2 §2.5

`POST /api/personal-space/docs/{docId}/reparse`

- 文件已在存储（不重传）。后端：清旧切片 → 重置 `parse_status=pending, error_reason=null` → 触发流水线（不产生重复切片，架构 §5.4）。
- 仅 `failed`（或 `parsed` 允许重切）状态可重试；`parsing` 中拒绝（避免并发重跑）。
- **错误处理：** 走 `skipGlobalError`（§0.2），前端以 `ApiError` 自行处理（单条重试就地回显结果）。

**出参 `ResultVO<Void>`**
| code | 含义 |
|------|------|
| 404 | 文档不存在 |
| 403 | 非本人 |
| 1107 | 文档正在解析中，无法重试 |

---

## 7. 容量 —— F3 §3.5

`GET /api/personal-space/capacity`

**出参 `ResultVO<CapacityVO>`：**
```json
{ "code":0,"message":"success","data":{
  "usedBytes":536870912,"totalBytes":2147483648,"percent":25.0 }}
```
- `usedBytes` = 登录用户全部 `deleted=false` 文档 `size` 之和（上传+转存均计，PRD §3.5）。

---

## 8. （后置占位）对话生成物转存 —— F5

`POST /api/personal-space/docs/transfer`  **【本轮后置占位，不实现】**

- 入参（占位）：`{ messageAttachmentRef, name? }`，`user_id`/`source=CHAT_GENERATED` 系统填。
- 行为（占位）：MinIO 留独立副本 → 落 `personal_doc(source=CHAT_GENERATED, parse_status=pending)` → 走同一流水线（架构 §5 已预留）。
- 本轮不开放，待对话页生成物卡片侧改动稳定后实现（PRD 增订 §3.2 F5 后置）。

---

## 9. （可选 P2）下载原文件 —— Q4

`GET /api/personal-space/docs/{docId}/download`  **【P2，本轮不实现，详情抽屉预留入口】**

---

## 10. （内部）RAG 检索接口 —— F4

> 供对话链路内部调用，**不对前端直接暴露 HTTP**。本轮以**模块内 Service 接口**形态被 `ChatStreamService` 经 `PersonalRagFacade` 调用（架构 §7）。契约形状固定（PRD §4.5 保留契约），便于将来按需转 REST。

**方法签名（Service 形态）：**
```java
// PersonalRagService
List<RagChunkVO> search(RagSearchRequest req);

// RagSearchRequest
record RagSearchRequest(String query, Long userId, Integer topK) {}
// userId 强制 = 当前登录态（由 Facade 注入，调用方不可伪造）；topK 默认 5
```

**入参契约（PRD §4.5）：**
| 字段 | 类型 | 必填 | 说明 |
|------|------|:---:|------|
| query | string | 是 | 检索词/用户问题；空则不检索返回空 |
| userId | long | 是（系统填） | **强制 = 当前登录用户**，硬隔离依据 |
| topK | int | 否 | 默认 5 |

**出参 `List<RagChunkVO>`：**
```json
[ { "docId":101, "chunkIndex":5, "content":"……", "score":0.83, "sourceName":"年度报告.pdf" } ]
```

**检索行为（硬隔离 + 非侵入，PRD §4.6/§4.7/§3.3）：**
- SQL 强制：`pd.user_id=:userId AND pd.deleted=false AND pd.parse_status='parsed' AND dc.deleted=false AND dc.embedding IS NOT NULL`，`ORDER BY dc.embedding <=> :queryVec LIMIT :topK`。
- 无就绪文档 / 0 命中 → 返回空 `[]`，不报错。
- 检索/向量化异常或超时 → 由 `PersonalRagFacade` 静默吞掉返回 `[]`，对话照常（绝不抛到对话主链路）。
- `query` 空白 → 不检索，返回 `[]`。
- 召回范围严格限本人就绪切片，切换专家不改变范围（PRD §6）。

> 对话注入：`PersonalRagFacade.snippetsForChat(userId, query)` 包裹本接口 + 系统级开关 `personalspace.rag.enabled` + 短超时 → 把 `content` 整形为 snippet 字符串列表，填入 `OrchestrateRequest.Conversation.ragSnippets`（snippet 拼接格式由 AI 专家定）。

---

## 11. 错误码汇总

| code | 含义 | 适用接口 |
|------|------|---------|
| 0 | 成功 | 全部 |
| 400 | 参数错误 | 全部 |
| 401 | 未登录/失效 | 全部 |
| 403 | 无权访问（非本人资源） | 详情/切片/删除/重试 |
| 404 | 资源不存在 | 详情/切片/删除/重试 |
| 1000 | 通用业务失败 | 全部 |
| 1101 | 格式不支持 | 上传 |
| 1102 | 单文件超限(50MB) | 上传 |
| 1103 | 单次选择文件数超过 10（前端批量提示，后端不强制账户总数；账户上限以 1104 容量为准） | 上传（前端） |
| 1104 | 容量不足（已用+本文件超 2GB，**账户上限**） | 上传/转存 |
| 1105 | 空文件 | 上传 |
| 1106 | 存储服务暂不可用 | 上传/转存 |
| 1107 | 文档解析中无法重试 | 重试解析 |

> 1xxx 业务码沿用 `ResultCode.BUSINESS_ERROR(1000)` 体系，个人空间细分码以 `ResultVO.fail(code, msg)` 显式返回（无需改 ResultCode 枚举即可用，亦可后续在枚举登记）。
> **写接口错误处理：** 上传/删除/重试/转存等写接口一律走 `skipGlobalError`，前端以 `ApiError` 自行做逐条/字段级精细提示（口径见 §0.2，与 admin 契约 §0.3.1 对齐）。
> **multipart 超限：** 当上传文件超过 Spring `spring.servlet.multipart.max-file-size` 时，框架抛 `MaxUploadSizeExceededException`，由 `GlobalExceptionHandler` 归一为 **1102**（单文件超限），前端按 1102 提示（实现见架构设计 §4.4）。

---

*（PRD-03 个人空间接口契约 完。架构设计见 docs/architecture/PRD03-个人空间-RAG架构设计.md。）*
