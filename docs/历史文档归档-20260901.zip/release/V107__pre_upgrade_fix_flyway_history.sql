-- =====================================================================
-- V107 升级前置修复脚本 —— 对齐 flyway_schema_history 编号错位
--
-- 【何时执行】把管理后台后端升级到 schema V107 之前，对**现网库**执行一次。
--             必须在应用启动之前跑完 —— 不跑则应用 Flyway 校验失败、直接起不来。
-- 【执行对象】现网 PostgreSQL 的 ai_assistant 库（生产库、官网库都要跑，两者同病）。
-- 【幂等性】  是。WHERE 精确匹配 version+script，跑过第二遍匹配不到、影响 0 行。
-- 【风险】    只改 flyway_schema_history 这一张记账表，不动任何业务数据、不动任何 schema。
--
-- 【为什么需要】
--   现网历史与发布仓的迁移脚本编号存在整体错位一位：
--
--     版本号   现网已执行                                发布仓当前脚本
--     ------   ---------------------------------------   ----------------------------
--     V79      V79__expert_default_avatar_backfill.sql   V79__admin_session_idle.sql
--     V80      V80__admin_session_idle.sql               V80__user_feedback.sql
--     V81      V81__user_feedback.sql                    V81__domain_expert.sql
--     V84.1    V84_1__domain_expert.sql                  （无，已并入 V81）
--
--   即现网多跑过一个 expert_default_avatar_backfill，导致其后三个脚本各自占用了
--   下一个版本号。Flyway 启动校验会报 V79/V80/V81 三处 checksum mismatch
--   + V84.1 "applied migration not resolved locally"，抛 FlywayValidateException。
--
-- 【为什么可以就地改记账而不是补跑脚本】
--   三个脚本的**内容语义完全等价**，且其产物在现网库中均已存在（已实测核验）：
--     - admin_session_idle  → app_user.last_admin_active_at 列    ✓ 已存在
--     - user_feedback       → user_feedback 表                    ✓ 已存在
--     - domain_expert       → domain_expert / domain_expert_skill ✓ 已存在
--   属纯记账错位，不是 schema 缺失。补跑反而会因对象已存在而出错。
--
-- 【checksum 取值来源】
--   下方三个 checksum 是发布仓当前 V79/V80/V81 脚本的 Flyway 校验和。
--   ⚠ 若上线前这三个脚本文件再被修改过，checksum 会变，须重新取值后再执行本脚本。
--   取值方法：在一个已升到 V107 的库上执行
--     SELECT version, script, checksum FROM flyway_schema_history
--      WHERE version IN ('79','80','81') AND type='SQL';
--
-- 【实测记录】已在 prod-full-20260824（V94 起）与 guanwang-full-20260824（V99 起）
--             两份现网全量数据副本上验证：执行本脚本后 Flyway
--             "Successfully validated 107 migrations" → 迁移全部应用 → 后端正常启动。
--             详见 docs/release/V107升级方案.md 与 docs/update/2026-08-24.md
-- =====================================================================

BEGIN;

-- (1) 现网独有的 avatar 回填行：让出 V79 号，并标记为 DELETE 使 Flyway 忽略它。
--     不物理删除——保留行以便追溯「这个库确实跑过这段回填」。
--     降级到 78.9 是为了避开 V79 号（同号会与下一步写入的行冲突）。
UPDATE flyway_schema_history
   SET version = '78.9',
       type    = 'DELETE'
 WHERE version = '79'
   AND script  = 'V79__expert_default_avatar_backfill.sql';

-- (2) admin_session_idle：现网记在 V80 → 归位到发布仓的 V79
UPDATE flyway_schema_history
   SET version  = '79',
       script   = 'V79__admin_session_idle.sql',
       checksum = -2136423721
 WHERE version  = '80'
   AND script   = 'V80__admin_session_idle.sql';

-- (3) user_feedback：现网记在 V81 → 归位到发布仓的 V80
UPDATE flyway_schema_history
   SET version  = '80',
       script   = 'V80__user_feedback.sql',
       checksum = -1668775426
 WHERE version  = '81'
   AND script   = 'V81__user_feedback.sql';

-- (4) domain_expert：现网记在 V84.1 → 归位到发布仓的 V81
UPDATE flyway_schema_history
   SET version  = '81',
       script   = 'V81__domain_expert.sql',
       checksum = -298488849
 WHERE version  = '84.1'
   AND script   = 'V84_1__domain_expert.sql';

-- 核验：期望恰好返回下面 4 行，缺任何一行都不要提交，回滚后排查。
--   78.9 | V79__expert_default_avatar_backfill.sql | DELETE
--   79   | V79__admin_session_idle.sql             | SQL
--   80   | V80__user_feedback.sql                  | SQL
--   81   | V81__domain_expert.sql                  | SQL
SELECT version, script, type
  FROM flyway_schema_history
 WHERE version IN ('78.9', '79', '80', '81')
 ORDER BY version;

-- 核验：期望 0 行（V84.1 应已归位，不再残留）。
SELECT count(*) AS should_be_zero
  FROM flyway_schema_history
 WHERE version = '84.1';

COMMIT;
