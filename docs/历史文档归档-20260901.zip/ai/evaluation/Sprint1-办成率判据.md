# Sprint 1 —— 「办成率」evaluation 判据

- **阶段：** Sprint 1「设计」工序
- **作者：** 大模型专家（AI Expert）
- **用途：** 给测试工程师/AI 专家一套**简单可执行**的判据，判定两个 SOP 是否"按关键步骤走到、是否正确追问、是否正确二次确认、是否正确汇报、失败是否诚实兜底"。
- **上游：** `docs/ai/model-strategy/ReAct-Plan工程化方案.md` §8、PRD §5.1、两个 SOP 文档、`Sprint1-SOP工具定义-Mock.md`。
- **引擎更新（2026-06-10）：** 核心编排已由"Java 内 ReAct 循环"改为 **LangGraph StateGraph**（Path A，见 `docs/ai/model-strategy/LangGraph-StateGraph设计.md`）。**本判据全部维度/case/门槛不变**——判据只依赖 `ReActTrace`（工具调用序列、ask_user 步、确认参数）与最终回复，与引擎实现解耦。下方仅补充"在 LangGraph 下数据从哪来"的对齐（§7），原 §1–§6 照旧执行。

> **本 Sprint 的「办成率」=** 一条 test case 的全部"关键判据"通过则记 1（办成），任一关键判据失败记 0。**办成率 = 办成 case 数 / 总 case 数。** 判据以**可程序化规则**为主（对 `ReActTrace` + 工具调用记录 + 最终回复做断言），开放式话术用少量 LLM-as-judge 兜底。

---

## 1. 判据维度（每条 case 都按这 6 维打分）

| 维度 | 判什么 | 判法 | 数据源 |
|---|---|---|---|
| **D1 关键步骤走到** | 是否调了 SOP 要求的工具、顺序对 | 规则：trace 工具调用序列匹配黄金路径 | `ReActTrace` 工具调用记录 |
| **D2 正确追问** | 缺必填时是否追问、补齐后是否不重复问 | 规则：缺参时存在 `ask_user` 步；已给信息无重复追问 | `ReActTrace` ask_user 步 |
| **D3 正确二次确认** | 提交类动作前是否二次确认、确认的=提交的 | 规则：submit 工具调用前存在确认 `ask_user`；确认摘要参数 == 提交入参 | trace + 工具入参 |
| **D4 正确汇报** | 最终回复是否含 SOP 要求的产出字段（工单号/审批人/时长等） | 规则：正则/关键字段命中 | 最终用户可见回复 |
| **D5 失败诚实兜底** | 失败态是否翻译为中文+补救建议，不暴露错误码/函数名 | 规则（不暴露）+ LLM-judge（话术合格） | 最终回复 |
| **D6 复杂度屏蔽** | 用户可见正文不含工具名/入参/错误码 | 规则：黑名单关键字（函数名/error码）不出现在用户正文 | 最终回复 |

> **关键判据（决定办成 0/1）：** D1、D3、D4 + 对应 case 的 D2/D5。D6 为合规红线（命中即整条 case 判 0，无论其他维度）。

---

## 2. 测试集（最小可执行 case 清单）

### 2.1 HR 小赫（5 条）

| # | 输入场景 | 黄金路径（D1） | 关键判据 |
|---|---|---|---|
| H1 | "我还有几天年假？"（纯查询） | `hr_get_leave_balance` → stop | D1 只调余额工具且**不**调 submit；D4 回复含各假别余额；D6 |
| H2 | "请假流程是怎样的？"（问流程） | （可调余额或直接答）→ stop | D4 回复含流程说明（几步/谁审批）；D6；**不**误触发 submit |
| H3 | "帮我请 6/15 的年假"（信息半全，缺确认前要算天数） | 余额 → calc_days → 二次确认(ask_user) → submit | D1 顺序对；D3 确认后才 submit 且摘要==入参；D4 含工单号 LV-…；D6 |
| H4 | "帮我请假"（信息全缺） | 余额 →（追问类型/日期 ask_user）→ … | D2 缺必填先追问；补齐后 D1/D3/D4 同 H3；D2 不重复追问已给信息 |
| H5 | "请 6/15-6/30 的年假"（余额不足，触发失败态） | 余额 → calc_days → 确认 → submit(返回 INSUFFICIENT_BALANCE) | D5 翻译为中文+给可请最大天数建议；D6 不暴露 INSUFFICIENT_BALANCE/函数名 |

### 2.2 IT 小图（5 条）

| # | 输入场景 | 黄金路径（D1） | 关键判据 |
|---|---|---|---|
| T1 | "帮我开通 CRM，用途是华东区客户跟进"（信息全、账号NONE） | list_systems → check_status(NONE) → 二次确认 → submit | D1 顺序对；D3；D4 含工单号 IT-…+SLA；D6 |
| T2 | "帮我开通那个客户系统"（系统模糊） | list_systems →（澄清 ask_user 列选项）→ … | D2 列可选项让用户选；选定后 D1/D3/D4 同 T1 |
| T3 | "开通 CRM"（缺用途） | list → check(NONE) →（追问用途 ask_user）→ 确认 → submit | D2 追问用途；D3；D4 |
| T4 | "开通 CRM"（账号已 ACTIVE） | list → check(ACTIVE) → stop | D1 调 check 后**不**调 submit；D4 告知"已开通无需重复申请"；D6 |
| T5 | "开通 CRM"（触发 NEED_MANAGER_APPROVAL 失败态） | list → check(NONE) → 确认 → submit(返回 NEED_MANAGER_APPROVAL) | D5 翻译为中文+明确下一步(去找谁授权)；D6 不暴露错误码/函数名 |

> 两个 SOP 各覆盖 PRD §1.3 必满足项：多步推理（≥3 步：H3/T1）、向用户追问（H4/T2/T3）、多工具串联且后步依赖前步（H3 算天数依赖余额、T1 提交依赖 check）、二次确认（H3/T1）、失败链路（H5/T5）、复杂度屏蔽（全 case D6）。

---

## 3. 可程序化判据细则（断言写法）

```text
D1 工具序列：assert trace.toolCalls.map(name) 子序列匹配黄金路径；
            否定项：纯查询/已开通 case，assert "submit工具" NOT IN toolCalls。
D2 追问：   缺必填 case，assert ∃ step.type==ask_user 且在 submit 之前；
            多轮 case，assert 用户已给的槽位值不在后续 ask_user 文本中再次询问。
D3 二次确认：assert ∃ ask_user(确认类) 紧邻 submit 之前；
            assert 确认摘要中的 {类型/日期/天数} 或 {系统/用途} == 实际 submit 入参（引擎托管的待确认 toolCall 参数，见 ReAct 落地 §4.2）。
D4 汇报：   成功 case，assert 最终回复正则命中 工单号(LV-\d+ / IT-\d+) + 审批人 + 时长/SLA。
D5 兜底：   失败 case，assert 回复含"补救/下一步"语义（关键字或 LLM-judge）。
D6 屏蔽：   assert 用户正文 NOT contains 任一函数名(hr_*/it_*) 与 错误码(INSUFFICIENT_BALANCE/INVALID_DATE/NEED_MANAGER_APPROVAL)。
```

- **D5 话术合格**用 LLM-as-judge（裁判模型异源于被测，rubric：是否中文可懂、是否给了明确补救/下一步、是否未甩错误码），打分 ≥ 阈值算过；规则部分（不暴露错误码）仍硬断言。
- **D3 是 Sprint 1 重点**：依赖引擎托管待确认 toolCall（ReAct 落地 §4.2），保证"确认的==提交的"，避免模型二次组参漂移。

---

## 4. 通过门槛（Sprint 1 Gate 建议）

| 指标 | 门槛 |
|---|---|
| **办成率（10 条 case）** | ≥ **90%**（即 ≤1 条不达标），且 H3/H5/T1/T5 四条核心 case **必须全过** |
| D6 复杂度屏蔽 | **100%**（红线，任一 case 暴露函数名/错误码即 Gate 不过） |
| D3 二次确认正确性 | 提交类 case **100%**（不得未确认直接提交） |

- 因 LLM 输出有抖动，每条 case 建议**跑 3 次取多数**（2/3 通过算该 case 过），降低偶发误判。
- 不达标时定位：按 D1–D6 哪维失败 → 反馈到 prompt（软约束）或引擎守护（硬约束）迭代。

---

## 5. 落地分工
- **测试工程师：** 据 §2 case 表 + §3 断言写自动化用例（对 trace + 回复断言）；D5 接 LLM-judge。
- **后端：** 保证 `ReActTrace` 含工具调用序列、ask_user 步、引擎托管的待确认 toolCall 参数（供 D3 断言）。
- **AI 专家/提示词工程师：** 据失败维度迭代 prompt 与守护规则。

---

## 6. 待澄清
**无阻塞项。** case 与门槛为 DEMO 可执行口径，如 PM/产品对门槛（90%）有调整诉求可定。

---

## 7. LangGraph 引擎下的数据来源对齐（引擎从 Java ReAct 改为 StateGraph 后）

判据维度、case、门槛全部不变；仅明确各断言数据在 LangGraph 实现下从哪取（见 `docs/ai/model-strategy/LangGraph-StateGraph设计.md`）：

| 判据 | 原数据源 | LangGraph 下数据源（等价） |
|---|---|---|
| D1 工具序列 | `ReActTrace` 工具调用记录 | `state.trace` 中 `type==tool_call` 序列（节点 `act` 产出，§9）；工具执行经回调 Java，`tool_call_log` 可交叉核对 |
| D2 追问 | trace 的 ask_user 步 | `state.trace` 中 `type==ask_user`（`interrupt(ASK_MISSING)`，§4.1）；多轮承接靠 checkpoint 保留的 `messages` |
| D3 二次确认（确认的==提交的） | 引擎托管的待确认 toolCall 参数 | **`state.pending_write`**（图层托管的待确认写操作 toolCall，§4.2）；断言 `confirm` 摘要参数 == `act` 实际执行的 `pending_write.args` |
| D4 汇报 | 最终用户回复 | `state.final_answer`（`finalize` 节点，§8.3/§9） |
| D5/D6 失败兜底/复杂度屏蔽 | 最终回复 | 同 `state.final_answer`；失败码翻译发生在 `reason` 据 SOP 失败分支（§8.2），不暴露 `error.code`/函数名 |

- **§5 落地分工补充：** "后端保证 `ReActTrace`…" 现指 **LangGraph 编排服务**产出 `state.trace` 并回传 Java 落 `message.reasoning_trace`；D3 依赖 `state.pending_write` 的"图层托管"机制（替代原 Java 引擎托管），语义与断言写法不变。
- **D3 仍是 Sprint 1 重点**：LangGraph 用 `interrupt(CONFIRM_WRITE)` + `pending_write` 保证未确认不提交、确认的就是提交的，比纯靠模型二次组参更稳。
</content>
