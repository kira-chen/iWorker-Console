# LangGraph StateGraph 编排图设计（Path A：独立 Python 编排服务）

- **阶段：** Sprint 1「设计」工序（核心编排引擎重构）
- **作者：** 大模型专家（AI Expert）
- **状态：** 待 PM / 架构师 / 提示词工程师联评
- **上游：**
  - `.claude/memory/project_langgraph_orchestration.md`（Path A 拍板：独立 Python LangGraph + FastAPI 编排服务，工具回调 Java，Docker 容器化）
  - `docs/prd/PRD-00-核心概念与通用模型.md`（§1 红线：配置即数据、引擎通用、HR/IT 仅种子；§3.9 ReAct/Plan 引擎；§3.10 工具调用；§4 关系模型）
  - `docs/prd/PRD-Sprint1-核心办事与个性化.md`（§1 两个 SOP、§2.1 ReAct 展示、§2.2 多轮、§2.3 @ 切换）
  - `docs/ai/model-strategy/Sprint1-ReAct引擎落地.md`（**此前纯 Java ReAct 方案，本文取代之**：吸收其约束思想——白名单/必填/二次确认/预算/诚实兜底，改用 LangGraph StateGraph 表达）
  - `docs/ai/model-strategy/Sprint1-SOP工具定义-Mock.md`（工具 schema 与 Mock 返回）
  - `docs/ai/prompts/通用-专家系统Prompt模板.md`、`react-驱动Prompt.md`（软约束注入口径）
  - `docs/architecture/ai-adapter/适配层接口契约.md`（`LlmGateway`/tier/`llm_call_log`，由 Java 承载；本文在调用边界对齐）

> **取代关系（重要）：** 原 `Sprint1-ReAct引擎落地.md` 设计的"Java 内 ReAct 单循环"被本文**以 LangGraph StateGraph 表达的等价图**取代。**所有硬约束语义（工具白名单物理收窄、必填校验、提交类二次确认、step/token 预算、循环检测、诚实兜底）一条不丢**，只是承载体从"Java while 循环 + preCheck"变为"StateGraph 节点/条件边 + interrupt/checkpoint"。原文档的工具契约、办成率判据、Prompt 模板**继续有效、无需改写**。

> **职责边界（与架构师）：** 本文定**图内部逻辑**——State schema、节点、边、SOP 注入算法、interrupt 语义、回调发起点。架构师定**服务契约与承载**——Java↔Python 的 HTTP/SSE 协议、工具回调 endpoint、checkpoint 持久化介质、部署。两者在 §5 工具回调、§6 interrupt/checkpoint、§7 模型调用三处对齐，本文给出"图侧需要对方提供什么"。

---

## 0. 设计总纲：一张图，对任意专家/任意 SOP 通用

**红线落地（PRD-00 §1.2）：图结构里不出现任何"HR/IT/请假/开账号"。** 图只认两个抽象输入：

1. **`EffectiveExpertView`**（有效专家，已合并覆盖层）—— 由 Java 算好后随请求传入；
2. **`EffectiveSkill` 集**（每个含 `sopDoc` + `orchestration` + `toolWhitelist`）—— 同上。

> **判定标准：** 删掉所有 HR/IT 种子数据、导入一套全新行业的专家/Skill，**图与节点代码一行不改**即可办事。SOP 是"流进图的数据"，不是"画在图里的分支"。本文所有节点逻辑对 `state.skill.sopDoc` / `state.skill.toolWhitelist` 做**数据驱动**处理，绝不 `if expert=="HR"`。

**一句话定位：** 本图 = 一个**带 SOP 软约束 + 引擎硬约束（图内校验节点/条件边）+ interrupt 人机协同 + checkpoint 续跑 + 诚实兜底**的 StateGraph，默认以 **ReAct 范式**驱动（plan 节点先产计划骨架，act/observe 循环推进），可平滑升级到 plan-and-execute（§2.4）。

---

## 1. State Schema（图的唯一共享状态）

LangGraph 的 `StateGraph(State)` 以一个带 reducer 的 `TypedDict` 为中枢，每个节点读它、返回增量、由 reducer 合并。下面是**通用 State**（Python 伪代码，字段名英文）：

```python
from typing import TypedDict, Annotated, Literal, Optional
from langgraph.graph.message import add_messages   # messages 累加 reducer

class OrchestrationState(TypedDict):
    # ── 会话与消息（短期记忆，LangGraph 续跑靠 checkpoint，落库由 Java/§6）──
    messages: Annotated[list, add_messages]   # 多轮上下文：system/user/assistant/tool 消息时间线
    session_id: str
    task_id: str                              # 一次 Task（@切换/新意图 → 新 task_id，预算重算 §3）

    # ── 注入态：有效专家 + 当前命中 Skill（图不感知行业，全是数据）──
    expert: dict                              # EffectiveExpertView：persona/specialty/welcome…（已合并覆盖层）
    active_skill: Optional[dict]             # EffectiveSkill：{code, sopDoc, orchestration, inputSchema}
    tool_whitelist: list[dict]               # 当前 Skill 的工具 schema 列表（物理白名单，§5.1）
    runtime_ctx: dict                         # userId/dept/today/userMemory/ragSnippets（注入 prompt L5）

    # ── 规划与推进（"规划+推进执行"的图内表达，§2）──
    plan: Optional[list[dict]]               # 计划骨架：[{stepNo, intent, expectTool?, status}]（可空=纯ReAct）
    cursor: int                               # 当前推进到计划的第几步（plan-execute 用；纯 ReAct 可忽略）
    reasoning_mode: Literal["react","plan"]  # 来自 expert.reasoning_mode，默认 react

    # ── 工具结果回灌 ──
    pending_tool_calls: list[dict]           # 本轮模型产出的待执行 tool_calls（含 id/name/args）
    last_observations: list[dict]            # 最近一批工具 observation（含 success/error/raw）

    # ── 人机协同（interrupt 续跑载体，§4/§6）──
    interrupt_kind: Optional[Literal["ASK_MISSING","CONFIRM_WRITE"]]
    ask_payload: Optional[dict]              # 追问/确认要展示给用户的话术 + 上下文
    pending_write: Optional[dict]            # 引擎托管的"待确认写操作 toolCall"（确认的==提交的，§4.2）

    # ── 预算与守护（硬约束，§3）──
    budget: dict                              # {maxSteps, stepUsed, maxToolCalls, toolUsed, maxTokens, tokenUsed}
    loop_guard: dict                          # {lastToolSig, repeatCount} 同 tool 同参重复检测

    # ── 轨迹与产出（前端展示 + 办成率判据，§9）──
    trace: Annotated[list, add_trace]        # ReActTrace：thought/tool_call/observation/ask_user/confirm/final/error
    final_answer: Optional[str]              # 面向用户的最终汇报（纯文本）
    outcome: Optional[Literal["DONE","ASK_USER","FAILED"]]
```

**Reducer 说明：**
- `messages` 用官方 `add_messages`（按 id 去重、追加）—— 这是 function-calling 多轮的载体（assistant 的 tool_calls + role=tool 的 observation 必须在此累加）。
- `trace` 自定义 `add_trace`（纯 append），保证每步留痕不被覆盖。
- 其余标量字段节点直接返回新值覆盖。

> **为什么 State 同时含 `plan` 和纯 ReAct 字段：** 见 §2.4——同一张图既能跑 ReAct（plan 为空/弱），又能跑 plan-and-execute（plan 为强骨架），由 `reasoning_mode` 切换，无需两张图。

---

## 2. 图结构：节点、边与"规划 + 推进执行"

### 2.1 节点清单（语义，均通用、数据驱动）

| 节点 | 类型 | 职责（对任意 SOP 一致） |
|---|---|---|
| `prepare` | 入口装配 | 用 `expert`+`active_skill` 渲染 system prompt（注入 SOP 软约束 §3）、把 `tool_whitelist` 转为 LangGraph `tools[]`、初始化 `budget`/`trace`。**SOP 在此进 prompt，不进图结构。** |
| `plan` | LLM（轻） | 让模型据 SOP 产出**计划骨架**（要走哪几步、大概用哪些工具）写入 `state.plan`。ReAct 模式下可降级为"只判意图（query/submit）不展开全计划"。 |
| `route` | 条件路由 | 据 `plan`/`cursor`/`outcome`/`budget` 决定去 `reason`、`finalize` 还是兜底。"推进执行"的指针在此前移。 |
| `reason` | LLM（编排档） | 核心推理：带 `messages`+`tools[]` 调模型（function-calling）。输出二选一：`tool_calls`（行动）或纯文本（追问/汇报）。 |
| `guard` | 校验（硬约束） | 对 `reason` 产出的 `pending_tool_calls` 做**图内校验**：白名单、必填、循环检测、二次确认标记。决定放行/打回/触发 interrupt。**不赌模型自觉。** |
| `act` | 工具执行 | 对放行的 tool_calls **回调 Java**（§5）拿 observation，写 `last_observations`，把 tool 结果以 `role=tool` 回灌 `messages`。 |
| `observe` | 轻处理 | 归一 observation（成功/失败码），更新 `plan[cursor].status`、`loop_guard`、预算计数，决定回 `route` 继续还是进 `finalize`。 |
| `ask_user` | **interrupt** | 缺必填 → 抛出追问；写操作前 → 抛出二次确认。`interrupt()` 挂起图，落 checkpoint，等用户下条消息续跑（§4/§6）。 |
| `finalize` | 收尾 | 产出 `final_answer`（诚实汇报或兜底话术），置 `outcome`，结束。 |
| `fallback` | 兜底 | 预算耗尽 / 模型失败 / 连续异常 → 诚实失败话术 + trace 落库（§8）。 |

### 2.2 边（控制流）

```
START
  └─> prepare ──> plan ──> route
                            │
        ┌───────────────────┼─────────────────────────────┐
        │ (有下一步要推进)    │ (计划完成/已可汇报)            │ (预算耗尽/异常)
        ▼                    ▼                              ▼
      reason              finalize ──> END               fallback ──> END
        │
   （条件边：reason 产出什么？）
        ├─ tool_calls ─> guard
        └─ 纯文本(追问/汇报) ─> [是追问? → ask_user ；是汇报? → finalize]
                                          │ interrupt 挂起
        ┌─────────────────────────────────┘
   guard 条件边：
        ├─ 放行            ─> act ──> observe ──> route   (回环：推进下一步)
        ├─ 缺必填          ─> ask_user  (interrupt 追问)
        ├─ 高风险写(需确认) ─> ask_user  (interrupt 二次确认，托管 pending_write)
        └─ 越权/重复       ─> observe   (回灌错误 observation，让模型纠正，不调真工具)

  ask_user ⟶ (interrupt 中断) ⟶ 用户回消息 ⟶ 从 checkpoint 恢复 ⟶ route  (续跑)
```

**核心回环：`route → reason → guard → act → observe → route`** 就是 ReAct 的"推理→选工具→调用→观察→继续"循环，用 StateGraph 的**条件边 + 状态回环**表达，等价于原 Java `while` 循环但**可中断、可持久化、可观测**（这正是选 LangGraph 的收益）。

### 2.3 "规划 + 推进执行"如何用图表达

用户要求的核心是"**根据 query 规划任务执行路径并推进执行**"。在图里拆成两件事：

- **规划（plan 节点）：** 据 query + SOP 产出"要走哪几步、用哪些工具、哪里要追问/确认"的**计划骨架**写入 `state.plan`。这是"规划任务执行路径"。
- **推进执行（route↔reason↔act↔observe 回环 + cursor）：** `route` 节点每轮看"计划走到哪、上一步 observation 是什么、预算还够不够"，决定**前移 cursor 推进下一步**还是收尾。这是"推进执行"。

### 2.4 ReAct vs plan-and-execute：同图两态（何时用哪种 / 混合）

| 维度 | ReAct 态（Sprint 1 默认） | plan-and-execute 态（S2 升级，同图） |
|---|---|---|
| `plan` 强度 | 弱：`plan` 节点只判意图（如 query/submit），不预排全步骤；每步靠 `reason` 现场决策 | 强：`plan` 节点据 SOP 预排完整步骤序列写入 `state.plan` |
| 推进方式 | `route` 主要看上一步 observation 动态决定下一步（反应式） | `route` 按 `cursor` 顺序推进预排计划，偏离才 replan |
| 适用 | 步骤强依赖前一步结果、分支多（两个 SOP 都是：先查余额/状态再决定）→ **ReAct 更稳** | 步骤线性、可预排、要并行/可复用计划 → plan 更高效 |
| 切换 | `state.reasoning_mode="react"` | `state.reasoning_mode="plan"`，加一个 `replan` 节点（S2） |

> **混合策略：** `plan` 节点产**粗骨架**（plan 给方向），`reason`/`route` 回环**细推进**（ReAct 应对不确定）。Sprint 1 两个 SOP 用 **ReAct 为主、plan 仅产意图骨架**即可满足；plan-and-execute 留 `reasoning_mode` + `cursor` + 预留 `replan` 节点，S2 接入**不改图骨架、不改 State schema**（向前兼容）。

---

## 3. SOP 如何驱动 / 约束图（通用注入，软约束 + 硬约束）

**核心原则（PRD-00 §1.2、§3.3）：SOP 是输入数据，"进入一个 Skill" = 注入 SOP 到 prompt + 把 Skill 工具注册为本轮白名单。图对任意 SOP 同一套处理。**

### 3.1 软约束：SOP 注入 prompt（`prepare` 节点，提示词工程师口径）

`prepare` 节点用 `通用-专家系统Prompt模板.md` 的分层结构渲染 system prompt，**SOP 数据填进插槽**：

- `state.expert.{persona,specialty,bio}` → 模板 L1 身份人设；
- 通用行为宪法 → L2（跨专家常量，含 ReAct 行为协议 `react-驱动Prompt.md` §2）；
- `state.tool_whitelist[*].{bizName,whenToUse,sideEffect,requiresConfirmation}` → L3 工具语义；
- **`state.active_skill.sopDoc`** → L4 SOP 剧本（**这是 SOP 软约束的注入点**）；
- `state.runtime_ctx` → L5 运行时上下文（含 `today`，影响算天数）。

> 渲染逻辑对所有 Skill 相同：读 `sopDoc` 字段填 L4，不解析其行业语义。换 SOP = 换文本，节点零改动。

### 3.2 硬约束：图内校验（`guard` 节点 + 条件边，引擎权威）

把 `active_skill.orchestration` 的**结构化锚点**翻成图内可执行的硬约束（**不赌模型听话**）。`guard` 节点对每个 `pending_tool_call` 跑下表：

| 硬约束 | 数据来源（SOP/Skill 配置） | `guard` 动作 |
|---|---|---|
| **工具白名单（物理收窄）** | `active_skill.toolWhitelist` | 注册进 LangGraph `tools[]` 的**只有白名单工具**（`prepare` 阶段就物理收窄，模型根本看不到白名单外工具）。`guard` 兜底：若模型仍幻觉调了名单外工具 → 拒绝 + 回灌错误 observation。 |
| **必填参数校验** | `orchestration.step.requiredSlots` / 工具 `parameters.required` | 校验 tool args 缺必填（如 `hr_submit_leave_request` 缺 `type`/`startDate`）→ 转 `ask_user`（ASK_MISSING）。 |
| **高风险二次确认** | 工具 `requiresConfirmation=true` | **不直接执行**，把该 toolCall 连参数存入 `state.pending_write`，转 `ask_user`（CONFIRM_WRITE）。用户确认后续跑 `act` 执行**托管的原 toolCall**（保证"确认的==提交的"）。 |
| **循环检测** | 引擎内置 | 同 tool + 同参连续 ≥2 次（比对 `loop_guard.lastToolSig`）→ 打回，回灌"已调用过，请基于已有结果继续或结束"。 |
| **step/toolCall/token 预算** | `active_skill` 可覆盖默认（§3.3 表） | 每过一次 `reason`/`act` 计数；超限 → 路由到 `fallback`。 |

> **软硬分工与原 ReAct 落地一致：** prompt（软）引导模型"按 SOP 走、缺信息先问、提交前确认"；`guard` 节点（硬）物理拦截。二者口径必须一致（`通用-专家系统Prompt模板.md` §4 对照表照搬）。

### 3.3 预算默认值（沿用原方案，配置化、Skill 可覆盖）

| 预算项 | 默认 | 说明 | 配置化 |
|---|---|---|---|
| `maxSteps` | 8 | 一次 Task 内 `reason` 轮数上限（两个 SOP 黄金路径 ≤4~5） | ✅ Skill 级覆盖 |
| `maxToolCalls` | 10 | 工具调用总数上限 | ✅ |
| `maxTokens` | ~16k | 累计 input+output token（用响应 usage 累加估算） | ✅ |
| `singleStepTimeout` | 60s（编排档） | 单次模型调用超时 → 由 §7 LLM 调用层管 | ✅ |
| 循环检测阈值 | 同 tool 同参 2 次 | `loop_guard` | ✅ |

> **预算随 Task（`task_id`）走**：追问/二次确认导致的 interrupt 中断—续跑**不重置预算**（防反复触发空转烧钱）；@ 切换专家视为新 `task_id`，预算重算（§ PRD §2.3）。

---

## 4. 人机协同：LangGraph interrupt（中断—续跑）

LangGraph 用 `interrupt()` + checkpointer 表达"挂起等人、收到输入再续跑"。本图两类 interrupt，均落在 `ask_user` 节点：

### 4.1 缺必填 → 追问（ASK_MISSING）

```python
def ask_user(state):
    payload = state["ask_payload"]   # guard 填好的追问话术（业务化，来自 SOP 追问规则）
    # interrupt 抛出 → 图挂起，checkpoint 保存当前 State（messages/plan/cursor/budget…）
    user_reply = interrupt({
        "kind": "ASK_MISSING",
        "question": payload["question"],     # 如"请哪种假？起止日期？"
        "missingSlots": payload["slots"],
    })
    # ── 用户回消息后从此处恢复 ──
    return {
        "messages": [HumanMessage(user_reply)],
        "interrupt_kind": None, "ask_payload": None,
    }
```
- 恢复后回到 `route`，模型带新槽位续跑。`messages` 经 checkpoint 保留 → **不重复追问已给信息**（PRD §2.2）。

### 4.2 高风险写操作 → 二次确认（CONFIRM_WRITE）

```python
def ask_user(state):   # CONFIRM_WRITE 分支
    pw = state["pending_write"]          # guard 托管的待确认 toolCall（含完整参数）
    summary = render_confirm_summary(pw) # 业务化摘要：类型/日期/天数 或 系统/用途
    decision = interrupt({"kind": "CONFIRM_WRITE", "summary": summary})
    if is_affirmative(decision):
        # 用户确认 → 执行"托管的原 toolCall"（确认的==提交的，杜绝二次组参漂移）
        return {"pending_tool_calls": [pw], "pending_write": None, "_goto": "act"}
    else:
        # 用户要改 → 丢弃 pending_write，把修改诉求回灌让模型重走
        return {"messages": [HumanMessage(decision)], "pending_write": None, "_goto": "route"}
```

> **关键设计（沿用原 §4.2）：** 二次确认由**图层托管 `pending_write`**（而非靠模型记住参数再发一次），保证"确认的就是提交的"。这是办成率判据 D3 的基础。**未确认禁止提交是图的硬约束**（CONFIRM_WRITE 不通过则 `act` 永不执行该写工具），不依赖模型自觉。

### 4.3 与 checkpoint 的关系（→ §6 与架构师对齐）

`interrupt()` 生效**前提是配了 checkpointer**。图挂起时整个 State（含 `messages/plan/cursor/budget/pending_write`）落 checkpoint；用户下条消息带 `thread_id`（= session/task 维度）`Command(resume=user_reply)` 恢复。**续跑不重新规划、不重置预算**。

---

## 5. 工具绑定与执行：声明在图、执行回调 Java

**权威分工（Path A）：Python 图负责"决定调哪个工具、组什么参、拿 observation 推进"；Java 是工具执行权威（MCP/API/Mock 的真实执行、`tool_call_log` 落库）。**

### 5.1 工具声明（图侧，来自 Skill 白名单）

- `EffectiveSkill.toolWhitelist` 随请求传入（每个工具含 `name`/`description`/`parameters`(JSON Schema)/`bizName`/`requiresConfirmation`）—— 来源是 §`Sprint1-SOP工具定义-Mock.md` 的 function schema。
- `prepare` 节点把白名单转为 LangGraph `tools[]` 绑定到 `reason` 的模型调用（function-calling `tools` 数组）。**物理收窄**：`tools[]` 只含白名单工具，名单外工具对模型不可见（§3.2 第一条硬约束）。
- 图侧**不实现工具体**——所有工具都是"声明 schema、执行委托 Java"的**远程工具（proxy tool）**。

### 5.2 执行回调 Java（`act` 节点）

`act` 节点拿到放行的 tool_calls 后，**HTTP 回调 Java 的工具执行 endpoint**（契约由架构师定，本文给图侧诉求）：

```
act 节点 ──HTTP POST──> Java /internal/tool/execute
  请求体（图侧提供）：{ sessionId, taskId, toolName, args, traceId }
  Java 侧：路由到 MCP/API/Mock executor → 执行 → 写 tool_call_log（成败/耗时/错误码）
  响应体（Java 回灌图）：{ toolCallId, success, observation:{...} | error:{code,message}, latencyMs }
```

- `act` 把响应的 `observation` 以 **`role=tool` 消息**（带 `tool_call_id`）回灌 `state.messages` —— function-calling 多轮硬要求。
- **失败不在图层重试写操作**（写非幂等）：把 `error` observation 回灌，让 `reason` 据 SOP 失败分支翻译成中文 + 补救建议（§8.2）。只读工具的超时重试可由 Java 侧或图侧按策略处理（§7 对齐）。
- **`userId`/`dept` 由 Java 从会话上下文注入**（`source=context`），图不向用户追问这些（与 Mock 工具定义 §3.4 一致）。

> **替换 Mock→真实工具：图与契约不变**，只换 Java 侧 executor 实现（PRD §3.10）。图侧永远只看到统一的"远程工具调用 + observation 回灌"。

### 5.3 子 Skill（Skill-as-tool，S2 预留）

嵌套 Skill 在白名单里表现为 `invoke_skill_<code>` 这种特殊工具。Sprint 1 两个 SOP 无子 Skill；S2 时 `act` 对该类工具的"回调"可走"子图递归"或"回调 Java 再起一个编排请求"，**图骨架不变**（同样是声明 schema + 回调拿 observation）。本文预留，不展开。

---

## 6. checkpoint 与状态持久化（与架构师对齐）

> 本文定**图侧需要什么**；架构师定**用什么承载**（介质/协议）。

| 图侧诉求 | 说明 | 与架构师对齐点 |
|---|---|---|
| **Checkpointer 必备** | interrupt 续跑、多轮上下文、@切换续传都依赖 checkpoint 保存 State | 介质选型：PG（项目已用 Postgres，无 Redis）→ 建议 LangGraph `PostgresSaver`，复用现有 PG。架构师定库/表与连接 |
| **`thread_id` 粒度** | 建议 = `session_id`（同 session 多轮/续跑同线程）；`task_id` 作为 State 内字段区分 Task 预算 | 架构师定 thread_id↔session 映射、并发（≤5，单机）|
| **State 落库 vs Java 落库职责** | LangGraph checkpoint 存"图运行态"（恢复用）；**业务消息/trace 的权威落库在 Java**（`message`/`message.reasoning_trace`，PRD §3.11/§3.9）。图通过 SSE/响应把 trace 增量推给 Java 落库 | 避免双写冲突：checkpoint=临时运行态，Java DB=业务权威。架构师定同步时机（SSE 流式 or 收尾批量）|
| **中断态可恢复字段** | `messages/plan/cursor/budget/pending_write/loop_guard` 必须随 checkpoint 持久（已在 State schema） | 确认 PostgresSaver 默认序列化覆盖这些字段 |

---

## 7. 模型调用：编排内调 DeepSeek（function-calling）

### 7.1 调用位置与档位

- 调模型只发生在 **`plan`**（轻，可用 EXTRACT/ROUTER 档）和 **`reason`**（编排，ORCHESTRATE 档）两个节点。
- **vendor/model/key 配置化**：Path A 下 Python 图**不重复造适配层**。两种对齐方式（架构师定选哪种，本文给图侧偏好）：
  - **方式 A（推荐）— 回调 Java 适配层：** 图的 `reason`/`plan` 把"messages + tools + tier"回调 Java 的 `LlmGateway`（`docs/architecture/ai-adapter/适配层接口契约.md`），由 Java 统一做 **tier→vendor/model 路由、fallback、熔断、`llm_call_log` 埋点**。图侧只声明 tier，不感知 vendor。**好处：** vendor/key/fallback/埋点单点收敛在 Java（已建好），符合"数据不出域、配置化"，DEMO 用 DeepSeek 只改 Java YAML。
  - **方式 B — Python 直连 DeepSeek（OpenAI 兼容）：** 图内用 `langchain-openai`(`ChatOpenAI` 指向 DeepSeek base_url) 直连。配置（base_url/model_id/key 别名/temperature）走 Python 侧 env/配置文件，**不硬编码**。**代价：** fallback/埋点要在 Python 侧重建一份，与 Java `llm_call_log` 口径需对齐。

> **建议 Sprint 1 取方式 A**：复用已设计的 Java 适配层（tier/fallback/`llm_call_log`/pricing 全在那），图保持薄。若架构师评估"图→Java→DeepSeek 多一跳延迟不可接受"，再退方式 B（Python 直连），但需把埋点字段对齐 `llm_call_log`。

### 7.2 模型参数（沿用 `react-驱动Prompt.md` §7）

| 参数 | 建议 | 理由 |
|---|---|---|
| temperature | 0.2–0.3 | 编排判断稳定可复现 |
| top_p | 0.9 | 配合低温 |
| tool_choice | `auto` | 让模型按 SOP 自选工具；`guard` 纠偏 |
| 流式 | 开（SSE） | 1s 内出处理中态（PRD §2.1），trace 逐步推前端 |

### 7.3 fallback / 预算 / 埋点

- **fallback：** 方式 A 由 Java `ResilientInvoker` 按策略矩阵（超时退避、限流切 fallback）处理；图侧只在收到 `success=false` 的最终响应时路由到 `fallback` 节点（§8.3）。
- **预算：** §3.3，图侧用响应 `usage` 累加 `budget.tokenUsed`/`stepUsed`，超限路由 `fallback`。
- **埋点：** 每次模型调用的 vendor/model/耗时/token/cost 落 `llm_call_log`（方式 A 由 Java 落；方式 B 由 Python 回传 Java 落）。trace 落 `message.reasoning_trace`（§9）。

---

## 8. 失败与诚实兜底（每条核心调用都有兜底）

沿用原 ReAct 落地 §6 三层，映射到图节点：

- **8.1 模型级：** `reason`/`plan` 收到适配层 `success=false`（重试/fallback 后仍失败）→ 路由 `fallback`。
- **8.2 工具级（失败码翻译）：** `act` 拿到 `error` observation（`INSUFFICIENT_BALANCE`/`INVALID_DATE`/`NEED_MANAGER_APPROVAL`）→ `observe` 不重试写操作 → 回 `route` → `reason` 据 SOP 失败分支**翻译成中文 + 补救建议**（prompt 引导）。**禁止暴露错误码/函数名**（判据 D5/D6）。
- **8.3 任务级（`fallback` 节点）：** 预算耗尽 / 模型连续失败 / 异常 → 产"已办到哪步 + 卡在哪 + 下一步建议"的**诚实失败话术**，`outcome=FAILED`，trace 落库。**宁可诚实办不成，不假装办成、不无限空转。**

---

## 9. ReAct 轨迹输出（对齐 PRD §2.1 + 办成率判据）

图每经 `reason`/`act`/`observe`/`ask_user`/`finalize` 节点向 `state.trace` append 一条结构化 step（与原 §9 schema 一致，前端展示 + 判据断言双用）：

```json
{
  "stepNo": 2,
  "type": "tool_call",                 // thought|tool_call|observation|ask_user|confirm|final|error
  "toolBizName": "核算请假天数",         // 业务名，前端展示（不暴露函数名）
  "toolName": "hr_calc_leave_days",     // 函数名，仅埋点/排障
  "summary": "按 6/15-6/16 核算占用工作日",
  "status": "success",                  // running|success|failed
  "latencyMs": 320
}
```

- trace 经 SSE 流式推前端（逐步点亮，1s 内出处理中态），同时回传 Java 落 `message.reasoning_trace`。
- 前端只展示 `toolBizName`+`summary`+`status`（PRD §2.1：不暴露函数名/入参/错误码）。
- `ask_user`/`confirm` 类型对应 §4 的 interrupt，前端展示为对话气泡。

---

## 10. 两个 SOP 走查（图的执行轨迹）

> 用 HR、IT 两个 SOP 各画一遍**图节点经过的轨迹**，体现：多步推理、向用户追问、多工具串联（后步依赖前步）、二次确认、失败兜底。**图与节点对两者完全相同，差异全在注入的 SOP 数据与白名单。**

### 10.1 HR 小赫 —— "帮我请假"（信息全缺 → 追问 → 算天数 → 二次确认 → 提交）

```
START
 └ prepare   : 渲染小赫 system prompt（注入 sopDoc=年假请假剧本 + L5 today=2026-06-10）；
               tools[] = {hr_get_leave_balance, hr_calc_leave_days, hr_submit_leave_request}（物理白名单）
 └ plan      : 判意图=leave_submit（ReAct 态，骨架：查余额→算天数→确认→提交）
 └ route     : 推进 → reason
 [step1] reason  : tool_call hr_get_leave_balance{userId(注入)}
         guard   : 白名单✓ 必填✓ 非写操作 → 放行
         act     : 回调 Java → observation {annual:6.5,...}（role=tool 回灌）
         observe : 记 trace；plan[0]=done → route → reason
 [step2] reason  : 缺 type/startDate/endDate → 模型产**纯文本追问**（非 tool_call）
                   ├ 条件边：纯文本=追问 → ask_user
         ask_user: interrupt(ASK_MISSING, "请哪种假？起止日期？") → 图挂起，checkpoint 落
   ── 用户："年假，6/15到6/16" ── Command(resume) 恢复 → route
 [step3] reason  : tool_call hr_calc_leave_days{2026-06-15, 2026-06-16}   # 后步依赖：先有余额上下文
         guard   : 放行 ; act : observation {workdays:2, excluded:[6/13,6/14]}
         observe : workdays=2 ≤ annual 6.5（模型据 observation 判断）→ route → reason
 [step4] reason  : 拟提交 → tool_call hr_submit_leave_request{type:年假,...,days:2}
         guard   : requiresConfirmation=true → **托管 pending_write** → ask_user
         ask_user: interrupt(CONFIRM_WRITE, "年假 6/15–6/16 共2天，确认提交？") → 挂起
   ── 用户："确认" ── resume → 执行**托管的原 toolCall**（确认的==提交的）
 [step5] act     : 回调 Java hr_submit_leave_request → {ticketId:"LV-...-0007",approver:"张经理",eta:"1工作日"}
 └ finalize : final_answer="已为您提交年假申请，工单号 LV-...-0007，审批人张经理，预计1个工作日…"
              outcome=DONE → END
```
**演示点命中：** 多步（5）✓ 追问（step2）✓ 多工具串联且后步依赖前步（余额→算天数→提交）✓ 二次确认（step4 托管）✓。
**失败兜走查（H5 余额不足）：** step5 submit 返回 `INSUFFICIENT_BALANCE` → `observe` 不重试 → `reason` 走 SOP 失败分支 → finalize 输出"年假只剩 X 天，本次需 Y 天，可改请 X 天或换事假"（中文、不暴露错误码）。

### 10.2 IT 小图 —— "帮我开通那个客户系统"（模糊澄清 → 查状态 → 追问用途 → 二次确认 → 提交）

```
START
 └ prepare   : 渲染小图 system prompt（注入 sopDoc=账号开通剧本）；
               tools[] = {it_list_available_systems, it_check_account_status, it_submit_account_request}
 └ plan      : 判意图=account_request（骨架：列系统→澄清→查状态→追问用途→确认→提交）
 [step1] reason  : tool_call it_list_available_systems{userId,dept(注入)}
         guard✓→act: observation [{CRM,客户关系系统},{ERP},{BI},{GIT}]
         observe → route → reason
 [step2] reason  : 用户"那个客户系统"模糊 → **纯文本澄清**列选项 → ask_user
         ask_user: interrupt(ASK_MISSING, "您指的是 CRM 客户关系系统吗？") → 挂起
   ── 用户："对，CRM" ── resume → route
 [step3] reason  : tool_call it_check_account_status{systemCode:CRM}   # 后步依赖：先确认系统再查状态
         guard✓→act: observation {status:"NONE"}     # ACTIVE/PENDING 则此处 finalize 拦截不提交
         observe → route → reason
 [step4] reason  : 缺 purpose（必填）→ **纯文本追问用途** → ask_user
         ask_user: interrupt(ASK_MISSING, "简单说下用途方便走审批？") → 挂起
   ── 用户："华东区客户跟进需要CRM" ── resume → route
 [step5] reason  : tool_call it_submit_account_request{systemCode:CRM,purpose:...}
         guard   : requiresConfirmation=true → 托管 pending_write → ask_user
         ask_user: interrupt(CONFIRM_WRITE, "开通CRM，用途：华东区客户跟进，确认提交？") → 挂起
   ── 用户："确认" ── resume → 执行托管 toolCall
 [step6] act     : it_submit_account_request → {ticketId:"IT-...-0031",approver:"信息部-王工",sla:"2工作日"}
 └ finalize : "已为您提交 CRM 开通申请，工单号 IT-...-0031，审批人王工，预计2个工作日，开通后站内通知。" → END
```
**演示点命中：** 多步（6）✓ 追问 2 处（模糊澄清 step2 + 用途 step4）✓ 多工具串联且后步依赖前步（列系统→查状态→提交）✓ 二次确认（step5 托管）✓。
**失败兜走查（T5 需上级授权）：** step6 submit 返回 `NEED_MANAGER_APPROVAL` → `observe` 不重试 → `reason` 失败分支 → finalize 输出"CRM 需直属上级先授权，请先找 X 审批，授权后我再帮您提交"（中文、给明确下一步）。
**已开通兜走查（T4）：** step3 `it_check_account_status` 返回 `ACTIVE` → `reason` 据 SOP 直接 finalize"您已开通，无需重复申请"，**不进 submit**（白名单 + SOP 软约束 + guard 不放行未经 check 的提交）。

> **通用性印证：** 上面两条轨迹**走的是同一张图、同一组节点**，唯一差异是 `prepare` 注入的 `sopDoc`/`toolWhitelist` 不同。换"财务/法务/设备维修"专家 → 只换这两项数据，图零改动。

---

## 11. 与原 Java ReAct 方案的映射（吸收约束、改用图表达）

| 原 `Sprint1-ReAct引擎落地.md` | 本图等价表达 | 约束是否保留 |
|---|---|---|
| `while not budget.exhausted()` 主循环 | `route↔reason↔guard↔act↔observe` 条件边回环 | ✅ |
| `preCheck(toolCall)` 四类硬拦截 | `guard` 节点 + 条件边 | ✅ 白名单/必填/确认/循环全保留 |
| `askUser(...)` 中断—续跑 | `ask_user` 节点 `interrupt()` + checkpointer | ✅ 且更稳（持久化续跑） |
| 引擎托管"待确认 toolCall" | `state.pending_write` | ✅ 确认的==提交的 |
| `Budget` 随 Task 累加 | `state.budget` + `task_id` | ✅ |
| `ReActTrace` 结构化输出 | `state.trace`（add_trace reducer） | ✅ schema 不变 |
| 诚实兜底 `gracefulFail` | `fallback` 节点 | ✅ |
| Java 内执行工具 | `act` 节点**回调 Java**（Path A 跨语言边界） | ✅ Java 仍是执行权威 |
| Java 内调 `LlmGateway` | `reason`/`plan` 回调 Java 适配层（§7 方式 A） | ✅ tier/fallback/埋点复用 |

---

## 12. 待澄清 / 与架构师待对齐

1. **模型调用走方式 A（回调 Java 适配层）还是方式 B（Python 直连 DeepSeek）** —— 本文建议 A（复用已建适配层，埋点/fallback 单点）。请架构师据"延迟容忍 + 部署复杂度"定，**非阻塞**（图骨架两种都支持）。
2. **Checkpointer 介质** —— 建议复用 PG（`PostgresSaver`，无 Redis 符合项目约束）。架构师定库表与 `thread_id↔session` 映射。
3. **trace/message 落库时机** —— SSE 流式增量 or 收尾批量回传 Java。架构师定，避免与 LangGraph checkpoint 双写冲突（checkpoint=运行态，Java DB=业务权威）。

> 以上均为"图侧已给方案、待架构师选承载"的对齐项，**不阻塞图内逻辑设计**。其余（两个 SOP 字段、Mock 入参出参、Prompt 模板、办成率判据）上游已定，无阻塞项。
