# 个人空间 —— 向量 RAG 策略（embedding / 切片 / 召回 / 接入对话 / 可观测）

- **文档状态：** 待评审（AI/LLM 专家产出，供 PM 汇总 + 架构师联审）
- **作者：** 大模型专家（AI/LLM Expert）
- **日期：** 2026-06-11
- **定位：** 本文给**策略与可实现口径**，不写实现代码。`embed()` 方法签名 / DB V5 迁移 / 分包 / MinIO / 流水线接口边界 / orchestrator 联动改造点由**架构师主笔**；本文主笔 **aliyun provider 配置、embed 实现策略、切片参数、召回策略、RAG 拼接、可观测/eval**。
- **上游依据：**
  - `docs/prd/PRD-03-个人空间-RAG就绪增订.md`（真实向量召回为唯一主路径；F6 接入对话零侵入带开关；F5 后置）
  - `docs/prd/PRD-03-个人空间.md` §2 / §4 / §6（切片口径、检索契约、与对话关系）
  - `docs/architecture/ai-adapter/适配层接口契约.md` / `适配层策略输入.md`
- **embedding 选型（已锁定，勿改）：** 阿里云 DashScope（百炼），**OpenAI 兼容接口**接入，模型 `text-embedding-v3`，**1024 维**，HNSW + cosine。

---

## 0. 关键参数表（一页速查）

| 维度 | 取值 | 说明 |
|------|------|------|
| embedding 模型 | `text-embedding-v3` | DashScope OpenAI 兼容 |
| 向量维度 | **1024** | v3 默认；DB 列 `vector(1024)` |
| 距离度量 | **cosine**（`<=>`） | HNSW 索引 `vector_cosine_ops` |
| Base URL | `https://dashscope.aliyuncs.com/compatible-mode/v1` | 已含 `/v1`，见 §1.3 路径陷阱 |
| 端点 | `POST /embeddings`（不带 `/v1`，经 `normalizeBaseUrl` 拼接） | OpenAI 兼容，见 §1.3 |
| 单批上限 | **≤ 10 条/批** | text-embedding-v3 OpenAI 兼容接口实测上限（>10 报 `batch size should not be larger than 10`）；适配层自动分批 |
| 单片长度 | **500–800 字**（目标 ~600） | 中文按字符、英文按词折算，见 §3.3 |
| overlap | **50–100 字**（目标 ~80） | 相邻片重叠，保上下文连续 |
| Top-K | **默认 5** | 召回切片数，契约固定 |
| 相似度阈值 | **cosine similarity ≥ 0.35**（建议起步值） | 见 §4.3，可配、需 eval 校准 |
| query embed 超时 | **5s**（建议） | 召回路径要短，超时即静默跳过 |
| 批量 embed 超时 | **30s/批**（建议） | 离线流水线，可放宽 |
| 重试 | 沿用 `llm.resilience`（max-retries=2，退避 500ms×2^n） | 仅 TIMEOUT/SERVER_ERROR/UNKNOWN 重试 |
| 流水线并发 | **≤5**（沿用全局非功能约束） | embedding 调用按批串行/小并发 |

> **零侵入兜底结论（先行）：** query embed 失败 / 召回为空 / 召回超时 / 任何异常 → **静默跳过、ragSnippets 传空、对话照常完成、仅记日志**，绝不阻断主问答。`F6` 开关关闭时等于该功能从未介入。详见 §5。

---

## 1. aliyun embedding provider 配置方案

### 1.1 `application.yml` 片段（新增 aliyun provider + EMBEDDING 路由）

在 `llm.providers` 下新增 `aliyun`，并把 `router.default-tier-model.EMBEDDING` 指向它：

```yaml
llm:
  providers:
    deepseek:
      type: openai-compatible
      base-url: https://api.deepseek.com
      api-key: ${DEEPSEEK_API_KEY:}
    internal-net:
      type: openai-compatible
      base-url: ${INTERNAL_LLM_BASE_URL:https://llm.intranet.local/v1}
      api-key: ${INTERNAL_LLM_API_KEY:}
    # ===== 新增：阿里云 DashScope（百炼）OpenAI 兼容，用于 embedding =====
    aliyun:
      type: openai-compatible
      base-url: https://dashscope.aliyuncs.com/compatible-mode/v1
      api-key: ${ALIYUN_DASHSCOPE_API_KEY:}   # 真实 key 由 application-local.yml 注入，缺省留空
  router:
    default-provider: deepseek
    default-tier-model:
      ORCHESTRATE: deepseek-chat
      ROUTER: deepseek-chat
      EXTRACT: deepseek-chat
      JUDGE: deepseek-chat
      EMBEDDING: aliyun:text-embedding-v3     # ← 占位替换为真实绑定
  # embedding 专用参数（★ 当前 LlmProperties 不存在此子节点，须新增静态内部类 Embedding）
  embedding:
    dimensions: 1024          # 默认 1024：v3 默认维度 / DB 列 vector(1024)
    batch-size: 10            # 默认 10：text-embedding-v3 单请求 input 上限实测=10，适配层据此自动分批
    query-timeout-ms: 5000    # 默认 5000：召回路径 query 向量化超时（短）
    batch-timeout-ms: 30000   # 默认 30000：离线批量向量化超时（长）
```

> **★ `llm.embedding` 子节点当前不存在（已核对 `LlmProperties`）。** 现有结构仅 `Provider / Router / Resilience / TierParams`，**无 `Embedding`**。须新增静态内部类 `Embedding`（含 `dimensions / batchSize / queryTimeoutMs / batchTimeoutMs` 四字段 + getter/setter），并在 `LlmProperties` 增 `private Embedding embedding = new Embedding();` 字段，由**架构师**落地。
>
> **默认值（后端落地依据）：** `dimensions=1024`、`batch-size=10`、`query-timeout-ms=5000`、`batch-timeout-ms=30000`。四项一律配置化，不硬编码。
> **修订（2026-06-11，BUG-02）：** `batch-size` 由 25 改为 **10**——text-embedding-v3 经 OpenAI 兼容接口单请求 `input` 数组上限为 10（>10 即报错），此前文档"≤25"有误。

### 1.2 `application-local.yml` 注入位（不写真实 key）

key 只入 `backend/config/application-local.yml`（已 gitignored），与现有 deepseek key 同级追加：

```yaml
llm:
  providers:
    deepseek:
      api-key: "<deepseek key 已存在>"
    aliyun:
      api-key: "<在此填阿里云 DashScope API Key，sk-... ；切勿提交 / 切勿进日志>"
```

> **铁律：** key 绝不进 Git / 日志 / 文档 / 记忆。沿用 `OpenAiCompatibleProvider` 现有做法——日志只提示「请在 application-local.yml 注入 llm.providers.aliyun.api-key」，从不打印 key 本身。

### 1.3 ★ 路径陷阱（必须处理，否则 404）

**实情（已核对源码）：**
- `OpenAiCompatibleProvider.CHAT_PATH = "/v1/chat/completions"`（写死带 `/v1`）；
- `normalizeBaseUrl(...)` 现仅做"去掉尾部 `/`"，**不处理 `/v1` 去重**；
- 源码 L42 留有遗留 TODO：`// TODO Sprint1: internal-net 等 base-url 已自带 /v1 时，CHAT_PATH 拼接需统一处理（去重 /v1）。`

对 deepseek base-url `https://api.deepseek.com`（不含 `/v1`）+ `CHAT_PATH=/v1/chat/completions` 拼接正确。但 **aliyun base-url 已自带 `/v1`**（`compatible-mode/v1`）。若 embed 端点写死 `/v1/embeddings` 拼到 aliyun base-url，会得到 `.../compatible-mode/v1/v1/embeddings` → **404**。

**口径（与架构师对齐，落到 `normalizeBaseUrl` 统一处理）：**
- embed 端点路径统一用 **`/embeddings`**（不带 `/v1`）；
- 在 `OpenAiCompatibleProvider` 侧把 `normalizeBaseUrl` 升级为统一规则：
  - base-url **已含 `/v1`**（如 aliyun `compatible-mode/v1`）→ 直接用 `/embeddings` 拼接；
  - base-url **不含 `/v1`**（如 deepseek、未来内网 embedding）→ 补成 `/v1/embeddings`；
- **同步收敛 chat 与 embed 的拼接逻辑**：建议借这次把 chat 侧也改为同一套 `normalizeBaseUrl` 规则（chat 用 `/chat/completions` 相对路径），**并清理 L42 那条遗留 TODO**，避免 chat 写死 `/v1/...`、embed 走 `normalizeBaseUrl` 的"两套拼接逻辑分叉"。
- **最小可行兜底：** 即便本轮先不动 chat，embed 也**不得**写死 `/v1/embeddings`——必须经 `normalizeBaseUrl` 判断 base-url 是否已含 `/v1`，否则 aliyun 必 404。

---

## 2. `embed()` 实现策略（方法签名由架构师主笔）

### 2.1 接口形态（建议，签名以架构师为准）

`LlmProvider` SPI 增 `embed()`；建议**两个语义入口**（也可单方法 + 单元素 list）：
- `embed(query)`：单条，召回路径用，走 `query-timeout-ms`；
- `embedBatch(List<text>)`：批量，离线流水线用，走 `batch-timeout-ms`，内部**自动分批 ≤10**。

统一返回 `List<float[]>`（维度 1024），**与输入 index 严格对齐**。

### 2.2 请求体（OpenAI 兼容 `POST /embeddings`）

```json
{
  "model": "text-embedding-v3",
  "input": ["文本1", "文本2", "..."],
  "dimensions": 1024,
  "encoding_format": "float"
}
```

- `input` 传**数组**（单条也用单元素数组，统一代码路径）；
- `dimensions: 1024` 显式传，避免依赖默认；
- `encoding_format: float`（默认 float，显式更稳）。

### 2.3 响应解析（按 index 对齐）

DashScope OpenAI 兼容响应：

```json
{
  "data": [
    {"index": 0, "embedding": [0.01, -0.02, ...]},
    {"index": 1, "embedding": [...]}
  ],
  "model": "text-embedding-v3",
  "usage": {"total_tokens": 123}
}
```

**对齐口径（强约束）：**
- **不假设 `data` 顺序 = 输入顺序**，必须按每项 `index` 回填到结果数组对应槽位；
- 解析后**校验**：`data.size() == input.size()`、每个 `embedding.length == 1024`，否则归一为错误码（见 §2.5）；
- `usage.total_tokens` 落埋点（见 §6）。

### 2.4 自动分批（≤10/批）

伪代码：

```
embedBatch(texts):
    results = float[texts.size()][]
    for window in partition(texts, batchSize=10):   # 保留每条全局 index
        resp = POST /embeddings {model, input: window.texts, dimensions:1024}
        for item in resp.data:
            results[window.globalIndex(item.index)] = item.embedding
    assert no-null slot in results
    return results
```

- 分批是**适配层内部行为**，对调用方透明；
- 每批一次 HTTP，每批独立超时/重试；
- **批间小并发或串行**：并发 ≤5 约束下，建议**串行**（实现简单、不触发限速），量大时再评估并发；
- 埋点按「批」记一条，并汇总（见 §6）。

### 2.5 超时 / 重试 / 错误分类（沿用 `OpenAiCompatibleProvider` 风格）

完全复用现有 `classifyError` 归一码与 `LlmGateway` 重试策略：

| 场景 | errorCode | 召回路径处置 | 离线流水线处置 |
|------|-----------|--------------|----------------|
| 429 限速 | `LLM_RATE_LIMITED` | 不重试 → 静默跳过 | 退避后整批重排（流水线层，非 gateway 重试） |
| 401/403 | `LLM_AUTH_ERROR` | 不重试 → 静默跳过 + 告警日志 | 整文档判向量化失败、可重试 |
| 4xx 参数 | `LLM_BAD_REQUEST` | 不重试 → 静默跳过 | 同上 |
| 5xx | `LLM_SERVER_ERROR` | gateway 重试 2 次，仍败→跳过 | gateway 重试，仍败→判失败可重试 |
| 超时 | `LLM_TIMEOUT` | gateway 重试（受 query-timeout 限制，整体仍要快）→跳过 | gateway 重试→判失败可重试 |
| 维度/对齐异常 | `LLM_BAD_RESPONSE`（建议新增）| 跳过 | 判失败 |

> **关键差异：召回路径（query embed）与离线路径（批量 embed）失败语义不同。** 召回失败 = 静默降级不阻断对话；离线失败 = 文档向量化失败、状态可见可重试（PRD §4.1）。`embed()` 本身只负责调用与归一错误码，「跳过 vs 判失败」由各自调用方决定。

### 2.6 fallback 兜底

- **召回 query embed 失败**：不切 provider，直接**静默跳过检索**（见 §5）。本轮 embedding 仅一个 provider，无跨 provider fallback；如未来配内网 embedding，可在 EMBEDDING tier 增备用绑定走 gateway fallback（预留，本轮不做）。
- **离线批量 embed 失败**：该文档 `parse_status` 进「向量化失败」可重试态（具体状态由架构师/产品定，PRD §4.1 已要求"对用户可见且可重试"），**不得显示为可正常语义检索**。
- **关键词兜底**：PRD 增订明确——关键词召回**最多**作为「query 向量化失败/向量为空」兜底，**是否实现交技术决定、不作主路径、不在前台暴露**。**本轮建议不做关键词兜底**（净化范围、守零侵入），失败即空召回；若后续 eval 发现 query embed 偶发失败影响体验，再评估补关键词兜底。→ **列为 PM 决策项**（§9）。

---

## 3. 切片策略（后端可实现口径）

### 3.1 目标与原则

- 切片粒度服务于**检索召回质量**：太碎丢上下文、太大稀释相关度。
- 口径：**段落/语义边界优先 + 固定窗口兜底 + 重叠**，与 PRD §2.4 一致。

### 3.2 算法（伪代码级）

```
chunk(text, doc_id):
    # 1. 归一化：去除连续空行、页眉页脚噪声（解析器层尽量先清洗）
    paragraphs = splitByParagraph(text)        # 按 \n\n / 标题 / 列表项等自然边界
    chunks = []
    buf = ""
    for p in paragraphs:
        if len(buf) + len(p) <= MAX (800):
            buf += p
        else:
            if buf: chunks.add(buf)
            if len(p) <= MAX:
                buf = p
            else:
                # 单段超长：固定窗口切，窗口 ~600，步长 = 600 - overlap(80)
                for w in slidingWindow(p, size=600, overlap=80):
                    chunks.add(w)
                buf = ""
    if buf: chunks.add(buf)

    # 2. 相邻 chunk 追加 overlap：把上一片尾部 ~80 字接到下一片头部（语义切边界时也补重叠）
    chunks = applyOverlap(chunks, overlap=80)

    # 3. 过滤：剔除纯空白/极短（<20 字）无信息片
    chunks = [c for c in chunks if meaningful(c)]

    # 4. 落 metadata
    return [Chunk(doc_id, chunk_index=i, content=c, metadata={...}) for i,c in enumerate(chunks)]
```

### 3.3 长度计量口径（中英文统一）

- **统一以「字符数」近似计量**（中文 1 字符≈1 token 量级，英文偏保守），阈值 500–800 指**字符**；
- 英文/代码为主的文档同口径用字符，简单稳健，不引入 tokenizer 依赖（守技术栈约束）；
- 单批 10 条 + 每条 ≤800 字，符合模型单请求 input ≤10 上限，安全。

### 3.4 metadata（落 `doc_chunk.metadata`，JSON）

| 字段 | 来源 | 用途 |
|------|------|------|
| `chunk_index` | 切片序号（独立列也可） | 排序/定位/契约出参 |
| `doc_id` | 所属文档 | 契约出参、隔离 |
| `page` / `heading` | 解析器提供（PDF 页码 / Word 标题层级，如有） | 来源标注、用户查看切片 |
| `char_len` | 切片字符数 | 调试/统计 |

> `source_name`（来源文件名）**不入 chunk metadata**，召回时 JOIN `personal_doc.name` 取，避免冗余/改名不一致。

### 3.5 超大文档

- 万级切片：切片**分批落库**（架构师定批大小，如 500 片/批 flush）；
- 向量化按 §2.4 自动 ≤10/批，全文档串行跑完；
- 流水线状态：解析中→切片中→向量化中→就绪，向量化阶段对超大文档可能耗时，状态需对用户可见（PRD §2.3 子状态）。

---

## 4. 向量召回策略

### 4.1 召回链路

```
query (非空) → embed(query)[text-embedding-v3,1024] → 向量 v
   → pgvector ANN（HNSW, cosine <=>）在 doc_chunk 上检索
   → 硬过滤：user_id = 当前登录用户 AND parse_status='parsed' AND deleted=false AND embedding IS NOT NULL
   → 取 Top-K（默认5）按距离升序
   → 计算 similarity，过滤 < 阈值
   → 返回 chunks[]（doc_id / chunk_index / content / score / source_name）
```

### 4.2 召回 SQL（native，pgvector）形态

```sql
-- :qvec 为 query 向量（1024 维），:uid 当前用户，:k Top-K
SELECT c.doc_id,
       c.chunk_index,
       c.content,
       1 - (c.embedding <=> :qvec) AS score,   -- cosine similarity ∈ [-1,1]，越大越相关
       d.name AS source_name
FROM doc_chunk c
JOIN personal_doc d ON d.id = c.doc_id
WHERE d.user_id = :uid              -- ★ 硬隔离：强制当前用户
  AND d.deleted = false
  AND d.parse_status = 'parsed'     -- 仅就绪文档
  AND c.embedding IS NOT NULL       -- 仅已向量化切片
ORDER BY c.embedding <=> :qvec      -- 距离升序 = 相似度降序，走 HNSW 索引
LIMIT :k;
```

- **排序用 `<=>`（cosine distance）升序**，让 HNSW 索引生效；`score = 1 - distance` 作为出参相似度（cosine similarity）。
- **阈值过滤在应用层做**（取回 Top-K 后按 `score >= threshold` 过滤，阈值 **0.35**），**不进 `WHERE`**——在 SQL 里加距离条件会破坏 HNSW 扫描计划；K 不大（5），应用层过滤开销可忽略。
- `:qvec` 绑定：pgvector 需把 `float[]` 以 `'[v1,v2,...]'::vector` 形式绑定，JPA native 用字符串参数 + `CAST(:qvec AS vector)`，具体由架构师定（这是实现细节）。

### 4.2.1 ★ embedding 字段不走 JPA 映射（与架构师口径对齐，确认）

经与架构师口径对齐，确认如下（本文记录，DDL/实体归架构师）：
- **`DocChunk.embedding` 字段不走 JPA 实体映射**（标 `@Transient`）——pgvector `vector` 类型无原生 JPA 映射，避免 Hibernate 误处理；
- **写向量用独立原生 SQL**：`UPDATE doc_chunk SET embedding = CAST(:vec AS vector) WHERE id = :id`（`:vec` 传 `'[v1,...]'` 字符串），不经实体 `save`；
- **召回查询用原生 SQL**：`1 - (embedding <=> CAST(:q AS vector))` 作 cosine similarity，阈值 **0.35** 在应用层过滤（见上，不进 `WHERE` 以免破坏 HNSW 扫描）。

> 即：embedding 列的读写**全部走原生 SQL**，JPA 实体只承载 chunk 的常规字段；这与 §4.2 召回 SQL、§4.5 HNSW 索引口径一致。

### 4.3 阈值与 Top-K 口径

- **Top-K = 5**（契约固定，PRD §4.5）。
- **相似度阈值起步值：cosine similarity ≥ 0.35**。理由：text-embedding-v3 cosine 下，强相关片通常 0.5+，弱相关 0.3–0.5，噪声 < 0.3；0.35 作为「宁缺毋滥」的保守门槛，过滤明显不相关片，避免污染上下文。
- 阈值**配置化**（`rag.score-threshold`），并在 §6 eval 中校准；不同语料分布可能需微调。
- **空召回是正常态**：无文档/无命中/全低于阈值 → 返回空，对话照常（§5）。

### 4.4 硬隔离（铁律，不可破）

- `user_id` 过滤**在 SQL 强制**，且 `user_id` 来自服务端会话（沿用现有 `resolveUserId()`），**前端不可传**；
- 仅 `parsed` + 未删除 + 已向量化切片参与；
- A 用户召不到 B 用户切片——列为 eval 必测项（§6.2）。

### 4.5 HNSW 索引（DB V5，架构师主笔，本文给参数建议）

```sql
-- doc_chunk.embedding vector(1024)
CREATE INDEX idx_doc_chunk_embedding
  ON doc_chunk USING hnsw (embedding vector_cosine_ops)
  WITH (m = 16, ef_construction = 64);
-- 查询期可设 SET hnsw.ef_search = 40; （召回质量/延迟权衡，默认 40 起）
```

- 数据量小（个人空间、并发≤5），`m=16, ef_construction=64` 足够；`ef_search` 40 起，召回不足再调高。
- 这些是索引参数建议，**DDL 归架构师 V5 迁移**。

---

## 5. RAG 接入对话（零侵入，硬约束）

### 5.1 注入点（已定位，最小改动）

现状：`ChatStreamService.buildConversation()`（约 L406–413）构造 `Conversation` 时，ragSnippets 恒为 `List.of()`。Python 侧 `app/graph/prompt.py` 的 `_runtime_block` 已消费 `ctx.ragSnippets`，逐条渲染为「参考资料」行。

> **零侵入挂载 = 仅把 `buildConversation` 里那个 `List.of()` 替换为「受开关与 try/catch 守护的检索结果」**。Python 侧、prompt 模板、OrchestrateRequest 结构**全部零改动**。这是本方案"增量而非改造"的关键——检索是对既有 ragSnippets 槽位的填充，链路其余部分不动。

### 5.2 ragSnippets 组装规则

每条 snippet 是一个**字符串**（契约即 `List<String>`），建议格式：

```
《来源文件名》：切片正文（裁剪后）
```

例：`《2025年度OKR.docx》：Q3 重点是把个人空间 RAG 跑通，目标召回准确率 >80% …`

组装口径：
1. 取召回 chunks（已按 score 降序、过阈值、Top-K）；
2. **去重**：同一 doc 多片相邻可合并/去高度重复片（简单按 content 前 N 字去重即可）；
3. **长度预算**：ragSnippets 总字符 **预算 ~1500–2000 字**（控 token 成本、防上下文挤占 SOP）；逐条累加，超预算截断（保留 score 最高的几条）；单条过长（>800）再裁到 ~600；
4. 每条带来源文件名（来自 SQL JOIN）。

### 5.3 触发条件（何时检索）

- `query` 非空（PRD §4.7）；
- 「个人知识参与对话」开关开启（§5.5）；
- 满足以上即检索；**不做复杂"是否需要个人知识"的 LLM 预判**（本轮从简，避免额外一次 LLM 调用与延迟）——每轮用户消息都尝试检索，命中则注入、不命中则空。后续如需省成本再加轻量门控。

### 5.4 非侵入兜底（硬验收，对应 PRD §3.3）

检索整段用 **try/catch 包裹 + 超时**，任何下列情况 → **ragSnippets 传空、对话照常、记日志，绝不抛出**：
- 用户无就绪文档 → 空召回；
- 召回无命中 / 全低于阈值 → 空；
- query embed 超时/失败（≤5s 限制）→ 空 + warn 日志；
- pgvector 查询异常 → 空 + warn 日志；
- 开关关闭 → **根本不进入检索分支**，与现状 100% 一致。

> 守则：**宁可少召回，绝不影响主问答。** 检索的耗时也要控制（query embed ≤5s + 一次 ANN 查询），不显著拉长首响。

### 5.5 开关（本轮验收项）

- 提供「个人知识参与对话」开关，**关闭时 `buildConversation` 走原 `List.of()` 路径**，链路与现状 100% 一致；
- 粒度（系统级 / 用户级）**归架构师定**（PRD §6 列为待 PM 拍板项之一）；
- AI 侧建议：起步**系统级配置开关**（`rag.personal.enabled`，配置化）即可满足"开关存在性"验收，用户级可后置。

### 5.6 与 prompt 拼接对齐

- 现 `_runtime_block` 把每条 snippet 渲染为 `- {s}`，置于「参考资料（仅供参考，引用时注明来源）」下，位于 L5 运行时上下文；
- 这与"专家可标注『参考了你的个人文档』"一致（PRD §4.2）——snippet 自带《文件名》前缀，模型可据此标注来源；
- **无需改 prompt 模板**（提示词工程师主导，如要在 OUTPUT_FORMAT 增"引用个人资料时注明来源"一句，属 prompt 侧增订，本文不擅改，列为与提示词工程师联审项）。

---

## 6. 可观测 + 轻量 evaluation

### 6.1 埋点字段（★ embedding 侧**新写**埋点，非"复用现有落库路径"）

> **★ 重要纠偏（与实际代码对齐）：** 原文写"embedding 调用复用 `LlmCallLog` / 与 `persistLlmMeta` 一致"，**与代码不符，已更正**：
> - `LlmGateway.chat()` 当前**并不落** `llm_call_log`，源码注释明确"llm_call_log 落库待 Sprint 1"，只打了日志，无 `repository.save`；
> - 真正写库在 `ChatStreamService.persistLlmMeta(...)`，由 **Python 编排侧发出的 `llm_meta` 事件**驱动（SSE 事件 → Java 落库）；
> - **embedding 是纯 Java 侧调用**（`LlmGateway.embed` → provider HTTP），既走不到 `chat()` 的（尚未实现的）落库，也走不到 `persistLlmMeta` 那条由 Python 事件触发的路径。
>
> 因此 embedding 埋点**必须在 `LlmGateway` 的 `embed` 侧新写一套独立落库**，不能假设"复用就有"。

**落库口径（架构师在 `LlmGateway.embed` 内实现）：**
- 每次 embed 调用结束后（成功/失败均落），构造 `LlmCallLog` 并调 `LlmCallLogRepository.save(...)`；
- **整段 `save` 用 try/catch 吞异常**：埋点失败只打 `log.warn`，**绝不阻断主流程**（与 `persistLlmMeta` 现有"埋点失败不阻断"风格一致）；
- 落库时机：召回 query embed 每次一条；离线批量 embed **按批各落一条**（见下 `finish_reason` 编码批信息）。

**★ 阻塞前置：`LlmCallLog` 实体缺 `errorCode` 映射，须先补字段。**
- DB 侧 **`llm_call_log.error_code VARCHAR(64)` 列已在 `V1__init.sql` 存在**（无需新建迁移）；
- 但**实体 `LlmCallLog` 当前未映射该列**（无 `errorCode` 字段 / getter / setter）；
- 须先给实体补：`@Column(name = "error_code") private String errorCode;` + getter/setter，**之后才能落 errorCode**。这是 embed 埋点能记录错误码的前置条件（归架构师/后端落地）。

**字段映射（沿用原定义：vendor / model / 耗时 / token / 批数 / 成本估算 / errorCode）：**

| 字段 | embedding 取值 |
|------|----------------|
| `tier` | `EMBEDDING` |
| `vendor` | `aliyun`（实际 provider 名，非协议名 openai-compatible） |
| `model` | `text-embedding-v3` |
| `scene` | `rag-query`（召回）/ `rag-index`（离线批量） |
| `prompt_tokens` | `usage.total_tokens`（embedding 无 completion） |
| `completion_tokens` | 0 |
| `latency_ms` | 本次（本批）调用耗时 |
| `success` | 成败 |
| `errorCode` | 失败时归一错误码（见 §2.5）；**需先补实体 `error_code` 映射**（见上） |
| `finish_reason` | 成功记 `batch:N`（本批序号/批数），失败可冗余记错误码，便于排查 |
| `trace_id`/`session_id`/`message_id` | 召回路径透传当前对话 trace；离线路径无对话 trace 可留空 |

> **批数 / 条数：** 优先用 `finish_reason` 编码 `batch:N` 承载批信息，避免改表。如后续要做成本/批量报表更细维度，可由架构师评估在 `llm_call_log` 增 `batch_count` / `input_count` / `cost` 列（本轮非必须）。成本估算见 §7.3。

应用层另建议记**召回质量埋点**（可落业务日志或简单表）：`query` hash、命中切片数、Top1 score、是否注入、耗时、是否走兜底。供 eval 与排障。

### 6.2 最小召回质量自检（供测试阶段）

准备 **3–5 条样例 query → 期望命中文档**，跑通即视为召回有效（对应 PRD §4.2 验收）：

| # | 操作 | 期望 |
|---|------|------|
| 1 | 上传一篇含已知内容的文档（如"我的OKR：Q3跑通个人空间RAG"），就绪后 | `parse_status=parsed`，切片有 embedding（非 NULL） |
| 2 | query="第三季度的重点目标是什么"（**措辞不同**） | Top-K 命中该文档切片，score ≥ 阈值 |
| 3 | query="完全无关的内容 xyz" | 空召回 或 全低于阈值 → 对话不附加个人知识 |
| 4 | 用 A 用户 query 去召 B 用户文档内容 | **召不到**（隔离铁律） |
| 5 | 关闭「个人知识参与对话」开关后同问 | ragSnippets 为空，对话与现状一致 |

> 这是**冒烟级 eval**，非全量评测；通过即满足本轮"语义召回有效 + 隔离 + 非侵入"硬验收。后续可扩为标注集 + recall@k 指标，列入 `docs/ai/evaluation/`。

---

## 7. 成本 / 性能

### 7.1 向量化时机

- **上传后异步流水线**触发（解析→切片→向量化），**不在上传请求同步路径**做 embedding，避免拖慢上传响应；
- 召回路径只做**一次** query embed（≤5s）+ 一次 ANN 查询，延迟可控。

### 7.2 批处理 / 并发

- 离线向量化**自动 ≤10/批**，并发 ≤5 约束下**建议串行批**（实现简单、规避限速）；
- 切片落库分批，避免大事务；
- query embed 单条、低频，无并发压力。

### 7.3 成本估算

- text-embedding-v3 按 token 计费、单价极低；个人空间语料量级小（单用户文档/切片有限），embedding 成本可忽略；
- 主要成本仍在 chat（ORCHESTRATE）；RAG 注入会**略增 prompt token**（受 §5.2 的 ~1500–2000 字预算控制），可控；
- 埋点记 token 数，便于后续核算（成本估算列可后置）。

---

## 8. 与架构师的接口对齐（统一口径）

检索接口形状统一为 **`query / user_id / top_k → chunks[]`**，每项含 `doc_id / chunk_index / content / score / source_name`（与 PRD §4.5 契约一致）。

| 归属 | 项 |
|------|----|
| **架构师主笔** | `embed()`/`embedBatch()` 方法签名、`LlmProvider` SPI 扩展、`LlmGateway.embed` 韧性接入 + **embed 侧新写 `LlmCallLogRepository.save` 埋点（try/catch 吞异常）**、**`LlmCallLog` 实体补 `@Column(name="error_code")` 映射**、**新增 `LlmProperties.Embedding` 内部类**、**`normalizeBaseUrl` 统一 /v1 拼接 + 清理 L42 遗留 TODO**、DB V5（`doc_chunk.embedding vector(1024)` `@Transient` + 写向量原生 `UPDATE ... CAST(:vec AS vector)` + HNSW + 索引参数）、分包、MinIO、上传→解析→切片→向量化流水线接口边界、`buildConversation` 注入点改造、`qvec` 绑定方式 |
| **本文（AI 专家）主笔** | aliyun provider 配置、embed 请求/响应/分批/错误/兜底策略、切片参数与算法、召回 SQL/阈值/Top-K/隔离、ragSnippets 组装与零侵入兜底、可观测埋点 + eval |
| **联审** | prompt 模板是否加"引用个人资料注来源"（提示词工程师主导，AI 专家联审） |

---

## 9. 风险 / 需 PM 决策项

1. **【需 PM/技术拍板】关键词兜底是否做？** 本文建议**本轮不做**（守零侵入、净化范围，query embed 失败即空召回）。若用户/测试要求"query 向量化偶发失败时仍尽量召回"，再补 ILIKE 关键词兜底（不在前台暴露）。
2. **【需架构师定】开关粒度**（系统级 vs 用户级）。AI 侧建议起步系统级 `rag.personal.enabled`，满足开关存在性验收；用户级可后置。
3. **【风险】路径拼接（§1.3）**：aliyun base-url 自带 `/v1`，embed 路径必须用 `/embeddings`（不带 `/v1`）经 `normalizeBaseUrl` 判断拼接，否则 `/v1/v1/embeddings` → 404。架构师须把 `normalizeBaseUrl` 升级为"已含 /v1 用 /embeddings、否则补 /v1/embeddings"，并清理 provider L42 遗留 TODO，收敛 chat/embed 两套拼接。
4. **【风险/需校准】相似度阈值 0.35 为经验起步值**，需用 §6.2 样例 + 真实语料 eval 校准；阈值配置化，避免硬编码。
5. **【依赖】DB V5 未落地前**（`doc_chunk.embedding` 列 + HNSW），召回链路无法联调；与架构师并行，向量化/召回实现需等 V5。
6. **【合规/区域】** DashScope 为公网阿里云，生产若要求"数据不出域"，embedding 需切客户内网模型（PRD §7.1）——本轮 DEMO 用 aliyun，生产换 provider 配置即可（接口契约不变）。属已知演进，非本轮阻塞。
7. **【后端落地前置（阻塞 embed 埋点 / 配置）】** 三项实体/配置改造须先于 embed 实现：(a) `LlmCallLog` 实体补 `@Column(name="error_code")` 映射（DB 列已存在 V1，否则埋点无法落 errorCode）；(b) 新增 `LlmProperties.Embedding` 内部类（当前不存在，否则 `llm.embedding.*` 配置无处绑定）；(c) embed 侧新写 `LlmCallLogRepository.save` 埋点（chat 当前不落库，embedding 走不到 `persistLlmMeta`）。归架构师/后端，与 V5 并行。

---

*（个人空间向量 RAG 策略 完。本文为策略/口径文档，实现以架构师主笔的签名/迁移/边界为准。）*
