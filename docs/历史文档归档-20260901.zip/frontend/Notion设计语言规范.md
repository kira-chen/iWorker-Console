# AI 同事 · Notion 设计语言落地规范

> 全站统一 Notion 风格，浅(light)/暗(dark)双主题，使用端提供切换。
> 本文是第二阶段全量铺页的**唯一套用基准**：所有页面只引用设计令牌，禁止硬编码色值。

适用范围：员工端 + 管理端全部页面与组件。
单一真相源：`frontend/src/assets/tokens.css`（令牌）、`frontend/src/assets/theme.css`（EP 映射 + 工具类）。

---

## 1. 设计原则（Notion 风硬要求）

- **克制、强留白**：用空间分隔而非重边框/重色块。
- **弱细边框**：分隔用 `--border-soft` / `--border-base`，不用粗框、不用重阴影。
- **中性灰阶 + 强排版层级**：标题/正文/次级/弱化四级文字，靠字重与色阶拉层次。
- **块/文档感**：内容区用 `--bg-surface` + 弱边框 + 小圆角组成"块"。
- **小圆角**：3–8px（`--radius-xs`～`--radius-lg`）。
- **阴影仅用于浮层/菜单/弹窗**，且很淡（`--shadow-md/-lg`）。内容卡片只用 `--shadow-card`（=最淡）或纯边框。
- **克制快速动效**：`--dur-fast/-base`，hover 只换底色（浅灰块），不做位移/辉光/渐变。
- **禁止**：Element Plus 默认蓝白企业风、老式 OA 蓝顶栏、玻璃拟态、彩色渐变、发光(glow)。

---

## 2. 设计令牌清单（`tokens.css`）

### 2.1 主题无关常量（`:root`，两主题共用）

| 类别 | 令牌 | 取值 |
|------|------|------|
| 圆角 | `--radius-xs/sm/md/lg/xl/pill` | 3 / 4 / 6 / 8 / 12 / 999px |
| 间距 | `--space-1…12` | 4 / 8 / 12 / 16 / 20 / 24 / 32 / 40 / 48px |
| 字体 | `--font-sans` | 系统无衬线栈（含 PingFang SC / Microsoft YaHei 中文兜底） |
| 字体 | `--font-mono` | SF Mono / JetBrains Mono / Menlo … |
| 字号 | `--fs-xs/sm/base/md/lg/xl/2xl/3xl` | 12 / 13 / 14 / 15 / 18 / 22 / 28 / 34px |
| 字重 | `--fw-regular/medium/semibold/bold` | 400 / 500 / 600 / 700 |
| 行高 | `--lh-tight` / `--lh-base` | 1.3 / 1.6 |
| 动效 | `--ease-out` / `--ease-in-out` | cubic-bezier |
| 动效 | `--dur-fast/base/slow` | 0.12 / 0.2 / 0.32s |
| 层级 | `--z-base/sticky/overlay/modal` | 1 / 100 / 1000 / 2000 |

### 2.2 主题相关语义令牌（业务只引用这一层）

| 语义 | 令牌 | 浅色(light) | 暗色(dark) |
|------|------|-------------|-----------|
| 页面底 | `--bg-app` | `#ffffff` | `#191919` |
| 凹陷区(侧栏/代码块) | `--bg-sunken` | `#f7f7f5` | `#202020` |
| 表面(卡片/内容) | `--bg-surface` | `#ffffff` | `#1f1f1f` |
| 抬升(浮层/菜单/弹窗) | `--bg-elevated` | `#ffffff` | `#2a2a2a` |
| hover 浅灰块 | `--bg-hover` | `rgba(55,53,47,.06)` | `rgba(255,255,255,.055)` |
| active 块 | `--bg-active` | `rgba(55,53,47,.09)` | `rgba(255,255,255,.09)` |
| 选中(强调淡底) | `--bg-selected` | `rgba(16,185,129,.1)` | `rgba(16,185,129,.22)` |
| 正文强调/标题 | `--c-text-strong` | `#37352f` | `#ffffff` |
| 正文 | `--c-text` | `#37352f` | `#e9e9e7` |
| 次级/说明 | `--c-text-muted` | `#787774` | `#9b9a97` |
| 弱化/占位 | `--c-text-faint` | `#9b9a97` | `#6f6f6c` |
| 强调底上文字 | `--c-text-on-accent` | `#ffffff` | `#0f172a`（暗色亮绿主按钮配深墨字） |
| 边框(标准) | `--border-base` | `rgba(55,53,47,.1)` | `rgba(255,255,255,.09)` |
| 边框(更淡) | `--border-soft` | `rgba(55,53,47,.06)` | `rgba(255,255,255,.055)` |
| 边框(略强) | `--border-strong` | `rgba(55,53,47,.16)` | `rgba(255,255,255,.16)` |
| 强调绿 | `--c-accent` | `#059669` | `#10b981` |
| 强调绿 hover | `--c-accent-hover` | `#047857` | `#34d399` |
| 强调绿淡底(色晕) | `--c-accent-soft` | `rgba(16,185,129,.14)` | `rgba(16,185,129,.2)` |
| 强调绿浅填充 | `--c-accent-fill` | `#ecfdf5` | `#123a2c` |
| 成功 / 淡底 | `--c-success` / `--c-success-soft` | `#047857` | `#34d399` |
| 警告 / 淡底 | `--c-warning` / `--c-warning-soft` | `#cb912f` | `#e0b250` |
| 危险 / 淡底 | `--c-danger` / `--c-danger-soft` | `#e03e3e` | `#f06b6b` |
| 阴影 | `--shadow-sm/md/lg` | 极淡黑 | 更深黑 |
| 卡片阴影 | `--shadow-card` | `= --shadow-sm` | `= --shadow-sm` |
| 遮罩 | `--mask` | `rgba(15,15,15,.45)` | `rgba(0,0,0,.6)` |

> 颜色语义可记忆为：**层级 = bg-app → bg-sunken → bg-surface → bg-elevated**；**文字 = strong → (text) → muted → faint**；强调一律 `--c-accent`。
>
> **📌 校准标注（2026-07-17）**：上表三处已按 `tokens.css` 现值订正——`--c-success` 配色对齐后归一 emerald（浅 `#047857`/暗 `#34d399`）；`--c-text-on-accent` 暗色为 `#0f172a`；补登记 `--c-accent-fill`（不透明浅填充，承载 EP light-9 / plain 底，与半透明色晕 `--c-accent-soft` 分工，见《交互设计-管理后台配色对齐客户端.md》）。详见《设计文档校准审计-20260717.md》。

---

## 3. 主题切换机制

- **状态管理**：`stores/theme.js`（Pinia，`useThemeStore`）。`theme`('light'|'dark') + `apply()` / `toggle()` / `init()`。
- **持久化**：`localStorage` key=`ai_theme`。
- **应用方式**：`data-theme` 写到 `<html>`（`document.documentElement`），使 EP 挂在 body 的弹层/消息/抽屉也命中主题。
- **初始化**：`main.js` 调 `useThemeStore().init()`，首屏即应用，刷新保持。
- **默认主题**：`light`（`tokens` 文件外，由 `theme.js` 的 `DEFAULT_THEME` 单点控制；要改默认改这一处。校准订正 2026-07-17：现值 `DEFAULT_THEME='light'`，Notion 经典文档感作首屏；用户可一键切到暗色）。
- **切换入口**：`components/ThemeToggle.vue`（日/月图标，EP `Sunny`/`Moon`）。已放在 **FrontLayout 顶栏** 与 **AdminLayout 顶栏**、**Login 右上角**。全站任意顶栏放 `<ThemeToggle />` 即可，行为一致。

用法：
```vue
import ThemeToggle from '@/components/ThemeToggle.vue'
<ThemeToggle />
```

主题随动（无需手动处理）：EP 组件（变量映射）、md-editor-v3（`MarkdownEditor.vue` 的 `theme` 绑 `themeStore.theme`）。

---

## 4. Element Plus 用法约定

- EP 的 `--el-*` 已在 `theme.css` 两主题下全量映射到我们的语义令牌，**业务页面默认无需再 `:deep` 改 EP 颜色**。
- 主按钮 `type="primary"` = 实心强调绿；默认按钮 hover = 浅灰块。
- 表格/输入/卡片/抽屉/下拉/弹窗已统一 Notion 化（弱边框、小圆角、浅灰 hover）。
- 如个别组件需微调，**只引用语义令牌**，不要写死颜色，且尽量提到 `theme.css` 复用而非散落到页面。

---

## 5. 通用工具类（`theme.css`）

| 类 | 用途 |
|----|------|
| `.surface-block` | Notion 内容块：`--bg-surface` + 弱边框 + `--radius-lg` |
| `.brand-chip` | 品牌标记块（强调底 + 白字 + 小圆角） |
| `.rise-in` | 入场上浮淡入（克制） |

---

## 6. 第二阶段全量铺页套用指引（务必遵守）

1. **零硬编码色值**：任何 `#xxx` / `rgba(数字…)` 一律换成语义令牌。审查红线。
2. **背景按层级取**：页面 `--bg-app`；侧栏/凹陷 `--bg-sunken`；卡片/内容块 `--bg-surface`；浮层/菜单/弹窗 `--bg-elevated`。
3. **文字按四级取**：标题/强调 `--c-text-strong`；正文 `--c-text`；次级 `--c-text-muted`；弱化/占位 `--c-text-faint`。
4. **hover 用 `--bg-hover`**（浅灰块），active 用 `--bg-active`，选中用 `--bg-selected` 或 `--c-accent-soft`。不要在 hover 加位移/辉光/渐变。
5. **边框用 `--border-soft/base/strong`**；卡片用边框为主、阴影为辅（`--shadow-card`）。
6. **圆角用 `--radius-*`**（控制在 sm–lg），间距用 `--space-*`，字号字重用 `--fs-*`/`--fw-*`。
7. **强调一律 `--c-accent`**；语义状态用 `--c-success/warning/danger` 及其 `-soft` 淡底。
8. **可复用样式上提**：多页共用的样式抽到 `theme.css` 工具类或组件，不在各页重复 CSS。
9. **新页顶栏**（若有独立顶栏）放 `<ThemeToggle />`；内容区主动验证 light/dark 两主题均协调。
10. **md 编辑器**统一用 `components/admin/MarkdownEditor.vue`（已随主题切换），不要直接裸用 md-editor-v3。

### 已完成的样板参考（第二阶段照此风格套用）
- 布局：`layouts/FrontLayout.vue`、`layouts/AdminLayout.vue`
- 员工端：`views/Login.vue`、`views/Chat.vue`（含 `components/ReActSteps.vue`、`components/AttachmentCard.vue`）
- 管理端：`views/admin/AdminSkills.vue`（含 `components/admin/AdminSkillEditor.vue` / `SchemaFieldEditor.vue` / `ToolPicker.vue` / `MarkdownEditor.vue`）

### 第二阶段待铺页面（仍引用旧令牌，需逐页改造）
员工端：`BindExpert` / `History` / `Tasks` / `Space` / `Settings` / `Personalize`
管理端：`AdminExperts` / `AdminMcp`(+`McpEditor`) / `AdminApis`(+`ApiEditor`) / `AdminMemory` / `AdminReports`
其他：`SkillEditor` / `DocDetailDrawer` / `PlaceholderPage` / `ExpertSkillBinder` / `AdminExpertEditor`

> 这些页面当前仍引用旧令牌（`--tech-*` / `--grad-*` / `--app-*` / `--text-*` 等已移除），在双主题下颜色会缺失，属第二阶段改造范围，逐页按本规范替换为新语义令牌即可。
