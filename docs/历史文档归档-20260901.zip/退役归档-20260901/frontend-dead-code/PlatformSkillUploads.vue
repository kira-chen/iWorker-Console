<script setup>
/**
 * 用户上传待确认技能（V92，系统配置模块，SYS_CONFIG/ADMIN）。
 *
 * 客户端用户经 POST /api/market/skill-commit 上传的技能先落待确认态（upload_review_state=PENDING_CONFIRM），
 * 不进「平台技能」列表；admin 在本单独页确认后转正进平台技能列表、走后续发布/审批流程。
 *
 * - 读：GET /api/fde/platform-skill-uploads（分页 + keyword 可选，列：名称/描述/工具数/上传用户/上传时间/操作）。
 * - 查看：跳既有整页技能查看器（SysConfigSkillView，platform 源 + 只读）——复用统一详情页，不自建抽屉。
 * - 确认：POST /api/fde/platform-skill-uploads/{skillId}/confirm（确认转正，二次确认弹窗）。
 */
import { ref, reactive, onMounted, watch } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Search } from '@element-plus/icons-vue'
import PageHeader from '@/components/PageHeader.vue'
import { fmtTime } from '@/utils/docMeta'
import { listPendingUploadSkills, confirmUploadedSkill } from '@/api/platformSkill'
// 列宽单一真相源（11 个列表页统一）：不再本页自定数值，避免同语义列在页面间对不齐
import { COL, opsWidth } from '@/utils/tableLayout'
import { useAdminList } from '@/composables/useAdminList'
import ListStates from '@/components/admin/ListStates.vue'
import ListPagination from '@/components/admin/ListPagination.vue'

const router = useRouter()

const busyId = ref(null)

const query = reactive({ keyword: '' })

let searchTimer = null
watch(() => query.keyword, () => {
  clearTimeout(searchTimer)
  searchTimer = setTimeout(reload, 300)
})

// 取数编排统一走 useAdminList（见 docs/frontend/规范-管理后台列表页.md）：
// 四态 / 分页 / 空筛选项过滤 / 防空页回退 / 竞态防护均由其承担，本页只描述「取什么」。
const list = useAdminList(listPendingUploadSkills, { params: () => ({ ...query }) })
const { rows, total, loading, loadError, page, pageSize, isEmpty } = list
const fetchList = list.reload

const reload = list.search


// 查看技能内容：跳既有统一整页技能查看器（platform 源 + 只读），新标签打开（与平台技能列表编辑入口同范式）。
function openDetail(row) {
  const href = router.resolve({ name: 'SysConfigSkillView', params: { id: row.id } }).href
  window.open(href, '_blank')
}

async function confirm(row) {
  try {
    await ElMessageBox.confirm(
      `确认将「${row.name}」加入平台技能？确认后该技能进入平台技能列表，可继续走发布/审批流程。`,
      '确认用户上传技能',
      { confirmButtonText: '确认加入', cancelButtonText: '取消', type: 'warning' }
    )
  } catch {
    return // 用户取消
  }
  busyId.value = row.id
  try {
    await confirmUploadedSkill(row.id)
    ElMessage.success(`已确认「${row.name}」，已加入平台技能`)
    fetchList()
  } catch (e) {
    ElMessage.error(e?.message || '确认失败，请重试')
  } finally {
    busyId.value = null
  }
}

onMounted(fetchList)
</script>

<template>
  <div class="pu-page">
    <PageHeader
      title="用户上传待确认"
      subtitle="客户端用户上传的技能，确认后加入平台技能列表"
    />

    <div class="pu-toolbar">
      <el-input v-model="query.keyword" placeholder="搜索 名称 / 描述" clearable class="pu-search">
        <template #prefix><el-icon><Search /></el-icon></template>
      </el-input>
    </div>

    <div class="table-wrap">
      <ListStates
        :loading="loading"
        :error="loadError"
        :empty="isEmpty"
       
        @retry="fetchList"
      >
        <el-table v-loading="loading" :data="rows" empty-text="暂无待确认的用户上传技能" row-key="id">
          <el-table-column prop="name" label="名称" :min-width="COL.NAME_MIN" />
          <el-table-column label="描述" :min-width="COL.DESC_MIN">
            <template #default="{ row }">
              <span v-if="row.description">{{ row.description }}</span>
              <span v-else class="pu-na">—</span>
            </template>
          </el-table-column>
          <el-table-column label="工具数" :width="COL.COUNT" align="center">
            <template #default="{ row }">{{ row.toolCount ?? 0 }}</template>
          </el-table-column>
          <el-table-column label="上传用户" :width="COL.USER">
            <template #default="{ row }">
              <el-tooltip v-if="row.uploaderId" :content="`用户 ID：${row.uploaderId}`" placement="top">
                <span>{{ row.uploaderName || `用户#${row.uploaderId}` }}</span>
              </el-tooltip>
              <span v-else class="pu-na">{{ row.uploaderName || '未知' }}</span>
            </template>
          </el-table-column>
          <el-table-column label="上传时间" :width="COL.TIME">
            <template #default="{ row }">{{ row.uploadedAt ? fmtTime(row.uploadedAt) : '—' }}</template>
          </el-table-column>
          <el-table-column label="操作" :width="opsWidth(3)" fixed="right">
            <template #default="{ row }">
              <el-button link type="primary" @click="openDetail(row)">查看</el-button>
              <el-button
                link
                type="primary"
                :loading="busyId === row.id"
                @click="confirm(row)"
              >确认加入</el-button>
            </template>
          </el-table-column>
        </el-table>

        <ListPagination
          v-model:page="page"
          :page-size="pageSize"
          :total="total"
          @change="fetchList"
        />
      </ListStates>
    </div>
  </div>
</template>

<style scoped>
.pu-page {
  padding: 4px 2px;
}
.pu-toolbar {
  display: flex;
  gap: 12px;
  margin: 12px 0;
}
.pu-search {
  width: 280px;
}
.pu-na {
  color: var(--el-text-color-placeholder);
}
.pu-pager {
  display: flex;
  justify-content: flex-end;
  margin-top: 16px;
}
</style>
