<script setup>
// 占位页通用组件：标题 + “建设中”
defineProps({
  title: { type: String, default: '' },
  desc: { type: String, default: '该功能正在建设中，敬请期待。' }
})
</script>

<template>
  <div class="placeholder">
    <el-result icon="info" :title="title" :sub-title="desc">
      <template #icon>
        <el-icon class="ph-icon"><Tools /></el-icon>
      </template>
    </el-result>
  </div>
</template>

<style scoped>
.placeholder {
  background: var(--bg-surface);
  border: 1px solid var(--border-base);
  border-radius: var(--radius-lg);
  box-shadow: var(--shadow-card);
  padding: var(--space-12) 0;
}
.placeholder :deep(.el-result__title),
.placeholder :deep(.el-result__subtitle p) {
  color: var(--c-text);
}
.ph-icon {
  font-size: 56px;
  color: var(--c-accent);
}
</style>
