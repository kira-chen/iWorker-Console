// @vitest-environment jsdom
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest'
import { createApp, h, nextTick } from 'vue'
import { createPinia } from 'pinia'

/**
 * PositionWorkbench · 技能编排链路契约（岗位编辑区加固批 #2，2026-08-08）。
 *
 * 白板页此前零测试。本文件不整页快照（1046 行重页面、价值低），只钉**用户会直接撞上的编排分支**：
 *  1. 引用技能：picker 打开时 existingIds 必须是「跨全部 Agent 的已引用集合」（防岗位内重复引用）；
 *  2. 跨泳道迁移失败：按后端错误码分流文案（1002 上限 / 1003 跨岗位 / 其它），
 *     且**失败后必须重拉详情回后端真实态**——否则白板停留在乐观态，界面与库不一致（最危险的一类）；
 *  3. 移除技能：二次确认文案须传达 V84 可逆语义（技能不删、可再拉入），取消则不调 detach；
 *  4. 同泳道调序：本地先排 + 按新序逐条 PUT sortOrder 持久化。
 *
 * 做法：以 AgentLane/SkillPickerDialog 桩把 emit 暴露成可编程触发点，其余重组件全桩，
 * store 用可控 mock —— 测的是页面这一层的编排决策，不是子组件与 store 内部。
 */

const store = {
  positionId: 5,
  loading: false,
  loadError: false,
  basic: { positionId: 5, name: '销售', status: 'draft' },
  agents: [
    { agentId: 'ag_1', name: 'A', skills: [{ skillId: 'sk_1', name: 's1' }] },
    { agentId: 'ag_2', name: 'B', skills: [{ skillId: 'sk_2', name: 's2' }] }
  ],
  allSkills: [
    { agentId: 'ag_1', skill: { skillId: 'sk_1', name: 's1' } },
    { agentId: 'ag_2', skill: { skillId: 'sk_2', name: 's2' } }
  ],
  intakeSchema: [],
  recommendedQuestions: ['', '', '', ''],
  load: vi.fn(() => Promise.resolve()),
  reset: vi.fn(),
  assignSkillToAgent: vi.fn(() => Promise.resolve({})),
  detachSkillFromAgent: vi.fn(() => Promise.resolve()),
  reorderSkillsLocal: vi.fn(),
  patchSkill: vi.fn(() => Promise.resolve({})),
  patchBasic: vi.fn(() => Promise.resolve({})),
  createAgent: vi.fn(),
  renameAgent: vi.fn(),
  removeAgent: vi.fn()
}
vi.mock('@/stores/position', () => ({ usePositionStore: () => store }))

const confirmMock = vi.fn()
const msgError = vi.fn()
const msgSuccess = vi.fn()
vi.mock('element-plus', () => ({
  ElMessage: Object.assign(vi.fn(), { success: msgSuccess, error: msgError, warning: vi.fn(), info: vi.fn() }),
  ElMessageBox: { confirm: (...a) => confirmMock(...a), prompt: vi.fn() }
}))

// 路由：白板页只用到 params/push
vi.mock('vue-router', () => ({
  useRoute: () => ({ params: { id: '5' }, query: {}, meta: {} }),
  useRouter: () => ({ push: vi.fn() }),
  onBeforeRouteLeave: () => {}
}))

// 其余 API 与重组件全桩（本测试只关心编排分支）
vi.mock('@/api/position', () => ({
  listSkills: vi.fn(() => Promise.resolve({ list: [] })),
  publishPosition: vi.fn(() => Promise.resolve({})),
  getPositionVersions: vi.fn(() => Promise.resolve([])),
  uploadIcon: vi.fn(),
  deleteSkill: vi.fn()
}))
vi.mock('@/api/dataTable', () => ({ listDataTables: vi.fn(() => Promise.resolve([])) }))
vi.mock('@/api/toolHealth', () => ({ listUnhealthyTools: vi.fn(() => Promise.resolve([])) }))

/** 暴露子组件 emit 的可编程桩。 */
const laneHandlers = {}
vi.mock('@/components/position/AgentLane.vue', () => ({
  default: {
    name: 'AgentLane',
    props: ['agent'],
    emits: ['pick-skill', 'delete-skill', 'reorder-skills', 'move-skill', 'rename', 'delete', 'focus-skill'],
    setup(props, { emit }) {
      laneHandlers[props.agent.agentId] = emit
      return () => h('div', { class: 'stub-lane' })
    }
  }
}))
let pickerProps = null
vi.mock('@/components/position/SkillPickerDialog.vue', () => ({
  default: {
    name: 'SkillPickerDialog',
    props: ['modelValue', 'existingIds'],
    setup(props) {
      pickerProps = props
      return () => h('div', { class: 'stub-picker' })
    }
  }
}))

for (const p of [
  '@/components/admin/AdminRail.vue',
  '@/components/position/PositionIdentityCard.vue',
  '@/components/position/PositionDataTableStage.vue',
  '@/components/position/PositionSampleTaskStage.vue',
  '@/components/position/PublishCheckDialog.vue',
  '@/components/position/PositionPublishVersionDialog.vue',
  '@/components/position/PositionVersionHistoryDialog.vue',
  '@/components/position/IntakeEditDialog.vue',
  '@/components/position/PersonaEditDialog.vue',
  '@/components/position/RecommendedQuestionsEditor.vue',
  '@/components/position/SkillFocusEditor.vue',
  '@/components/position/SaveStatusIndicator.vue',
  '@/components/position/TermHelp.vue'
]) {
  vi.doMock(p, () => ({ default: { name: 'Stub', setup: () => () => h('div') } }))
}

const PositionWorkbench = (await import('@/views/admin/PositionWorkbench.vue')).default

const stubs = {
  'el-icon': { template: '<i><slot /></i>' },
  'el-button': { emits: ['click'], template: '<button @click="$emit(\'click\')"><slot /></button>' },
  'el-input': { props: ['modelValue'], template: '<input />' },
  'el-tooltip': { template: '<div><slot /></div>' },
  'el-dialog': { template: '<div><slot /><slot name="footer" /></div>' },
  'el-drawer': { template: '<div><slot /></div>' },
  'el-dropdown': { template: '<div><slot /><slot name="dropdown" /></div>' },
  'el-dropdown-menu': { template: '<div><slot /></div>' },
  'el-dropdown-item': { template: '<div><slot /></div>' },
  'el-empty': { template: '<div />' },
  'el-skeleton': { template: '<div />' },
  'el-tag': { template: '<span><slot /></span>' },
  'el-switch': { template: '<span />' },
  'el-select': { template: '<div><slot /></div>' },
  'el-option': { template: '<div />' }
}

let app, container
function mount() {
  container = document.createElement('div')
  document.body.appendChild(container)
  app = createApp(PositionWorkbench)
  app.use(createPinia()) // 页面内还有其它 store（非本测试关注点），装 pinia 让它们正常初始化
  app.directive('loading', {})
  for (const [n, c] of Object.entries(stubs)) app.component(n, c)
  app.config.warnHandler = () => {}
  app.mount(container)
  return container
}

beforeEach(() => {
  vi.clearAllMocks()
  // 本环境 jsdom 未提供 localStorage（user/companion store 会读）——沿用 reports.test.js 既有内存桩范式
  if (!('localStorage' in globalThis) || typeof globalThis.localStorage?.getItem !== 'function') {
    const mem = new Map()
    globalThis.localStorage = {
      getItem: (k) => (mem.has(k) ? mem.get(k) : null),
      setItem: (k, v) => mem.set(k, String(v)),
      removeItem: (k) => mem.delete(k),
      clear: () => mem.clear()
    }
  }
  confirmMock.mockResolvedValue()
  store.assignSkillToAgent.mockResolvedValue({})
  store.detachSkillFromAgent.mockResolvedValue()
  store.patchSkill.mockResolvedValue({})
})
afterEach(() => {
  app?.unmount()
  container?.remove()
  pickerProps = null
})

describe('PositionWorkbench · 技能编排链路契约', () => {
  it('引用技能：picker 的 existingIds = 跨全部 Agent 的已引用集合（防岗位内重复引用）', async () => {
    mount()
    await nextTick()
    expect(pickerProps).toBeTruthy()
    expect([...pickerProps.existingIds].sort()).toEqual(['sk_1', 'sk_2'])
  })

  it('跨泳道迁移成功 → 调 assign 端点并提示成功', async () => {
    mount()
    await nextTick()
    laneHandlers.ag_1('move-skill', { skillId: 'sk_2', fromAgentId: 'ag_2', toAgentId: 'ag_1' })
    await nextTick()
    await nextTick()
    expect(store.assignSkillToAgent).toHaveBeenCalledWith('sk_2', 'ag_1')
    expect(msgSuccess).toHaveBeenCalled()
    expect(store.load).not.toHaveBeenCalledWith(5) // 成功路径不重拉
  })

  it('迁移失败(1002 上限) → 专用文案 + 重拉详情回后端真实态（防白板停在乐观态）', async () => {
    const err = new Error('boom')
    err.code = 1002
    store.assignSkillToAgent.mockRejectedValue(err)
    mount()
    await nextTick()
    store.load.mockClear()
    laneHandlers.ag_1('move-skill', { skillId: 'sk_2', fromAgentId: 'ag_2', toAgentId: 'ag_1' })
    await nextTick()
    await nextTick()
    expect(msgError).toHaveBeenCalledWith(expect.stringContaining('技能数已达上限'))
    expect(store.load).toHaveBeenCalledWith(5)
  })

  it('迁移失败(1003 跨岗位) → 专用文案 + 同样重拉详情', async () => {
    const err = new Error('boom')
    err.code = 1003
    store.assignSkillToAgent.mockRejectedValue(err)
    mount()
    await nextTick()
    store.load.mockClear()
    laneHandlers.ag_1('move-skill', { skillId: 'sk_9', fromAgentId: 'ag_2', toAgentId: 'ag_1' })
    await nextTick()
    await nextTick()
    expect(msgError).toHaveBeenCalledWith(expect.stringContaining('不属于本岗位'))
    expect(store.load).toHaveBeenCalledWith(5)
  })

  it('同 Agent 内 move（from===to）→ 不调 assign（无意义请求）', async () => {
    mount()
    await nextTick()
    laneHandlers.ag_1('move-skill', { skillId: 'sk_1', fromAgentId: 'ag_1', toAgentId: 'ag_1' })
    await nextTick()
    expect(store.assignSkillToAgent).not.toHaveBeenCalled()
  })

  it('移除技能：确认文案传达 V84 可逆语义（不删除/可再拉入），确认后调 detach', async () => {
    mount()
    await nextTick()
    laneHandlers.ag_1('delete-skill', { agentId: 'ag_1', skillId: 'sk_1' })
    await nextTick()
    expect(confirmMock).toHaveBeenCalled()
    const [msg] = confirmMock.mock.calls[0]
    expect(msg).toContain('技能不会被删除')
    expect(msg).toContain('再次拉入')
    await nextTick()
    expect(store.detachSkillFromAgent).toHaveBeenCalledWith('ag_1', 'sk_1')
  })

  it('移除技能取消 → 不调 detach', async () => {
    confirmMock.mockRejectedValue(new Error('cancel'))
    mount()
    await nextTick()
    laneHandlers.ag_1('delete-skill', { agentId: 'ag_1', skillId: 'sk_1' })
    await nextTick()
    await nextTick()
    expect(store.detachSkillFromAgent).not.toHaveBeenCalled()
  })

  it('同泳道调序 → 本地先排 + 按新序逐条 PUT sortOrder', async () => {
    mount()
    await nextTick()
    const next = [{ skillId: 'sk_b' }, { skillId: 'sk_a' }]
    laneHandlers.ag_1('reorder-skills', 'ag_1', next)
    await nextTick()
    await nextTick()
    expect(store.reorderSkillsLocal).toHaveBeenCalledWith('ag_1', next)
    expect(store.patchSkill).toHaveBeenCalledWith('sk_b', { sortOrder: 0 })
    expect(store.patchSkill).toHaveBeenCalledWith('sk_a', { sortOrder: 1 })
  })
})
