// @vitest-environment jsdom
import { describe, it, expect } from 'vitest'
import router from '@/router'

/**
 * 技能三页合一（2026-08-23）：**真实路由表**上的角色门一致性守卫。
 *
 * <p>与 guard.test.js 的分工：那边用构造出来的路由对象测**守卫函数**的判定逻辑（node 环境即可）；
 * 本文件查 router/index.js 里**实际写下的 meta.roles**——本类回归就发生在那里，构造对象覆盖不到。
 * （import @/router 会执行 createWebHistory，需要 window，故本文件单独声明 jsdom。）</p>
 *
 * <p><b>为什么必须钉住</b>：三页合一后列表页放开到三类后台角色，但三个编辑器路由一度仍保留着
 * 三页时代的角色划分（AdminSkillEdit=['FDE','ADMIN']、两个平台编辑器=['SYS_CONFIG','ADMIN']）。
 * 净效果：FDE 打开技能页 → 看得见平台技能行 → 点「编辑」→ 新标签被前端守卫弹回。
 * 这正是权限合并（V107）要消灭的「读得到、改不动」，只是从后端 403 变成了前端拦截。</p>
 */
describe('技能页与编辑器：真实路由表的角色门一致性', () => {
  const rolesOf = (name) => router.getRoutes().find((r) => r.name === name)?.meta?.roles

  // 合并页按 row.type 分流到这三条编辑路由（见 api/unifiedSkill.js 的 SKILL_EDIT_ROUTE）。
  const EDIT_ROUTES = ['AdminSkillEdit', 'SysConfigSkillEdit', 'SysConfigSystemSkillEdit']

  it('列表页 AdminSkillsUnified 对三类后台角色开放（否则原三页下线后有角色完全没有技能入口）', () => {
    expect(rolesOf('AdminSkillsUnified')).toEqual(
      expect.arrayContaining(['FDE', 'SYS_CONFIG', 'ADMIN'])
    )
  })

  it.each(EDIT_ROUTES)('%s 的角色门不窄于列表页（防「看得见、点不开」）', (name) => {
    const listRoles = rolesOf('AdminSkillsUnified')
    const editRoles = rolesOf(name)
    expect(editRoles, `${name} 路由不存在`).toBeTruthy()
    for (const role of listRoles) {
      expect(editRoles, `${name} 缺角色 ${role}：该角色在列表能看见此类行，点编辑却会被弹回`)
        .toContain(role)
    }
  })

  it.each(EDIT_ROUTES)('%s 的 activeMenu 指向合并页（编辑器自带侧栏，高亮不能落到已删入口）', (name) => {
    const rec = router.getRoutes().find((r) => r.name === name)
    expect(rec.meta.activeMenu).toBe('AdminSkillsUnified')
  })

  it('放宽不等于对所有人开放：EMPLOYEE 不在任何技能路由的角色门内', () => {
    for (const name of ['AdminSkillsUnified', ...EDIT_ROUTES]) {
      expect(rolesOf(name), `${name} 不应放行 EMPLOYEE`).not.toContain('EMPLOYEE')
    }
  })
})
