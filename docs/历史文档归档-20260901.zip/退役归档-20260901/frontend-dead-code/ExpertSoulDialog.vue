<script setup>
/**
 * 专家「职责描述」编辑弹窗（SYS_CONFIG 专家配置台）。
 *
 * 【当前无调用方】职责描述编辑器已就地内嵌进 ExpertEditor 抽屉（2026-08-23），本弹窗不再被引用。
 * 暂留待确认是否清理；此处文案同步改名，避免日后被复用时又冒出旧称「Soul」。
 *
 * 复用岗位人格同款 Markdown 所见即所得编辑器（{@link SkillMilkdownEditor}，无工具引用），
 * 与「岗位配置」的人格编辑体验一致——只是专家侧不含领用文案/推荐问题，故不整体复用
 * {@code PersonaEditDialog}（那是岗位专属聚合弹窗），只取其中的人格编辑器这一块。
 *
 * 数据流：编辑器实时 emit → v-model 回写父级 form.roleDesc；保存沿用配置页「手动保存」
 * （顶部条保存按钮 + basicDirty），本弹窗仅作编辑容器、不持有保存职责。
 * close-on-click-modal=false + 禁 Esc 关闭（全站弹窗统一，防误触丢编辑态）。
 */
import { computed } from 'vue'
import SkillMilkdownEditor from '@/components/position/SkillMilkdownEditor.vue'

const SOUL_SOFT_LIMIT = 2000

const props = defineProps({
  visible: { type: Boolean, default: false },
  /** 专家职责描述（markdown 文本，对应 domain_expert.role_desc）。 */
  modelValue: { type: String, default: '' }
})
const emit = defineEmits(['update:visible', 'update:modelValue'])

const soulLen = computed(() => (props.modelValue || '').length)
</script>

<template>
  <el-dialog
    :model-value="visible"
    title="编辑职责描述"
    width="820px"
    :close-on-click-modal="false"
    :close-on-press-escape="false"
    append-to-body
    @update:model-value="emit('update:visible', $event)"
  >
    <div class="es-sec">
      <div class="es-sec-title">
        专家职责描述
        <span class="es-sec-sub">
          我是谁 · 擅长什么 · 以什么风格回答 · markdown（@ 委派时子 agent 据此拼装人设）
        </span>
        <span class="es-hint" :class="{ over: soulLen > SOUL_SOFT_LIMIT }">
          {{ soulLen }} / {{ SOUL_SOFT_LIMIT }}
        </span>
      </div>
      <div class="es-mde">
        <SkillMilkdownEditor
          :model-value="modelValue"
          height="400px"
          placeholder="你是……专家，专注……。你擅长：1) … 2) …。回答风格：稳、细、主动、有分寸。"
          @update:model-value="emit('update:modelValue', $event)"
        />
      </div>
    </div>

    <template #footer>
      <el-button type="primary" @click="emit('update:visible', false)">完成</el-button>
    </template>
  </el-dialog>
</template>

<style scoped>
.es-sec {
  display: flex;
  flex-direction: column;
}
.es-sec-title {
  display: flex;
  align-items: baseline;
  gap: var(--space-2);
  font-size: var(--fs-sm);
  font-weight: var(--fw-semibold);
  color: var(--c-text-strong);
  margin-bottom: var(--space-2);
}
.es-sec-sub {
  font-size: var(--fs-xs);
  font-weight: var(--fw-regular);
  color: var(--c-text-faint);
}
.es-hint {
  margin-left: auto;
  font-size: var(--fs-xs);
  color: var(--c-text-faint);
}
.es-hint.over {
  color: var(--c-warning);
}
.es-mde {
  border: 1px solid var(--border-base);
  border-radius: var(--radius-md);
  overflow: hidden;
}
</style>
