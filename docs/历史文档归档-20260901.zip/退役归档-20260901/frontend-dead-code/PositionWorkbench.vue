<script setup>
/**
 * 白板工作台（交互规格全篇 13 项决议）。
 *
 * 沉浸式编排页：顶部条 + 白板（总览态：身份卡 + Agent 泳道 + 技能卡）+ 数据底座弹窗。
 *
 * 技能编辑（设计 §5 改造）：点技能卡 / 新建技能 → 新标签打开整页编辑器（AdminSkillEdit），
 * 白板内不再有聚焦浮层（SkillFocusEditor 已退役）；回到白板标签（window focus）时轻量 refetch 同步。
 *
 * 保存：
 * - 身份卡改动（含人格/采集弹窗内编辑）debounce 自动保存（顶部「已自动保存」）；
 * - 顶部「保存」显式跑校验；「发布」走发布前检查。
 */
import { ref, computed, watch, onMounted, onBeforeUnmount, defineAsyncComponent } from 'vue'
import { useRoute, useRouter, onBeforeRouteLeave } from 'vue-router'
import { ElMessage, ElMessageBox } from 'element-plus'
import { usePositionStore } from '@/stores/position'
import { createPosition, publishPosition, getNextVersionLabel } from '@/api/position'
import { useVersionPublish } from '@/composables/useVersionPublish'
import { listDataTables } from '@/api/dataTable'
import { computePublishCheck, normalizeIntakeForSubmit, validateIntakeRows, normalizePublishWarnings, normalizeRecommendedQuestions, recommendedQuestionsComplete, LIMITS } from '@/utils/positionModel'
import { EFFECT_TEST_ENABLED } from '@/utils/featureFlags'
import SkillPickerDialog from '@/components/position/SkillPickerDialog.vue'
import StatusTag from '@/components/StatusTag.vue'
import ThemeToggle from '@/components/ThemeToggle.vue'
import PositionIdentityCard from '@/components/position/PositionIdentityCard.vue'
import PersonaEditDialog from '@/components/position/PersonaEditDialog.vue'
import IntakeEditDialog from '@/components/position/IntakeEditDialog.vue'
import AgentLane from '@/components/position/AgentLane.vue'
import PositionDataTableStage from '@/components/position/PositionDataTableStage.vue'
import PositionSampleTaskStage from '@/components/position/PositionSampleTaskStage.vue'
import PublishCheckDialog from '@/components/position/PublishCheckDialog.vue'
import PositionVersionHistoryDialog from '@/components/position/PositionVersionHistoryDialog.vue'
import AdminRail from '@/components/admin/AdminRail.vue'
// 效果测试台异步加载：仅在点「效果测试」打开时拉取，避免把对话链路提前并入白板首屏 + 保持现有测试 import 图不变。
const EffectTestStage = defineAsyncComponent(() => import('@/components/test/EffectTestStage.vue'))

const route = useRoute()
const router = useRouter()
const store = usePositionStore()

const isNew = computed(() => route.params.id === 'new')

/* ---------- 效果测试台（纯前端 demo，就地扮演终端用户试跑该岗位） ---------- */
const testStageOpen = ref(false)
function openTest() {
  // 把当前岗位对象（basic + agents + 数据表数）传入；缺字段由测试台 mock 兜底。
  testStageOpen.value = true
}
function closeTest() {
  testStageOpen.value = false
}

/* ---------- 加载 ---------- */
const autosaveText = ref('')
const intakeErrors = ref({})

// 延迟骨架屏（闪烁修复）：仅当加载持续 >250ms 才显骨架，避免缓存/快响应时骨架一闪而过的「闪屏」感。
const showSkeleton = ref(false)
let skeletonTimer = null
watch(
  () => store.loading,
  (v) => {
    clearTimeout(skeletonTimer)
    if (v) {
      skeletonTimer = setTimeout(() => { showSkeleton.value = true }, 250)
    } else {
      showSkeleton.value = false
    }
  }
)

onMounted(async () => {
  if (isNew.value) {
    store.initNew()
  } else {
    try {
      await store.load(route.params.id)
      // 岗位详情就绪后轻量预取数据表数量，供身份卡「数据底座」入口徽标显示
      prefetchDtCount()
    } catch {
      /* error 态由 store.error 呈现 */
    }
  }
  document.addEventListener('click', onSearchClickOutside)
  // 整页编辑器在新标签编完关掉、焦点回白板 → 轻量 refetch 当前岗位（设计 §5.4，对齐 AdminSkills）。
  window.addEventListener('focus', onWindowFocus)
  document.addEventListener('visibilitychange', onVisibilityChange)
})
onBeforeUnmount(() => {
  document.removeEventListener('click', onSearchClickOutside)
  window.removeEventListener('focus', onWindowFocus)
  document.removeEventListener('visibilitychange', onVisibilityChange)
  clearTimeout(basicTimer)
  clearTimeout(skeletonTimer)
  store.reset()
})

// 回到白板标签（窗口聚焦 / 可见）时对当前岗位轻量 refetch，避免整页改名/删技能后看到旧态（§5.4）。
async function refetchOnReturn() {
  if (store.positionId == null) return
  // 防数据丢失：若有 pending 的基本信息自动保存（编辑后 2s debounce 未到点就切走了标签），
  // 先 flush 该保存，再 silent refetch——否则 silent load 会 hydrate 服务端旧值覆盖未存的本地编辑
  // （且随后被 deep watch 以旧值重存）→ 丢改动。flush 后服务端=最新，refetch 安全。
  if (basicSavePending) {
    clearTimeout(basicTimer) // 取消排队的 debounce 定时器，避免稍后重复保存
    await doSaveBasic(true) // doSaveBasic 内部已清 basicSavePending
  }
  // 静默刷新：不切骨架屏，避免每次切回白板标签整页闪一下（窗口聚焦/可见性回切闪烁修复）。
  store.load(store.positionId, { silent: true })
}
// wasHidden 门：只有标签真被隐藏过再回来才 refetch；纯页内点击不触发（修「点击即刷新」，window focus 在嵌入式下每点必触发）。
let wasHidden = false
function onWindowFocus() {
  if (wasHidden) {
    wasHidden = false
    refetchOnReturn()
  }
}
function onVisibilityChange() {
  if (document.visibilityState === 'hidden') {
    wasHidden = true
  } else if (document.visibilityState === 'visible' && wasHidden) {
    wasHidden = false
    refetchOnReturn()
  }
}

/* ---------- 身份卡（双向） ---------- */
const basic = computed({
  get: () => store.basic,
  set: (v) => {
    store.basic = v
  }
})

/* ---------- 身份卡自动保存（debounce 2s） ---------- */
let basicTimer = null
let basicSavePending = false // 有未到点的 debounce 自动保存在排队（供 refetchOnReturn 守卫，防覆盖未存编辑）
const hasPositionId = computed(() => store.positionId != null)

function scheduleBasicSave() {
  if (isNew.value && !hasPositionId.value) return // 新建未落库：等首次显式保存
  clearTimeout(basicTimer)
  basicSavePending = true
  basicTimer = setTimeout(() => doSaveBasic(true), 2000)
}
watch(
  () => store.basic,
  () => scheduleBasicSave(),
  { deep: true }
)

function buildBasicPayload() {
  const b = store.basic
  const payload = {
    name: b.name,
    intro: b.intro,
    icon: b.icon,
    iconSource: b.iconSource,
    // claimDesc 多条数组 [{emoji,content}]（content 富文本由后端 Jsoup 净化）；welcome/sopDoc 已退役不上送（设计 §2）
    claimDesc: b.claimDesc,
    persona: b.persona,
    intakeSchema: normalizeIntakeForSubmit(b.intakeSchema)
  }
  // N4 推荐问题（部分更新语义）：仅当 4 格全部填好才随保存下发（后端要求非 null 时恰好 4 个且非空）；
  // 未填满时不上送该字段（=不改），避免 debounce 静默自动保存因半填被后端校验拦下。
  const rq = normalizeRecommendedQuestions(b.recommendedQuestions)
  if (recommendedQuestionsComplete(rq)) payload.recommendedQuestions = rq.map((q) => q.trim())
  return payload
}

async function doSaveBasic(silent) {
  // 进入保存即认为 pending 已被消费（无论来源：debounce 定时器 / 显式保存 / refetch flush），
  // 避免守卫读到陈旧 pending 标记。
  basicSavePending = false
  if (!hasPositionId.value) return
  // 采集字段前端轻校验
  const { ok, errors } = validateIntakeRows(store.basic.intakeSchema || [])
  intakeErrors.value = errors
  if (!ok) {
    if (!silent) ElMessage.warning('采集字段有误，请修正后保存')
    return
  }
  try {
    const { warnings } = await store.saveBasic(buildBasicPayload())
    autosaveText.value = '已自动保存 · 刚刚'
    if (!silent) {
      ElMessage.success(warnings.length ? `已保存（${warnings.length} 项提示）` : '已保存')
    }
  } catch (e) {
    if (e?.field) {
      // 字段级回显（采集 key/name 等）
      ElMessage.error(e.message || '保存失败')
    } else if (!silent) {
      ElMessage.error(e?.message || '保存失败')
    } else {
      autosaveText.value = '自动保存失败，已保留本地内容'
    }
  }
}

/* ---------- 新建态首次落库 ---------- */
async function ensurePersisted() {
  if (hasPositionId.value) return true
  if (!String(store.basic.name || '').trim()) {
    ElMessage.warning('请先填写岗位名')
    return false
  }
  try {
    const data = await createPosition(buildBasicPayload())
    store.hydrate(data)
    // 路由切到真实 id（replace，避免回退到 new）
    router.replace({ name: 'PositionWorkbench', params: { id: data.positionId } })
    return true
  } catch (e) {
    ElMessage.error(e?.message || '创建失败')
    return false
  }
}

/* ---------- Agent 增删改 ---------- */
const agentAtLimit = computed(() => store.agents.length >= LIMITS.AGENT_MAX)

async function addAgent() {
  if (!(await ensurePersisted())) return
  if (agentAtLimit.value) {
    ElMessage.warning(`单岗位最多 ${LIMITS.AGENT_MAX} 个 Agent`)
    return
  }
  try {
    await store.addAgent({ name: '新 Agent', sortOrder: store.agents.length })
  } catch (e) {
    ElMessage.error(e?.message || '新建 Agent 失败')
  }
}
async function onAgentRename(agentId, payload) {
  try {
    await store.patchAgent(agentId, payload)
  } catch (e) {
    ElMessage.error(e?.message || (e?.field === 'name' ? 'Agent 名已存在' : '保存失败'))
  }
}
async function onAgentDelete(agentId) {
  try {
    const res = await store.removeAgent(agentId)
    const n = res?.orphanedSkillCount ?? 0
    if (n > 0) {
      // PRD §3.3：删后提示 N 个技能已变「未被引用」+ 直达技能页（自动应用「未被引用」筛选）的跳转链接。
      ElMessage({
        type: 'success',
        duration: 6000,
        showClose: true,
        dangerouslyUseHTMLString: true,
        message:
          `已删除 Agent · ${n} 个技能已变为「未被引用」。` +
          `<a class="wb-toast-link" data-goto-skills="1" style="margin-left:6px;color:var(--c-accent);cursor:pointer;text-decoration:underline">去技能页查看</a>`,
        onClose: () => {}
      })
      // ElMessage 的 HTML 内 a 无法直接绑 Vue 事件 → 用一次性事件委托捕获点击跳转。
      bindToastSkillsJump()
    } else {
      ElMessage.success('已删除空 Agent')
    }
  } catch (e) {
    ElMessage.error(e?.message || '删除失败')
  }
}

// 跳转技能页并自动应用「未被引用」筛选（PRD §3.3）。用路由 query 携带筛选意图，「技能」页进入时读取
// （2026-08-23 三页合一：原 AdminSkills 已下线，合并页 AdminSkillsUnified 消费该 query 并同时钉类型=岗位私有）。
function gotoUnreferencedSkills() {
  router.push({ name: 'AdminSkillsUnified', query: { referenced: 'no' } })
}
// 给当前 toast 内「去技能页查看」链接绑一次性点击（ElMessage HTML 不支持 Vue 事件，用事件委托兜一次）。
function bindToastSkillsJump() {
  const handler = (e) => {
    const t = e.target
    if (t && t.getAttribute && t.getAttribute('data-goto-skills') === '1') {
      document.removeEventListener('click', handler, true)
      gotoUnreferencedSkills()
    }
  }
  document.addEventListener('click', handler, true)
  // 8s 后无论是否点击都解绑，防泄漏。
  setTimeout(() => document.removeEventListener('click', handler, true), 8000)
}

/* ---------- 技能整页编辑（设计 §5：移除聚焦浮层，改新标签开整页编辑器） ---------- */
// 新标签打开整页技能编辑器（对齐 AdminSkills.openEditorTab 范式）。
function openSkillFullPage(skillId) {
  const href = router.resolve({ name: 'AdminSkillEdit', params: { id: skillId } }).href
  window.open(href, '_blank')
}

/* ---------- 技能引用（岗位页只引用「已发布」技能，不创建；创建/管理在「技能」页） ---------- */
/* 从技能库引用已发布 FDE 技能（V84 引用模型） */
const pickSkillVisible = ref(false)
const pickSkillAgentId = ref(null)
// 本岗位已引用的技能 id 集合（跨全部 Agent）：picker 据此置灰，防岗位内重复引用。
const positionSkillIds = computed(() =>
  store.allSkills.map((x) => x.skill?.skillId).filter(Boolean)
)
function onPickSkill(agentId) {
  pickSkillAgentId.value = agentId
  pickSkillVisible.value = true
}
async function onSkillPicked(skillId) {
  try {
    await store.assignSkillToAgent(skillId, pickSkillAgentId.value)
    ElMessage.success('已引用技能到该 Agent')
  } catch (e) {
    ElMessage.error(e?.message || '引用失败')
  }
}
async function onReorderSkills(agentId, newSkills) {
  store.reorderSkillsLocal(agentId, newSkills)
  // 逐条 PUT sortOrder 持久化（决议 9 整体 PUT 思路，最小代价）
  try {
    await Promise.all(
      newSkills.map((s, i) => store.patchSkill(s.skillId, { sortOrder: i }))
    )
  } catch (e) {
    ElMessage.error('调序保存失败')
  }
}
// Agent↔Agent 跨泳道迁移：走 assign 端点（PUT /skills/{id}/assign）。收纳区退役后，仅服务白板内
// 把技能从一个 Agent 拖到另一个 Agent。
async function assignSkillTo(skillId, fromAgentId, toAgentId) {
  if (fromAgentId === toAgentId) return
  const target = store.agents.find((a) => a.agentId === toAgentId)
  try {
    await store.assignSkillToAgent(skillId, toAgentId)
    ElMessage.success(`已分配技能到 ${target?.name || 'Agent'}`)
  } catch (e) {
    // 1002 该 Agent 技能数上限 / 1003 跨岗位非法 / 其它
    if (e?.code === 1002) {
      ElMessage.error(`${target?.name || '该 Agent'} 技能数已达上限`)
    } else if (e?.code === 1003) {
      ElMessage.error('该技能不属于本岗位，无法分配')
    } else {
      ElMessage.error(e?.message || '分配失败')
    }
    // 失败：重拉详情回到后端真实态
    store.load(store.positionId)
  }
}

function onMoveSkill({ skillId, fromAgentId, toAgentId }) {
  assignSkillTo(skillId, fromAgentId, toAgentId)
}

/* ---------- 数据底座：三栏聚焦弹窗（身份卡入口打开） ---------- */
const dtStageOpen = ref(false)
const dtTableCount = ref(0)
const dtCountLoading = ref(false)

// 首屏轻量预取一次数据表数量，供身份卡入口徽标显示（新建岗位未落库 → 0）。
async function prefetchDtCount() {
  if (store.positionId == null) {
    dtTableCount.value = 0
    return
  }
  dtCountLoading.value = true
  try {
    const data = await listDataTables(store.positionId)
    dtTableCount.value = (data?.list || []).length
  } catch {
    /* 预取失败：徽标降级显示「暂无表」，打开 stage 后会以真实列表回吐覆盖 */
  } finally {
    dtCountLoading.value = false
  }
}

// 点身份卡「数据底座」入口：若岗位未落库先 ensurePersisted（与 addAgent 同款，岗位名空则提示先填名），
// 落库成功后打开三栏弹窗（此时 positionId 已就绪，避免越权/报错）。
async function onOpenDataTable() {
  if (!(await ensurePersisted())) return
  dtStageOpen.value = true
}

/* ---------- 样例任务：两栏聚焦弹窗（顶部条「⏰ 样例任务」入口打开，与数据底座同款 ensurePersisted） ---------- */
const sampleStageOpen = ref(false)
const sampleTaskCount = ref(0)

// 与 onOpenDataTable 同款：岗位未落库先 ensurePersisted（样例是岗位级资产，须先有 positionId 才能挂载）。
async function onOpenSampleTasks() {
  if (!(await ensurePersisted())) return
  sampleStageOpen.value = true
}

/* ---------- 人格 / 采集 编辑弹窗（设计 §4：替代原折叠块） ---------- */
const personaDialogOpen = ref(false)
const intakeDialogOpen = ref(false)
// N4：推荐问题逐格红框开关。仅在发布门被拦（半填/空）或用户显式点开人格弹窗校验时置 true，
// 日常打字不硬拦（半填静默不下发的现状保持），只在发布门显式校验时逐格标红。
const rqShowErrors = ref(false)
// 打开人格弹窗时复位红框（避免上次发布拦截的残留红框在下次编辑时突兀常驻）。
watch(personaDialogOpen, (open) => {
  if (!open) rqShowErrors.value = false
})

// 白板画布滚动容器（数据底座弹窗 .focus-mode 复用其退背后视觉；非聚焦态用）
const boardRef = ref(null)

// 反馈 4 修复「切页面时弹窗下遮罩闪一下」：append-to-body 的 el-dialog/弹窗 .el-overlay 挂在 body 上，
// 路由离开时组件直接卸载会让遮罩被异步突兀移除（闪一下）。改为离开路由前先关闭所有弹窗/数据底座，
// 让 Vue 过渡正常收起遮罩，再卸载组件——遮罩平滑消失，无闪烁。
onBeforeRouteLeave(() => {
  personaDialogOpen.value = false
  intakeDialogOpen.value = false
  dtStageOpen.value = false
  sampleStageOpen.value = false
  // 同页其它 append-to-body 浮层一并复位，避免遮罩在卸载时残留闪烁（CR 一致性）。
  // 注：这两个 ref 在下方声明，回调在导航时（setup 完成后）才执行，闭包引用安全。
  publishDialogVisible.value = false
  testStageOpen.value = false
})

/* ============================ 技能从 Agent 移除（V84 引用模型：可逆 detach） ============================
 * 从 Agent 移除 = 删该 Agent 对技能的引用行；技能本体留在库里、可在「技能」页查看，也可再拉入任意 Agent。
 * 取代旧「解绑=彻底游离、不可逆」语义（后端 detach 端点：DELETE /fde/agents/{agentId}/skills/{skillId}）。 */
async function onDeleteSkill({ agentId, skillId }) {
  // 取技能名让确认文案更明确（取不到则用「这个技能」兜底）。
  const hit = store.allSkills.find((x) => x.skill?.skillId === skillId)
  const skillName = hit?.skill?.name || '这个技能'
  try {
    await ElMessageBox.confirm(
      `将「${skillName}」从当前 Agent 移除？技能不会被删除，仍可在「技能」页查看，也可再次拉入本 Agent 或其它 Agent。`,
      '从 Agent 移除技能',
      {
        type: 'warning',
        confirmButtonText: '移除',
        cancelButtonText: '取消'
      }
    )
  } catch {
    return
  }
  try {
    await store.detachSkillFromAgent(agentId, skillId)
    ElMessage.success('已移除 · 技能留在「技能」页，可再次拉入')
  } catch (e) {
    ElMessage.error(e?.message || '移除失败')
  }
}

/* ============================ 全局技能搜索（§6.1） ============================ */
const searchKeyword = ref('')
const searchOpen = ref(false)
const searchActive = ref(-1) // 键盘高亮项索引（UI2）
const searchRef = ref(null) // 搜索容器，用于点击外部关闭（UI3）
const searchResults = computed(() => {
  const kw = searchKeyword.value.trim().toLowerCase()
  if (!kw) return []
  return store.allSkills
    .filter((x) => (x.skill.name || '').toLowerCase().includes(kw))
    .slice(0, 12)
})
function pickSearchResult(item) {
  closeSearch()
  searchKeyword.value = ''
  // 搜中技能 → 新标签开整页编辑器（设计 §5.2，原 enterFocus 退役）
  openSkillFullPage(item.skill.skillId)
}
function closeSearch() {
  searchOpen.value = false
  searchActive.value = -1
}
// 键盘上下键 + 回车选中（UI2）
function onSearchKeydown(e) {
  if (!searchOpen.value || !searchResults.value.length) return
  if (e.key === 'ArrowDown') {
    e.preventDefault()
    searchActive.value = (searchActive.value + 1) % searchResults.value.length
  } else if (e.key === 'ArrowUp') {
    e.preventDefault()
    searchActive.value =
      (searchActive.value - 1 + searchResults.value.length) % searchResults.value.length
  } else if (e.key === 'Enter') {
    const item = searchResults.value[searchActive.value] ?? searchResults.value[0]
    if (item) pickSearchResult(item)
  }
}
// 输入变化时重置高亮（避免指向越界项）
function onSearchInput() {
  searchOpen.value = true
  searchActive.value = -1
}
// 点击外部关闭下拉（UI3）
function onSearchClickOutside(e) {
  if (searchOpen.value && searchRef.value && !searchRef.value.contains(e.target)) closeSearch()
}

/* ============================ 顶部条：保存 / 发布 / 下架 ============================ */
const publishDialogVisible = ref(false)
const publishing = ref(false)
const publishCheck = computed(() => computePublishCheck(store.checkInput))

/* ---------- N5 发布版本号 + 升级说明（编排收敛到 useVersionPublish；行为不变） ---------- */
// atMax/nextLoading 别名回本组件既有模板变量名（versionAtMax/nextLabelLoading），保持模板与测试引用不变。
const {
  versionLabel, // 展示版本号 v001~v999（打开发布页自动带出建议号）
  releaseNotes, // 升级说明（必填）
  prevMaxLabel, // 历史最大版本号（供"建议递增"软提示）
  atMax: versionAtMax, // 已到 v999 上限（禁用版本框 + 人话提示）
  nextLoading: nextLabelLoading,
  load: loadNextVersionLabel
} = useVersionPublish({ fetchNextLabel: () => getNextVersionLabel(store.positionId) })

// 版本历史对话框（管理侧 §6.6 C/D）：仅已发布岗位有版本快照可看/下线。
const versionHistoryVisible = ref(false)
function openVersionHistory() {
  versionHistoryVisible.value = true
}

async function explicitSave() {
  // 技能整页化后白板无聚焦态，技能保存在整页编辑器自管；此处只存身份卡基本信息。
  if (!(await ensurePersisted())) return
  await doSaveBasic(false)
}

async function openPublish() {
  if (!(await ensurePersisted())) return
  // 先存一遍身份卡当前内容
  await doSaveBasic(true)
  // N4 发布门：4 个推荐问题必须全部填写，否则拦下发布并把用户带到人格弹窗逐格标红指出哪格空。
  // （半填在 buildBasicPayload 里静默不下发，若不在此硬拦，用户填 2 格就能发布 → 客户端拿不到推荐问题。）
  if (!recommendedQuestionsComplete(store.basic.recommendedQuestions)) {
    rqShowErrors.value = true
    personaDialogOpen.value = true
    ElMessage.warning('请把 4 个推荐问题都填好再发布')
    return
  }
  // N5：打开即带出建议的下一个版本号；load 内部会清空升级说明（每次发布重填，必填）。
  publishDialogVisible.value = true
  loadNextVersionLabel()
}

async function doPublish() {
  publishing.value = true
  try {
    const res = await publishPosition(store.positionId, {
      versionLabel: versionLabel.value.trim(),
      releaseNotes: releaseNotes.value.trim()
    })
    const w = normalizePublishWarnings(res?.warnings)
    publishDialogVisible.value = false
    await store.load(store.positionId)
    if (w.count) {
      const lines = w.items
        .map((i) => `<li>${i.label}${i.message ? '：' + i.message : ''}${i.detail ? `<br/><span style="color:var(--c-text-faint)">${i.detail}</span>` : ''}</li>`)
        .join('')
      const head = w.unhealthy.length
        ? `已发布，但有 ${w.unhealthy.length} 个被引用工具当前异常（运行时可能降级）：`
        : `已发布，但有 ${w.count} 项提示：`
      await ElMessageBox.alert(`<div>${head}</div><ul style="margin:8px 0 0;padding-left:18px">${lines}</ul>`, '发布完成（含告警）', {
        dangerouslyUseHTMLString: true,
        confirmButtonText: '知道了',
        type: 'warning'
      })
    } else {
      ElMessage.success('已发布')
    }
  } catch (e) {
    ElMessage.error(e?.message || '发布失败')
  } finally {
    publishing.value = false
  }
}

function backToList() {
  router.push({ name: 'AdminPositions' })
}

/* Esc 不再关闭聚焦窗 / 不收抽屉（规格 §5：误触退聚焦问题）。退聚焦唯一显式入口为「↩ 返回总览」/面包屑跳转。 */

const completionText = computed(() => {
  const c = publishCheck.value
  if (c.blockingPassed) return '✓ 已通过发布检查'
  const remain = c.items.filter((i) => i.blocking && !i.ok).length
  return `还差 ${remain} 项可发布`
})
</script>

<template>
  <div class="wb-shell">
    <!-- 共享后台窄轨（与 AdminLayout 同源，保证一致；工作台路由 meta.activeMenu 高亮「岗位」） -->
    <AdminRail />

    <div class="wb-container">
      <!-- 顶部条 -->
      <header class="topbar">
        <div class="tb-l">
          <span class="tb-back" @click="backToList">← 返回岗位列表</span>
          <span class="tb-name">{{ store.basic?.name || '新岗位' }}</span>
          <StatusTag :type="store.isPublished ? 'success' : 'info'">
            {{ store.isPublished ? '已发布' : '草稿' }}
          </StatusTag>
          <span
            class="ready"
            :class="{ ok: publishCheck.blockingPassed }"
            @click="openPublish"
          >
            <span class="bar"><i :style="{ width: Math.round(publishCheck.doneRatio * 100) + '%' }"></i></span>
            {{ completionText }}
          </span>
        </div>

        <div class="tb-mid">
          <!-- 全局技能搜索 -->
          <div ref="searchRef" class="global-search">
            <el-input
              v-model="searchKeyword"
              placeholder="🔍 搜技能名直达…"
              size="small"
              clearable
              @focus="searchOpen = true"
              @input="onSearchInput"
              @keydown="onSearchKeydown"
            />
            <div v-if="searchOpen && searchResults.length" class="gs-results">
              <div
                v-for="(item, i) in searchResults"
                :key="item.skill.skillId"
                class="gs-item"
                :class="{ active: i === searchActive }"
                @click="pickSearchResult(item)"
                @mousemove="searchActive = i"
              >
                <span class="gs-name">{{ item.skill.name }}</span>
                <span class="gs-agent">{{ item.agentName }}</span>
              </div>
            </div>
            <div v-else-if="searchOpen && searchKeyword.trim()" class="gs-results">
              <div class="gs-empty">没找到匹配的技能</div>
            </div>
          </div>
        </div>

        <div class="tb-r">
          <span class="autosave">{{ autosaveText }}</span>
          <ThemeToggle />
          <el-button @click="onOpenSampleTasks">⏰ 样例任务</el-button>
          <!-- 执行链路未就绪，测试入口统一由 EFFECT_TEST_ENABLED 隐藏（utils/featureFlags.js） -->
          <el-button v-if="EFFECT_TEST_ENABLED" @click="openTest">🧪 效果测试</el-button>
          <el-button v-if="store.isPublished" @click="openVersionHistory">🗂 版本历史</el-button>
          <el-button @click="explicitSave">保存</el-button>
          <el-button type="primary" @click="openPublish">发布</el-button>
        </div>
      </header>

      <!-- 白板主体 -->
      <div class="wb-body" :class="{ 'focus-mode': dtStageOpen || testStageOpen || sampleStageOpen }">
        <!-- 加载 / 错误态：骨架延迟 250ms 才显（showSkeleton），避免快响应时骨架一闪而过的闪屏；
             加载未超阈值时（store.loading 且 !showSkeleton）整块留空（仅点阵底），无闪。 -->
        <div v-if="showSkeleton" class="board-state">
          <el-skeleton :rows="8" animated style="max-width: 900px; margin: 0 auto" />
        </div>
        <div v-else-if="store.error" class="board-state">
          <p>{{ store.error }}</p>
          <el-button @click="store.load(route.params.id)">重试</el-button>
        </div>
        <!-- 加载中但未到骨架阈值：留空（不渲染骨架也不渲染白板内容，避免空内容闪现） -->
        <div v-else-if="store.loading" class="board-state"></div>

        <!-- 白板画布（总览态；数据底座弹窗时仅退背后，决议 7 视觉复用） -->
        <div v-else ref="boardRef" class="board">
          <PositionIdentityCard
            v-if="store.basic"
            v-model:basic="basic"
            :position-id="store.positionId"
            :position-name="store.basic.name"
            :table-count="dtTableCount"
            :table-count-loading="dtCountLoading"
            @open-datatable="onOpenDataTable"
            @open-persona="personaDialogOpen = true"
            @open-intake="intakeDialogOpen = true"
          />

          <div class="stage-head">
            <span class="stage-title">⚙️ 技能舞台</span>
            <span class="stage-sub">每个 Agent 是一组技能 · 点技能卡在新标签编辑</span>
          </div>

          <div class="lanes">
            <AgentLane
              v-for="a in store.agents"
              :key="a.agentId"
              :agent="a"
              @rename="onAgentRename"
              @delete="onAgentDelete"
              @pick-skill="onPickSkill"
              @focus-skill="openSkillFullPage"
              @delete-skill="onDeleteSkill"
              @reorder-skills="onReorderSkills"
              @move-skill="onMoveSkill"
            />

            <!-- 「未绑定 Agent」收纳泳道已退役（删Agent技能脱钩·用户拍板）：白板只呈现「岗位 → Agent → 已挂载技能」，
                 游离技能不在白板任何位置，其查看入口收敛到「技能」管理页的「未被引用」。 -->

            <!-- 新增 Agent 大虚线卡 -->
            <div
              class="lane-new"
              :class="{ disabled: agentAtLimit }"
              @click="addAgent"
            >
              <template v-if="agentAtLimit">已达 {{ LIMITS.AGENT_MAX }} 个 Agent 上限</template>
              <template v-else-if="!store.agents.length">
                ＋ 先建一个 Agent（技能分组），再往里加技能
              </template>
              <template v-else>＋ 新 Agent</template>
            </div>
          </div>
        </div>

        <!-- 效果测试台（复用 .focus-stage 浮层，背后白板 blur 退场） -->
        <div v-if="testStageOpen" class="focus-stage">
          <EffectTestStage
            mode="position"
            :position="{ basic: store.basic, agents: store.agents, tableCount: dtTableCount }"
            :position-id="store.positionId"
            @close="closeTest"
          />
        </div>

        <!-- 数据底座三栏弹窗（复用 .focus-stage 同尺寸同风格） -->
        <div v-if="dtStageOpen" class="focus-stage">
          <PositionDataTableStage
            :position-id="store.positionId"
            :position-name="store.basic?.name || '岗位'"
            :table-count="dtTableCount"
            @close="dtStageOpen = false"
            @update:table-count="dtTableCount = $event"
            @saved="prefetchDtCount"
          />
        </div>

        <!-- 样例任务两栏弹窗（第三个岗位级 .focus-stage，与数据底座并列） -->
        <div v-if="sampleStageOpen" class="focus-stage">
          <PositionSampleTaskStage
            :position-id="store.positionId"
            :position-name="store.basic?.name || '岗位'"
            @close="sampleStageOpen = false"
            @update:sample-count="sampleTaskCount = $event"
          />
        </div>
      </div>
    </div>

    <!-- 从技能库引用已发布 FDE 技能：选中后写引用行到当前 Agent；岗位内已引用的置灰。
         岗位页只引用、不创建——新技能在「FDE 工作台 → 技能」页创建后再来引用。 -->
    <SkillPickerDialog
      v-model="pickSkillVisible"
      :existing-ids="positionSkillIds"
      @pick="onSkillPicked"
    />

    <!-- 人格编辑弹窗（设计 §4 + 反馈 1/3：领用页文案多条 + 岗位人格 Milkdown；图标选择已移至头像 popover） -->
    <PersonaEditDialog
      v-if="store.basic"
      v-model:visible="personaDialogOpen"
      v-model:basic="basic"
      :rq-show-errors="rqShowErrors"
    />

    <!-- 采集编辑弹窗（设计 §4：内嵌 IntakeFieldEditor） -->
    <IntakeEditDialog
      v-if="store.basic"
      v-model:visible="intakeDialogOpen"
      v-model:basic="basic"
      :has-claims="store.isPublished"
      :intake-errors="intakeErrors"
    />

    <!-- 发布前检查 + N5 版本号/升级说明 -->
    <PublishCheckDialog
      v-model:visible="publishDialogVisible"
      v-model:version-label="versionLabel"
      v-model:release-notes="releaseNotes"
      :check="publishCheck"
      :publishing="publishing"
      :prev-max-label="prevMaxLabel"
      :at-max="versionAtMax"
      :next-loading="nextLabelLoading"
      @publish="doPublish"
    />

    <!-- 版本历史（管理侧 §6.6 C/D）：只读版本列表 + 下线/恢复历史版本 -->
    <PositionVersionHistoryDialog
      v-model="versionHistoryVisible"
      :position-id="store.positionId"
      :position-name="store.basic?.name || '岗位'"
    />

  </div>
</template>

<style scoped>
.wb-shell {
  display: flex;
  height: 100vh;
  overflow: hidden;
  background: var(--bg-app);
}
.wb-container {
  flex: 1;
  display: flex;
  flex-direction: column;
  min-width: 0;
}
.topbar {
  flex-shrink: 0;
  height: 56px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: var(--space-4);
  padding: 0 var(--space-5);
  background: var(--bg-app);
  border-bottom: 1px solid var(--border-base);
  z-index: 30;
}
.tb-l {
  display: flex;
  align-items: center;
  gap: var(--space-3);
  min-width: 0;
}
.tb-back {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  cursor: pointer;
  color: var(--c-text-muted);
  padding: 5px 10px;
  border-radius: var(--radius-md);
  font-size: var(--fs-sm);
}
.tb-back:hover {
  background: var(--bg-hover);
  color: var(--c-text);
}
.tb-name {
  font-size: var(--fs-md);
  font-weight: var(--fw-semibold);
  color: var(--c-text-strong);
  max-width: 220px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.ready {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  font-size: var(--fs-xs);
  color: var(--c-warning);
  background: var(--c-warning-soft);
  padding: 3px 10px;
  border-radius: var(--radius-pill);
  cursor: pointer;
}
.ready.ok {
  color: var(--c-success);
  background: var(--c-success-soft);
}
.ready .bar {
  width: 54px;
  height: 5px;
  border-radius: var(--radius-pill);
  background: var(--bg-active);
  overflow: hidden;
}
.ready .bar i {
  display: block;
  height: 100%;
  background: currentColor;
  border-radius: var(--radius-pill);
  transition: width var(--dur-base);
}
.tb-mid {
  flex: 1;
  display: flex;
  justify-content: center;
  min-width: 0;
}
.global-search {
  position: relative;
  width: 280px;
}
.gs-results {
  position: absolute;
  top: 100%;
  left: 0;
  right: 0;
  margin-top: 4px;
  background: var(--bg-elevated);
  border: 1px solid var(--border-base);
  border-radius: var(--radius-md);
  box-shadow: var(--shadow-md);
  z-index: 40;
  max-height: 320px;
  overflow: auto;
  padding: var(--space-1);
}
.gs-item {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 6px 10px;
  border-radius: var(--radius-sm);
  cursor: pointer;
  font-size: var(--fs-sm);
}
.gs-item:hover,
.gs-item.active {
  background: var(--bg-hover);
}
.gs-name {
  color: var(--c-text);
}
.gs-agent {
  font-size: var(--fs-xs);
  color: var(--c-text-faint);
}
.gs-empty {
  padding: var(--space-3);
  font-size: var(--fs-xs);
  color: var(--c-text-faint);
  text-align: center;
}
.tb-r {
  display: flex;
  align-items: center;
  gap: var(--space-2);
}
.autosave {
  font-size: var(--fs-xs);
  color: var(--c-text-faint);
  margin-right: var(--space-1);
  min-width: 92px;
  text-align: right;
}
.wb-body {
  flex: 1;
  display: flex;
  min-height: 0;
  position: relative;
}
.board {
  flex: 1;
  overflow: auto;
  padding: var(--space-5) var(--space-8) var(--space-12);
  background-color: var(--board-bg, var(--bg-sunken));
  background-image: radial-gradient(var(--board-dot, rgba(55, 53, 47, 0.07)) 1px, transparent 1px);
  background-size: 22px 22px;
  transition: filter var(--dur-slow) var(--ease-out), opacity var(--dur-slow) var(--ease-out);
}
/* 聚焦态：白板退背后（决议 7：blur 单层 + contain，不卸载 DOM 保滚动位） */
/* UI1：冻结滚动（overflow hidden）避免长文回流抖动，scrollTop 仍由 DOM 保留，exitFocus 原位回位 */
.wb-body.focus-mode .board {
  filter: blur(4px) saturate(0.7);
  opacity: 0.45;
  pointer-events: none;
  overflow: hidden;
  will-change: filter, opacity;
  contain: layout paint;
}
.board-state {
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: var(--space-3);
  color: var(--c-text-muted);
  padding: var(--space-10);
}
.stage-head {
  display: flex;
  align-items: flex-end;
  gap: var(--space-3);
  margin: var(--space-2) 0 var(--space-4);
}
.stage-title {
  font-size: var(--fs-lg);
  font-weight: var(--fw-bold);
  color: var(--c-text-strong);
  display: flex;
  align-items: center;
  gap: 8px;
}
.stage-sub {
  font-size: var(--fs-xs);
  color: var(--c-text-faint);
  padding-bottom: 2px;
}
.lanes {
  display: flex;
  gap: var(--space-4);
  align-items: flex-start;
  overflow-x: auto;
  padding-bottom: var(--space-4);
}
.lane-new {
  flex: 0 0 240px;
  width: 240px;
  align-self: stretch;
  min-height: 160px;
  border: 1.5px dashed var(--border-strong);
  border-radius: var(--radius-lg);
  background: transparent;
  display: flex;
  align-items: center;
  justify-content: center;
  text-align: center;
  padding: var(--space-4);
  color: var(--c-text-muted);
  cursor: pointer;
  font-size: var(--fs-sm);
  font-weight: var(--fw-medium);
}
.lane-new:hover {
  border-color: var(--c-accent);
  color: var(--c-accent);
  background: var(--c-accent-soft);
}
.lane-new.disabled {
  opacity: 0.5;
  cursor: not-allowed;
}
.lane-new.disabled:hover {
  border-color: var(--border-strong);
  color: var(--c-text-muted);
  background: transparent;
}
.focus-stage {
  position: absolute;
  inset: 0;
  display: flex;
  flex-direction: column;
  z-index: 40;
  padding: var(--space-4) var(--space-6) var(--space-6);
}
</style>
