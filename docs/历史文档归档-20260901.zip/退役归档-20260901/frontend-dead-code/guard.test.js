import { describe, it, expect } from 'vitest'
import { resolveGuard } from '@/router/guard'

// 路由 to 的极简构造：name + meta + matched（含父路由 meta.roles）
function route(name, { meta = {}, matched, fullPath = '/' + name } = {}) {
  return { name, meta, fullPath, matched: matched || [{ meta }] }
}
// /admin* 父路由放宽 roles（进后台壳即可，细分由子路由把关）
const adminRoute = (name) =>
  route(name, {
    matched: [{ meta: { roles: ['ADMIN', 'FDE', 'SYS_CONFIG'] } }, { meta: {} }]
  })
// 细分模块路由：FDE 工作台（岗位/技能）与系统配置（连接器/市场）。
// 按**真实 /admin 树的 matched 顺序**构造：父路由放宽门在 matched[0]
// （['ADMIN','FDE','SYS_CONFIG']，进后台壳即可），子路由细分门在 matched[1]
// （模块收窄）。守卫必须逐层求交，子门才能兜住越权直达（防父层放宽短路）。
const fdeRoute = (name) =>
  route(name, {
    matched: [
      { meta: { roles: ['ADMIN', 'FDE', 'SYS_CONFIG'] } },
      { meta: { roles: ['FDE', 'ADMIN'] } }
    ]
  })
const sysConfigRoute = (name) =>
  route(name, {
    matched: [
      { meta: { roles: ['ADMIN', 'FDE', 'SYS_CONFIG'] } },
      { meta: { roles: ['SYS_CONFIG', 'ADMIN'] } }
    ]
  })
// 仅 ADMIN 的系统配置路由（V39：统一发布审核台 UnifiedReview）：子门收窄到 ['ADMIN']。
const adminOnlyRoute = (name) =>
  route(name, {
    matched: [
      { meta: { roles: ['ADMIN', 'FDE', 'SYS_CONFIG'] } },
      { meta: { roles: ['ADMIN'] } }
    ]
  })

// 用户态以 roles 数组 + 派生计算属性构造（与 store 口径一致；不再用单值 role 判权）
function ctx(
  roles,
  { hasBoundPosition = false, isLoggedIn = true, mustChangePassword = false } = {}
) {
  const has = (r) => roles.includes(r)
  const isAdmin = has('ADMIN')
  const canFde = has('FDE') || isAdmin
  const canSysConfig = has('SYS_CONFIG') || isAdmin
  return {
    isLoggedIn,
    roles,
    isAdmin,
    canFde,
    canSysConfig,
    isBackstage: canFde || canSysConfig,
    role: roles[0] || '',
    hasBoundPosition,
    mustChangePassword
  }
}

const employeeBound = ctx(['EMPLOYEE'], { hasBoundPosition: true })
const employeeUnbound = ctx(['EMPLOYEE'], { hasBoundPosition: false })
const admin = ctx(['ADMIN'])
const fde = ctx(['FDE'])
const sysconfig = ctx(['SYS_CONFIG'])
const both = ctx(['FDE', 'SYS_CONFIG'])
const anon = { ...ctx([], { isLoggedIn: false }) }

describe('公开页 / 未登录', () => {
  it('未登录访问受保护页 → 跳登录并带 redirect', () => {
    const r = resolveGuard(route('Chat'), anon)
    expect(r).toEqual({ name: 'Login', query: { redirect: '/Chat' } })
  })
  it('未登录访问公开登录页 → 放行', () => {
    expect(resolveGuard(route('Login', { meta: { public: true } }), anon)).toBe(true)
  })
  it('已登录访问登录页 → 回首页 Chat', () => {
    expect(
      resolveGuard(route('Login', { meta: { public: true } }), employeeBound)
    ).toEqual({ name: 'Chat' })
  })
})

describe('三路落地分流（登录后默认落点，判定顺序固定）', () => {
  // 路 1：isBackstage（admin / 持 FDE，canFde 真）→ AdminPositions
  it('admin 访问 Chat → 落 FDE 工作台首页 AdminPositions', () => {
    expect(resolveGuard(route('Chat'), admin)).toEqual({ name: 'AdminPositions' })
  })
  it('admin 访问 BindPosition → 落后台（无需绑定）', () => {
    expect(resolveGuard(route('BindPosition'), admin)).toEqual({ name: 'AdminPositions' })
  })
  it('admin 访问 Onboarding → 落后台（无需引导）', () => {
    expect(resolveGuard(route('Onboarding'), admin)).toEqual({ name: 'AdminPositions' })
  })
  it('纯 FDE 访问 Chat → 落 AdminPositions', () => {
    expect(resolveGuard(route('Chat'), fde)).toEqual({ name: 'AdminPositions' })
  })
  it('兼任（FDE+SYS_CONFIG）访问 Chat → 优先落 AdminPositions（路 1 先于路 2）', () => {
    expect(resolveGuard(route('Chat'), both)).toEqual({ name: 'AdminPositions' })
  })
  // 路 2：仅 SYS_CONFIG（不含 FDE）→ AdminConnector
  it('仅 SYS_CONFIG 访问 Chat → 落系统配置首页 AdminConnector', () => {
    expect(resolveGuard(route('Chat'), sysconfig)).toEqual({ name: 'AdminConnector' })
  })
  it('仅 SYS_CONFIG 访问 Onboarding → 落 AdminConnector（不被引去绑定）', () => {
    expect(resolveGuard(route('Onboarding'), sysconfig)).toEqual({ name: 'AdminConnector' })
  })
  // 路 3：EMPLOYEE → 使用端（见下方员工绑定流转用例）

  it('admin 访问后台页本身（角色命中白名单）→ 放行', () => {
    expect(resolveGuard(adminRoute('AdminSkills'), admin)).toBe(true)
  })
  it('admin 未绑定但不受绑定约束 → 不会被推去 BindPosition', () => {
    expect(resolveGuard(adminRoute('AdminPositions'), admin)).toBe(true)
  })
})

describe('细分模块角色门（管理账号访问不属其角色的后台路由 → 跳其有权首页，非白屏）', () => {
  it('纯 FDE 访问 FDE 模块路由（岗位/技能）→ 放行', () => {
    expect(resolveGuard(fdeRoute('AdminSkills'), fde)).toBe(true)
  })
  it('纯 SYS_CONFIG 访问系统配置路由（连接器）→ 放行', () => {
    expect(resolveGuard(sysConfigRoute('AdminConnector'), sysconfig)).toBe(true)
  })
  it('纯 FDE 直达系统配置路由（连接器）URL → 父放宽不短路，被子门挡，landing 跳 AdminPositions（非白屏）', () => {
    // 真实 matched：父放宽 [ADMIN,FDE,SYS_CONFIG] 与 FDE 有交集，但子细分门 [SYS_CONFIG,ADMIN] 与 FDE 无交集 → 拦截
    expect(resolveGuard(sysConfigRoute('AdminConnector'), fde)).toEqual({ name: 'AdminPositions' })
    expect(resolveGuard(sysConfigRoute('SysConfigReports'), fde)).toEqual({ name: 'AdminPositions' })
  })
  it('纯 SYS_CONFIG 直达 FDE 路由（岗位/技能）URL → 父放宽不短路，被子门挡，landing 跳 AdminConnector（非白屏）', () => {
    expect(resolveGuard(fdeRoute('AdminPositions'), sysconfig)).toEqual({ name: 'AdminConnector' })
    expect(resolveGuard(fdeRoute('AdminSkills'), sysconfig)).toEqual({ name: 'AdminConnector' })
  })
  it('admin（超管）两模块路由均放行', () => {
    expect(resolveGuard(fdeRoute('AdminPositions'), admin)).toBe(true)
    expect(resolveGuard(sysConfigRoute('AdminConnector'), admin)).toBe(true)
  })
  it('统一发布审核台（UnifiedReview，仅 ADMIN）：admin 放行，纯 SYS_CONFIG 被子门挡 → landing 跳 AdminConnector（V39）', () => {
    expect(resolveGuard(adminOnlyRoute('UnifiedReview'), admin)).toBe(true)
    // 纯 SYS_CONFIG：父放宽进壳，但子门 ['ADMIN'] 无交集 → 拦截，落其有权首页
    expect(resolveGuard(adminOnlyRoute('UnifiedReview'), sysconfig)).toEqual({ name: 'AdminConnector' })
    // 纯 FDE 同样被挡，落 FDE 首页
    expect(resolveGuard(adminOnlyRoute('UnifiedReview'), fde)).toEqual({ name: 'AdminPositions' })
  })
  it('「技能」页（三页合一）：三类后台角色路由门均放行，真正的门是页面权限', () => {
    // 2026-08-23 三页合一：原三个技能入口下线后若仍钉 ADMIN，FDE / SYS_CONFIG 将完全没有技能入口。
    // 故路由 meta.roles 放开到三类后台角色（只挡非后台角色），
    // 「谁能看/能进」改由页面权限 CAPABILITY_SKILL_CONSOLE 治理（管理员在角色页授予）——
    // 菜单侧断言见 AdminRail.test.js「授予 CAPABILITY_SKILL_CONSOLE 的 FDE 角色也能看到「技能」」。
    const skillsRoute = (name) =>
      route(name, {
        matched: [
          { meta: { roles: ['ADMIN', 'FDE', 'SYS_CONFIG'] } },
          { meta: { roles: ['FDE', 'SYS_CONFIG', 'ADMIN'] } }
        ]
      })
    expect(resolveGuard(skillsRoute('AdminSkillsUnified'), admin)).toBe(true)
    expect(resolveGuard(skillsRoute('AdminSkillsUnified'), sysconfig)).toBe(true)
    expect(resolveGuard(skillsRoute('AdminSkillsUnified'), fde)).toBe(true)
    expect(resolveGuard(skillsRoute('AdminSkillsUnified'), both)).toBe(true)
  })
  // 注：「编辑器路由角色门与列表页一致」的断言需要查**真实路由表**（import @/router 需要 window），
  // 本文件是 node 环境，故独立成 skillRouteRoles.test.js（jsdom）。
  it('兼任账号两模块路由均放行', () => {
    expect(resolveGuard(fdeRoute('AdminPositions'), both)).toBe(true)
    expect(resolveGuard(sysConfigRoute('AdminConnector'), both)).toBe(true)
  })
})

describe('旧响应单 role 兜底（无 roles 字段时由 store 兜底 [role]，分流仍正确）', () => {
  // 模拟 store 兜底后传入 guard 的 ctx：roles=[role]
  it('旧响应单 role=FDE → roles 兜底 [FDE]，访问 Chat 落 AdminPositions', () => {
    expect(resolveGuard(route('Chat'), ctx(['FDE']))).toEqual({ name: 'AdminPositions' })
  })
  it('旧响应单 role=SYS_CONFIG → roles 兜底 [SYS_CONFIG]，访问 Chat 落 AdminConnector', () => {
    expect(resolveGuard(route('Chat'), ctx(['SYS_CONFIG']))).toEqual({ name: 'AdminConnector' })
  })
  it('旧响应单 role=EMPLOYEE（已绑定）→ 使用端放行', () => {
    expect(resolveGuard(route('Settings'), ctx(['EMPLOYEE'], { hasBoundPosition: true }))).toBe(true)
  })
})

describe('员工绑定流转', () => {
  it('已登录未绑定 → 强制进首登引导页 Onboarding', () => {
    expect(resolveGuard(route('Chat'), employeeUnbound)).toEqual({ name: 'Onboarding' })
  })
  it('未绑定访问首登引导页本身 → 放行', () => {
    expect(resolveGuard(route('Onboarding'), employeeUnbound)).toBe(true)
  })
  it('未绑定访问绑定页（兜底保留）→ 放行', () => {
    expect(resolveGuard(route('BindPosition'), employeeUnbound)).toBe(true)
  })
  it('已绑定访问首登引导页 → 回对话页', () => {
    expect(resolveGuard(route('Onboarding'), employeeBound)).toEqual({ name: 'Chat' })
  })
  it('已绑定访问绑定页 → 回对话页', () => {
    expect(resolveGuard(route('BindPosition'), employeeBound)).toEqual({ name: 'Chat' })
  })
  it('已绑定访问普通员工页 → 放行', () => {
    expect(resolveGuard(route('Settings'), employeeBound)).toBe(true)
  })
})

describe('员工访问后台被挡', () => {
  it('普通员工访问 /admin* → 被挡回对话页', () => {
    expect(resolveGuard(adminRoute('AdminPositions'), employeeBound)).toEqual({ name: 'Chat' })
  })
  it('未绑定员工访问 /admin* 也先被角色门挡回对话页（先于绑定判定）', () => {
    expect(resolveGuard(adminRoute('AdminSkills'), employeeUnbound)).toEqual({ name: 'Chat' })
  })
  it('角色门优先级：未绑定员工进 /admin 不会被引去绑定页而是回 Chat', () => {
    const r = resolveGuard(adminRoute('AdminConnector'), employeeUnbound)
    expect(r).toEqual({ name: 'Chat' })
    expect(r).not.toEqual({ name: 'BindPosition' })
  })
})

describe('强制首改密码（mustChangePassword）', () => {
  const adminMustChange = ctx(['ADMIN'], { mustChangePassword: true })
  const employeeMustChange = ctx(['EMPLOYEE'], {
    hasBoundPosition: false,
    mustChangePassword: true
  })
  const loginPage = () => route('Login', { meta: { public: true } })
  const changePwdPage = () => route('ChangePassword')

  it('未改密的后台账号访问任意后台页 → 强跳改密页并带 redirect（优先级高于角色门/落地）', () => {
    const r = resolveGuard(adminRoute('AdminUsers'), adminMustChange)
    expect(r).toEqual({ name: 'ChangePassword', query: { redirect: '/AdminUsers' } })
  })
  it('未改密的未绑定员工访问受保护页 → 强跳改密页（优先级高于绑定引导）', () => {
    const r = resolveGuard(route('Chat'), employeeMustChange)
    expect(r).toEqual({ name: 'ChangePassword', query: { redirect: '/Chat' } })
  })
  it('未改密的已登录用户访问登录页 → 仍强跳改密页（不放行登录页回首页）', () => {
    const r = resolveGuard(loginPage(), adminMustChange)
    expect(r).toEqual({ name: 'ChangePassword', query: { redirect: '/Login' } })
  })
  it('未改密访问改密页本身 → 放行（避免自跳死循环）', () => {
    expect(resolveGuard(changePwdPage(), adminMustChange)).toBe(true)
  })
  it('已改密（标志已清）却仍访问改密页 → 按落地分流回首页', () => {
    // admin 落地 AdminPositions
    expect(resolveGuard(changePwdPage(), admin)).toEqual({ name: 'AdminPositions' })
    // 员工落地 Chat
    expect(resolveGuard(changePwdPage(), employeeBound)).toEqual({ name: 'Chat' })
  })
  it('未登录访问改密页 → 跳登录并带 redirect（未登录不触发强改判定）', () => {
    expect(resolveGuard(changePwdPage(), anon)).toEqual({
      name: 'Login',
      query: { redirect: '/ChangePassword' }
    })
  })
})
