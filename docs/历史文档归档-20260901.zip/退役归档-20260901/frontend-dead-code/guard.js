/**
 * 全局前置守卫的「纯决策函数」（从 router/index.js 抽离，便于单测）。
 *
 * 入参 ctx 为对路由与用户态的最小抽象，避免依赖 router 实例 / vue-router 运行时：
 *   to: { name, fullPath, meta, matched } —— matched 为路由链（含父路由），用于取 meta.roles
 *   user: { isLoggedIn, roles, isAdmin, canFde, canSysConfig, isBackstage, role, hasBoundPosition }
 *         —— 权限判定一律走 roles 数组 + canFde/canSysConfig/isBackstage，不读单值 role（仅显示兜底）。
 *
 * 返回值与 vue-router beforeEach 约定一致：
 *   true            —— 放行
 *   { name, query } —— 重定向目标
 *
 * 注：afterEach 的主题切换等副作用仍留在 index.js，不属于本决策。
 */

/**
 * 登录后默认落点（三路分流，判定顺序固定且短路，设计 §3.3/§4.4）：
 *   1) canFde（admin / 持 FDE）            → AdminPositions（FDE 工作台首页）
 *   2) 否则 canSysConfig（仅 SYS_CONFIG）   → AdminConnector（系统配置首页）
 *   3) 否则（EMPLOYEE）                     → Chat（使用端，绑定流转由后续判定处理）
 * 顺序 1 必须先于 2：admin/兼任账号 canFde 与 canSysConfig 同真，优先落 FDE 工作台。
 */
function landing(user) {
  if (user.canFde) return { name: 'AdminPositions' }
  if (user.canSysConfig) return { name: 'AdminConnector' }
  return { name: 'Chat' }
}

export function resolveGuard(to, user) {
  // 公开页（登录页等）：未登录时放行（登录页需可达）。已登录用户的公开页处理下沉到
  // 「强制首改」判定之后——因为带 mustChangePassword 的已登录用户即便访问登录页也须先改密。
  if (to.meta?.public && !user.isLoggedIn) {
    return true
  }

  // 未登录：去登录页并带 redirect
  if (!user.isLoggedIn) {
    return { name: 'Login', query: { redirect: to.fullPath } }
  }

  // —— 强制首改密码（P5）：优先级最高（先于绑定/落地/角色门/公开页分流）——
  // mustChangePassword 为真时，一切目标（含登录页、后台页）强跳改密页，携带原目标供改密后放行。
  // 改密页本身放行，避免自跳死循环；改密成功后 store 清标志，下次导航即通行（与后端 403 硬拦截配合）。
  if (user.mustChangePassword && to.name !== 'ChangePassword') {
    return { name: 'ChangePassword', query: { redirect: to.fullPath } }
  }
  // 已改密（标志已清）却仍停留/直达改密页 → 按落地分流回其首页，避免卡在改密页
  if (!user.mustChangePassword && to.name === 'ChangePassword') {
    return landing(user)
  }

  // 已登录访问公开页（登录页等）：登录页回首页，其余放行
  if (to.meta?.public) {
    if (to.name === 'Login') {
      return { name: 'Chat' }
    }
    return true
  }

  // 后台角色门：对路由链（matched）上**每一个**带 meta.roles 的节点逐层求交，
  // 任一层与 user.roles 无交集即拦截。这样父路由放宽（进后台壳）与子路由收窄
  // （模块细分门，如连接器 ['SYS_CONFIG','ADMIN']）能正确叠加——父放行进壳、
  // 子门把关模块隔离，避免父层放宽短路掩盖子门（设计 §4.3 模块隔离矩阵）。
  // 交集判定一律走 roles 数组（设计 §4.4），不读单值 role。
  const userRoles = user.roles || []
  const blocked = (to.matched || [])
    .map((r) => r.meta?.roles)
    .filter((roles) => Array.isArray(roles) && roles.length)
    .some((roles) => !roles.some((r) => userRoles.includes(r)))
  if (blocked) {
    // 管理账号访问不属其角色的后台路由 → 跳到其有权的首页（按三路分流落点），其余回 Chat
    return landing(user)
  }

  // 后台可达账号（admin / FDE / SYS_CONFIG）落地后台首页：
  // 访问 Chat / Onboarding / BindPosition 时按三路分流引导到其首页（设计 §3.3/§4.4）
  if (
    user.isBackstage &&
    (to.name === 'Chat' || to.name === 'Onboarding' || to.name === 'BindPosition')
  ) {
    return landing(user)
  }

  // 已登录但未绑定（非后台账号，即纯 EMPLOYEE）→ 强制首登引导页 Onboarding
  // （Onboarding 本身放行；BindPosition 也放行，供未绑定用户走旧绑定页兜底，不互相打架）
  if (
    !user.hasBoundPosition &&
    !user.isBackstage &&
    to.name !== 'Onboarding' &&
    to.name !== 'BindPosition'
  ) {
    return { name: 'Onboarding' }
  }

  // 已绑定却仍访问首登引导页 → 回对话页（Onboarding 仅首登用）
  if (user.hasBoundPosition && to.name === 'Onboarding') {
    return { name: 'Chat' }
  }

  // 已绑定却仍访问首绑页 → 回对话页（BindPosition 首登已被 Onboarding 取代，
  // 路由保留供更换/重新绑定场景；更换流程实际经设置页强确认，不直接放行已绑定进首绑页）
  if (user.hasBoundPosition && to.name === 'BindPosition') {
    return { name: 'Chat' }
  }

  return true
}
