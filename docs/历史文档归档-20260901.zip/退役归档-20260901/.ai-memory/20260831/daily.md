## [13:56] - 验证+打包: 知识库双子页批次全绿后出全量源码包

- **文件**: frontend/src/{views/admin/AdminKnowledgeBase.vue, views/admin/KnowledgeBaseList.vue, views/admin/KnowledgeSourceList.vue, components/admin/KnowledgeSourceEditor.vue, components/admin/KnowledgeSourceDocsDrawer.vue, components/admin/KnowledgeBaseEditor.vue, api/knowledgeBase*.js, utils/knowledgeBaseMeta.js} 等（本日知识库改版全集，详见 docs/update/2026-08-31.md）
- **决策**: 打包走 deploy/pack.sh 唯一入口；后端本轮零改动不重跑全量
- **验证**: 前端 vitest 114 文件 / 1400 例全过 + vite build 通过；pack.sh 四项核验全过（完整性/安全红线全0/可用性/顶层目录）
