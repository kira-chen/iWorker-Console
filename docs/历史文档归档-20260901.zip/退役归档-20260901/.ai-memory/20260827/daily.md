# 2026-08-27 工作日志

## [16:40] - 代码审查/回归完成: 版本全流程回归（六阶段），五项改动通过，1 个外部发布决策点

- **文件**: 无代码改动（验证性）；产出 docs/update/2026-08-27.md（追溯矩阵+证据）
- **决策**: 未登录 code 401 的 HTTP 200 包裹属平台既定约定，不计缺陷；打包待用户明确；appmod `java.version=25` 与 JDK21 工具链冲突升级为 P0 决策点，不擅自回退他人提交
- **验证**: worktree 后端 mvn test 2003/0/0/20；前端 vitest 1374 + build + browser 23；变异验证前后端各 1 翻红；接口实测 18/18；Playwright 15 页零错误
- **陷阱记录**: macOS 系统代理会劫持 Python urllib 对 localhost 的请求（502 空体），curl 不受影响 → 脚本须 `ProxyHandler({})`；appmod 自动化会监听改动用 JDK26 重编 target/（major 69），跑测试前须 `mvn clean` 并显式 `-Djava.version=21`

## [17:05] - 配置变更: Java 目标回退 21（撤销 appmod e33d4ed 升级内容 + 丢弃其未提交依赖钉定）

- **文件**: backend/pom.xml、backend/Dockerfile、CLAUDE.md、README.md、backend/README.md、deploy/README.md、deploy/prod/docker-compose.prod.yml、docs/architecture/管理后台发布指南.md（反向应用，未改历史）
- **决策**: 负责人拍板不升级 25；反向应用而非 git revert，保持"无提交概念"工作流
- **验证**: 原生 JDK21 `mvn -o clean test`（零覆盖参数）+ class major 65 + 后端重启探活

## [22:18] - 发布打包: AI-Assistant-Release-20260827-2218.zip（deploy/pack.sh，四项核验全过）

- **文件**: /Users/calvin/Documents/Coding/AI-Assistant-Release-20260827-2218.zip（1703 文件 / 13MB）
- **验证**: 完整性 1703=1703、安全红线全 0、pom java.version=21 在包内、顶层唯一目录
